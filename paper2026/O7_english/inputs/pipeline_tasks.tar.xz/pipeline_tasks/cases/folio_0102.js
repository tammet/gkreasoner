[
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "man",
   "#:Luke 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "isa",
    "sibling",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "born together with",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "hang out with",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu4"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "isa",
    "sibling",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "born together with",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "play",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu7"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Cu8"
   ],
   [
    "-is rel2",
    "born together",
    "?:X",
    "?:Y",
    "?:Cu8"
   ],
   [
    "isa",
    "multiple birth",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Cu9"
   ],
   [
    "-is rel2",
    "born together",
    "?:X",
    "?:Y",
    "?:Cu9"
   ],
   [
    "is rel2",
    "born in",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu9"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu10"
   ],
   [
    "-is rel2",
    "complain",
    "?:X",
    "?:Y",
    "?:Cu10"
   ],
   [
    "isa",
    "sibling",
    [
     "sk3",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "complain",
    "?:X",
    "?:Y",
    "?:Cu11"
   ],
   [
    "have",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "complain",
    "?:X",
    "?:Y",
    "?:Cu12"
   ],
   [
    "is rel2",
    "born together",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu12"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-is rel2",
    "live",
    "?:X",
    "?:H",
    "?:Cu13"
   ],
   [
    "-isa",
    "stranger",
    "?:Z"
   ],
   [
    "-is rel2",
    "live",
    "?:X",
    "?:Z",
    "?:Cu13"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "hang out with",
    "?:X",
    "?:Y",
    "?:Cu14"
   ],
   [
    "-is rel2",
    "play",
    "?:X",
    "?:Y",
    "?:Cu14"
   ],
   [
    "isa",
    "home",
    [
     "sk4",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "hang out with",
    "?:X",
    "?:Y",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "play",
    "?:X",
    "?:Y",
    "?:Cu15"
   ],
   [
    "is rel2",
    "live",
    "?:X",
    [
     "sk4",
     "?:X"
    ],
    "?:Cu15"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Luke 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "isa",
    "multiple birth",
    "sk5_multiple birth"
   ],
   [
    "-isa",
    "multiple birth",
    "?:Z"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:Z",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "isa",
    "multiple birth",
    "sk5_multiple birth"
   ],
   [
    "-isa",
    "stranger",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Y",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "is rel2",
    "born in",
    "#:Luke 1",
    "sk5_multiple birth",
    "?:Cu19"
   ],
   [
    "-isa",
    "multiple birth",
    "?:Z"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:Z",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "is rel2",
    "born in",
    "#:Luke 1",
    "sk5_multiple birth",
    "?:Cu20"
   ],
   [
    "-isa",
    "stranger",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Y",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "isa",
    "stranger",
    "sk6_stranger"
   ],
   [
    "-isa",
    "multiple birth",
    "?:Z"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:Z",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "isa",
    "stranger",
    "sk6_stranger"
   ],
   [
    "-isa",
    "stranger",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Y",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk6_stranger",
    "?:Cu23"
   ],
   [
    "-isa",
    "multiple birth",
    "?:Z"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:Z",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk6_stranger",
    "?:Cu24"
   ],
   [
    "-isa",
    "stranger",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Y",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:Z"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:Z",
    "?:Cu25"
   ],
   [
    "-isa",
    "stranger",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Y",
    "?:Cu25"
   ],
   [
    "isa",
    "multiple birth",
    "sk7_multiple birth"
   ],
   [
    "isa",
    "stranger",
    "sk6_stranger"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:Z"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:Z",
    "?:Cu26"
   ],
   [
    "-isa",
    "stranger",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Y",
    "?:Cu26"
   ],
   [
    "isa",
    "multiple birth",
    "sk7_multiple birth"
   ],
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk6_stranger",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:Z"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:Z",
    "?:Cu27"
   ],
   [
    "-isa",
    "stranger",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Y",
    "?:Cu27"
   ],
   [
    "is rel2",
    "born in",
    "#:Luke 1",
    "sk7_multiple birth",
    "?:Cu27"
   ],
   [
    "isa",
    "stranger",
    "sk6_stranger"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:Z"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:Z",
    "?:Cu28"
   ],
   [
    "-isa",
    "stranger",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Y",
    "?:Cu28"
   ],
   [
    "is rel2",
    "born in",
    "#:Luke 1",
    "sk7_multiple birth",
    "?:Cu28"
   ],
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk6_stranger",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "sibling",
    "sk9_sibling"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "hang out with",
    "#:Luke 1",
    "sk9_sibling",
    "?:Cu30"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "play",
    "#:Luke 1",
    "sk9_sibling",
    "?:Cu31"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "hang out with",
    "#:Luke 1",
    "?:Y",
    "?:Cu32"
   ],
   [
    "-is rel2",
    "play",
    "#:Luke 1",
    "?:Y",
    "?:Cu32"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "sibling",
   "$some_sibling"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "sibling",
   "$some_not_sibling"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "multiple birth",
   "$some_multiple_birth"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "multiple birth",
   "$some_not_multiple_birth"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "home",
   "$some_home"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "home",
   "$some_not_home"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "stranger",
   "$some_stranger"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "stranger",
   "$some_not_stranger"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "annoying",
   "$some_annoying",
   "?:Cu42"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "annoying",
   "$some_not_annoying",
   "?:Cu43"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:X"
   ],
   [
    "isa",
    "birth",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "multiple",
    "?:X"
   ],
   [
    "-isa",
    "birth",
    "?:X"
   ],
   [
    "isa",
    "multiple birth",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]