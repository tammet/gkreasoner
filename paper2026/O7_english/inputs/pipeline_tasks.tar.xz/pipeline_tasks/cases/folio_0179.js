[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "horse",
    "?:X"
   ],
   [
    "isa",
    "hoof",
    [
     "sk0",
     "?:X"
    ]
   ]
  ],
  "@confidence": 0.9899
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "horse",
    "?:X"
   ],
   [
    "has part",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu2"
   ]
  ],
  "@confidence": 0.9899
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "human",
    "?:X"
   ],
   [
    "-isa",
    "hoof",
    "?:Y"
   ],
   [
    "-has part",
    "?:X",
    "?:Y",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "human",
    "sk1_human"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "horse",
    "sk1_human"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "human",
    "?:X"
   ],
   [
    "-isa",
    "horse",
    "?:X"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_haspart_bridge",
  "@logic": [
   [
    "-isa",
    "hoof",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ],
   [
    "has part",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "horse",
   "$some_horse"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "horse",
   "$some_not_horse"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "hoof",
   "$some_hoof"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "hoof",
   "$some_not_hoof"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "human",
   "$some_human"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "human",
   "$some_not_human"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]