[
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "man",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "make",
    "?:X",
    "wedding plans",
    "?:Cu3"
   ],
   [
    "has property",
    "busy",
    "?:X",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "invite",
    "?:X",
    "person",
    "?:Cu4"
   ],
   [
    "is rel2",
    "make",
    "?:X",
    "wedding plans",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "wedding",
    "?:V"
   ],
   [
    "-has property",
    "well-attended",
    "?:V",
    "?:Cu5"
   ],
   [
    "-have",
    "?:X",
    "?:V",
    "?:Cu5"
   ],
   [
    "is rel2",
    "invite",
    "?:X",
    "person",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "person",
   "sk0_person"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "wedding",
   "sk1_wedding"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "well-attended",
   "sk1_wedding",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "sk0_person",
   "sk1_wedding",
   "?:Cu9"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "family",
   "sk2_family"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "large",
   "sk2_family",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "sk0_person",
   "sk2_family",
   "?:Cu12"
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-has property",
    "busy",
    "#:John 1",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-has property",
    "busy",
    "#:John 1",
    "?:Cu14"
   ],
   [
    "-is rel2",
    "make",
    "#:John 1",
    "wedding plans",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-has property",
    "large",
    "?:F",
    "?:Cu15"
   ],
   [
    "-have",
    "#:John 1",
    "?:F",
    "?:Cu15"
   ],
   [
    "isa",
    "wedding",
    "sk3_wedding"
   ],
   [
    "is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-has property",
    "large",
    "?:F",
    "?:Cu16"
   ],
   [
    "-have",
    "#:John 1",
    "?:F",
    "?:Cu16"
   ],
   [
    "has property",
    "well-attended",
    "sk3_wedding",
    "?:Cu16"
   ],
   [
    "is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-has property",
    "large",
    "?:F",
    "?:Cu17"
   ],
   [
    "-have",
    "#:John 1",
    "?:F",
    "?:Cu17"
   ],
   [
    "have",
    "#:John 1",
    "sk3_wedding",
    "?:Cu17"
   ],
   [
    "is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-has property",
    "large",
    "?:F",
    "?:Cu18"
   ],
   [
    "-have",
    "#:John 1",
    "?:F",
    "?:Cu18"
   ],
   [
    "-isa",
    "wedding",
    "?:V"
   ],
   [
    "-has property",
    "well-attended",
    "?:V",
    "?:Cu18"
   ],
   [
    "-have",
    "#:John 1",
    "?:V",
    "?:Cu18"
   ],
   [
    "-is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "busy",
    "#:John 1",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "busy",
    "#:John 1",
    "?:Cu20"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "wedding",
   "$some_wedding"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "wedding",
   "$some_not_wedding"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "family",
   "$some_family"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "family",
   "$some_not_family"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "busy",
   "$some_not_engaged",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "well-attended",
   "$some_well-attended",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "well-attended",
   "$some_not_well-attended",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "large",
   "$some_large",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "large",
   "$some_not_large",
   "?:Cu32"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]