[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "eat",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-isa",
    "berry",
    "?:Y"
   ],
   [
    "-has property",
    "red",
    "?:Y",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Y",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "has degree property",
    "big",
    "?:X",
    "none",
    "bear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "bear",
     5
    ],
    [
     "$not",
     [
      "has degree property",
      "big",
      "?:X",
      "none",
      "bear",
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has type",
   "sk0_activity",
   "eat",
   [
    "$ctxt",
    "?:Fv8",
    "?:Fv7",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:John 1",
   [
    "$ctxt",
    "?:Fv8",
    "?:Fv7",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "berry",
   "sk1_berry"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has target",
   "sk0_activity",
   "sk1_berry",
   [
    "$ctxt",
    "?:Fv8",
    "?:Fv7",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "typical",
    "sk0_activity",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$block",
    [
     "$",
     "$generic",
     1
    ],
    [
     "$not",
     [
      "typical",
      "sk0_activity",
      [
       "$ctxt",
       "?:Fv8",
       "?:Fv7",
       "?:Fv5",
       "?:Fv6"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "bear",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "big",
    "#:John 1",
    "none",
    "bear",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv11",
     "?:Fv12"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has degree property",
    "big",
    "#:John 1",
    "none",
    "bear",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv11",
     "?:Fv12"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has degree property",
    "big",
    "#:John 1",
    "none",
    "bear",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree property",
    "big",
    "#:John 1",
    "none",
    "bear",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "big",
      "#:John 1",
      "none",
      "bear",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bear",
   "$some_not_bear"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "berry",
   "$some_berry"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "berry",
   "$some_not_berry"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "red",
   "$some_red",
   [
    "$ctxt",
    "?:Fv50",
    "?:Fv47",
    "?:Fv48",
    "?:Fv49"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "red",
   "$some_not_red",
   [
    "$ctxt",
    "?:Fv54",
    "?:Fv51",
    "?:Fv52",
    "?:Fv53"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "big",
   "$some_big_bear",
   "none",
   "bear",
   [
    "$ctxt",
    "?:Fv58",
    "?:Fv55",
    "?:Fv56",
    "?:Fv57"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "bear",
   "$some_big_bear"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "big",
   "$some_not_big_bear",
   "none",
   "bear",
   [
    "$ctxt",
    "?:Fv66",
    "?:Fv63",
    "?:Fv64",
    "?:Fv65"
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "big",
    "?:X",
    "none",
    "?:Fv67",
    [
     "$ctxt",
     "past",
     "?:Fv15",
     "?:Fv16",
     "?:Fv17"
    ]
   ],
   [
    "has degree property",
    "big",
    "?:X",
    "none",
    "?:Fv68",
    [
     "$ctxt",
     "present",
     "?:Fv15",
     "?:Fv16",
     "?:Fv17"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "big",
      "?:X",
      "none",
      "?:Fv69",
      [
       "$ctxt",
       "present",
       "?:Fv15",
       "?:Fv16",
       "?:Fv17"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "big",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv18",
     "?:Fv19",
     "?:Fv20"
    ]
   ],
   [
    "has degree property",
    "big",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv18",
     "?:Fv19",
     "?:Fv20"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "big",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv18",
       "?:Fv19",
       "?:Fv20"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv21",
     "?:Fv22",
     "?:Fv23"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv21",
     "?:Fv22",
     "?:Fv23"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv21",
       "?:Fv22",
       "?:Fv23"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv24",
     "?:Fv25",
     "?:Fv26"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv24",
     "?:Fv25",
     "?:Fv26"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv24",
       "?:Fv25",
       "?:Fv26"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]