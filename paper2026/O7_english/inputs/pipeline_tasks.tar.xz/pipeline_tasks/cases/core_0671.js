[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "woman",
   "#:woman 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "sing",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:woman 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "woman",
   "#:woman 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "lamp",
   "#:lamp 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "activity",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has type",
   "sk1_activity",
   "hold",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has actor",
   "sk1_activity",
   "#:woman 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has target",
   "sk1_activity",
   "#:lamp 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has time",
   "sk1_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "actuality",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "lamp",
   "#:lamp 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "-has degree property",
   "light",
   "#:lamp 2",
   "none",
   "artifact",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "light",
    "#:lamp 2",
    "none",
    "artifact",
    [
     "$ctxt",
     "past",
     "W0",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has degree property",
    "light",
    "#:lamp 2",
    "none",
    "artifact",
    [
     "$ctxt",
     "past",
     "W0",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has degree property",
    "light",
    "#:lamp 2",
    "none",
    "artifact",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree property",
    "light",
    "#:lamp 2",
    "none",
    "artifact",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "light",
      "#:lamp 2",
      "none",
      "artifact",
      [
       "$ctxt",
       "past",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "has degree property",
    "light",
    "?:X",
    "none",
    "?:Fv30",
    [
     "$ctxt",
     "past",
     "?:Fv10",
     "?:Fv11",
     "?:Fv12"
    ]
   ],
   [
    "-has degree property",
    "light",
    "?:X",
    "none",
    "?:Fv31",
    [
     "$ctxt",
     "present",
     "?:Fv10",
     "?:Fv11",
     "?:Fv12"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "heavy",
      "?:X",
      "none",
      "?:Fv32",
      [
       "$ctxt",
       "present",
       "?:Fv10",
       "?:Fv11",
       "?:Fv12"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "has degree property",
    "light",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv13",
     "?:Fv14",
     "?:Fv15"
    ]
   ],
   [
    "-has degree property",
    "light",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv14",
     "?:Fv15"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "heavy",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv13",
       "?:Fv14",
       "?:Fv15"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "light",
    "?:X",
    "none",
    "?:Fv33",
    [
     "$ctxt",
     "past",
     "?:Fv16",
     "?:Fv17",
     "?:Fv18"
    ]
   ],
   [
    "has degree property",
    "light",
    "?:X",
    "none",
    "?:Fv34",
    [
     "$ctxt",
     "present",
     "?:Fv16",
     "?:Fv17",
     "?:Fv18"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "light",
      "?:X",
      "none",
      "?:Fv35",
      [
       "$ctxt",
       "present",
       "?:Fv16",
       "?:Fv17",
       "?:Fv18"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "light",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv19",
     "?:Fv20",
     "?:Fv21"
    ]
   ],
   [
    "has degree property",
    "light",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv19",
     "?:Fv20",
     "?:Fv21"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "light",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv19",
       "?:Fv20",
       "?:Fv21"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]