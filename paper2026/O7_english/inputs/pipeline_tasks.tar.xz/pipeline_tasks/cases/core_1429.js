[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "has type",
    [
     "sk0",
     "?:X"
    ],
    "fly",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "has actor",
    [
     "sk0",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "capability",
    [
     "sk0",
     "?:X"
    ]
   ],
   [
    "$block",
    [
     "$",
     "bird",
     1
    ],
    [
     "$not",
     [
      "capability",
      [
       "sk0",
       "?:X"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "has type",
    [
     "sk1",
     "?:X"
    ],
    "eat",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "has actor",
    [
     "sk1",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "typical",
    [
     "sk1",
     "?:X"
    ],
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$block",
    [
     "$",
     "bird",
     1
    ],
    [
     "$not",
     [
      "typical",
      [
       "sk1",
       "?:X"
      ],
      [
       "$ctxt",
       "?:Fv8",
       "?:Fv7",
       "?:Fv5",
       "?:Fv6"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "baby bird",
    "?:X"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "fly",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-capability",
    "?:E"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "baby bird",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "bird",
   "#:Mike 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "fly",
    [
     "$ctxt",
     "?:Fv24",
     "?:Fv23",
     "?:Fv17",
     "?:Fv18"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:John 1",
    [
     "$ctxt",
     "?:Fv26",
     "?:Fv25",
     "?:Fv17",
     "?:Fv18"
    ]
   ],
   [
    "-capability",
    "?:E"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "activity",
    "sk2_activity"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "has type",
    "sk2_activity",
    "fly",
    [
     "$ctxt",
     "?:Fv30",
     "?:Fv29",
     "?:Fv17",
     "?:Fv18"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "has actor",
    "sk2_activity",
    "#:John 1",
    [
     "$ctxt",
     "?:Fv32",
     "?:Fv31",
     "?:Fv17",
     "?:Fv18"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "capability",
    "sk2_activity"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bird",
   "$some_not_bird"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "baby bird",
   "$some_not_baby_bird"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "baby bird",
    "?:X"
   ],
   [
    "isa",
    "bird",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "baby",
    "?:X"
   ],
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "isa",
    "baby bird",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "fly",
    "?:Fv33"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv33"
   ]
  ],
  "@confidence": 0.52
 }
]