[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "bicycle",
   "#:bicycle 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "bicycle",
   [
    "$theof1",
    "bicycle",
    "#:Tom 1",
    [
     "$ctxt",
     "past",
     "W0",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "have",
   "#:Tom 1",
   [
    "$theof1",
    "bicycle",
    "#:Tom 1",
    [
     "$ctxt",
     "past",
     "W0",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "bicycle",
   [
    "$theof1",
    "bicycle",
    "#:Tom 1",
    [
     "$ctxt",
     "past",
     "W0",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has degree property",
   "new",
   [
    "$theof1",
    "bicycle",
    "#:Tom 1",
    [
     "$ctxt",
     "past",
     "W0",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   "none",
   "artifact",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has degree property",
    "new",
    [
     "$theof1",
     "bicycle",
     "#:Tom 1",
     [
      "$ctxt",
      "past",
      "W0",
      "?:Fv1",
      "?:Fv2"
     ]
    ],
    "none",
    "artifact",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "has degree property",
    "new",
    [
     "$theof1",
     "bicycle",
     "#:Tom 1",
     [
      "$ctxt",
      "past",
      "W0",
      "?:Fv1",
      "?:Fv2"
     ]
    ],
    "none",
    "artifact",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "has degree property",
    "new",
    [
     "$theof1",
     "bicycle",
     "#:Tom 1",
     [
      "$ctxt",
      "past",
      "W0",
      "?:Fv1",
      "?:Fv2"
     ]
    ],
    "none",
    "artifact",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "-has degree property",
    "new",
    [
     "$theof1",
     "bicycle",
     "#:Tom 1",
     [
      "$ctxt",
      "past",
      "W0",
      "?:Fv1",
      "?:Fv2"
     ]
    ],
    "none",
    "artifact",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "old",
      [
       "$theof1",
       "bicycle",
       "#:Tom 1",
       [
        "$ctxt",
        "past",
        "W0",
        "?:Fv1",
        "?:Fv2"
       ]
      ],
      "none",
      "artifact",
      [
       "$ctxt",
       "past",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_theof",
  "@logic": [
   "have",
   "#:Tom 1",
   [
    "$theof1",
    "bicycle",
    "#:Tom 1",
    [
     "$ctxt",
     "past",
     "W0",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "frm_theof",
  "@logic": [
   "is rel2",
   "bicycle of",
   [
    "$theof1",
    "bicycle",
    "?:S",
    "?:C"
   ],
   "?:S",
   "?:C"
  ]
 },
 {
  "@name": "frm_theof",
  "@logic": [
   "isa",
   "bicycle",
   [
    "$theof1",
    "bicycle",
    "?:S",
    "?:C"
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "has degree property",
    "new",
    "?:X",
    "none",
    "?:Fv15",
    [
     "$ctxt",
     "past",
     "?:Fv9",
     "?:Fv10",
     "?:Fv11"
    ]
   ],
   [
    "-has degree property",
    "new",
    "?:X",
    "none",
    "?:Fv16",
    [
     "$ctxt",
     "present",
     "?:Fv9",
     "?:Fv10",
     "?:Fv11"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "old",
      "?:X",
      "none",
      "?:Fv17",
      [
       "$ctxt",
       "present",
       "?:Fv9",
       "?:Fv10",
       "?:Fv11"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "has degree property",
    "new",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv12",
     "?:Fv13",
     "?:Fv14"
    ]
   ],
   [
    "-has degree property",
    "new",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv12",
     "?:Fv13",
     "?:Fv14"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "old",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv12",
       "?:Fv13",
       "?:Fv14"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]