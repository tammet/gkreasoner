[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "mary's school",
   "#:Mary's school 1"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "woman",
   "#:Hannah 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu3"
   ],
   [
    "-is rel2",
    "work",
    "?:X",
    "student jobs",
    "?:Cu3"
   ],
   [
    "is rel2",
    "earn",
    "?:X",
    "money",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu4"
   ],
   [
    "-is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu4"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    "student jobs",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu5"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu5"
   ],
   [
    "isa",
    "dining hall meal",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu6"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu6"
   ],
   [
    "has property",
    "enjoy",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu7"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu7"
   ],
   [
    "isa",
    "recipes",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu8"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu8"
   ],
   [
    "has property",
    "enjoy",
    "?:X",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu9"
   ],
   [
    "-isa",
    "dining hall meal",
    "?:M"
   ],
   [
    "-has property",
    "enjoy",
    "?:X",
    "?:Cu9"
   ],
   [
    "-isa",
    "recipes",
    "?:R"
   ],
   [
    "-has property",
    "picky",
    "?:X",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu10"
   ],
   [
    "-isa",
    "dining hall meal",
    "?:M"
   ],
   [
    "-has property",
    "enjoy",
    "?:X",
    "?:Cu10"
   ],
   [
    "-isa",
    "recipes",
    "?:R"
   ],
   [
    "is rel2",
    "eat",
    "?:X",
    "campus dining halls",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu11"
   ],
   [
    "-isa",
    "dining hall meal",
    "?:M"
   ],
   [
    "-has property",
    "enjoy",
    "?:X",
    "?:Cu11"
   ],
   [
    "-isa",
    "recipes",
    "?:R"
   ],
   [
    "is rel2",
    "catch up",
    "?:X",
    "campus dining halls",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Hannah 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "organization",
   "#:Mary's school 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "at",
   "#:Hannah 2",
   "#:Mary's school 1",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Hannah 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "work",
   "#:Hannah 2",
   "student jobs",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-is rel2",
    "earn",
    "#:Hannah 2",
    "money",
    "?:Cu17"
   ],
   [
    "-has property",
    "picky",
    "#:Hannah 2",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "-is rel2",
   "earn",
   "#:Hannah 2",
   "money",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "earn",
    "#:Hannah 2",
    "money",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "earn",
    "#:Hannah 2",
    "money",
    "?:Cu20"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "dining hall meal",
   "$some_dining_hall_meals"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "dining hall meal",
   "$some_not_dining_hall_meals"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "recipes",
   "$some_recipes"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "recipes",
   "$some_not_recipes"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "enjoy",
   "$some_enjoy",
   "?:Cu26"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "enjoy",
   "$some_not_enjoy",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "picky",
   "$some_picky",
   "?:Cu28"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "dining hall meal",
    "?:X"
   ],
   [
    "isa",
    "meal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "dining hall",
    "?:X"
   ],
   [
    "-isa",
    "meal",
    "?:X"
   ],
   [
    "isa",
    "dining hall meal",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "mary's school",
    "?:X"
   ],
   [
    "isa",
    "school",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "mary'",
    "?:X"
   ],
   [
    "-isa",
    "school",
    "?:X"
   ],
   [
    "isa",
    "mary's school",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]