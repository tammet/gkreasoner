[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "measure",
   "3 meters"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "measure",
   "5 meters"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "red",
   "#:car 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "=",
   [
    "$measure_of",
    "length",
    "#:car 1",
    "W0"
   ],
   [
    "$list",
    3,
    "#:meter"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "car",
   "#:car 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has property",
   "red",
   "#:car 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "car",
   "#:car 3"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has property",
   "black",
   "#:car 3",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "=",
   [
    "$measure_of",
    "length",
    "#:car 3",
    "W0"
   ],
   [
    "$list",
    5,
    "#:meter"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "car",
   "#:car 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "black",
   "#:car 3",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "less_measure",
    [
     "$measure_of",
     "length",
     "#:car 1",
     "W0"
    ],
    [
     "$measure_of",
     "length",
     "#:car 3",
     "W0"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "not",
    [
     "less_measure",
     [
      "$measure_of",
      "length",
      "#:car 1",
      "W0"
     ],
     [
      "$measure_of",
      "length",
      "#:car 3",
      "W0"
     ]
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "length",
    "?:S",
    "?:W"
   ],
   [
    "$ctxt",
    "?:T",
    "?:W",
    "?:L",
    "?:K"
   ]
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "length",
   [
    "$measure_of",
    "length",
    "?:S",
    "?:W"
   ]
  ]
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "black",
    "?:X",
    "?:Fv13"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv13"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "red",
     "?:X",
     "?:Fv13"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "black",
    "?:X",
    "?:Fv14"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv14"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "black",
     "?:X",
     "?:Fv14"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "black",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv15",
     "?:Fv16",
     "?:Fv17"
    ]
   ],
   [
    "has property",
    "black",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv15",
     "?:Fv16",
     "?:Fv17"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "black",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv15",
       "?:Fv16",
       "?:Fv17"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "black",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv18",
     "?:Fv19",
     "?:Fv20"
    ]
   ],
   [
    "has property",
    "black",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv18",
     "?:Fv19",
     "?:Fv20"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "black",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv18",
       "?:Fv19",
       "?:Fv20"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv21",
     "?:Fv22",
     "?:Fv23"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv21",
     "?:Fv22",
     "?:Fv23"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv21",
       "?:Fv22",
       "?:Fv23"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv24",
     "?:Fv25",
     "?:Fv26"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv24",
     "?:Fv25",
     "?:Fv26"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv24",
       "?:Fv25",
       "?:Fv26"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]