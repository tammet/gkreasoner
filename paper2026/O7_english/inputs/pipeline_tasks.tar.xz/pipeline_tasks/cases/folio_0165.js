[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "measure",
   "8 pm"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "abstract",
   "Monday"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "roses",
   "#:roses 2"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "ro",
   "#:roses 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "event",
   "#:The Bachelor 4"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "the bachelor",
   "#:The Bachelor 4"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "breaking bad",
   "#:Breaking Bad 5"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "show",
   "#:show 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "airs at",
   "#:show 1",
   "8 pm",
   "?:Cu9"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "airs on",
   "#:show 1",
   "Monday",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "show",
   "#:show 1"
  ],
  "@confidence": 0.995
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "rose",
   "#:roses 2"
  ],
  "@confidence": 0.995
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "artifact",
   "TV"
  ],
  "@confidence": 0.995
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "give out",
   "#:show 1",
   "#:roses 2",
   "?:Cu14"
  ],
  "@confidence": 0.995
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "give out",
    "?:X",
    "rose",
    "?:Cu15"
   ],
   [
    "is rel2",
    "episode of",
    "?:X",
    "#:The Bachelor 4",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-has property",
    "real",
    "?:X",
    "?:Cu16"
   ],
   [
    "is rel2",
    "portray",
    "#:The Bachelor 4",
    "?:X",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "show",
    "?:X"
   ],
   [
    "-isa",
    "person",
    "?:Y"
   ],
   [
    "-has property",
    "real",
    "?:Y",
    "?:Cu17"
   ],
   [
    "-is rel2",
    "portray",
    "?:X",
    "?:Y",
    "?:Cu17"
   ],
   [
    "isa",
    "reality tv show",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "show",
   "#:Breaking Bad 5"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "-isa",
   "reality tv show",
   "#:Breaking Bad 5"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "give out",
    "#:Breaking Bad 5",
    "rose",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "give out",
    "#:Breaking Bad 5",
    "rose",
    "?:Cu21"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "show",
   "$some_not_show"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "reality tv show",
   "$some_reality_TV_show"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "real",
   "$some_real",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "real",
   "$some_not_real",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_real_person"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "real",
   "$some_real_person",
   "?:Cu30"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "breaking bad",
    "?:X"
   ],
   [
    "isa",
    "bad",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "breaking",
    "?:X"
   ],
   [
    "-isa",
    "bad",
    "?:X"
   ],
   [
    "isa",
    "breaking bad",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "reality tv show",
    "?:X"
   ],
   [
    "isa",
    "show",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "reality tv",
    "?:X"
   ],
   [
    "-isa",
    "show",
    "?:X"
   ],
   [
    "isa",
    "reality tv show",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "the bachelor",
    "?:X"
   ],
   [
    "isa",
    "bachelor",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "the",
    "?:X"
   ],
   [
    "-isa",
    "bachelor",
    "?:X"
   ],
   [
    "isa",
    "the bachelor",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "artifact",
    "?:X"
   ],
   [
    "-isa",
    "event",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "artifact",
    "?:X"
   ],
   [
    "-isa",
    "event",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "bachelor",
    "?:Xg"
   ],
   [
    "isa",
    "man",
    "?:Xg"
   ]
  ]
 }
]