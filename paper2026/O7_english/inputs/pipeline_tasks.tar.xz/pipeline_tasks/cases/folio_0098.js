[
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "organization",
   "#:Harvard Weekly Book Club 1"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "harvard weekly book club",
   "#:Harvard Weekly Book Club 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "business organization",
    "?:X"
   ],
   [
    "isa",
    "legal entity",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "company",
    "?:X"
   ],
   [
    "isa",
    "business organization",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "private company",
    "?:X"
   ],
   [
    "isa",
    "company",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "legal entity",
    "?:X"
   ],
   [
    "is rel2",
    "create",
    "?:X",
    "law",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "legal entity",
    "?:X"
   ],
   [
    "isa",
    "legal obligation",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "legal entity",
    "?:X"
   ],
   [
    "have",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-is rel2",
    "create",
    "#:Harvard Weekly Book Club 1",
    "law",
    "?:Cu9"
   ],
   [
    "-isa",
    "private company",
    "#:Harvard Weekly Book Club 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "private company",
    "#:Harvard Weekly Book Club 1"
   ],
   [
    "isa",
    "legal obligation",
    "sk1_legal obligation"
   ],
   [
    "is rel2",
    "create",
    "#:Harvard Weekly Book Club 1",
    "law",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "private company",
    "#:Harvard Weekly Book Club 1"
   ],
   [
    "have",
    "#:Harvard Weekly Book Club 1",
    "sk1_legal obligation",
    "?:Cu11"
   ],
   [
    "is rel2",
    "create",
    "#:Harvard Weekly Book Club 1",
    "law",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "private company",
    "#:Harvard Weekly Book Club 1"
   ],
   [
    "-isa",
    "legal obligation",
    "?:Y"
   ],
   [
    "-have",
    "#:Harvard Weekly Book Club 1",
    "?:Y",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "create",
    "#:Harvard Weekly Book Club 1",
    "law",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "private company",
    "#:Harvard Weekly Book Club 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "legal obligation",
    "?:Y"
   ],
   [
    "-have",
    "#:Harvard Weekly Book Club 1",
    "?:Y",
    "?:Cu14"
   ],
   [
    "isa",
    "legal obligation",
    "sk2_legal obligation"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "legal obligation",
    "?:Y"
   ],
   [
    "-have",
    "#:Harvard Weekly Book Club 1",
    "?:Y",
    "?:Cu15"
   ],
   [
    "have",
    "#:Harvard Weekly Book Club 1",
    "sk2_legal obligation",
    "?:Cu15"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "legal obligation",
    "?:Y"
   ],
   [
    "-have",
    "#:Harvard Weekly Book Club 1",
    "?:Y",
    "?:Cu16"
   ],
   [
    "is rel2",
    "create",
    "#:Harvard Weekly Book Club 1",
    "law",
    "?:Cu16"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "create",
    "#:Harvard Weekly Book Club 1",
    "law",
    "?:Cu17"
   ],
   [
    "isa",
    "legal obligation",
    "sk2_legal obligation"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "create",
    "#:Harvard Weekly Book Club 1",
    "law",
    "?:Cu18"
   ],
   [
    "have",
    "#:Harvard Weekly Book Club 1",
    "sk2_legal obligation",
    "?:Cu18"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "business organization",
   "$some_business_organization"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "business organization",
   "$some_not_business_organization"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "legal entity",
   "$some_legal_entity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "legal entity",
   "$some_not_legal_entity"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "company",
   "$some_company"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "company",
   "$some_not_company"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "private company",
   "$some_private_company"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "legal obligation",
   "$some_legal_obligation"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "legal obligation",
   "$some_not_legal_obligation"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "business organization",
    "?:X"
   ],
   [
    "isa",
    "organization",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "business",
    "?:X"
   ],
   [
    "-isa",
    "organization",
    "?:X"
   ],
   [
    "isa",
    "business organization",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "harvard weekly book club",
    "?:X"
   ],
   [
    "isa",
    "club",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "harvard weekly book",
    "?:X"
   ],
   [
    "-isa",
    "club",
    "?:X"
   ],
   [
    "isa",
    "harvard weekly book club",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "legal",
    "?:X"
   ],
   [
    "isa",
    "legal entity",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "legal obligation",
    "?:X"
   ],
   [
    "isa",
    "obligation",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "legal",
    "?:X"
   ],
   [
    "-isa",
    "obligation",
    "?:X"
   ],
   [
    "isa",
    "legal obligation",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "private company",
    "?:X"
   ],
   [
    "isa",
    "company",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "private",
    "?:X"
   ],
   [
    "-isa",
    "company",
    "?:X"
   ],
   [
    "isa",
    "private company",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "organization",
    "?:X"
   ],
   [
    "isa",
    "company",
    "?:X"
   ]
  ],
  "@confidence": 0.79
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "company",
    "?:X"
   ],
   [
    "isa",
    "organization",
    "?:X"
   ]
  ],
  "@confidence": 0.79
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]