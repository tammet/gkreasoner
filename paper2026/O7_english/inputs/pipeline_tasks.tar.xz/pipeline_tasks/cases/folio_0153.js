[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "hydrocarbon",
    "?:X"
   ],
   [
    "isa",
    "organic compound",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "alkane",
    "?:X"
   ],
   [
    "isa",
    "hydrocarbon",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "organic compound",
    "?:X"
   ],
   [
    "isa",
    "chemical compound",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "organic compound",
    "?:X"
   ],
   [
    "is rel2",
    "contain",
    "?:X",
    "carbon",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "chemical compound",
    "?:X"
   ],
   [
    "-is rel2",
    "contain",
    "?:X",
    "element",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "chemical compound",
    "#:mixture 1"
   ],
   [
    "-is rel2",
    "contain",
    "#:mixture 1",
    "element",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "contain",
    "#:mixture 1",
    "element",
    "?:Cu8"
   ],
   [
    "-isa",
    "chemical compound",
    "#:mixture 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "contain",
    "#:mixture 1",
    "carbon",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "contain",
    "#:mixture 1",
    "carbon",
    "?:Cu12"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "hydrocarbon",
   "$some_hydrocarbon"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "hydrocarbon",
   "$some_not_hydrocarbon"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "organic compound",
   "$some_organic_compound"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "organic compound",
   "$some_not_organic_compound"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "alkane",
   "$some_alkane"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "alkane",
   "$some_not_alkane"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "chemical compound",
    "?:X"
   ],
   [
    "isa",
    "compound",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "chemical",
    "?:X"
   ],
   [
    "-isa",
    "compound",
    "?:X"
   ],
   [
    "isa",
    "chemical compound",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "organic compound",
    "?:X"
   ],
   [
    "isa",
    "compound",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "organic",
    "?:X"
   ],
   [
    "-isa",
    "compound",
    "?:X"
   ],
   [
    "isa",
    "organic compound",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]