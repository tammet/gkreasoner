[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "symphony no. 9",
   "Symphony No. 9 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "organization",
   "#:Vienna Music Society 3"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "vienna music society",
   "#:Vienna Music Society 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "music piece",
   "Symphony No. 9 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "composer",
    "?:X"
   ],
   [
    "is rel2",
    "write",
    "?:X",
    "music piece",
    "?:Cu5"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "person",
   "#:Beethoven 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "music piece",
   "Symphony No. 9 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "write",
   "#:Beethoven 2",
   "Symphony No. 9 1",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "composer",
   "#:Beethoven 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "organization",
   "https://en.wikipedia.org/wiki/Gesellschaft_der_Musikfreunde"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "music piece",
   "Symphony No. 9 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "premiere",
   "https://en.wikipedia.org/wiki/Gesellschaft_der_Musikfreunde",
   "Symphony No. 9 1",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "next",
   "W1",
   "W2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "orchestra",
   "https://en.wikipedia.org/wiki/Gesellschaft_der_Musikfreunde"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Beethoven 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "organization",
   "https://en.wikipedia.org/wiki/Gesellschaft_der_Musikfreunde"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "lead",
   "#:Beethoven 2",
   "https://en.wikipedia.org/wiki/Gesellschaft_der_Musikfreunde",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "conductor",
   "#:Beethoven 2"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "-isa",
    "conductor",
    "?:X"
   ],
   [
    "is rel2",
    "lead",
    "?:X",
    "orchestra",
    "?:Cu20"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "orchestra",
    "sk0_orchestra"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "premiere",
    "sk0_orchestra",
    "music piece",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "orchestra",
    "?:X"
   ],
   [
    "-is rel2",
    "premiere",
    "?:X",
    "music piece",
    "?:Cu23"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "composer",
   "$some_not_composer"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "conductor",
   "$some_not_conductor"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "music piece",
    "?:X"
   ],
   [
    "isa",
    "piece",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "music",
    "?:X"
   ],
   [
    "-isa",
    "piece",
    "?:X"
   ],
   [
    "isa",
    "music piece",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "symphony no. 9",
    "?:X"
   ],
   [
    "isa",
    "9",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "symphony no.",
    "?:X"
   ],
   [
    "-isa",
    "9",
    "?:X"
   ],
   [
    "isa",
    "symphony no. 9",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "vienna music society",
    "?:X"
   ],
   [
    "isa",
    "society",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "vienna music",
    "?:X"
   ],
   [
    "-isa",
    "society",
    "?:X"
   ],
   [
    "isa",
    "vienna music society",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W1",
   "W2"
  ]
 }
]