[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "event",
   "#:GRE test 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "gre test",
   "#:GRE test 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "measure",
   "$205"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "measure",
   "$300"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "organization",
   "#:ETS 2"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "dad",
   "#:dad 5"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "=",
   [
    "$measure_of",
    "price",
    "https://en.wikipedia.org/wiki/Graduate_Record_Examinations",
    "W0"
   ],
   [
    "$list",
    205,
    "#:dollar"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "cheap",
   "$205",
   "$300",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "gre applicant",
    "?:X"
   ],
   [
    "-isa",
    "economic hardship",
    "?:Z"
   ],
   [
    "-is rel2",
    "prove",
    "?:X",
    "?:Z",
    "?:Cu9"
   ],
   [
    "isa",
    "financial aid",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "gre applicant",
    "?:X"
   ],
   [
    "-isa",
    "economic hardship",
    "?:Z"
   ],
   [
    "-is rel2",
    "prove",
    "?:X",
    "?:Z",
    "?:Cu10"
   ],
   [
    "is rel2",
    "provide",
    "https://en.wikipedia.org/wiki/Educational_Testing_Service",
    "?:X",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "single-parent family",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "?:X",
    "?:Y",
    "?:Cu11"
   ],
   [
    "isa",
    "economic hardship",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "single-parent family",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "?:X",
    "?:Y",
    "?:Cu12"
   ],
   [
    "is rel2",
    "prove",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "resource",
    "?:R"
   ],
   [
    "-have",
    "?:X",
    "?:R",
    "?:Cu13"
   ],
   [
    "isa",
    "economic hardship",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "resource",
    "?:R"
   ],
   [
    "-have",
    "?:X",
    "?:R",
    "?:Cu14"
   ],
   [
    "is rel2",
    "prove",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "single-parent family",
   "#:single-parent family 4"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "live",
   "#:Tom 3",
   "#:single-parent family 4",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:dad 5"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "dad of",
   "#:dad 5",
   "#:Tom 3",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "-has property",
   "work",
   "#:dad 5",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:dad 5"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "dad of",
   "#:dad 5",
   "#:Tom 3",
   "?:Cu24"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Tom 3"
   ],
   [
    "-isa",
    "resource",
    "?:R"
   ],
   [
    "-have",
    "#:Tom 3",
    "?:R",
    "?:Cu25"
   ]
  ],
  "@confidence": 0.4
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "person",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "apply",
   "#:Tom 3",
   "provide",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "person",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "gre applicant",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "less_measure",
    [
     "$measure_of",
     "price",
     "https://en.wikipedia.org/wiki/Graduate_Record_Examinations",
     "W0"
    ],
    [
     "$list",
     300,
     "#:dollar"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "not",
    [
     "less_measure",
     [
      "$measure_of",
      "price",
      "https://en.wikipedia.org/wiki/Graduate_Record_Examinations",
      "W0"
     ],
     [
      "$list",
      300,
      "#:dollar"
     ]
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "have",
   "#:Tom 3",
   "#:dad 5",
   "?:Cu32"
  ]
 },
 {
  "@name": "sent_S11",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "price",
    "?:S",
    "?:W"
   ],
   "?:Cu33"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "price",
   [
    "$measure_of",
    "price",
    "?:S",
    "?:W"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "gre applicant",
   "$some_not_GRE_applicant"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "economic hardship",
   "$some_economic_hardship"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "economic hardship",
   "$some_not_economic_hardship"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "financial aid",
   "$some_financial_aid"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "financial aid",
   "$some_not_financial_aid"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "single-parent family",
   "$some_not_single-parent_family"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "resource",
   "$some_resource"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "resource",
   "$some_not_resource"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "work",
   "$some_work",
   "?:Cu44"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "gre applicant",
    "?:X"
   ],
   [
    "isa",
    "applicant",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "gre",
    "?:X"
   ],
   [
    "-isa",
    "applicant",
    "?:X"
   ],
   [
    "isa",
    "gre applicant",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "economic hardship",
    "?:X"
   ],
   [
    "isa",
    "hardship",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "economic",
    "?:X"
   ],
   [
    "-isa",
    "hardship",
    "?:X"
   ],
   [
    "isa",
    "economic hardship",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "financial aid",
    "?:X"
   ],
   [
    "isa",
    "help",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "financial",
    "?:X"
   ],
   [
    "-isa",
    "help",
    "?:X"
   ],
   [
    "isa",
    "financial aid",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "gre test",
    "?:X"
   ],
   [
    "isa",
    "test",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "gre",
    "?:X"
   ],
   [
    "-isa",
    "test",
    "?:X"
   ],
   [
    "isa",
    "gre test",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "single-parent family",
    "?:X"
   ],
   [
    "isa",
    "family",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "single-parent",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:X"
   ],
   [
    "isa",
    "single-parent family",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "provide",
    "?:Fv31"
   ],
   [
    "has type",
    "?:E",
    "give",
    "?:Fv31"
   ]
  ],
  "@confidence": 0.84
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "resource",
    "?:X"
   ],
   [
    "isa",
    "keep",
    "?:X"
   ]
  ],
  "@confidence": 0.75
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "keep",
    "?:X"
   ],
   [
    "isa",
    "resource",
    "?:X"
   ]
  ],
  "@confidence": 0.75
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "dad",
    "?:Xg"
   ],
   [
    "isa",
    "man",
    "?:Xg"
   ]
  ]
 }
]