[
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "man",
   "#:Luke 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "is rel2",
    "hang out",
    "?:X",
    "?:Y",
    "?:Cu2"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "is rel2",
    "play",
    "?:X",
    "?:Y",
    "?:Cu3"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Cu4"
   ],
   [
    "-is rel2",
    "born together",
    "?:X",
    "?:Y",
    "?:Cu4"
   ],
   [
    "isa",
    "multiple birth",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "born together",
    "?:X",
    "?:Y",
    "?:Cu5"
   ],
   [
    "is rel2",
    "born in",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu5"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu6"
   ],
   [
    "-is rel2",
    "complain",
    "?:X",
    "?:Y",
    "?:Cu6"
   ],
   [
    "isa",
    "sibling",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu7"
   ],
   [
    "-is rel2",
    "complain",
    "?:X",
    "?:Y",
    "?:Cu7"
   ],
   [
    "have",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu8"
   ],
   [
    "-is rel2",
    "complain",
    "?:X",
    "?:Y",
    "?:Cu8"
   ],
   [
    "is rel2",
    "born together",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu8"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-is rel2",
    "live",
    "?:X",
    "?:H",
    "?:Cu9"
   ],
   [
    "-isa",
    "stranger",
    "?:S"
   ],
   [
    "-is rel2",
    "live",
    "?:X",
    "?:S",
    "?:Cu9"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "hang out",
    "?:X",
    "?:Y",
    "?:Cu10"
   ],
   [
    "isa",
    "home",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "hang out",
    "?:X",
    "?:Y",
    "?:Cu11"
   ],
   [
    "is rel2",
    "live",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu11"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "play",
    "?:X",
    "?:Y",
    "?:Cu12"
   ],
   [
    "isa",
    "home",
    [
     "sk3",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "play",
    "?:X",
    "?:Y",
    "?:Cu13"
   ],
   [
    "is rel2",
    "live",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu13"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:Luke 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "isa",
    "multiple birth",
    "sk4_multiple birth"
   ],
   [
    "-isa",
    "multiple birth",
    "?:M"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:M",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "isa",
    "multiple birth",
    "sk4_multiple birth"
   ],
   [
    "-isa",
    "stranger",
    "?:S"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:S",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "is rel2",
    "born in",
    "#:Luke 1",
    "sk4_multiple birth",
    "?:Cu17"
   ],
   [
    "-isa",
    "multiple birth",
    "?:M"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:M",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "is rel2",
    "born in",
    "#:Luke 1",
    "sk4_multiple birth",
    "?:Cu18"
   ],
   [
    "-isa",
    "stranger",
    "?:S"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:S",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "isa",
    "stranger",
    "sk5_stranger"
   ],
   [
    "-isa",
    "multiple birth",
    "?:M"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:M",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "isa",
    "stranger",
    "sk5_stranger"
   ],
   [
    "-isa",
    "stranger",
    "?:S"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:S",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk5_stranger",
    "?:Cu21"
   ],
   [
    "-isa",
    "multiple birth",
    "?:M"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:M",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk5_stranger",
    "?:Cu22"
   ],
   [
    "-isa",
    "stranger",
    "?:S"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:S",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:M"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:M",
    "?:Cu23"
   ],
   [
    "-isa",
    "stranger",
    "?:S"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:S",
    "?:Cu23"
   ],
   [
    "isa",
    "multiple birth",
    "sk6_multiple birth"
   ],
   [
    "isa",
    "stranger",
    "sk5_stranger"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:M"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:M",
    "?:Cu24"
   ],
   [
    "-isa",
    "stranger",
    "?:S"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:S",
    "?:Cu24"
   ],
   [
    "isa",
    "multiple birth",
    "sk6_multiple birth"
   ],
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk5_stranger",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:M"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:M",
    "?:Cu25"
   ],
   [
    "-isa",
    "stranger",
    "?:S"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:S",
    "?:Cu25"
   ],
   [
    "is rel2",
    "born in",
    "#:Luke 1",
    "sk6_multiple birth",
    "?:Cu25"
   ],
   [
    "isa",
    "stranger",
    "sk5_stranger"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:M"
   ],
   [
    "-is rel2",
    "born in",
    "#:Luke 1",
    "?:M",
    "?:Cu26"
   ],
   [
    "-isa",
    "stranger",
    "?:S"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:S",
    "?:Cu26"
   ],
   [
    "is rel2",
    "born in",
    "#:Luke 1",
    "sk6_multiple birth",
    "?:Cu26"
   ],
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk5_stranger",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "sibling",
    "sk8_sibling"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "annoying",
    "sk8_sibling",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "complain",
    "#:Luke 1",
    "sk8_sibling",
    "?:Cu29"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu30"
   ],
   [
    "-is rel2",
    "complain",
    "#:Luke 1",
    "?:Y",
    "?:Cu30"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "sibling",
   "$some_sibling"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "sibling",
   "$some_not_sibling"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "multiple birth",
   "$some_multiple_birth"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "multiple birth",
   "$some_not_multiple_birth"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "home",
   "$some_home"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "home",
   "$some_not_home"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "stranger",
   "$some_stranger"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "stranger",
   "$some_not_stranger"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "annoying",
   "$some_annoying",
   "?:Cu40"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "annoying",
   "$some_not_annoying",
   "?:Cu41"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "multiple birth",
    "?:X"
   ],
   [
    "isa",
    "birth",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "multiple",
    "?:X"
   ],
   [
    "-isa",
    "birth",
    "?:X"
   ],
   [
    "isa",
    "multiple birth",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]