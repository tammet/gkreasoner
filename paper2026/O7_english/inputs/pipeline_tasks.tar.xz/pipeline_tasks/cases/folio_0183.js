[
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "person",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "animal",
    "?:Y"
   ],
   [
    "-is rel2",
    "good",
    "?:X",
    "?:Y",
    "?:Cu2"
   ],
   [
    "-is rel2",
    "mean",
    "?:X",
    "?:Y",
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "sk0_person"
  ],
  "@confidence": 0.995
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has property",
   "grumpy",
   "sk0_person",
   "?:Cu4"
  ],
  "@confidence": 0.995
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "animal",
   "sk1_animal"
  ],
  "@confidence": 0.995
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "mean",
   "sk0_person",
   "sk1_animal",
   "?:Cu6"
  ],
  "@confidence": 0.995
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "animal lover",
    "?:X"
   ],
   [
    "-isa",
    "animal",
    "?:Y"
   ],
   [
    "is rel2",
    "good",
    "?:X",
    "?:Y",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "pet owner",
    "?:X"
   ],
   [
    "-isa",
    "animal",
    "?:Y"
   ],
   [
    "is rel2",
    "love",
    "?:X",
    "?:Y",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "pet owner",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has property",
    "grumpy",
    "#:Tom 1",
    "?:Cu10"
   ],
   [
    "-isa",
    "animal",
    "?:Y"
   ],
   [
    "-is rel2",
    "mean",
    "#:Tom 1",
    "?:Y",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "has property",
    "grumpy",
    "#:Tom 1",
    "?:Cu11"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "animal",
    "sk1_animal"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "mean",
    "#:Tom 1",
    "sk1_animal",
    "?:Cu13"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "animal",
    "sk1_animal"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal lover",
   "$some_animal_lover"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal lover",
   "$some_not_animal_lover"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "pet owner",
   "$some_not_pet_owner"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "grumpy",
   "$some_grumpy",
   "?:Cu24"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "grumpy",
   "$some_not_grumpy",
   "?:Cu25"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "animal lover",
    "?:X"
   ],
   [
    "isa",
    "lover",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-isa",
    "lover",
    "?:X"
   ],
   [
    "isa",
    "animal lover",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "pet owner",
    "?:X"
   ],
   [
    "isa",
    "owner",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "pet",
    "?:X"
   ],
   [
    "-isa",
    "owner",
    "?:X"
   ],
   [
    "isa",
    "pet owner",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]