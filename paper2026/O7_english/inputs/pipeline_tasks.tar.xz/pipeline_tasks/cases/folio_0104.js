[
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "man",
   "#:Luke 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "isa",
    "sibling",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "born with",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "hang out",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu4"
   ]
  ],
  "@confidence": 0.96
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "isa",
    "sibling",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "born with",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "play",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu7"
   ]
  ],
  "@confidence": 0.96
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "isa",
    "sibling",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "born with",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu9"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Cu10"
   ],
   [
    "-is rel2",
    "born together",
    "?:X",
    "?:Y",
    "?:Cu10"
   ],
   [
    "is rel2",
    "born in multiple birth",
    "?:X",
    "?:X",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "complain",
    "?:X",
    "?:Y",
    "?:Cu11"
   ],
   [
    "isa",
    "sibling",
    [
     "sk3",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "complain",
    "?:X",
    "?:Y",
    "?:Cu12"
   ],
   [
    "have",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "complain",
    "?:X",
    "?:Y",
    "?:Cu13"
   ],
   [
    "is rel2",
    "born together",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-is rel2",
    "live",
    "?:X",
    "?:H",
    "?:Cu14"
   ],
   [
    "-isa",
    "stranger",
    "?:Z"
   ],
   [
    "-is rel2",
    "live",
    "?:X",
    "?:Z",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "hang out",
    "?:X",
    "?:Y",
    "?:Cu15"
   ],
   [
    "isa",
    "home",
    [
     "sk4",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "hang out",
    "?:X",
    "?:Y",
    "?:Cu16"
   ],
   [
    "is rel2",
    "live",
    "?:X",
    [
     "sk4",
     "?:X"
    ],
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "play",
    "?:X",
    "?:Y",
    "?:Cu17"
   ],
   [
    "isa",
    "home",
    [
     "sk5",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-is rel2",
    "play",
    "?:X",
    "?:Y",
    "?:Cu18"
   ],
   [
    "is rel2",
    "live",
    "?:X",
    [
     "sk5",
     "?:X"
    ],
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "person",
   "#:Luke 1"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "born in multiple birth",
    "#:Luke 1",
    "#:Luke 1",
    "?:Cu21"
   ],
   [
    "-isa",
    "stranger",
    "?:Z"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Z",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "stranger",
    "sk6_stranger"
   ],
   [
    "-is rel2",
    "born in multiple birth",
    "#:Luke 1",
    "#:Luke 1",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "stranger",
    "sk6_stranger"
   ],
   [
    "-isa",
    "stranger",
    "?:Z"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Z",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk6_stranger",
    "?:Cu24"
   ],
   [
    "-is rel2",
    "born in multiple birth",
    "#:Luke 1",
    "#:Luke 1",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "live",
    "#:Luke 1",
    "sk6_stranger",
    "?:Cu25"
   ],
   [
    "-isa",
    "stranger",
    "?:Z"
   ],
   [
    "-is rel2",
    "live",
    "#:Luke 1",
    "?:Z",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "born in multiple birth",
    "#:Luke 1",
    "#:Luke 1",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "sibling",
    "?:Y"
   ],
   [
    "-has property",
    "annoying",
    "?:Y",
    "?:Cu29"
   ],
   [
    "-is rel2",
    "complain",
    "#:Luke 1",
    "?:Y",
    "?:Cu29"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "born in multiple birth",
    "#:Luke 1",
    "#:Luke 1",
    "?:Cu30"
   ],
   [
    "isa",
    "sibling",
    "sk8_sibling"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "born in multiple birth",
    "#:Luke 1",
    "#:Luke 1",
    "?:Cu31"
   ],
   [
    "has property",
    "annoying",
    "sk8_sibling",
    "?:Cu31"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "born in multiple birth",
    "#:Luke 1",
    "#:Luke 1",
    "?:Cu32"
   ],
   [
    "is rel2",
    "complain",
    "#:Luke 1",
    "sk8_sibling",
    "?:Cu32"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "sibling",
   "$some_sibling"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "sibling",
   "$some_not_sibling"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "home",
   "$some_home"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "home",
   "$some_not_home"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "stranger",
   "$some_stranger"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "stranger",
   "$some_not_stranger"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "annoying",
   "$some_annoying",
   "?:Cu43"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "annoying",
   "$some_not_annoying",
   "?:Cu44"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]