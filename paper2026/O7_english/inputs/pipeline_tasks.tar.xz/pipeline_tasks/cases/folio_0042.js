[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:Zaha Hadid 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "zaha hadid",
   "#:Zaha Hadid 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:Max 2"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "man",
   "#:Max 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "person",
   "#:Kelly Wearstler 3"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "kelly wearstler",
   "#:Kelly Wearstler 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-have",
    "#:Zaha Hadid 1",
    "?:X",
    "?:Cu7"
   ],
   [
    "-is rel2",
    "adore",
    "#:Max 2",
    "?:X",
    "?:Cu7"
   ],
   [
    "has property",
    "interesting",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "adore",
    "#:Max 2",
    "?:X",
    "?:Cu8"
   ],
   [
    "-has property",
    "interesting",
    "?:X",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "adore",
    "#:Max 2",
    "?:X",
    "?:Cu9"
   ],
   [
    "have",
    "#:Zaha Hadid 1",
    "?:X",
    "?:Cu9"
   ],
   [
    "have",
    "#:Kelly Wearstler 3",
    "?:X",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "adore",
    "#:Max 2",
    "?:X",
    "?:Cu10"
   ],
   [
    "-have",
    "#:Zaha Hadid 1",
    "?:X",
    "?:Cu10"
   ],
   [
    "-have",
    "#:Kelly Wearstler 3",
    "?:X",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-have",
    "#:Kelly Wearstler 3",
    "?:X",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "adore",
    "#:Max 2",
    "?:X",
    "?:Cu11"
   ],
   [
    "has property",
    "evocative",
    "?:X",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-have",
    "#:Kelly Wearstler 3",
    "?:X",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "adore",
    "#:Max 2",
    "?:X",
    "?:Cu12"
   ],
   [
    "has property",
    "dreamy",
    "?:X",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-is rel2",
    "by",
    "?:X",
    "#:Max 2",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "adore",
    "#:Max 2",
    "?:X",
    "?:Cu13"
   ],
   [
    "-has property",
    "interesting",
    "?:X",
    "?:Cu13"
   ],
   [
    "isa",
    "brutalist building",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "by",
    "?:X",
    "#:Max 2",
    "?:Cu14"
   ],
   [
    "-is rel2",
    "adore",
    "#:Max 2",
    "?:X",
    "?:Cu14"
   ],
   [
    "-has property",
    "interesting",
    "?:X",
    "?:Cu14"
   ],
   [
    "has property",
    "evocative",
    "?:X",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "design",
    "sk0_design"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "by",
    "sk0_design",
    "#:Max 2",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "evocative",
    "sk0_design",
    "?:Cu17"
   ],
   [
    "has property",
    "dreamy",
    "sk0_design",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has property",
    "evocative",
    "sk0_design",
    "?:Cu18"
   ],
   [
    "-has property",
    "dreamy",
    "sk0_design",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "design",
    "?:X"
   ],
   [
    "-is rel2",
    "by",
    "?:X",
    "#:Max 2",
    "?:Cu20"
   ],
   [
    "-has property",
    "evocative",
    "?:X",
    "?:Cu20"
   ],
   [
    "has property",
    "dreamy",
    "?:X",
    "?:Cu20"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "design",
    "?:X"
   ],
   [
    "-is rel2",
    "by",
    "?:X",
    "#:Max 2",
    "?:Cu21"
   ],
   [
    "-has property",
    "dreamy",
    "?:X",
    "?:Cu21"
   ],
   [
    "has property",
    "evocative",
    "?:X",
    "?:Cu21"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "brutalist building",
   "$some_brutalist_building"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "brutalist building",
   "$some_not_brutalist_building"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "interesting",
   "$some_interesting",
   "?:Cu26"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "interesting",
   "$some_not_interesting",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "evocative",
   "$some_evocative",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "evocative",
   "$some_not_evocative",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "dreamy",
   "$some_dreamy",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "dreamy",
   "$some_not_dreamy",
   "?:Cu31"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "brutalist building",
    "?:X"
   ],
   [
    "isa",
    "building",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "brutalist",
    "?:X"
   ],
   [
    "-isa",
    "building",
    "?:X"
   ],
   [
    "isa",
    "brutalist building",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "kelly wearstler",
    "?:X"
   ],
   [
    "isa",
    "wearstler",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "kelly",
    "?:X"
   ],
   [
    "-isa",
    "wearstler",
    "?:X"
   ],
   [
    "isa",
    "kelly wearstler",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "zaha hadid",
    "?:X"
   ],
   [
    "isa",
    "hadid",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "zaha",
    "?:X"
   ],
   [
    "-isa",
    "hadid",
    "?:X"
   ],
   [
    "isa",
    "zaha hadid",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]