[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "man",
   "#:Peter 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "pet",
    "?:X"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:X",
    "?:Cu2"
   ],
   [
    "-isa",
    "mammal",
    "?:X"
   ],
   [
    "isa",
    "animal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "monkey",
    "?:X"
   ],
   [
    "isa",
    "mammal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "pet",
    "?:X"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:X",
    "?:Cu4"
   ],
   [
    "isa",
    "monkey",
    "?:X"
   ],
   [
    "isa",
    "bird",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "pet",
    "?:X"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:X",
    "?:Cu5"
   ],
   [
    "-isa",
    "monkey",
    "?:X"
   ],
   [
    "-isa",
    "bird",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:X",
    "?:Cu6"
   ],
   [
    "has property",
    "fly",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:X",
    "?:Cu7"
   ],
   [
    "has property",
    "breathe",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "pet",
    "?:X"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:X",
    "?:Cu8"
   ],
   [
    "-has property",
    "fly",
    "?:X",
    "?:Cu8"
   ],
   [
    "isa",
    "wing",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "pet",
    "?:X"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:X",
    "?:Cu9"
   ],
   [
    "-has property",
    "fly",
    "?:X",
    "?:Cu9"
   ],
   [
    "has part",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "animal",
   "#:Rock 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Peter 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "pet",
   "#:Rock 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "have",
   "#:Peter 1",
   "#:Rock 2",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "has property",
    "fly",
    "#:Rock 2",
    "?:Cu14"
   ],
   [
    "isa",
    "bird",
    "#:Rock 2"
   ],
   [
    "-has property",
    "breathe",
    "#:Rock 2",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "monkey",
    "#:Rock 2"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "monkey",
    "#:Rock 2"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "pet",
   "$some_not_pet"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "mammal",
   "$some_mammal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "mammal",
   "$some_not_mammal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "monkey",
   "$some_monkey"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "monkey",
   "$some_not_monkey"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bird",
   "$some_not_bird"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "wing",
   "$some_wing"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "wing",
   "$some_not_wing"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "fly",
   "$some_not_fly",
   "?:Cu26"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "breathe",
   "$some_breathe",
   "?:Cu27"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "fly",
    "?:Fv37"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv37"
   ]
  ],
  "@confidence": 0.52
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "-isa",
    "mammal",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "-isa",
    "mammal",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]