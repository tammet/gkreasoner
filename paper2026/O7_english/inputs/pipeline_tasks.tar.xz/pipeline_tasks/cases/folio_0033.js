[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "mixer",
   "#:mixer 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:mixer 1",
    "?:Cu2"
   ],
   [
    "isa",
    "grand slam champion",
    "?:X"
   ],
   [
    "isa",
    "oscar-nominated actor",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:mixer 1",
    "?:Cu3"
   ],
   [
    "isa",
    "professional tennis player",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:mixer 1",
    "?:Cu4"
   ],
   [
    "isa",
    "celebrity",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:mixer 1",
    "?:Cu5"
   ],
   [
    "isa",
    "athlete",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:mixer 1",
    "?:Cu6"
   ],
   [
    "has property",
    "well paid",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:mixer 1",
    "?:Cu7"
   ],
   [
    "has property",
    "famous",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:mixer 1",
    "?:Cu8"
   ],
   [
    "-has property",
    "well paid",
    "?:X",
    "?:Cu8"
   ],
   [
    "isa",
    "tax haven",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:mixer 1",
    "?:Cu9"
   ],
   [
    "-has property",
    "well paid",
    "?:X",
    "?:Cu9"
   ],
   [
    "is rel2",
    "live",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:Djokovic 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "event",
   "#:mixer 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "at",
   "#:Djokovic 1",
   "#:mixer 1",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "-isa",
    "athlete",
    "#:Djokovic 1"
   ],
   [
    "-has property",
    "famous",
    "#:Djokovic 1",
    "?:Cu13"
   ],
   [
    "has property",
    "well paid",
    "#:Djokovic 1",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "tax haven",
    "?:Y"
   ],
   [
    "-is rel2",
    "live",
    "#:Djokovic 1",
    "?:Y",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "tax haven",
    "sk1_tax haven"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "live",
    "#:Djokovic 1",
    "sk1_tax haven",
    "?:Cu16"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "grand slam champion",
   "$some_Grand_Slam_champion"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "grand slam champion",
   "$some_not_Grand_Slam_champion"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "oscar-nominated actor",
   "$some_Oscar-nominated_actor"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "oscar-nominated actor",
   "$some_not_Oscar-nominated_actor"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "professional tennis player",
   "$some_professional_tennis_player"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "professional tennis player",
   "$some_not_professional_tennis_player"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "celebrity",
   "$some_celebrity"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "celebrity",
   "$some_not_celebrity"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "athlete",
   "$some_not_athlete"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "tax haven",
   "$some_tax_haven"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "tax haven",
   "$some_not_tax_haven"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "well paid",
   "$some_not_well_paid",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "famous",
   "$some_not_famous",
   "?:Cu30"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "grand slam champion",
    "?:X"
   ],
   [
    "isa",
    "champion",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "grand slam",
    "?:X"
   ],
   [
    "-isa",
    "champion",
    "?:X"
   ],
   [
    "isa",
    "grand slam champion",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "oscar-nominated actor",
    "?:X"
   ],
   [
    "isa",
    "actor",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "oscar-nominated",
    "?:X"
   ],
   [
    "-isa",
    "actor",
    "?:X"
   ],
   [
    "isa",
    "oscar-nominated actor",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "professional tennis player",
    "?:X"
   ],
   [
    "isa",
    "player",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "professional tennis",
    "?:X"
   ],
   [
    "-isa",
    "player",
    "?:X"
   ],
   [
    "isa",
    "professional tennis player",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "tax haven",
    "?:X"
   ],
   [
    "isa",
    "haven",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "tax",
    "?:X"
   ],
   [
    "-isa",
    "haven",
    "?:X"
   ],
   [
    "isa",
    "tax haven",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]