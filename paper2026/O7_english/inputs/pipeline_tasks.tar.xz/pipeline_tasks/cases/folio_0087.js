[
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "the surprising adventures of sir digby chicken caesar",
   "#:The Surprising Adventures of Sir Digby Chicken Caesar 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "sir digby",
   "#:Sir Digby 2"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "person",
   "#:nemesis 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "superhero movie",
    "?:X"
   ],
   [
    "-isa",
    "good guy",
    "?:Y"
   ],
   [
    "is rel2",
    "win",
    "?:Y",
    "?:X",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "superhero movie",
   "#:The Surprising Adventures of Sir Digby Chicken Caesar 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "good guy",
    "?:X"
   ],
   [
    "-isa",
    "bad guy",
    "?:Y"
   ],
   [
    "is rel2",
    "fight",
    "?:X",
    "?:Y",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "bad guy",
    "?:X"
   ],
   [
    "-isa",
    "good guy",
    "?:Y"
   ],
   [
    "is rel2",
    "fight",
    "?:X",
    "?:Y",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Sir Digby 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "nemesis",
   "#:nemesis 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "fight",
   "#:Sir Digby 2",
   "#:nemesis 3",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "nemesis",
   "#:nemesis 3"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Sir Digby 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "nemesis of",
   "#:nemesis 3",
   "#:Sir Digby 2",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "superhero movie",
    "?:X"
   ],
   [
    "-is rel2",
    "named after",
    "?:X",
    "?:Y",
    "?:Cu14"
   ],
   [
    "isa",
    "good guy",
    "?:Y"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "artifact",
   "#:The Surprising Adventures of Sir Digby Chicken Caesar 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:Sir Digby 2"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "named after",
   "#:The Surprising Adventures of Sir Digby Chicken Caesar 1",
   "#:Sir Digby 2",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "person",
    "?:Y"
   ],
   [
    "-is rel2",
    "fight",
    "?:X",
    "?:Y",
    "?:Cu18"
   ],
   [
    "-has property",
    "win",
    "?:X",
    "?:Cu18"
   ],
   [
    "-has property",
    "win",
    "?:Y",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   [
    "-isa",
    "superhero movie",
    "?:X"
   ],
   [
    "-is rel2",
    "named after",
    "?:X",
    "?:Y",
    "?:Cu19"
   ],
   [
    "is rel2",
    "in",
    "?:Y",
    "?:X",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has property",
    "win",
    "#:nemesis 3",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "has property",
    "win",
    "#:nemesis 3",
    "?:Cu21"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "have",
   "#:Sir Digby 2",
   "#:nemesis 3",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S11",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "superhero movie",
   "$some_not_superhero_movie"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "good guy",
   "$some_good_guy"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "good guy",
   "$some_not_good_guy"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "bad guy",
   "$some_bad_guy"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bad guy",
   "$some_not_bad_guy"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "win",
   "$some_win",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "win",
   "$some_not_win",
   "?:Cu30"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "bad guy",
    "?:X"
   ],
   [
    "isa",
    "guy",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "isa",
    "good",
    "?:X"
   ],
   [
    "-isa",
    "guy",
    "?:X"
   ],
   [
    "isa",
    "bad guy",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "good guy",
    "?:X"
   ],
   [
    "isa",
    "guy",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "good",
    "?:X"
   ],
   [
    "-isa",
    "guy",
    "?:X"
   ],
   [
    "isa",
    "good guy",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "sir digby",
    "?:X"
   ],
   [
    "isa",
    "digby",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "sir",
    "?:X"
   ],
   [
    "-isa",
    "digby",
    "?:X"
   ],
   [
    "isa",
    "sir digby",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "superhero movie",
    "?:X"
   ],
   [
    "isa",
    "movie",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "superhero",
    "?:X"
   ],
   [
    "-isa",
    "movie",
    "?:X"
   ],
   [
    "isa",
    "superhero movie",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "the surprising adventures of sir digby chicken caesar",
    "?:X"
   ],
   [
    "isa",
    "caesar",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "the surprising adventures of sir digby chicken",
    "?:X"
   ],
   [
    "-isa",
    "caesar",
    "?:X"
   ],
   [
    "isa",
    "the surprising adventures of sir digby chicken caesar",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "guy",
    "?:Xg"
   ],
   [
    "isa",
    "man",
    "?:Xg"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "sir",
    "?:Xg"
   ],
   [
    "isa",
    "man",
    "?:Xg"
   ]
  ]
 }
]