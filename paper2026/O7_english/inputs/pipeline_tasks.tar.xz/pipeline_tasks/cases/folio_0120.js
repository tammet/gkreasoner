[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "barutin cove",
   "#:Barutin Cove 1"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "place",
   "#:Snow Island 3"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "snow island",
   "#:Snow Island 3"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "place",
   "#:South Shetland Islands 5"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "south shetland island",
   "#:South Shetland Islands 5"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "place",
   "#:Greenwich Island 6"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "greenwich island",
   "#:Greenwich Island 6"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "place",
   "#:Deception Island 7"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "deception island",
   "#:Deception Island 7"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "place",
   "#:Antarctica 8"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "cove",
   "#:Barutin Cove 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "named after",
   "#:Barutin Cove 1",
   "#:Barutin 2",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "settlement",
   "#:Barutin 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has property",
   "Bulgarian",
   "#:Barutin 2",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "coast",
   "#:coast 4"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has part",
   "#:Snow Island 3",
   "#:coast 4",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "southwest",
   "#:coast 4",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "on",
   "#:Barutin Cove 1",
   "#:coast 4",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "in",
   "#:Barutin Cove 1",
   "#:Snow Island 3",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "in",
   "#:Snow Island 3",
   "#:South Shetland Islands 5",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "in",
   "#:Greenwich Island 6",
   "#:South Shetland Islands 5",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "in",
   "#:Deception Island 7",
   "#:South Shetland Islands 5",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "in",
   "#:South Shetland Islands 5",
   "#:Antarctica 8",
   "?:Cu23"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "?:Y",
    "?:Cu24"
   ],
   [
    "-is rel2",
    "in",
    "?:Y",
    "?:Z",
    "?:Cu24"
   ],
   [
    "is rel2",
    "in",
    "?:X",
    "?:Z",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "in",
    "#:Barutin Cove 1",
    "#:Antarctica 8",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "in",
    "#:Barutin Cove 1",
    "#:Antarctica 8",
    "?:Cu26"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "barutin cove",
    "?:X"
   ],
   [
    "isa",
    "cove",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "barutin",
    "?:X"
   ],
   [
    "-isa",
    "cove",
    "?:X"
   ],
   [
    "isa",
    "barutin cove",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "deception island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "deception",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "deception island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "greenwich island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "greenwich",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "greenwich island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "snow island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "snow",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "snow island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "south shetland island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "south shetland",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "south shetland island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_in_haspart",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "?:Y",
    "?:C"
   ],
   [
    "has part",
    "?:Y",
    "?:X",
    "?:C"
   ]
  ]
 }
]