[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "book",
   "#:book 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "table",
   "#:table 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "on",
   "#:book 1",
   "#:table 2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:Mary 3"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "book",
   "#:book 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has type",
   "sk0_activity",
   "buy",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:Mary 3",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:book 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has type",
    [
     "sk1",
     "?:X"
    ],
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv10",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has actor",
    [
     "sk1",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv12",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has target",
    [
     "sk1",
     "?:X"
    ],
    "#:book 1",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has time",
    [
     "sk1",
     "?:X"
    ],
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv16",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "actuality",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv20",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv22",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has target",
    "?:E",
    "#:book 1",
    [
     "$ctxt",
     "past",
     "?:Fv24",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0",
   "?:X"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv28",
     "?:Fv29",
     "?:Fv31",
     "?:Fv32"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv28",
     "?:Fv29",
     "?:Fv31",
     "?:Fv32"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv28",
     "?:Fv29",
     "?:Fv31",
     "?:Fv32"
    ]
   ],
   [
    "-next",
    "?:Fv29",
    "?:Fv30"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv30",
     "?:Fv31",
     "?:Fv32"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "?:Owner",
      "?:Obj",
      [
       "$ctxt",
       "present",
       "?:Fv30",
       "?:Fv31",
       "?:Fv32"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv33",
     "?:Fv34",
     "?:Fv36",
     "?:Fv37"
    ]
   ],
   [
    "-has beneficiary",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv33",
     "?:Fv34",
     "?:Fv36",
     "?:Fv37"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv33",
     "?:Fv34",
     "?:Fv36",
     "?:Fv37"
    ]
   ],
   [
    "-next",
    "?:Fv34",
    "?:Fv35"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv35",
     "?:Fv36",
     "?:Fv37"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv38",
     "?:Fv39",
     "?:Fv41",
     "?:Fv42"
    ]
   ],
   [
    "-has recipient",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv38",
     "?:Fv39",
     "?:Fv41",
     "?:Fv42"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv38",
     "?:Fv39",
     "?:Fv41",
     "?:Fv42"
    ]
   ],
   [
    "-next",
    "?:Fv39",
    "?:Fv40"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv40",
     "?:Fv41",
     "?:Fv42"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "book",
   "$some_book"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "table",
   "$some_table"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]