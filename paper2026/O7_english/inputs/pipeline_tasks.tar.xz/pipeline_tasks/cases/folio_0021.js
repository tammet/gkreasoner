[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "campus",
    "?:Cu1"
   ],
   [
    "has property",
    "cute",
    "?:X",
    "?:Cu1"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "turtle",
   "sk0_turtle"
  ],
  "@confidence": 0.9933
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "campus",
   "sk1_campus"
  ],
  "@confidence": 0.9933
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "spot",
   "sk0_turtle",
   "sk1_campus",
   "?:Cu4"
  ],
  "@confidence": 0.9933
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "campus",
    "?:Cu5"
   ],
   [
    "isa",
    "rabbit",
    "?:X"
   ],
   [
    "isa",
    "squirrel",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-has property",
    "skittish",
    "?:X",
    "?:Cu6"
   ],
   [
    "-has property",
    "calm",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "campus",
    "?:Cu7"
   ],
   [
    "has property",
    "skittish",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "animal",
   "#:Rockie 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "campus",
   "#:campus 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "spot",
   "#:Rockie 1",
   "#:campus 2",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "animal",
   "#:Rockie 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "has property",
   "calm",
   "#:Rockie 1",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has property",
    "cute",
    "#:Rockie 1",
    "?:Cu13"
   ],
   [
    "-has property",
    "calm",
    "#:Rockie 1",
    "?:Cu13"
   ],
   [
    "isa",
    "turtle",
    "#:Rockie 1"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has property",
    "cute",
    "#:Rockie 1",
    "?:Cu14"
   ],
   [
    "-has property",
    "calm",
    "#:Rockie 1",
    "?:Cu14"
   ],
   [
    "has property",
    "skittish",
    "#:Rockie 1",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "has property",
    "cute",
    "#:Rockie 1",
    "?:Cu15"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "has property",
    "calm",
    "#:Rockie 1",
    "?:Cu16"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "turtle",
    "#:Rockie 1"
   ],
   [
    "-has property",
    "skittish",
    "#:Rockie 1",
    "?:Cu17"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "turtle",
   "$some_turtle"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "turtle",
   "$some_not_turtle"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "campus",
   "$some_not_campus"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "rabbit",
   "$some_rabbit"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "rabbit",
   "$some_not_rabbit"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "squirrel",
   "$some_squirrel"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "squirrel",
   "$some_not_squirrel"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "cute",
   "$some_cute",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "cute",
   "$some_not_cute",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "skittish",
   "$some_skittish",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "skittish",
   "$some_not_skittish",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "calm",
   "$some_not_calm",
   "?:Cu32"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]