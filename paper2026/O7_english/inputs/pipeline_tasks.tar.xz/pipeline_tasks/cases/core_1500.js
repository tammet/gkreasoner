[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Tallinn 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Latvia 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "-is rel2",
   "in",
   "https://en.wikipedia.org/wiki/Tallinn",
   "https://en.wikipedia.org/wiki/Latvia",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ],
  "@confidence": 0.6
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Tallinn",
    "https://en.wikipedia.org/wiki/Latvia",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Tallinn",
    "https://en.wikipedia.org/wiki/Latvia",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Tallinn",
    "https://en.wikipedia.org/wiki/Latvia",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Tallinn",
    "https://en.wikipedia.org/wiki/Latvia",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "in",
      "https://en.wikipedia.org/wiki/Tallinn",
      "https://en.wikipedia.org/wiki/Latvia",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 }
]