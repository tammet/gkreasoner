[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "bear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "isa",
    "activity",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "bear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "has type",
    [
     "sk0",
     "?:X"
    ],
    "eat",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "bear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "has actor",
    [
     "sk0",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "bear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "isa",
    "fish",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "bear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "has degree property",
    "strong",
    [
     "sk1",
     "?:X"
    ],
    "none",
    "fish",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "bear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "has target",
    [
     "sk0",
     "?:X"
    ],
    [
     "sk1",
     "?:X"
    ],
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "bear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "typical",
    [
     "sk0",
     "?:X"
    ],
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "bear",
     2
    ],
    [
     "$not",
     [
      "typical",
      [
       "sk0",
       "?:X"
      ],
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "bear",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has degree property",
   "good",
   "#:John 1",
   "none",
   "bear",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question_subject",
  "@logic": [
   "isa",
   "bear",
   "skq_S4_bear"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question_subject",
  "@logic": [
   "has degree property",
   "good",
   "skq_S4_bear",
   "none",
   "bear",
   [
    "$ctxt",
    "?:Fv12",
    "?:Fv11",
    "?:Fv9",
    "?:Fv10"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk2_activity",
    "eat",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk2_activity",
    "skq_S4_bear",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "fish",
    "sk3_fish"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "strong",
    "sk3_fish",
    "none",
    "fish",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has target",
    "sk2_activity",
    "sk3_fish",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "typical",
    "sk2_activity",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "eat",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "skq_S4_bear",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-isa",
    "fish",
    "?:Y"
   ],
   [
    "-has degree property",
    "strong",
    "?:Y",
    "none",
    "fish",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Y",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-typical",
    "?:E",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bear",
   "$some_not_bear"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "fish",
   "$some_fish"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "fish",
   "$some_not_fish"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "good",
   "$some_not_nice_bear",
   "none",
   "bear",
   [
    "$ctxt",
    "?:Fv42",
    "?:Fv39",
    "?:Fv40",
    "?:Fv41"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "strong",
   "$some_strong_fish",
   "none",
   "fish",
   [
    "$ctxt",
    "?:Fv46",
    "?:Fv43",
    "?:Fv44",
    "?:Fv45"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "fish",
   "$some_strong_fish"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "strong",
   "$some_not_strong_fish",
   "none",
   "fish",
   [
    "$ctxt",
    "?:Fv54",
    "?:Fv51",
    "?:Fv52",
    "?:Fv53"
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "strong",
    "?:X",
    "none",
    "?:Fv55",
    [
     "$ctxt",
     "past",
     "?:Fv13",
     "?:Fv14",
     "?:Fv15"
    ]
   ],
   [
    "has degree property",
    "strong",
    "?:X",
    "none",
    "?:Fv56",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv14",
     "?:Fv15"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "strong",
      "?:X",
      "none",
      "?:Fv57",
      [
       "$ctxt",
       "present",
       "?:Fv13",
       "?:Fv14",
       "?:Fv15"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "strong",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv16",
     "?:Fv17",
     "?:Fv18"
    ]
   ],
   [
    "has degree property",
    "strong",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv16",
     "?:Fv17",
     "?:Fv18"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "strong",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv16",
       "?:Fv17",
       "?:Fv18"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]