[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "animal",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has property",
    "defeated",
    "?:X",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has degree property",
    "strong",
    "?:X",
    "none",
    "animal",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "animal",
     3
    ],
    [
     "$not",
     [
      "has degree property",
      "weak",
      "?:X",
      "none",
      "animal",
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "animal",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has degree property",
   "good",
   "#:John 1",
   "none",
   "animal",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "animal",
   "#:Mike 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has degree property",
   "good",
   "#:Mike 2",
   "none",
   "animal",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "animal",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "defeated",
   "#:John 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv9",
    "?:Fv10"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has degree property",
    "strong",
    "#:John 1",
    "none",
    "animal",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv11",
     "?:Fv12"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "has degree property",
    "strong",
    "#:John 1",
    "none",
    "animal",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv11",
     "?:Fv12"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "has degree property",
    "strong",
    "#:John 1",
    "none",
    "animal",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "-has degree property",
    "strong",
    "#:John 1",
    "none",
    "animal",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "weak",
      "#:John 1",
      "none",
      "animal",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "good",
   "$some_not_nice_animal",
   "none",
   "animal",
   [
    "$ctxt",
    "?:Fv28",
    "?:Fv25",
    "?:Fv26",
    "?:Fv27"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "defeated",
   "$some_not_defeated_animal",
   [
    "$ctxt",
    "?:Fv32",
    "?:Fv29",
    "?:Fv30",
    "?:Fv31"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "strong",
   "$some_weak_animal",
   "none",
   "animal",
   [
    "$ctxt",
    "?:Fv36",
    "?:Fv33",
    "?:Fv34",
    "?:Fv35"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_weak_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "strong",
   "$some_not_weak_animal",
   "none",
   "animal",
   [
    "$ctxt",
    "?:Fv44",
    "?:Fv41",
    "?:Fv42",
    "?:Fv43"
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "has degree property",
    "strong",
    "?:X",
    "none",
    "?:Fv45",
    [
     "$ctxt",
     "past",
     "?:Fv15",
     "?:Fv16",
     "?:Fv17"
    ]
   ],
   [
    "-has degree property",
    "strong",
    "?:X",
    "none",
    "?:Fv46",
    [
     "$ctxt",
     "present",
     "?:Fv15",
     "?:Fv16",
     "?:Fv17"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "weak",
      "?:X",
      "none",
      "?:Fv47",
      [
       "$ctxt",
       "present",
       "?:Fv15",
       "?:Fv16",
       "?:Fv17"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "has degree property",
    "strong",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv18",
     "?:Fv19",
     "?:Fv20"
    ]
   ],
   [
    "-has degree property",
    "strong",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv18",
     "?:Fv19",
     "?:Fv20"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "weak",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv18",
       "?:Fv19",
       "?:Fv20"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]