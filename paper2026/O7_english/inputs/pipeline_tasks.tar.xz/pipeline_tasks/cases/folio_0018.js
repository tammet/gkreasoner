[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "sk0_campus",
    "?:Cu2"
   ],
   [
    "has property",
    "cute",
    "?:X",
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ],
  "@confidence": 0.9933
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "turtle",
   "sk2_turtle"
  ],
  "@confidence": 0.9933
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "spot",
   "sk2_turtle",
   "sk0_campus",
   "?:Cu5"
  ],
  "@confidence": 0.9933
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "sk0_campus",
    "?:Cu7"
   ],
   [
    "isa",
    "rabbit",
    "?:X"
   ],
   [
    "isa",
    "squirrel",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-has property",
    "skittish",
    "?:X",
    "?:Cu8"
   ],
   [
    "-has property",
    "calm",
    "?:X",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "sk0_campus",
    "?:Cu10"
   ],
   [
    "has property",
    "skittish",
    "?:X",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "animal",
   "#:Rockie 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "spot",
   "#:Rockie 1",
   "sk0_campus",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "animal",
   "#:Rockie 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "has property",
   "calm",
   "#:Rockie 1",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "turtle",
    "#:Rockie 1"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "turtle",
    "#:Rockie 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "campus",
   "$some_campus"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "campus",
   "$some_not_campus"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "turtle",
   "$some_turtle"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "turtle",
   "$some_not_turtle"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "rabbit",
   "$some_rabbit"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "rabbit",
   "$some_not_rabbit"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "squirrel",
   "$some_squirrel"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "squirrel",
   "$some_not_squirrel"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "cute",
   "$some_cute",
   "?:Cu26"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "cute",
   "$some_not_cute",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "skittish",
   "$some_skittish",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "skittish",
   "$some_not_skittish",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "calm",
   "$some_not_calm",
   "?:Cu30"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]