[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "professional basketball player",
   "sk0_professional basketball player"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "-has property",
   "American",
   "sk0_professional basketball player",
   "?:Cu2"
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "professional basketball player",
    "?:X"
   ],
   [
    "-isa",
    "jump shot",
    "?:Y"
   ],
   [
    "is rel2",
    "do",
    "?:X",
    "?:Y",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "do",
    "?:X",
    "jump shot",
    "?:Cu4"
   ],
   [
    "is rel2",
    "spring",
    "?:X",
    "air",
    "?:Cu4"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "spring",
    "?:X",
    "air",
    "?:Cu5"
   ],
   [
    "isa",
    "leg muscle",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "spring",
    "?:X",
    "air",
    "?:Cu6"
   ],
   [
    "has part",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "spring",
    "?:X",
    "air",
    "?:Cu7"
   ],
   [
    "is rel2",
    "activate",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu7"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Yuri 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "leg muscle",
    "?:Y"
   ],
   [
    "-has part",
    "#:Yuri 1",
    "?:Y",
    "?:Cu9"
   ],
   [
    "-is rel2",
    "activate",
    "#:Yuri 1",
    "?:Y",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "person",
    "#:Yuri 1"
   ],
   [
    "has property",
    "American",
    "#:Yuri 1",
    "?:Cu10"
   ],
   [
    "isa",
    "professional basketball player",
    "#:Yuri 1"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "person",
    "#:Yuri 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "American",
    "#:Yuri 1",
    "?:Cu12"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "professional basketball player",
    "#:Yuri 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_haspart_bridge",
  "@logic": [
   [
    "-isa",
    "leg muscle",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ],
   [
    "has part",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "professional basketball player",
   "$some_professional_basketball_player"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "professional basketball player",
   "$some_not_professional_basketball_player"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "jump shot",
   "$some_jump_shot"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "jump shot",
   "$some_not_jump_shot"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "leg muscle",
   "$some_leg_muscle"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "leg muscle",
   "$some_not_leg_muscle"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "American",
   "$some_American",
   "?:Cu23"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "American",
   "$some_not_American",
   "?:Cu24"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "jump shot",
    "?:X"
   ],
   [
    "isa",
    "shot",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "jump",
    "?:X"
   ],
   [
    "-isa",
    "shot",
    "?:X"
   ],
   [
    "isa",
    "jump shot",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "leg muscle",
    "?:X"
   ],
   [
    "isa",
    "muscle",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "leg",
    "?:X"
   ],
   [
    "-isa",
    "muscle",
    "?:X"
   ],
   [
    "isa",
    "leg muscle",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "professional basketball player",
    "?:X"
   ],
   [
    "isa",
    "player",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "professional basketball",
    "?:X"
   ],
   [
    "-isa",
    "player",
    "?:X"
   ],
   [
    "isa",
    "professional basketball player",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]