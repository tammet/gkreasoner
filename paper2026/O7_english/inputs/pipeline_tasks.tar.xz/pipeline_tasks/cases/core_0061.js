[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "red",
   "#:car 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "bike",
   "#:bike 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has degree property",
   "small",
   "#:bike 2",
   "none",
   "bike",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "red",
    "#:bike 2",
    [
     "$ctxt",
     "present",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "red",
    "#:bike 2",
    [
     "$ctxt",
     "present",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has property",
    "red",
    "#:bike 2",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has property",
    "red",
    "#:bike 2",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "#:bike 2",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has degree property",
    "small",
    "?:X",
    "none",
    "?:Fv23",
    "?:Fv9"
   ],
   [
    "-has degree property",
    "high",
    "?:X",
    "none",
    "?:Fv24",
    "?:Fv9"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "has degree property",
    "high",
    "?:X",
    "none",
    "?:Fv25",
    "?:Fv10"
   ],
   [
    "has degree property",
    "small",
    "?:X",
    "none",
    "?:Fv26",
    "?:Fv10"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv11",
       "?:Fv12",
       "?:Fv13"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv14",
       "?:Fv15",
       "?:Fv16"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "small",
    "?:X",
    "none",
    "?:Fv27",
    [
     "$ctxt",
     "past",
     "?:Fv17",
     "?:Fv18",
     "?:Fv19"
    ]
   ],
   [
    "has degree property",
    "small",
    "?:X",
    "none",
    "?:Fv28",
    [
     "$ctxt",
     "present",
     "?:Fv17",
     "?:Fv18",
     "?:Fv19"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "small",
      "?:X",
      "none",
      "?:Fv29",
      [
       "$ctxt",
       "present",
       "?:Fv17",
       "?:Fv18",
       "?:Fv19"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "small",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv20",
     "?:Fv21",
     "?:Fv22"
    ]
   ],
   [
    "has degree property",
    "small",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv20",
     "?:Fv21",
     "?:Fv22"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "small",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv20",
       "?:Fv21",
       "?:Fv22"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]