[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "-has property",
    "deadly",
    "?:X",
    "?:Cu1"
   ],
   [
    "isa",
    "survival rate",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "-has property",
    "deadly",
    "?:X",
    "?:Cu2"
   ],
   [
    "-has property",
    "high",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "-has property",
    "deadly",
    "?:X",
    "?:Cu3"
   ],
   [
    "is rel2",
    "comes with",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "severe cancer",
    "?:X"
   ],
   [
    "-has property",
    "deep",
    "?:X",
    "?:Cu4"
   ],
   [
    "isa",
    "deadly disease",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "severe cancer",
    "?:X"
   ],
   [
    "-has property",
    "deep",
    "?:X",
    "?:Cu5"
   ],
   [
    "has property",
    "deadly",
    "?:X",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bile duct cancer",
    "?:X"
   ],
   [
    "isa",
    "severe cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bile duct cancer",
    "?:X"
   ],
   [
    "has property",
    "deep",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "https://en.wikipedia.org/wiki/cholangiocarcinoma",
    "?:X"
   ],
   [
    "isa",
    "bile duct cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "mild flu",
    "?:X"
   ],
   [
    "-has property",
    "mild",
    "?:X",
    "?:Cu9"
   ],
   [
    "isa",
    "survival rate",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "mild flu",
    "?:X"
   ],
   [
    "-has property",
    "mild",
    "?:X",
    "?:Cu10"
   ],
   [
    "-has property",
    "high",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "mild flu",
    "?:X"
   ],
   [
    "-has property",
    "mild",
    "?:X",
    "?:Cu11"
   ],
   [
    "is rel2",
    "comes with",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "colorectal cancer",
    "?:X"
   ],
   [
    "-isa",
    "bile duct cancer",
    "?:X"
   ],
   [
    "-isa",
    "survival rate",
    "?:Y"
   ],
   [
    "has property",
    "high",
    "?:Y",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "comes with",
    "?:X",
    "?:Y",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "colorectal cancer",
    "?:X"
   ],
   [
    "isa",
    "severe cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "colorectal cancer",
    "?:X"
   ],
   [
    "has property",
    "deep",
    "?:X",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "colorectal cancer",
    "sk2_colorectal cancer"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "severe cancer",
    "sk2_colorectal cancer"
   ],
   [
    "-has property",
    "deep",
    "sk2_colorectal cancer",
    "?:Cu16"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "deadly disease",
   "$some_deadly_disease"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "deadly disease",
   "$some_not_deadly_disease"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "survival rate",
   "$some_survival_rate"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "survival rate",
   "$some_not_survival_rate"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "severe cancer",
   "$some_severe_cancer"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "severe cancer",
   "$some_not_severe_cancer"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "bile duct cancer",
   "$some_bile_duct_cancer"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bile duct cancer",
   "$some_not_bile_duct_cancer"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "https://en.wikipedia.org/wiki/cholangiocarcinoma",
   "$some_https://en.wikipedia.org/wiki/Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "https://en.wikipedia.org/wiki/cholangiocarcinoma",
   "$some_not_https://en.wikipedia.org/wiki/Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "mild flu",
   "$some_mild_flu"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "mild flu",
   "$some_not_mild_flu"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "colorectal cancer",
   "$some_colorectal_cancer"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "colorectal cancer",
   "$some_not_colorectal_cancer"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "deadly",
   "$some_deadly",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "deadly",
   "$some_not_deadly",
   "?:Cu32"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "high",
   "$some_low",
   "?:Cu33"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "high",
   "$some_not_low",
   "?:Cu34"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "deep",
   "$some_severe",
   "?:Cu35"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "deep",
   "$some_not_severe",
   "?:Cu36"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "mild",
   "$some_mild",
   "?:Cu37"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "mild",
   "$some_not_mild",
   "?:Cu38"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "deadly disease",
   "$some_deadly_deadly_disease"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "deadly",
   "$some_deadly_deadly_disease",
   "?:Cu40"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "severe cancer",
   "$some_severe_severe_cancer"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "deep",
   "$some_severe_severe_cancer",
   "?:Cu42"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "mild flu",
   "$some_mild_mild_flu"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "mild",
   "$some_mild_mild_flu",
   "?:Cu44"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "bile duct cancer",
    "?:X"
   ],
   [
    "isa",
    "cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "bile duct",
    "?:X"
   ],
   [
    "-isa",
    "cancer",
    "?:X"
   ],
   [
    "isa",
    "bile duct cancer",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "colorectal cancer",
    "?:X"
   ],
   [
    "isa",
    "cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "colorectal",
    "?:X"
   ],
   [
    "-isa",
    "cancer",
    "?:X"
   ],
   [
    "isa",
    "colorectal cancer",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "isa",
    "disease",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "deadly",
    "?:X"
   ],
   [
    "-isa",
    "disease",
    "?:X"
   ],
   [
    "isa",
    "deadly disease",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "mild flu",
    "?:X"
   ],
   [
    "isa",
    "flu",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "mild",
    "?:X"
   ],
   [
    "-isa",
    "flu",
    "?:X"
   ],
   [
    "isa",
    "mild flu",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "severe cancer",
    "?:X"
   ],
   [
    "isa",
    "cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "deep",
    "?:X"
   ],
   [
    "-isa",
    "cancer",
    "?:X"
   ],
   [
    "isa",
    "severe cancer",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "survival rate",
    "?:X"
   ],
   [
    "isa",
    "rate",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "survival",
    "?:X"
   ],
   [
    "-isa",
    "rate",
    "?:X"
   ],
   [
    "isa",
    "survival rate",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]