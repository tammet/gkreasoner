[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:Ellen 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "fond of",
   "#:Ellen 1",
   "#:John 2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "is rel2",
   "afraid of",
   "#:Ellen 1",
   "?:X",
   [
    "$ctxt",
    "present",
    "?:Fv5",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "afraid of",
    "#:Ellen 1",
    "?:Br1",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "afraid of",
    "#:Ellen 1",
    "?:Br1",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "afraid of",
      "#:Ellen 1",
      "?:Br1",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 }
]