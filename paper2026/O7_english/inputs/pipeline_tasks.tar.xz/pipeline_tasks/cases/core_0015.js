[
 {
  "@name": "sent_S1",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "man",
    "#:John 1"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "tall",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "present",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has degree property",
    "tall",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "present",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "man",
    "#:John 1"
   ],
   [
    "-has degree property",
    "tall",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "present",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "has degree property",
    "tall",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "present",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has degree property",
    "tall",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree property",
    "tall",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "tall",
      "#:John 1",
      "none",
      "person",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has degree property",
    "tall",
    "?:X",
    "none",
    "?:Fv17",
    "?:Fv9"
   ],
   [
    "has degree property",
    "high",
    "?:X",
    "none",
    "?:Fv18",
    "?:Fv9"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has degree property",
    "high",
    "?:X",
    "none",
    "?:Fv19",
    "?:Fv10"
   ],
   [
    "has degree property",
    "tall",
    "?:X",
    "none",
    "?:Fv20",
    "?:Fv10"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "tall",
    "?:X",
    "none",
    "?:Fv21",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "has degree property",
    "tall",
    "?:X",
    "none",
    "?:Fv22",
    [
     "$ctxt",
     "present",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "tall",
      "?:X",
      "none",
      "?:Fv23",
      [
       "$ctxt",
       "present",
       "?:Fv11",
       "?:Fv12",
       "?:Fv13"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "tall",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "has degree property",
    "tall",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "tall",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv14",
       "?:Fv15",
       "?:Fv16"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]