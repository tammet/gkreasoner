[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "isa",
    "trunk",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "has part",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "has degree property",
    "long",
    [
     "sk0",
     "?:X"
    ],
    "none",
    "trunk",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "has property",
    "grey",
    [
     "sk0",
     "?:X"
    ],
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "elephant",
     1
    ],
    [
     "$not",
     [
      "has property",
      "grey",
      [
       "sk0",
       "?:X"
      ],
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "elephant",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "isa",
    "trunk",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has property",
    "grey",
    [
     "sk1",
     "?:X"
    ],
    [
     "$ctxt",
     "?:Fv14",
     "?:Fv13",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has part",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    [
     "$ctxt",
     "present",
     "?:Fv15",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "trunk",
    "?:Y"
   ],
   [
    "-has property",
    "grey",
    "?:Y",
    [
     "$ctxt",
     "?:Fv19",
     "?:Fv18",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-has part",
    "?:X",
    "?:Y",
    [
     "$ctxt",
     "present",
     "?:Fv20",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_haspart_bridge",
  "@logic": [
   [
    "-isa",
    "trunk",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ],
   [
    "has part",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0",
   "?:X"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has part",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has part",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has part",
      "?:Br1",
      "?:Br2",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "elephant",
   "$some_not_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "trunk",
   "$some_trunk"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "trunk",
   "$some_not_trunk"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "long",
   "$some_long_trunk",
   "none",
   "trunk",
   [
    "$ctxt",
    "?:Fv48",
    "?:Fv45",
    "?:Fv46",
    "?:Fv47"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "trunk",
   "$some_long_trunk"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "long",
   "$some_not_long_trunk",
   "none",
   "trunk",
   [
    "$ctxt",
    "?:Fv56",
    "?:Fv53",
    "?:Fv54",
    "?:Fv55"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "grey",
   "$some_grey_trunk",
   [
    "$ctxt",
    "?:Fv60",
    "?:Fv57",
    "?:Fv58",
    "?:Fv59"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "trunk",
   "$some_grey_trunk"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "grey",
   "$some_not_grey_trunk",
   [
    "$ctxt",
    "?:Fv68",
    "?:Fv65",
    "?:Fv66",
    "?:Fv67"
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "grey",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv21",
     "?:Fv22",
     "?:Fv23"
    ]
   ],
   [
    "has property",
    "grey",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv21",
     "?:Fv22",
     "?:Fv23"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "grey",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv21",
       "?:Fv22",
       "?:Fv23"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "grey",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv24",
     "?:Fv25",
     "?:Fv26"
    ]
   ],
   [
    "has property",
    "grey",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv24",
     "?:Fv25",
     "?:Fv26"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "grey",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv24",
       "?:Fv25",
       "?:Fv26"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "long",
    "?:X",
    "none",
    "?:Fv69",
    [
     "$ctxt",
     "past",
     "?:Fv27",
     "?:Fv28",
     "?:Fv29"
    ]
   ],
   [
    "has degree property",
    "long",
    "?:X",
    "none",
    "?:Fv70",
    [
     "$ctxt",
     "present",
     "?:Fv27",
     "?:Fv28",
     "?:Fv29"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "long",
      "?:X",
      "none",
      "?:Fv71",
      [
       "$ctxt",
       "present",
       "?:Fv27",
       "?:Fv28",
       "?:Fv29"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "long",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv30",
     "?:Fv31",
     "?:Fv32"
    ]
   ],
   [
    "has degree property",
    "long",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv30",
     "?:Fv31",
     "?:Fv32"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "long",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv30",
       "?:Fv31",
       "?:Fv32"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "elephant",
   "$some_elephant"
  ]
 }
]