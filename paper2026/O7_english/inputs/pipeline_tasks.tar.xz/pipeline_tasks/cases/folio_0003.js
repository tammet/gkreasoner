[
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "organization",
   "this club"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu2"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu2"
   ],
   [
    "is rel2",
    "attend",
    "?:X",
    "school event",
    "?:Cu2"
   ]
  ],
  "@confidence": 0.96
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu3"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu3"
   ],
   [
    "is rel2",
    "engaged with",
    "?:X",
    "school events",
    "?:Cu3"
   ]
  ],
  "@confidence": 0.96
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu4"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu4"
   ],
   [
    "isa",
    "community member",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu5"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu5"
   ],
   [
    "has property",
    "inactive",
    "?:X",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu6"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu6"
   ],
   [
    "has property",
    "disinterested",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu7"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu7"
   ],
   [
    "-isa",
    "community member",
    "?:X"
   ],
   [
    "-has property",
    "inactive",
    "?:X",
    "?:Cu7"
   ],
   [
    "-has property",
    "disinterested",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu8"
   ],
   [
    "-is rel2",
    "chaperone",
    "?:X",
    "high school dance",
    "?:Cu8"
   ],
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-is rel2",
    "attend",
    "?:X",
    "school",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu9"
   ],
   [
    "-has property",
    "inactive",
    "?:X",
    "?:Cu9"
   ],
   [
    "-has property",
    "disinterested",
    "?:X",
    "?:Cu9"
   ],
   [
    "is rel2",
    "chaperone",
    "?:X",
    "high school dance",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-has property",
    "young",
    "?:X",
    "?:Cu10"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu10"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu10"
   ],
   [
    "isa",
    "student",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-has property",
    "young",
    "?:X",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu11"
   ],
   [
    "is rel2",
    "attend",
    "?:X",
    "school",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu12"
   ],
   [
    "isa",
    "student",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu13"
   ],
   [
    "is rel2",
    "attend",
    "?:X",
    "school",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:Bonnie 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "in",
   "#:Bonnie 1",
   "this club",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu17"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 1"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "engaged with",
    "#:Bonnie 1",
    "school events",
    "?:Cu19"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 1"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "student",
    "#:Bonnie 1"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu20"
   ],
   [
    "-is rel2",
    "engaged with",
    "#:Bonnie 1",
    "school events",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu22"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu22"
   ],
   [
    "-is rel2",
    "engaged with",
    "#:Bonnie 1",
    "school events",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu34"
   ],
   [
    "isa",
    "child",
    "#:Bonnie 1"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 1"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu35"
   ],
   [
    "has property",
    "young",
    "#:Bonnie 1",
    "?:Cu35"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 1"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu36"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 1",
    "further",
    "?:Cu36"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu37"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 1"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu38"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 1",
    "?:Cu38"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu39"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 1",
    "?:Cu39"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu40"
   ],
   [
    "is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu40"
   ],
   [
    "isa",
    "child",
    "#:Bonnie 1"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 1"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu41"
   ],
   [
    "is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu41"
   ],
   [
    "has property",
    "young",
    "#:Bonnie 1",
    "?:Cu41"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 1"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu42"
   ],
   [
    "is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu42"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 1",
    "further",
    "?:Cu42"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu43"
   ],
   [
    "is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu43"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 1"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu44"
   ],
   [
    "is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu44"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 1",
    "?:Cu44"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu45"
   ],
   [
    "is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu45"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 1",
    "?:Cu45"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu46"
   ],
   [
    "-is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu46"
   ],
   [
    "isa",
    "child",
    "#:Bonnie 1"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 1"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu47"
   ],
   [
    "-is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu47"
   ],
   [
    "has property",
    "young",
    "#:Bonnie 1",
    "?:Cu47"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 1"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu48"
   ],
   [
    "-is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu48"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 1",
    "further",
    "?:Cu48"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu49"
   ],
   [
    "-is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu49"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 1"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu50"
   ],
   [
    "-is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu50"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 1",
    "?:Cu50"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu51"
   ],
   [
    "-is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu51"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 1",
    "?:Cu51"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 1",
    "high school dance",
    "?:Cu65"
   ],
   [
    "is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu65"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "child",
    "#:Bonnie 1"
   ],
   [
    "-has property",
    "young",
    "#:Bonnie 1",
    "?:Cu67"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 1",
    "further",
    "?:Cu67"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 1"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 1",
    "?:Cu67"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 1",
    "?:Cu67"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "teenager",
    "#:Bonnie 1"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 1",
    "further",
    "?:Cu68"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 1"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 1",
    "?:Cu68"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 1",
    "?:Cu68"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "community member",
   "$some_community_member"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "inactive",
   "$some_inactive",
   "?:Cu76"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "inactive",
   "$some_not_inactive",
   "?:Cu77"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "disinterested",
   "$some_disinterested",
   "?:Cu78"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "disinterested",
   "$some_not_disinterested",
   "?:Cu79"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "young",
   "$some_young",
   "?:Cu80"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "young",
   "$some_not_young",
   "?:Cu81"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "community member",
    "?:X"
   ],
   [
    "isa",
    "member",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "community",
    "?:X"
   ],
   [
    "-isa",
    "member",
    "?:X"
   ],
   [
    "isa",
    "community member",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]