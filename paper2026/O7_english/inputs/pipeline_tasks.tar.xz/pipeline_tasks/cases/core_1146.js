[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "chef",
   "#:chef 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "guest",
   "#:guests 3"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "guest",
   "#:guests 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:chef 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "meal",
   "#:meal 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:guests 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "cook",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:chef 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:meal 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has beneficiary",
   "sk0_activity",
   "#:guests 3",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has type",
    [
     "sk1",
     "?:X"
    ],
    "cook",
    [
     "$ctxt",
     "past",
     "?:Fv8",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has target",
    [
     "sk1",
     "?:X"
    ],
    "#:meal 2",
    [
     "$ctxt",
     "past",
     "?:Fv10",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has beneficiary",
    [
     "sk1",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv12",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "actuality",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "cook",
    [
     "$ctxt",
     "past",
     "?:Fv16",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has target",
    "?:E",
    "#:meal 2",
    [
     "$ctxt",
     "past",
     "?:Fv18",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has beneficiary",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv20",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0",
   "?:X"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "chef",
    "?:X"
   ],
   [
    "isa",
    "cook",
    "?:X"
   ]
  ],
  "@confidence": 0.86
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "cook",
    "?:X"
   ],
   [
    "isa",
    "chef",
    "?:X"
   ]
  ],
  "@confidence": 0.86
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "chef",
   "$some_chef"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "meal",
   "$some_meal"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "guest",
   "$some_guests"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "guest",
   "$some_guest"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]