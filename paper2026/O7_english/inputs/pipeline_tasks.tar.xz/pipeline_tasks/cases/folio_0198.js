[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:Jane 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "woman",
   "#:Jane 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-has property",
    "bark",
    "?:X",
    "?:Cu3"
   ],
   [
    "-has property",
    "like",
    "#:Jane 1",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "dog",
    "?:X"
   ],
   [
    "isa",
    "animal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "dog",
    "?:X"
   ],
   [
    "has property",
    "bark",
    "?:X",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-has property",
    "jump",
    "?:X",
    "?:Cu6"
   ],
   [
    "has property",
    "like",
    "#:Jane 1",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-isa",
    "leg",
    "?:Y"
   ],
   [
    "-has part",
    "?:X",
    "?:Y",
    "?:Cu7"
   ],
   [
    "has property",
    "jump",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-has property",
    "terricolous",
    "?:X",
    "?:Cu8"
   ],
   [
    "isa",
    "leg",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-has property",
    "terricolous",
    "?:X",
    "?:Cu9"
   ],
   [
    "has part",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "animal",
   "#:KiKi 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "has property",
    "jump",
    "#:KiKi 1",
    "?:Cu11"
   ],
   [
    "isa",
    "leg",
    "sk1_leg"
   ],
   [
    "has property",
    "terricolous",
    "#:KiKi 1",
    "?:Cu11"
   ],
   [
    "isa",
    "leg",
    "sk2_leg"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "has property",
    "jump",
    "#:KiKi 1",
    "?:Cu12"
   ],
   [
    "isa",
    "leg",
    "sk1_leg"
   ],
   [
    "has property",
    "terricolous",
    "#:KiKi 1",
    "?:Cu12"
   ],
   [
    "has part",
    "#:KiKi 1",
    "sk2_leg",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "has property",
    "jump",
    "#:KiKi 1",
    "?:Cu13"
   ],
   [
    "has part",
    "#:KiKi 1",
    "sk1_leg",
    "?:Cu13"
   ],
   [
    "has property",
    "terricolous",
    "#:KiKi 1",
    "?:Cu13"
   ],
   [
    "isa",
    "leg",
    "sk2_leg"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "has property",
    "jump",
    "#:KiKi 1",
    "?:Cu14"
   ],
   [
    "has part",
    "#:KiKi 1",
    "sk1_leg",
    "?:Cu14"
   ],
   [
    "has property",
    "terricolous",
    "#:KiKi 1",
    "?:Cu14"
   ],
   [
    "has part",
    "#:KiKi 1",
    "sk2_leg",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has property",
    "bark",
    "#:KiKi 1",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "dog",
    "#:KiKi 1"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "has property",
    "bark",
    "#:KiKi 1",
    "?:Cu17"
   ],
   [
    "isa",
    "dog",
    "#:KiKi 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_haspart_bridge",
  "@logic": [
   [
    "-isa",
    "leg",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ],
   [
    "has part",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "dog",
   "$some_dog"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "dog",
   "$some_not_dog"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "leg",
   "$some_leg"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "leg",
   "$some_not_leg"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "bark",
   "$some_bark",
   "?:Cu25"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "bark",
   "$some_not_bark",
   "?:Cu26"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "jump",
   "$some_jump",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "terricolous",
   "$some_not_terricolous",
   "?:Cu28"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "dog",
    "?:Xg"
   ],
   [
    "isa",
    "man",
    "?:Xg"
   ]
  ]
 }
]