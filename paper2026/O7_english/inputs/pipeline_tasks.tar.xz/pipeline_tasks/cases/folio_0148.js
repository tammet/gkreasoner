[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:United States 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "united states",
   "#:United States 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "event",
   "2024 United States presidential election 2"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "2024 united states presidential election",
   "2024 United States presidential election 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "register",
    "?:X",
    "#:United States 1",
    "?:Cu5"
   ],
   [
    "is rel2",
    "participate",
    "?:X",
    "2024 United States presidential election 2",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-have",
    "?:X",
    "United States citizenship",
    "?:Cu6"
   ],
   [
    "is rel2",
    "register",
    "?:X",
    "#:United States 1",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "have",
    "?:X",
    "United States citizenship",
    "?:Cu7"
   ],
   [
    "have",
    "?:X",
    "Taiwanese citizenship",
    "?:Cu7"
   ]
  ],
  "@confidence": 0.9899
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-have",
    "?:X",
    "United States citizenship",
    "?:Cu8"
   ],
   [
    "-have",
    "?:X",
    "Taiwanese citizenship",
    "?:Cu8"
   ]
  ],
  "@confidence": 0.9899
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "russian federation official",
    "?:X"
   ],
   [
    "-have",
    "?:X",
    "Taiwanese citizenship",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Vladimir 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "-have",
   "#:Vladimir 3",
   "Taiwanese citizenship",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Vladimir 3"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "-isa",
   "russian federation official",
   "#:Vladimir 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Ekaterina 4"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "is rel2",
    "register",
    "#:Ekaterina 4",
    "#:United States 1",
    "?:Cu15"
   ],
   [
    "isa",
    "russian federation official",
    "#:Ekaterina 4"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "participate",
    "#:Ekaterina 4",
    "2024 United States presidential election 2",
    "?:Cu16"
   ],
   [
    "isa",
    "russian federation official",
    "#:Vladimir 3"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "participate",
    "#:Ekaterina 4",
    "2024 United States presidential election 2",
    "?:Cu17"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "russian federation official",
    "#:Vladimir 3"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "2024 united states presidential election",
    "?:X"
   ],
   [
    "isa",
    "election",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "2024 united states presidential",
    "?:X"
   ],
   [
    "-isa",
    "election",
    "?:X"
   ],
   [
    "isa",
    "2024 united states presidential election",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "russian federation official",
    "?:X"
   ],
   [
    "isa",
    "official",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "russian federation",
    "?:X"
   ],
   [
    "-isa",
    "official",
    "?:X"
   ],
   [
    "isa",
    "russian federation official",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "united states",
    "?:X"
   ],
   [
    "isa",
    "states",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "united",
    "?:X"
   ],
   [
    "-isa",
    "states",
    "?:X"
   ],
   [
    "isa",
    "united states",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]