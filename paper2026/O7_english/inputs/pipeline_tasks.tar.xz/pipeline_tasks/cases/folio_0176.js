[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "summer olympic games",
   "#:summer Olympic games 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "summer olympic game",
   "#:summer Olympic games 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "summer olympic games",
   "#:summer Olympic games 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "place",
   "#:Tokyo 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "organization",
   "#:United States 3"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "united states",
   "#:United States 3"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "event",
   "#:world championships 4"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "world championship",
   "#:world championships 4"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "world championship",
   "#:world championships 4"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "sporting event",
   "#:summer Olympic games 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "in",
   "#:summer Olympic games 1",
   "#:Tokyo 2",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "win",
   "#:United States 3",
   "medal",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "sporting event",
    "https://en.wikipedia.org/wiki/World_championship"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "sporting event",
    "https://en.wikipedia.org/wiki/World_championship"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "sporting event",
    "?:X"
   ],
   [
    "isa",
    "event",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "sporting",
    "?:X"
   ],
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "isa",
    "sporting event",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "summer olympic game",
    "?:X"
   ],
   [
    "isa",
    "game",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "summer olympic",
    "?:X"
   ],
   [
    "-isa",
    "game",
    "?:X"
   ],
   [
    "isa",
    "summer olympic game",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "summer olympic games",
    "?:X"
   ],
   [
    "isa",
    "games",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "summer olympic",
    "?:X"
   ],
   [
    "-isa",
    "games",
    "?:X"
   ],
   [
    "isa",
    "summer olympic games",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "summer olympic games",
    "?:X"
   ],
   [
    "isa",
    "games",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "summer olympic",
    "?:X"
   ],
   [
    "-isa",
    "games",
    "?:X"
   ],
   [
    "isa",
    "summer olympic games",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "united states",
    "?:X"
   ],
   [
    "isa",
    "states",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "united",
    "?:X"
   ],
   [
    "-isa",
    "states",
    "?:X"
   ],
   [
    "isa",
    "united states",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "world championship",
    "?:X"
   ],
   [
    "isa",
    "championship",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "world",
    "?:X"
   ],
   [
    "-isa",
    "championship",
    "?:X"
   ],
   [
    "isa",
    "world championship",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "world championship",
    "?:X"
   ],
   [
    "isa",
    "championship",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "world",
    "?:X"
   ],
   [
    "-isa",
    "championship",
    "?:X"
   ],
   [
    "isa",
    "world championship",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]