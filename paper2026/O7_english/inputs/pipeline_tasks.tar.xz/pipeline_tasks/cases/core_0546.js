[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "has degree property",
    "big",
    "?:X",
    "none",
    "bear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "bear",
     1
    ],
    [
     "$not",
     [
      "has degree property",
      "big",
      "?:X",
      "none",
      "bear",
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.6
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "bear",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "big",
    "#:John 1",
    "none",
    "bear",
    [
     "$ctxt",
     "present",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has degree property",
    "big",
    "#:John 1",
    "none",
    "bear",
    [
     "$ctxt",
     "present",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has degree property",
    "big",
    "#:John 1",
    "none",
    "bear",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree property",
    "big",
    "#:John 1",
    "none",
    "bear",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "big",
      "#:John 1",
      "none",
      "bear",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bear",
   "$some_not_bear"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "big",
   "$some_big_bear",
   "none",
   "bear",
   [
    "$ctxt",
    "?:Fv24",
    "?:Fv21",
    "?:Fv22",
    "?:Fv23"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "bear",
   "$some_big_bear"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "big",
   "$some_not_big_bear",
   "none",
   "bear",
   [
    "$ctxt",
    "?:Fv32",
    "?:Fv29",
    "?:Fv30",
    "?:Fv31"
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "big",
    "?:X",
    "none",
    "?:Fv33",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "has degree property",
    "big",
    "?:X",
    "none",
    "?:Fv34",
    [
     "$ctxt",
     "present",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "big",
      "?:X",
      "none",
      "?:Fv35",
      [
       "$ctxt",
       "present",
       "?:Fv11",
       "?:Fv12",
       "?:Fv13"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "big",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "has degree property",
    "big",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "big",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv14",
       "?:Fv15",
       "?:Fv16"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]