[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:London 2"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "place",
   "#:Paris 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Mary 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "place",
   "https://en.wikipedia.org/wiki/London"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "visit",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:Mary 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "https://en.wikipedia.org/wiki/London",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "September",
   "in",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv3"
   ],
   [
    "$datetime",
    "September"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is_past_world",
   "W0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk1_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk1_activity",
    "visit",
    [
     "$ctxt",
     "past",
     "?:Fv9",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk1_activity",
    "#:Mary 1",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has target",
    "sk1_activity",
    "https://en.wikipedia.org/wiki/Paris",
    [
     "$ctxt",
     "past",
     "?:Fv13",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has time",
    "sk1_activity",
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv15",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "actuality",
    "sk1_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "visit",
    [
     "$ctxt",
     "past",
     "?:Fv19",
     "?:Fv4",
     "?:Fv5"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:Mary 1",
    [
     "$ctxt",
     "past",
     "?:Fv21",
     "?:Fv4",
     "?:Fv5"
    ]
   ],
   [
    "-has target",
    "?:E",
    "https://en.wikipedia.org/wiki/Paris",
    [
     "$ctxt",
     "past",
     "?:Fv23",
     "?:Fv4",
     "?:Fv5"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]