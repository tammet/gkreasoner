[
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "animal",
   "#:cat 3"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "animal",
   "#:cat 3"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "olive garden",
   "#:Olive Garden 1"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "measure",
   "$2000"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "measure",
   "$1500"
  ]
 },
 {
  "@name": "entity_S13",
  "@logic": [
   "isa",
   "abstract",
   "#:deposit 4"
  ]
 },
 {
  "@name": "entity_S13",
  "@logic": [
   "isa",
   "deposit",
   "#:deposit 4"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "managed building",
   "sk0_managed building"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "pet",
    "?:X"
   ],
   [
    "is rel2",
    "allowed in",
    "?:X",
    "sk0_managed building",
    "?:Cu9"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-is rel2",
    "in",
    "?:A",
    "?:Z",
    "?:Cu10"
   ],
   [
    "isa",
    "deposit",
    [
     "sk1",
     "?:Z"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-is rel2",
    "in",
    "?:A",
    "?:Z",
    "?:Cu11"
   ],
   [
    "is rel2",
    "rent",
    "?:A",
    "?:Z",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "deposit",
    "?:D"
   ],
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-is rel2",
    "at",
    "?:R",
    "?:Z",
    "?:Cu12"
   ],
   [
    "=",
    [
     "$measure_of",
     "deposit",
     "?:D",
     "W0"
    ],
    [
     "$measure_of",
     "monthly rent",
     "?:Z",
     "W0"
    ]
   ],
   [
    "less_measure",
    [
     "$measure_of",
     "monthly rent",
     "?:Z",
     "W0"
    ],
    [
     "$measure_of",
     "deposit",
     "?:D",
     "W0"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "deposit",
    "?:D"
   ],
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-is rel2",
    "at",
    "?:R",
    "?:Z",
    "?:Cu13"
   ],
   [
    "-=",
    [
     "$measure_of",
     "deposit",
     "?:D",
     "W0"
    ],
    [
     "$measure_of",
     "monthly rent",
     "?:Z",
     "W0"
    ]
   ],
   [
    "not",
    [
     "less_measure",
     [
      "$measure_of",
      "monthly rent",
      "?:Z",
      "W0"
     ],
     [
      "$measure_of",
      "deposit",
      "?:D",
      "W0"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "cat",
   "#:cat 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "person",
   "#:Tom 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "cat",
   "#:cat 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "#:Tom 2",
   "#:cat 3",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "cat",
   "#:cat 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Tom 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "have",
   "#:Tom 2",
   "#:cat 3",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "cat",
    "?:X"
   ],
   [
    "isa",
    "pet",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "managed building",
   "#:Olive Garden 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "=",
   [
    "$measure_of",
    "monthly rent",
    "#:Olive Garden 1",
    "W0"
   ],
   [
    "$list",
    2000,
    "#:dollar"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "place",
   "#:Olive Garden 1"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "monthly rent at",
   "#:monthly rent 2",
   "#:Olive Garden 1",
   "?:Cu25"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "less_measure",
   [
    "$list",
    1500,
    "#:dollar"
   ],
   [
    "$list",
    2000,
    "#:dollar"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-is rel2",
    "allow",
    "#:Tom 2",
    "#:cat 3",
    "?:Cu27"
   ],
   [
    "-isa",
    "deposit",
    "?:D"
   ],
   [
    "less_measure",
    [
     "$list",
     1500,
     "#:dollar"
    ],
    [
     "$measure_of",
     "deposit",
     "?:D",
     "W0"
    ]
   ],
   [
    "isa",
    "managed building",
    "sk2_managed building"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-is rel2",
    "allow",
    "#:Tom 2",
    "#:cat 3",
    "?:Cu28"
   ],
   [
    "-isa",
    "deposit",
    "?:D"
   ],
   [
    "less_measure",
    [
     "$list",
     1500,
     "#:dollar"
    ],
    [
     "$measure_of",
     "deposit",
     "?:D",
     "W0"
    ]
   ],
   [
    "isa",
    "apartment",
    "sk3_apartment"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-is rel2",
    "allow",
    "#:Tom 2",
    "#:cat 3",
    "?:Cu29"
   ],
   [
    "-isa",
    "deposit",
    "?:D"
   ],
   [
    "less_measure",
    [
     "$list",
     1500,
     "#:dollar"
    ],
    [
     "$measure_of",
     "deposit",
     "?:D",
     "W0"
    ]
   ],
   [
    "is rel2",
    "rent",
    "#:Tom 2",
    "sk3_apartment",
    "?:Cu29"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S12",
  "@logic": [
   [
    "-is rel2",
    "allow",
    "?:Z",
    "pets",
    "?:Cu30"
   ],
   [
    "-isa",
    "person",
    "?:P"
   ],
   [
    "-isa",
    "pet",
    "?:T"
   ],
   [
    "is rel2",
    "go",
    "?:P",
    "?:T",
    "?:Cu30"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "=",
    [
     "$measure_of",
     "deposit",
     "#:deposit 4",
     "W0"
    ],
    [
     "$list",
     2000,
     "#:dollar"
    ]
   ],
   [
    "less_measure",
    [
     "$list",
     2000,
     "#:dollar"
    ],
    [
     "$measure_of",
     "deposit",
     "#:deposit 4",
     "W0"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-=",
    [
     "$measure_of",
     "deposit",
     "#:deposit 4",
     "W0"
    ],
    [
     "$list",
     2000,
     "#:dollar"
    ]
   ],
   [
    "not",
    [
     "less_measure",
     [
      "$list",
      2000,
      "#:dollar"
     ],
     [
      "$measure_of",
      "deposit",
      "#:deposit 4",
      "W0"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-=",
    [
     "$measure_of",
     "deposit",
     "#:deposit 4",
     "W0"
    ],
    [
     "$list",
     2000,
     "#:dollar"
    ]
   ],
   [
    "less_measure",
    [
     "$list",
     2000,
     "#:dollar"
    ],
    [
     "$measure_of",
     "deposit",
     "#:deposit 4",
     "W0"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "not",
    [
     "less_measure",
     [
      "$list",
      2000,
      "#:dollar"
     ],
     [
      "$measure_of",
      "deposit",
      "#:deposit 4",
      "W0"
     ]
    ]
   ],
   [
    "=",
    [
     "$measure_of",
     "deposit",
     "#:deposit 4",
     "W0"
    ],
    [
     "$list",
     2000,
     "#:dollar"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "not",
    [
     "less_measure",
     [
      "$list",
      2000,
      "#:dollar"
     ],
     [
      "$measure_of",
      "deposit",
      "#:deposit 4",
      "W0"
     ]
    ]
   ],
   [
    "less_measure",
    [
     "$list",
     2000,
     "#:dollar"
    ],
    [
     "$measure_of",
     "deposit",
     "#:deposit 4",
     "W0"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "deposit",
    "?:S",
    "?:W"
   ],
   "?:Cu37"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "deposit",
   [
    "$measure_of",
    "deposit",
    "?:S",
    "?:W"
   ]
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "monthly rent",
    "?:S",
    "?:W"
   ],
   "?:Cu39"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "monthly rent",
   [
    "$measure_of",
    "monthly rent",
    "?:S",
    "?:W"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "managed building",
   "$some_not_managed_building"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "pet",
   "$some_pet"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "pet",
   "$some_not_pet"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "deposit",
   "$some_deposit"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "deposit",
   "$some_not_deposit"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "cat",
   "$some_not_cat"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "apartment",
   "$some_apartment"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "apartment",
   "$some_not_apartment"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:X"
   ],
   [
    "isa",
    "building",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "managed",
    "?:X"
   ],
   [
    "-isa",
    "building",
    "?:X"
   ],
   [
    "isa",
    "managed building",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "olive garden",
    "?:X"
   ],
   [
    "isa",
    "garden",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "olive",
    "?:X"
   ],
   [
    "-isa",
    "garden",
    "?:X"
   ],
   [
    "isa",
    "olive garden",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "allow",
    "?:Fv41"
   ],
   [
    "has type",
    "?:E",
    "give",
    "?:Fv41"
   ]
  ],
  "@confidence": 0.56
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv42"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv42"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "cat",
    "?:Xg"
   ],
   [
    "isa",
    "woman",
    "?:Xg"
   ]
  ]
 }
]