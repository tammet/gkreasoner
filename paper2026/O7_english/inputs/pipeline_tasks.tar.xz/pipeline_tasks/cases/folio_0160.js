[
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "person",
   "#:Professor David 1"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "professor david",
   "#:Professor David 1"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "man",
   "#:James 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "work",
    "?:X",
    "library",
    "?:Cu4"
   ],
   [
    "-isa",
    "computer science department",
    "?:D"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "?:D",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "?:X",
    "?:J",
    "?:Cu5"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu5"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    "library",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "take",
    "?:X",
    "database course",
    "?:Cu6"
   ],
   [
    "isa",
    "computer science department",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "take",
    "?:X",
    "database course",
    "?:Cu7"
   ],
   [
    "is rel2",
    "from",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "take",
    "?:X",
    "class",
    "?:Cu8"
   ],
   [
    "is rel2",
    "take",
    "?:X",
    "database course",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "work",
    "?:X",
    "lab",
    "?:Cu9"
   ],
   [
    "is rel2",
    "take",
    "?:X",
    "class",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "student",
   "#:James 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:James 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "lab",
   "#:lab 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "work",
   "#:James 2",
   "#:lab 3",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:James 2"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "lab",
   "#:lab 3"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "-is rel2",
   "work",
   "#:James 2",
   "#:lab 3",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "#:James 2",
    "?:J",
    "?:Cu17"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "take",
    "#:James 2",
    "database course",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "take",
    "#:James 2",
    "database course",
    "?:Cu19"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "computer science department",
   "$some_computer_science_department"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "computer science department",
   "$some_not_computer_science_department"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "student",
   "$some_not_student"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "part-time job",
   "$some_part-time_job"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "part-time job",
   "$some_not_part-time_job"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "university",
   "$some_university"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "university",
   "$some_not_university"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "computer science department",
    "?:X"
   ],
   [
    "isa",
    "department",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "computer science",
    "?:X"
   ],
   [
    "-isa",
    "department",
    "?:X"
   ],
   [
    "isa",
    "computer science department",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:X"
   ],
   [
    "isa",
    "job",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "part-time",
    "?:X"
   ],
   [
    "-isa",
    "job",
    "?:X"
   ],
   [
    "isa",
    "part-time job",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "professor david",
    "?:X"
   ],
   [
    "isa",
    "david",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "professor",
    "?:X"
   ],
   [
    "-isa",
    "david",
    "?:X"
   ],
   [
    "isa",
    "professor david",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]