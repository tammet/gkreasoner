[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "picuris mountain",
   "#:Picuris Mountains 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:New Mexico 2"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "new mexico",
   "#:New Mexico 2"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Texas 3"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "man",
   "#:Juan de Onate 4"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "juan de onate",
   "#:Juan de Onate 4"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "harding pegmatite mine",
   "#:Harding Pegmatite Mine 5"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "mountain range",
   "#:Picuris Mountains 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "is rel2",
    "in",
    "#:Picuris Mountains 1",
    "#:New Mexico 2",
    "?:Cu9"
   ],
   [
    "is rel2",
    "in",
    "#:Picuris Mountains 1",
    "#:Texas 3",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:Juan de Onate 4"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "mountain range",
   "#:Picuris Mountains 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "visit",
   "#:Juan de Onate 4",
   "#:Picuris Mountains 1",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "mine",
   "#:Harding Pegmatite Mine 5"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has property",
   "donate",
   "#:Harding Pegmatite Mine 5",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "mine",
   "#:Harding Pegmatite Mine 5"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "mountain range",
   "#:Picuris Mountains 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "in",
   "#:Harding Pegmatite Mine 5",
   "#:Picuris Mountains 1",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:Texas 3",
    "?:Cu18"
   ],
   [
    "-isa",
    "mine",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Cu18"
   ],
   [
    "-has property",
    "donate",
    "?:Y",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "mountain range",
    "sk0_mountain range"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "sk0_mountain range",
    "#:Texas 3",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "visit",
    "#:Juan de Onate 4",
    "sk0_mountain range",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "mountain range",
    "?:X"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "#:Texas 3",
    "?:Cu22"
   ],
   [
    "-is rel2",
    "visit",
    "#:Juan de Onate 4",
    "?:X",
    "?:Cu22"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "mine",
   "$some_not_mine"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "donate",
   "$some_not_donate",
   "?:Cu26"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "harding pegmatite mine",
    "?:X"
   ],
   [
    "isa",
    "mine",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "harding pegmatite",
    "?:X"
   ],
   [
    "-isa",
    "mine",
    "?:X"
   ],
   [
    "isa",
    "harding pegmatite mine",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "juan de onate",
    "?:X"
   ],
   [
    "isa",
    "onate",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "juan de",
    "?:X"
   ],
   [
    "-isa",
    "onate",
    "?:X"
   ],
   [
    "isa",
    "juan de onate",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "mountain range",
    "?:X"
   ],
   [
    "isa",
    "range",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "mountain",
    "?:X"
   ],
   [
    "-isa",
    "range",
    "?:X"
   ],
   [
    "isa",
    "mountain range",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "new mexico",
    "?:X"
   ],
   [
    "isa",
    "mexico",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "new",
    "?:X"
   ],
   [
    "-isa",
    "mexico",
    "?:X"
   ],
   [
    "isa",
    "new mexico",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "picuris mountain",
    "?:X"
   ],
   [
    "isa",
    "mountain",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "picuris",
    "?:X"
   ],
   [
    "-isa",
    "mountain",
    "?:X"
   ],
   [
    "isa",
    "picuris mountain",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]