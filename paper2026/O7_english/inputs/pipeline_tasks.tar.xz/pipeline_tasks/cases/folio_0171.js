[
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "abstract",
   "#:Bile duct cancer 1"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "bile duct cancer",
   "#:Bile duct cancer 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "mild flu",
   "#:Mild flu 1"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "colorectal cancer",
   "#:Colorectal cancer 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "isa",
    "low survival rate",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "is rel2",
    "comes with",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "cancer",
    "?:X"
   ],
   [
    "-has property",
    "deep",
    "?:X",
    "?:Cu7"
   ],
   [
    "isa",
    "deadly disease",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "cancer",
   "Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "bile duct cancer",
   "Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has property",
   "deep",
   "Cholangiocarcinoma",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "cholangiocarcinoma",
    "?:X"
   ],
   [
    "isa",
    "bile duct cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "flu",
   "#:Mild flu 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "has property",
   "mild",
   "#:Mild flu 1",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "low survival rate",
   "sk1_low survival rate"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "comes with",
   "#:Mild flu 1",
   "sk1_low survival rate",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "cancer",
   "#:Colorectal cancer 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "bile duct cancer",
    "#:Colorectal cancer 1"
   ],
   [
    "-isa",
    "low survival rate",
    "?:Z"
   ],
   [
    "-is rel2",
    "comes with",
    "#:Colorectal cancer 1",
    "?:Z",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "bile duct cancer",
    "#:Colorectal cancer 1"
   ],
   [
    "isa",
    "flu",
    "#:Mild flu 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "bile duct cancer",
    "#:Colorectal cancer 1"
   ],
   [
    "is rel2",
    "is kind of",
    "#:Colorectal cancer 1",
    "#:Mild flu 1",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "cholangiocarcinoma",
    "#:Colorectal cancer 1"
   ],
   [
    "isa",
    "bile duct cancer",
    "#:Colorectal cancer 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "cholangiocarcinoma",
    "#:Colorectal cancer 1"
   ],
   [
    "isa",
    "flu",
    "#:Mild flu 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "cholangiocarcinoma",
    "#:Colorectal cancer 1"
   ],
   [
    "is rel2",
    "is kind of",
    "#:Colorectal cancer 1",
    "#:Mild flu 1",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "bile duct cancer",
    "#:Colorectal cancer 1"
   ],
   [
    "isa",
    "cholangiocarcinoma",
    "#:Colorectal cancer 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "bile duct cancer",
    "#:Colorectal cancer 1"
   ],
   [
    "-isa",
    "flu",
    "#:Mild flu 1"
   ],
   [
    "-is rel2",
    "is kind of",
    "#:Colorectal cancer 1",
    "#:Mild flu 1",
    "?:Cu25"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "deadly disease",
   "$some_deadly_disease"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "deadly disease",
   "$some_not_deadly_disease"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "low survival rate",
   "$some_low_survival_rate"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "low survival rate",
   "$some_not_low_survival_rate"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "cancer",
   "$some_not_cancer"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "cholangiocarcinoma",
   "$some_Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "cholangiocarcinoma",
   "$some_not_Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "deep",
   "$some_not_severe",
   "?:Cu34"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "bile duct cancer",
    "?:X"
   ],
   [
    "isa",
    "cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "bile duct",
    "?:X"
   ],
   [
    "-isa",
    "cancer",
    "?:X"
   ],
   [
    "isa",
    "bile duct cancer",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "colorectal cancer",
    "?:X"
   ],
   [
    "isa",
    "cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "colorectal",
    "?:X"
   ],
   [
    "-isa",
    "cancer",
    "?:X"
   ],
   [
    "isa",
    "colorectal cancer",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "isa",
    "disease",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "deadly",
    "?:X"
   ],
   [
    "-isa",
    "disease",
    "?:X"
   ],
   [
    "isa",
    "deadly disease",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "low survival rate",
    "?:X"
   ],
   [
    "isa",
    "rate",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "low survival",
    "?:X"
   ],
   [
    "-isa",
    "rate",
    "?:X"
   ],
   [
    "isa",
    "low survival rate",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "mild flu",
    "?:X"
   ],
   [
    "isa",
    "flu",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "mild",
    "?:X"
   ],
   [
    "-isa",
    "flu",
    "?:X"
   ],
   [
    "isa",
    "mild flu",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]