[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "event",
   "#:GRE test 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "gre test",
   "#:GRE test 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "measure",
   "$205"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "measure",
   "$300"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "organization",
   "#:ETS 2"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "dad",
   "#:dad 5"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "=",
   [
    "$measure_of",
    "cost",
    "https://en.wikipedia.org/wiki/Graduate_Record_Examinations",
    "W0"
   ],
   [
    "$list",
    205,
    "#:dollar"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "less_measure",
   [
    "$measure_of",
    "cost",
    "$205",
    "W0"
   ],
   [
    "$measure_of",
    "cost",
    "$300",
    "W0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "prove",
    "?:X",
    "economic hardship",
    "?:Cu9"
   ],
   [
    "is rel2",
    "provide",
    "https://en.wikipedia.org/wiki/Educational_Testing_Service",
    "?:X",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "live",
    "?:X",
    "single-parent family",
    "?:Cu10"
   ],
   [
    "is rel2",
    "prove",
    "?:X",
    "economic hardship",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "resources",
    "?:R"
   ],
   [
    "-have",
    "?:X",
    "?:R",
    "?:Cu11"
   ],
   [
    "is rel2",
    "prove",
    "?:X",
    "economic hardship",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "single-parent family",
   "#:single-parent family 4"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "live",
   "#:Tom 3",
   "#:single-parent family 4",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:dad 5"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "-has property",
   "work",
   "#:dad 5",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:dad 5"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "dad of",
   "#:dad 5",
   "#:Tom 3",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Tom 3"
   ],
   [
    "-isa",
    "resources",
    "?:X"
   ],
   [
    "-have",
    "#:Tom 3",
    "?:X",
    "?:Cu20"
   ]
  ],
  "@confidence": 0.4
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "person",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "apply",
   "#:Tom 3",
   "provide",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "gre applicant",
   "#:Tom 3"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "take",
    "?:X",
    "https://en.wikipedia.org/wiki/Graduate_Record_Examinations",
    "?:Cu24"
   ],
   [
    "-isa",
    "financial aid",
    "?:Z"
   ],
   [
    "-is rel2",
    "provide",
    "?:X",
    "?:Z",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "take",
    "sk0",
    "https://en.wikipedia.org/wiki/Graduate_Record_Examinations",
    "?:Cu25"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "financial aid",
    "sk1_financial aid"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "provide",
    "sk0",
    "sk1_financial aid",
    "?:Cu27"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "have",
   "#:Tom 3",
   "#:dad 5",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S11",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "cost",
    "?:S",
    "?:W"
   ],
   "?:Cu29"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "cost",
   [
    "$measure_of",
    "cost",
    "?:S",
    "?:W"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "resources",
   "$some_resources"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "resources",
   "$some_not_resources"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "work",
   "$some_work",
   "?:Cu34"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "gre applicant",
    "?:X"
   ],
   [
    "isa",
    "applicant",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "gre",
    "?:X"
   ],
   [
    "-isa",
    "applicant",
    "?:X"
   ],
   [
    "isa",
    "gre applicant",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "financial aid",
    "?:X"
   ],
   [
    "isa",
    "help",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "financial",
    "?:X"
   ],
   [
    "-isa",
    "help",
    "?:X"
   ],
   [
    "isa",
    "financial aid",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "gre test",
    "?:X"
   ],
   [
    "isa",
    "test",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "gre",
    "?:X"
   ],
   [
    "-isa",
    "test",
    "?:X"
   ],
   [
    "isa",
    "gre test",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "single-parent family",
    "?:X"
   ],
   [
    "isa",
    "family",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "single-parent",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:X"
   ],
   [
    "isa",
    "single-parent family",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "cost",
    "?:X"
   ],
   [
    "isa",
    "price",
    "?:X"
   ]
  ],
  "@confidence": 0.94
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "price",
    "?:X"
   ],
   [
    "isa",
    "cost",
    "?:X"
   ]
  ],
  "@confidence": 0.94
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "provide",
    "?:Fv31"
   ],
   [
    "has type",
    "?:E",
    "give",
    "?:Fv31"
   ]
  ],
  "@confidence": 0.84
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "dad",
    "?:Xg"
   ],
   [
    "isa",
    "man",
    "?:Xg"
   ]
  ]
 }
]