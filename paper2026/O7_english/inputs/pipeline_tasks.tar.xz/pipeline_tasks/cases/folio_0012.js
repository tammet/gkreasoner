[
 {
  "@name": "entity_S13",
  "@logic": [
   "isa",
   "animal",
   "#:Joey 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "wild turkey type",
   "Eastern wild turkey"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "eastern wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "wild turkey type",
   "Osceola wild turkey"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "osceola wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "wild turkey type",
   "Merriam's wild turkey"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "merriam's wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "wild turkey type",
   "Merriam's wild turkey"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "merriam's wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "wild turkey type",
   "Rio Grande wild turkey"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "rio grande wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "wild turkey type",
   "Ocellated wild turkey"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "ocellated wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "wild turkey",
    "?:X"
   ],
   [
    "isa",
    "eastern wild turkey",
    "?:X"
   ],
   [
    "isa",
    "osceola wild turkey",
    "?:X"
   ],
   [
    "isa",
    "merriam's wild turkey",
    "?:X"
   ],
   [
    "isa",
    "rio grande wild turkey",
    "?:X"
   ],
   [
    "isa",
    "ocellated wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "animal",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "-isa",
   "eastern wild turkey",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "animal",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "-isa",
   "osceola wild turkey",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "animal",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "-isa",
   "merriam's wild turkey",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "isa",
   "animal",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "-isa",
   "merriam's wild turkey",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "-isa",
   "rio grande wild turkey",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "isa",
   "animal",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "isa",
   "wild turkey",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "wild turkey",
    "#:Joey 2"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "wild turkey",
    "#:Joey 2"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "eastern wild turkey",
   "$some_Eastern_wild_turkey"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "wild turkey",
   "$some_not_wild_turkey"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "osceola wild turkey",
   "$some_Osceola_wild_turkey"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "merriam's wild turkey",
   "$some_Merriam's_wild_turkey"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "rio grande wild turkey",
   "$some_Rio_Grande_wild_turkey"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "ocellated wild turkey",
   "$some_Ocellated_wild_turkey"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "ocellated wild turkey",
   "$some_not_Ocellated_wild_turkey"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "eastern wild turkey",
    "?:X"
   ],
   [
    "isa",
    "turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "eastern wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "eastern wild",
    "?:X"
   ],
   [
    "-isa",
    "turkey",
    "?:X"
   ],
   [
    "isa",
    "eastern wild turkey",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "merriam's wild turkey",
    "?:X"
   ],
   [
    "isa",
    "turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "merriam's wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "merriam's wild",
    "?:X"
   ],
   [
    "-isa",
    "turkey",
    "?:X"
   ],
   [
    "isa",
    "merriam's wild turkey",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "ocellated wild turkey",
    "?:X"
   ],
   [
    "isa",
    "turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "ocellated wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "ocellated wild",
    "?:X"
   ],
   [
    "-isa",
    "turkey",
    "?:X"
   ],
   [
    "isa",
    "ocellated wild turkey",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "osceola wild turkey",
    "?:X"
   ],
   [
    "isa",
    "turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "osceola wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "osceola wild",
    "?:X"
   ],
   [
    "-isa",
    "turkey",
    "?:X"
   ],
   [
    "isa",
    "osceola wild turkey",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "rio grande wild turkey",
    "?:X"
   ],
   [
    "isa",
    "turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "rio grande wild turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "rio grande wild",
    "?:X"
   ],
   [
    "-isa",
    "turkey",
    "?:X"
   ],
   [
    "isa",
    "rio grande wild turkey",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "wild turkey",
    "?:X"
   ],
   [
    "isa",
    "turkey",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "wild",
    "?:X"
   ],
   [
    "-isa",
    "turkey",
    "?:X"
   ],
   [
    "isa",
    "wild turkey",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "wild turkey type",
    "?:X"
   ],
   [
    "isa",
    "type",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "wild turkey",
    "?:X"
   ],
   [
    "-isa",
    "type",
    "?:X"
   ],
   [
    "isa",
    "wild turkey type",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]