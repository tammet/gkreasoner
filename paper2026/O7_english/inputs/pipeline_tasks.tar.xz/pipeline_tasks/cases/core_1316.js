[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has degree property",
   "good",
   "#:John 1",
   "none",
   "person",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "good",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has degree property",
    "good",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has degree property",
    "good",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree property",
    "good",
    "#:John 1",
    "none",
    "person",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "good",
      "#:John 1",
      "none",
      "person",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 }
]