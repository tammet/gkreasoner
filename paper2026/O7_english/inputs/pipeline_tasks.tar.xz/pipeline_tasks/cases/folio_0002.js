[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "organization",
   "#:this club 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "this club",
   "#:this club 1"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "organization",
   "#:school 5"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "school",
   "#:school 5"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu5"
   ],
   [
    "is rel2",
    "attend",
    "?:X",
    "school event",
    "?:Cu5"
   ]
  ],
  "@confidence": 0.96
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu6"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu6"
   ],
   [
    "has property",
    "busy",
    "?:X",
    "?:Cu6"
   ]
  ],
  "@confidence": 0.96
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu7"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu7"
   ],
   [
    "isa",
    "community member",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu8"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu8"
   ],
   [
    "has property",
    "inactive",
    "?:X",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu9"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu9"
   ],
   [
    "has property",
    "disinterested",
    "?:X",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu10"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu10"
   ],
   [
    "-isa",
    "community member",
    "?:X"
   ],
   [
    "-has property",
    "inactive",
    "?:X",
    "?:Cu10"
   ],
   [
    "-has property",
    "disinterested",
    "?:X",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "chaperone",
    "?:X",
    "high school dance",
    "?:Cu11"
   ],
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-is rel2",
    "attend",
    "?:X",
    "#:school 5",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu12"
   ],
   [
    "-has property",
    "inactive",
    "?:X",
    "?:Cu12"
   ],
   [
    "-has property",
    "disinterested",
    "?:X",
    "?:Cu12"
   ],
   [
    "is rel2",
    "chaperone",
    "?:X",
    "high school dance",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-has property",
    "young",
    "?:X",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu13"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu13"
   ],
   [
    "isa",
    "student",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-has property",
    "young",
    "?:X",
    "?:Cu14"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu14"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu14"
   ],
   [
    "is rel2",
    "attend",
    "?:X",
    "#:school 5",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu15"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu15"
   ],
   [
    "isa",
    "student",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:this club 1",
    "?:Cu16"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu16"
   ],
   [
    "is rel2",
    "attend",
    "?:X",
    "#:school 5",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:Bonnie 8"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "in",
   "#:Bonnie 8",
   "#:this club 1",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "school event",
    "?:Cu20"
   ],
   [
    "has property",
    "busy",
    "#:Bonnie 8",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "school event",
    "?:Cu21"
   ],
   [
    "-has property",
    "busy",
    "#:Bonnie 8",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "school event",
    "?:Cu22"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "has property",
    "busy",
    "#:Bonnie 8",
    "?:Cu23"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "school event",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "has property",
   "busy",
   "#:Bonnie 8",
   "?:Cu24"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "has property",
    "busy",
    "#:Bonnie 8",
    "?:Cu26"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "school event",
    "?:Cu27"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "busy",
    "#:Bonnie 8",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "busy",
    "#:Bonnie 8",
    "?:Cu29"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu31"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "school event",
    "?:Cu31"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu32"
   ],
   [
    "has property",
    "busy",
    "#:Bonnie 8",
    "?:Cu32"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu33"
   ],
   [
    "-has property",
    "busy",
    "#:Bonnie 8",
    "?:Cu33"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu44"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu44"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu45"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu45"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu45"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu46"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu46"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu46"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu47"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu47"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu47"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu48"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu48"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu48"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu48"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu49"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu49"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu49"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu49"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu50"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu50"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu50"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu50"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu50"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu51"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu51"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu52"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu52"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu52"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu53"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu53"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu53"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu54"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu54"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu54"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu55"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu55"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu55"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu55"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu56"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu56"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu56"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu56"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu57"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu57"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu57"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu57"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu57"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu72"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu72"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu73"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu73"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu73"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu74"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu74"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu74"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu75"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu75"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu75"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu76"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu76"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu76"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu76"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu77"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu77"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu77"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu77"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu78"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu78"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu78"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu78"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu78"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu79"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu79"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu80"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu80"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu80"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu81"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu81"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu81"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu82"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu82"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu82"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu83"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu83"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu83"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu83"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu84"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu84"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu84"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu84"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu85"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu85"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu85"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu85"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu85"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu93"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu93"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu94"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu94"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu94"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu95"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu95"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu95"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu96"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu96"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu96"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu97"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu97"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu97"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu97"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu98"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu98"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu98"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu98"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu99"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu99"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu99"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu99"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu99"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu100"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu100"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu101"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu101"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu101"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu102"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu102"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu102"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu103"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu103"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu103"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu104"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu104"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu104"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu104"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu105"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu105"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu105"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu105"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu106"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu106"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu106"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu106"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu106"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu121"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu121"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu122"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu122"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu122"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu123"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu123"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu123"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu124"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu124"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu124"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu125"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu125"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu125"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu125"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu126"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu126"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu126"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu126"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu127"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu127"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu127"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu127"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu127"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu128"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu128"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu129"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu129"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu129"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu130"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu130"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu130"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu131"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu131"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu131"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu132"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu132"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu132"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu132"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu133"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu133"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu133"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu133"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "academic career",
    "?:C"
   ],
   [
    "-isa",
    "educational opportunity",
    "?:O"
   ],
   [
    "-is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu134"
   ],
   [
    "-is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu134"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu134"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu134"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu134"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu136"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu137"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu138"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu139"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu139"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu140"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu140"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu141"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu141"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu141"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu143"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu144"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu145"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu146"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu146"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu147"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu147"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "academic career",
    "sk0_academic career"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu148"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu148"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu148"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu150"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu151"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu152"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu153"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu153"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu154"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu154"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "educational opportunity",
    "sk1_educational opportunity"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu155"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu155"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu155"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu156"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu157"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu157"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu158"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu158"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu159"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu159"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu160"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu160"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu160"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu161"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu161"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu161"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu162"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu162"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu162"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu162"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu163"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu164"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu164"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu165"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu165"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu166"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu166"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu167"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu167"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu167"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu168"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu168"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu168"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu169"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu169"
   ],
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu169"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu169"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "academic career",
    "sk2_academic career"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "academic career",
    "sk2_academic career"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "educational opportunity",
    "sk3_educational opportunity"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "educational opportunity",
    "sk3_educational opportunity"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu190"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "wish",
    "#:Bonnie 8",
    "attend",
    "?:Cu191"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu192"
   ],
   [
    "-isa",
    "young child",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "chaperone",
    "#:Bonnie 8",
    "high school dance",
    "?:Cu193"
   ],
   [
    "-isa",
    "teenager",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu198"
   ],
   [
    "isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu199"
   ],
   [
    "has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu199"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu200"
   ],
   [
    "has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu200"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu201"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu201"
   ],
   [
    "isa",
    "student",
    "#:Bonnie 8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "community member",
    "#:Bonnie 8"
   ],
   [
    "-has property",
    "inactive",
    "#:Bonnie 8",
    "?:Cu202"
   ],
   [
    "-has property",
    "disinterested",
    "#:Bonnie 8",
    "?:Cu202"
   ],
   [
    "is rel2",
    "attend",
    "#:Bonnie 8",
    "#:school 5",
    "?:Cu202"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "community member",
   "$some_community_member"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "academic career",
   "$some_academic_career"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "academic career",
   "$some_not_academic_career"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "educational opportunity",
   "$some_educational_opportunity"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "educational opportunity",
   "$some_not_educational_opportunity"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "inactive",
   "$some_inactive",
   "?:Cu216"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "inactive",
   "$some_not_inactive",
   "?:Cu217"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "disinterested",
   "$some_disinterested",
   "?:Cu218"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "disinterested",
   "$some_not_disinterested",
   "?:Cu219"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "young",
   "$some_young",
   "?:Cu220"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "young",
   "$some_not_young",
   "?:Cu221"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "academic career",
    "?:X"
   ],
   [
    "isa",
    "career",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "academic",
    "?:X"
   ],
   [
    "-isa",
    "career",
    "?:X"
   ],
   [
    "isa",
    "academic career",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "community member",
    "?:X"
   ],
   [
    "isa",
    "member",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "community",
    "?:X"
   ],
   [
    "-isa",
    "member",
    "?:X"
   ],
   [
    "isa",
    "community member",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "educational opportunity",
    "?:X"
   ],
   [
    "isa",
    "opportunity",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "educational",
    "?:X"
   ],
   [
    "-isa",
    "opportunity",
    "?:X"
   ],
   [
    "isa",
    "educational opportunity",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "this club",
    "?:X"
   ],
   [
    "isa",
    "club",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "this",
    "?:X"
   ],
   [
    "-isa",
    "club",
    "?:X"
   ],
   [
    "isa",
    "this club",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "young child",
    "?:X"
   ],
   [
    "isa",
    "child",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "young",
    "?:X"
   ],
   [
    "-isa",
    "child",
    "?:X"
   ],
   [
    "isa",
    "young child",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]