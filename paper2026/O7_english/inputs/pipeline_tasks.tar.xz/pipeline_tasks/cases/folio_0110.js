[
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "man",
   "#:Peter 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "clothing",
    "?:Z"
   ],
   [
    "-have",
    "?:X",
    "?:Z",
    "?:Cu2"
   ],
   [
    "-is rel2",
    "spill",
    "?:X",
    "food",
    "?:Cu2"
   ],
   [
    "-has property",
    "tidy",
    "?:X",
    "?:Cu2"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-has property",
    "clumsy",
    "?:X",
    "?:Cu3"
   ],
   [
    "-is rel2",
    "go out",
    "?:X",
    "food restaurant",
    "?:Cu3"
   ],
   [
    "isa",
    "clothing",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-has property",
    "clumsy",
    "?:X",
    "?:Cu4"
   ],
   [
    "-is rel2",
    "go out",
    "?:X",
    "food restaurant",
    "?:Cu4"
   ],
   [
    "have",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-has property",
    "clumsy",
    "?:X",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "go out",
    "?:X",
    "food restaurant",
    "?:Cu5"
   ],
   [
    "is rel2",
    "spill",
    "?:X",
    "food",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-has property",
    "cleanly",
    "?:X",
    "?:Cu6"
   ],
   [
    "has property",
    "tidy",
    "?:X",
    "?:Cu6"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "value",
    "?:X",
    "?:O",
    "?:Cu7"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "value",
    "?:X",
    "?:SP",
    "?:Cu7"
   ],
   [
    "has property",
    "cleanly",
    "?:X",
    "?:Cu7"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "?:X",
    "?:Cu8"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu8"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu8"
   ],
   [
    "isa",
    "order",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "?:X",
    "?:Cu9"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu9"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu9"
   ],
   [
    "is rel2",
    "value",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "?:X",
    "?:Cu10"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu10"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu10"
   ],
   [
    "isa",
    "spotlessness",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "?:X",
    "?:Cu11"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu11"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu11"
   ],
   [
    "is rel2",
    "value",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Peter 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "clothing",
    "sk3_clothing"
   ],
   [
    "-isa",
    "clothing",
    "?:Y2"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:Y2",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "clothing",
    "sk3_clothing"
   ],
   [
    "-has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "have",
    "#:Peter 1",
    "sk3_clothing",
    "?:Cu15"
   ],
   [
    "-isa",
    "clothing",
    "?:Y2"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:Y2",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "have",
    "#:Peter 1",
    "sk3_clothing",
    "?:Cu16"
   ],
   [
    "-has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu18"
   ],
   [
    "-has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu19"
   ],
   [
    "-isa",
    "clothing",
    "?:Y2"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:Y2",
    "?:Cu19"
   ],
   [
    "-is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "person",
    "#:Peter 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu26"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu26"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu28"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu28"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu28"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu30"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu30"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu30"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu30"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "family",
    "sk5_family"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu31"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu31"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "family",
    "sk5_family"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu32"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu32"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu32"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "family of",
    "sk5_family",
    "#:Peter 1",
    "?:Cu33"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu33"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu33"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "family of",
    "sk5_family",
    "#:Peter 1",
    "?:Cu34"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu34"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu34"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu34"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu35"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu35"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu36"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu36"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu36"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk12_order",
    "?:Cu37"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu37"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu37"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk12_order",
    "?:Cu38"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu38"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu38"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu38"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu39"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu39"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu40"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu40"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu40"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk13_spotlessness",
    "?:Cu41"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu41"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu41"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk13_spotlessness",
    "?:Cu42"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu42"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu42"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu42"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu64"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu64"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "#:Peter 1",
    "?:Cu64"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu64"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu64"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu65"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu65"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "#:Peter 1",
    "?:Cu65"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu65"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu65"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu65"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu66"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu66"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "#:Peter 1",
    "?:Cu66"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu66"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu66"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu67"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu67"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "#:Peter 1",
    "?:Cu67"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu67"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu67"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu67"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu68"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu68"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "#:Peter 1",
    "?:Cu68"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu68"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu68"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu69"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu69"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "#:Peter 1",
    "?:Cu69"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu69"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu69"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu69"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu70"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu70"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "#:Peter 1",
    "?:Cu70"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu70"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu70"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu71"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu71"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "#:Peter 1",
    "?:Cu71"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu71"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu71"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu71"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu71"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu71"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu73"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu74"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu76"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu78"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu80"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu82"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu82"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu82"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu83"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu84"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu84"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu85"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu85"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu86"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu87"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu87"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu88"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu89"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu89"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu90"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu91"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu91"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu93"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu93"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu93"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu93"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu95"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu96"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu98"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu100"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu102"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu104"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu104"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu104"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu105"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu106"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu106"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu107"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu107"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu108"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu109"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu109"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu110"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu111"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu111"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu112"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu113"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu113"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu115"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu115"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu115"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu115"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu117"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu118"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu120"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu122"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu124"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu126"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu126"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu126"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu127"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu128"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu128"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu129"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu129"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu130"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu131"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu131"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu132"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu133"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu133"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu134"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu135"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu135"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu137"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu137"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu137"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu137"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu138"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu139"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu140"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu140"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu141"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu142"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu142"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu143"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu144"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu144"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu145"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu146"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu146"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu148"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu148"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu148"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu148"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu149"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu149"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu150"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu150"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu151"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu151"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu151"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu152"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu152"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu153"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu153"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu153"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu154"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu154"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu155"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu155"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu155"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu156"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu156"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu157"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu157"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu157"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu159"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu159"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu159"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu159"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu159"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu160"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu161"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu162"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu162"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu163"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu164"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu164"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu165"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu166"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu166"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu167"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu168"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu168"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu170"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu170"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu170"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu170"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu171"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu171"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu172"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu172"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu173"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu173"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu173"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu174"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu174"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu175"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu175"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu175"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu176"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu176"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu177"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu177"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu177"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu178"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu178"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu179"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu179"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu179"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu181"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu181"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu181"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu181"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu181"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu182"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu183"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu184"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu184"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu185"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu186"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu186"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu187"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu188"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu188"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu189"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu190"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu190"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu192"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu192"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu192"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu192"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu193"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu193"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu194"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu194"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu195"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu195"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu195"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu196"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu196"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu197"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu197"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu197"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu198"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu198"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu199"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu199"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu199"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu200"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu200"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu201"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu201"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu201"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu203"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu203"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu203"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu203"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu203"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu204"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu205"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu205"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu206"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu207"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu208"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu208"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu209"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu210"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu210"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu211"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu212"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu212"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu214"
   ],
   [
    "isa",
    "family",
    "sk11_family"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu214"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu214"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu214"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu215"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu215"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu216"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu216"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu216"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu217"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu217"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu218"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu218"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu219"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu219"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu219"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu220"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu220"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu221"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu221"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu221"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu222"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu222"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu223"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu223"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu223"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu225"
   ],
   [
    "is rel2",
    "family of",
    "sk11_family",
    "#:Peter 1",
    "?:Cu225"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu225"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu225"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu225"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu226"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu227"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu227"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu228"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu229"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu230"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu230"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu231"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu232"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu232"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu233"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu234"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu234"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu236"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu236"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu236"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu236"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu237"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu237"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu238"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu238"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu238"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu239"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu239"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu240"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu240"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu241"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu241"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu241"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu242"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu242"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu243"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu243"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu243"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu244"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu244"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu245"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu245"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu245"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu247"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk12_order",
    "?:Cu247"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu247"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu247"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu247"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu248"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu249"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu249"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu250"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu251"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu252"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu252"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu253"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu254"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu254"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu255"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu256"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu256"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu258"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu258"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu258"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu258"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu259"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu259"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu260"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu260"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu260"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu261"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu261"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu262"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu262"
   ],
   [
    "isa",
    "family",
    "sk14_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu263"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu263"
   ],
   [
    "is rel2",
    "family of",
    "sk14_family",
    "#:Peter 1",
    "?:Cu263"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu264"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu264"
   ],
   [
    "isa",
    "order",
    "sk12_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu265"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu265"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk12_order",
    "?:Cu265"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu266"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu266"
   ],
   [
    "isa",
    "spotlessness",
    "sk13_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu267"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu267"
   ],
   [
    "is rel2",
    "prioritize",
    "sk14_family",
    "sk13_spotlessness",
    "?:Cu267"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu269"
   ],
   [
    "is rel2",
    "prioritize",
    "sk11_family",
    "sk13_spotlessness",
    "?:Cu269"
   ],
   [
    "-isa",
    "family",
    "?:F2"
   ],
   [
    "-is rel2",
    "family of",
    "?:F2",
    "#:Peter 1",
    "?:Cu269"
   ],
   [
    "-isa",
    "order",
    "?:O2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:O2",
    "?:Cu269"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP2"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F2",
    "?:SP2",
    "?:Cu269"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "have",
    "#:Peter 1",
    "sk5_family",
    "?:Cu270"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu271"
   ],
   [
    "-is rel2",
    "go out",
    "#:Peter 1",
    "food restaurant",
    "?:Cu271"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-is rel2",
    "family of",
    "?:F",
    "#:Peter 1",
    "?:Cu271"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu271"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu271"
   ],
   [
    "have",
    "#:Peter 1",
    "sk8_family",
    "?:Cu271"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "have",
    "#:Peter 1",
    "sk14_family",
    "?:Cu272"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "clothing",
   "$some_clothing"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "clothing",
   "$some_not_clothing"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "order",
   "$some_order"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "order",
   "$some_not_order"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "family",
   "$some_family"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "family",
   "$some_not_family"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "tidy",
   "$some_tidy",
   "?:Cu284"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "tidy",
   "$some_not_tidy",
   "?:Cu285"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "clumsy",
   "$some_clumsy",
   "?:Cu286"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "clumsy",
   "$some_not_clumsy",
   "?:Cu287"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_cleanly_person"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "cleanly",
   "$some_cleanly_person",
   "?:Cu289"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "clumsy foodie",
    "?:X"
   ],
   [
    "isa",
    "foodie",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "clumsy",
    "?:X"
   ],
   [
    "-isa",
    "foodie",
    "?:X"
   ],
   [
    "isa",
    "clumsy foodie",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]