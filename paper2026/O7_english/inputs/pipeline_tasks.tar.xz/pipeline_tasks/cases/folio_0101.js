[
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "animal",
   "#:Harry 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "isa",
    "invertebrate",
    "?:X"
   ],
   [
    "isa",
    "vertebrate",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-isa",
    "invertebrate",
    "?:X"
   ],
   [
    "-isa",
    "vertebrate",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "?:X",
    "?:Y",
    "?:Cu4"
   ],
   [
    "is rel2",
    "reproduce",
    "?:X",
    "male-and-female mating",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-has property",
    "vertebrate",
    "?:X",
    "?:Cu5"
   ],
   [
    "isa",
    "backbone",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-has property",
    "vertebrate",
    "?:X",
    "?:Cu6"
   ],
   [
    "has part",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "bee",
    "?:X"
   ],
   [
    "-is rel2",
    "reproduce",
    "?:X",
    "male-and-female mating",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "queen bee",
    "?:X"
   ],
   [
    "isa",
    "bee",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "bee",
   "#:Harry 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu12"
   ],
   [
    "isa",
    "backbone",
    "sk2_backbone"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu13"
   ],
   [
    "isa",
    "backbone",
    "sk2_backbone"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu14"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk2_backbone",
    "?:Cu14"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu15"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk2_backbone",
    "?:Cu15"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu16"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu17"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu18"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu19"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "isa",
    "backbone",
    "sk1_backbone"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "isa",
    "backbone",
    "sk1_backbone"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "isa",
    "backbone",
    "sk1_backbone"
   ],
   [
    "isa",
    "backbone",
    "sk2_backbone"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "isa",
    "backbone",
    "sk1_backbone"
   ],
   [
    "isa",
    "backbone",
    "sk2_backbone"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "isa",
    "backbone",
    "sk1_backbone"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk2_backbone",
    "?:Cu24"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "isa",
    "backbone",
    "sk1_backbone"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk2_backbone",
    "?:Cu25"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "isa",
    "backbone",
    "sk1_backbone"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu28"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "isa",
    "backbone",
    "sk1_backbone"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu29"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk1_backbone",
    "?:Cu30"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk1_backbone",
    "?:Cu31"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk1_backbone",
    "?:Cu32"
   ],
   [
    "isa",
    "backbone",
    "sk2_backbone"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk1_backbone",
    "?:Cu33"
   ],
   [
    "isa",
    "backbone",
    "sk2_backbone"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk1_backbone",
    "?:Cu34"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk2_backbone",
    "?:Cu34"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk1_backbone",
    "?:Cu35"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk2_backbone",
    "?:Cu35"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk1_backbone",
    "?:Cu38"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu38"
   ],
   [
    "-isa",
    "invertebrate",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "has part",
    "#:Harry 1",
    "sk1_backbone",
    "?:Cu39"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu39"
   ],
   [
    "-isa",
    "queen bee",
    "#:Harry 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu41"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "backbone",
    "sk3_backbone"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "backbone",
    "sk3_backbone"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu43"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "has part",
    "#:Harry 1",
    "sk3_backbone",
    "?:Cu44"
   ],
   [
    "-isa",
    "vertebrate",
    "#:Harry 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "has part",
    "#:Harry 1",
    "sk3_backbone",
    "?:Cu45"
   ],
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-has part",
    "#:Harry 1",
    "?:Y",
    "?:Cu45"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "invertebrate",
    "#:Harry 1"
   ],
   [
    "isa",
    "queen bee",
    "#:Harry 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_haspart_bridge",
  "@logic": [
   [
    "-isa",
    "backbone",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ],
   [
    "has part",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "invertebrate",
   "$some_invertebrate"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "vertebrate",
   "$some_vertebrate"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "backbone",
   "$some_backbone"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "backbone",
   "$some_not_backbone"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bee",
   "$some_not_bee"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "queen bee",
   "$some_queen_bee"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "queen bee",
   "$some_not_queen_bee"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "vertebrate",
   "$some_vertebrate",
   "?:Cu60"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "vertebrate",
   "$some_not_vertebrate",
   "?:Cu61"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_vertebrate_animal"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "vertebrate",
   "$some_vertebrate_animal",
   "?:Cu63"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "queen bee",
    "?:X"
   ],
   [
    "isa",
    "bee",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "queen",
    "?:X"
   ],
   [
    "-isa",
    "bee",
    "?:X"
   ],
   [
    "isa",
    "queen bee",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "queen",
    "?:Xg"
   ],
   [
    "isa",
    "woman",
    "?:Xg"
   ]
  ]
 }
]