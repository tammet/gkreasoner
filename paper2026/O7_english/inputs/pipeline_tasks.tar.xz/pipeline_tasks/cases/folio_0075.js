[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Istanbul 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:Istanbul 1",
    "?:Cu2"
   ],
   [
    "-isa",
    "number",
    "?:Y"
   ],
   [
    "-=",
    "?:Y",
    "34"
   ],
   [
    "is rel2",
    "begins with",
    "?:X",
    "?:Y",
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "vehicle registration plate",
    "?:X"
   ],
   [
    "-isa",
    "number",
    "?:Y"
   ],
   [
    "-=",
    "?:Y",
    "34"
   ],
   [
    "is rel2",
    "begins with",
    "?:X",
    "?:Y",
    "?:Cu3"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "#:Istanbul 1",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "vehicle registration plate",
   "#:vehicle registration plate 3"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "person",
   "#:Joe 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "have",
   "#:Joe 2",
   "#:vehicle registration plate 3",
   "?:Cu6"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "from",
   "#:vehicle registration plate 3",
   "#:Istanbul 1",
   "?:Cu7"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "vehicle registration plate",
   "#:vehicle registration plate 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "person",
   "#:Joe 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "#:Joe 2",
   "#:vehicle registration plate 3",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "vehicle registration plate",
   "#:vehicle registration plate 5"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Tom 4"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "have",
   "#:Tom 4",
   "#:vehicle registration plate 5",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "number",
   "35"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "begins with",
   "#:vehicle registration plate 5",
   "35",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "vehicle registration plate",
   "#:vehicle registration plate 5"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Tom 4"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "have",
   "#:Tom 4",
   "#:vehicle registration plate 5",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-=",
    "?:Y",
    "35"
   ],
   [
    "-isa",
    "number",
    "?:Z"
   ],
   [
    "-=",
    "?:Z",
    "34"
   ],
   [
    "-is rel2",
    "begins with",
    "?:X",
    "?:Y",
    "?:Cu19"
   ],
   [
    "-is rel2",
    "begins with",
    "?:X",
    "?:Z",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "from",
    "#:vehicle registration plate 5",
    "#:Istanbul 1",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "from",
    "#:vehicle registration plate 5",
    "#:Istanbul 1",
    "?:Cu21"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "number",
   "$some_not_number"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "vehicle registration plate",
   "$some_not_vehicle_registration_plate"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "vehicle registration plate",
    "?:X"
   ],
   [
    "isa",
    "plate",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "vehicle registration",
    "?:X"
   ],
   [
    "-isa",
    "plate",
    "?:X"
   ],
   [
    "isa",
    "vehicle registration plate",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:Istanbul 1",
    "?:Cu32"
   ],
   [
    "-isa",
    "number",
    "34"
   ],
   [
    "is rel2",
    "begins with",
    "?:X",
    "34",
    "?:Cu32"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "vehicle registration plate",
    "?:X"
   ],
   [
    "-isa",
    "number",
    "34"
   ],
   [
    "is rel2",
    "begins with",
    "?:X",
    "34",
    "?:Cu33"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "#:Istanbul 1",
    "?:Cu33"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "number",
    "34"
   ],
   [
    "-is rel2",
    "begins with",
    "?:X",
    "35",
    "?:Cu34"
   ],
   [
    "-is rel2",
    "begins with",
    "?:X",
    "34",
    "?:Cu34"
   ]
  ]
 }
]