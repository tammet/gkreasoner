[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "yale university",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "place",
   "#:New Haven 2"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "new haven",
   "#:New Haven 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "measure",
   "$42.3 billion"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "benjamin franklin college",
   "#:Benjamin Franklin College 3"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "organization",
   "#:Berkeley College 4"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "berkeley college",
   "#:Berkeley College 4"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "organization",
   "#:Branford College 5"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "branford college",
   "#:Branford College 5"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "organization",
   "#:Davenport College 6"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "davenport college",
   "#:Davenport College 6"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "ezra stiles college",
   "#:Ezra Stiles College 7"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "grace hopper college",
   "#:Grace Hopper College 8"
  ]
 },
 {
  "@name": "entity_S11",
  "@logic": [
   "isa",
   "jonathan edwards college",
   "#:Jonathan Edwards College 9"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "morse college",
   "#:Morse College 10"
  ]
 },
 {
  "@name": "entity_S13",
  "@logic": [
   "isa",
   "pauli murray college",
   "#:Pauli Murray College 11"
  ]
 },
 {
  "@name": "entity_S14",
  "@logic": [
   "isa",
   "pierson college",
   "#:Pierson College 12"
  ]
 },
 {
  "@name": "entity_S15",
  "@logic": [
   "isa",
   "saybrook college",
   "#:Saybrook College 13"
  ]
 },
 {
  "@name": "entity_S16",
  "@logic": [
   "isa",
   "silliman college",
   "#:Silliman College 14"
  ]
 },
 {
  "@name": "entity_S17",
  "@logic": [
   "isa",
   "timothy dwight college",
   "#:Timothy Dwight College 15"
  ]
 },
 {
  "@name": "entity_S18",
  "@logic": [
   "isa",
   "trumbull college",
   "#:Trumbull College 16"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "university",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "private",
   "#:Yale University 1",
   "?:Cu23"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "Ivy League",
   "#:Yale University 1",
   "?:Cu24"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "research",
   "#:Yale University 1",
   "?:Cu25"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "university",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "place",
   "https://en.wikipedia.org/wiki/New_Haven,_Connecticut"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "go",
   "#:Yale University 1",
   "https://en.wikipedia.org/wiki/New_Haven,_Connecticut",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv5"
   ],
   [
    "$datetime",
    1716
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is_past_world",
   "W0"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "university",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "endowment",
   "#:endowment 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "have",
   "#:Yale University 1",
   "#:endowment 2",
   "?:Cu34"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "=",
   [
    "$measure_of",
    "endowment",
    "#:Yale University 1",
    "W0"
   ],
   [
    "$list",
    42,
    "#:billion dollars"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "endowment",
   "#:endowment 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "university",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "#:Yale University 1",
   "#:endowment 2",
   "?:Cu38"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "residential college",
   "#:Benjamin Franklin College 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "at",
   "#:Benjamin Franklin College 3",
   "#:Yale University 1",
   "?:Cu40"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "residential college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu42"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "residential college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu44"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "residential college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu46"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "residential college",
   "#:Ezra Stiles College 7"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "at",
   "#:Ezra Stiles College 7",
   "#:Yale University 1",
   "?:Cu48"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "residential college",
   "#:Grace Hopper College 8"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "is rel2",
   "at",
   "#:Grace Hopper College 8",
   "#:Yale University 1",
   "?:Cu50"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "isa",
   "residential college",
   "#:Jonathan Edwards College 9"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "is rel2",
   "at",
   "#:Jonathan Edwards College 9",
   "#:Yale University 1",
   "?:Cu52"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "isa",
   "residential college",
   "#:Morse College 10"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "is rel2",
   "at",
   "#:Morse College 10",
   "#:Yale University 1",
   "?:Cu54"
  ]
 },
 {
  "@name": "sent_S13",
  "@logic": [
   "isa",
   "residential college",
   "#:Pauli Murray College 11"
  ]
 },
 {
  "@name": "sent_S13",
  "@logic": [
   "is rel2",
   "at",
   "#:Pauli Murray College 11",
   "#:Yale University 1",
   "?:Cu56"
  ]
 },
 {
  "@name": "sent_S14",
  "@logic": [
   "isa",
   "residential college",
   "#:Pierson College 12"
  ]
 },
 {
  "@name": "sent_S14",
  "@logic": [
   "is rel2",
   "at",
   "#:Pierson College 12",
   "#:Yale University 1",
   "?:Cu58"
  ]
 },
 {
  "@name": "sent_S15",
  "@logic": [
   "isa",
   "residential college",
   "#:Saybrook College 13"
  ]
 },
 {
  "@name": "sent_S15",
  "@logic": [
   "is rel2",
   "at",
   "#:Saybrook College 13",
   "#:Yale University 1",
   "?:Cu60"
  ]
 },
 {
  "@name": "sent_S16",
  "@logic": [
   "isa",
   "residential college",
   "#:Silliman College 14"
  ]
 },
 {
  "@name": "sent_S16",
  "@logic": [
   "is rel2",
   "at",
   "#:Silliman College 14",
   "#:Yale University 1",
   "?:Cu62"
  ]
 },
 {
  "@name": "sent_S17",
  "@logic": [
   "isa",
   "residential college",
   "#:Timothy Dwight College 15"
  ]
 },
 {
  "@name": "sent_S17",
  "@logic": [
   "is rel2",
   "at",
   "#:Timothy Dwight College 15",
   "#:Yale University 1",
   "?:Cu64"
  ]
 },
 {
  "@name": "sent_S18",
  "@logic": [
   "isa",
   "residential college",
   "#:Trumbull College 16"
  ]
 },
 {
  "@name": "sent_S18",
  "@logic": [
   "is rel2",
   "at",
   "#:Trumbull College 16",
   "#:Yale University 1",
   "?:Cu66"
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "residential college",
    "#:Pierson College 12"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "at",
    "#:Pierson College 12",
    "#:Yale University 1",
    "?:Cu68"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "residential college",
    "#:Pierson College 12"
   ],
   [
    "-is rel2",
    "at",
    "#:Pierson College 12",
    "#:Yale University 1",
    "?:Cu69"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "endowment",
    "?:S",
    "?:W"
   ],
   "?:Cu71"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "endowment",
   [
    "$measure_of",
    "endowment",
    "?:S",
    "?:W"
   ]
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "benjamin franklin college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "benjamin franklin",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "benjamin franklin college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "berkeley college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "berkeley",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "berkeley college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "branford college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "branford",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "branford college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "davenport college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "davenport",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "davenport college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "ezra stiles college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "ezra stiles",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "ezra stiles college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "grace hopper college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "grace hopper",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "grace hopper college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "jonathan edwards college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "jonathan edward",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "jonathan edwards college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "morse college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "morse",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "morse college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "new haven",
    "?:X"
   ],
   [
    "isa",
    "haven",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "new",
    "?:X"
   ],
   [
    "-isa",
    "haven",
    "?:X"
   ],
   [
    "isa",
    "new haven",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "pauli murray college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "pauli murray",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "pauli murray college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "pierson college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "pierson",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "pierson college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "residential college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "residential",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "residential college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "saybrook college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "saybrook",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "saybrook college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "silliman college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "silliman",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "silliman college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "timothy dwight college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "timothy dwight",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "timothy dwight college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "trumbull college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "trumbull",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "trumbull college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "yale university",
    "?:X"
   ],
   [
    "isa",
    "university",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "yale",
    "?:X"
   ],
   [
    "-isa",
    "university",
    "?:X"
   ],
   [
    "isa",
    "yale university",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv45"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv45"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]