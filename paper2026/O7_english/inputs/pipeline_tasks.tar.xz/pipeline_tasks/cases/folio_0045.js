[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "organization",
   "#:Women's Tennis Association 3"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "women's tennis association",
   "#:Women's Tennis Association 3"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "person",
   "#:Iga Swiatek 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "iga swiatek",
   "#:Iga Swiatek 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "event",
   "#:Roland Garros 2022 2"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "roland garros 2022",
   "#:Roland Garros 2022 2"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "person",
   "#:Rafael Nadal 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "man",
   "#:Rafael Nadal 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "rafael nadal",
   "#:Rafael Nadal 4"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "coco gauff",
   "#:Coco Gauff 5"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "rank",
    "#:Women's Tennis Association 3",
    "?:X",
    "?:Cu11"
   ],
   [
    "isa",
    "player",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "rank",
    "#:Women's Tennis Association 3",
    "?:X",
    "?:Cu12"
   ],
   [
    "has property",
    "most active",
    "?:X",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "rank",
    "#:Women's Tennis Association 3",
    "?:X",
    "?:Cu13"
   ],
   [
    "is rel2",
    "in",
    "?:X",
    "major tennis",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "lose",
    "?:X",
    "#:Iga Swiatek 1",
    "?:Cu14"
   ],
   [
    "is rel2",
    "rank",
    "#:Women's Tennis Association 3",
    "?:X",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-has property",
    "female",
    "?:X",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "at",
    "?:X",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu15"
   ],
   [
    "is rel2",
    "lose",
    "?:X",
    "#:Iga Swiatek 1",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu16"
   ],
   [
    "has property",
    "female",
    "?:X",
    "?:Cu16"
   ],
   [
    "has property",
    "male",
    "?:X",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu17"
   ],
   [
    "-has property",
    "female",
    "?:X",
    "?:Cu17"
   ],
   [
    "-has property",
    "male",
    "?:X",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-has property",
    "male",
    "?:X",
    "?:Cu18"
   ],
   [
    "-is rel2",
    "at",
    "?:X",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu18"
   ],
   [
    "is rel2",
    "lose",
    "?:X",
    "#:Rafael Nadal 4",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-is rel2",
    "rank",
    "#:Women's Tennis Association 3",
    "#:Coco Gauff 5",
    "?:Cu19"
   ],
   [
    "-isa",
    "tennis player",
    "#:Coco Gauff 5"
   ],
   [
    "-has property",
    "male",
    "#:Coco Gauff 5",
    "?:Cu19"
   ],
   [
    "-is rel2",
    "at",
    "#:Coco Gauff 5",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-is rel2",
    "lose",
    "#:Coco Gauff 5",
    "#:Rafael Nadal 4",
    "?:Cu20"
   ],
   [
    "-isa",
    "tennis player",
    "#:Coco Gauff 5"
   ],
   [
    "-has property",
    "male",
    "#:Coco Gauff 5",
    "?:Cu20"
   ],
   [
    "-is rel2",
    "at",
    "#:Coco Gauff 5",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Coco Gauff 5"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "at",
   "#:Coco Gauff 5",
   "https://en.wikipedia.org/wiki/2022_French_Open",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:Coco Gauff 5"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "tennis player",
   "#:Coco Gauff 5"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "lose",
    "#:Coco Gauff 5",
    "#:Iga Swiatek 1",
    "?:Cu25"
   ],
   [
    "-isa",
    "player",
    "#:Coco Gauff 5"
   ],
   [
    "-has property",
    "most active",
    "#:Coco Gauff 5",
    "?:Cu25"
   ],
   [
    "-is rel2",
    "in",
    "#:Coco Gauff 5",
    "major tennis",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "lose",
    "#:Coco Gauff 5",
    "#:Iga Swiatek 1",
    "?:Cu26"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "player",
    "#:Coco Gauff 5"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "has property",
    "most active",
    "#:Coco Gauff 5",
    "?:Cu28"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "in",
    "#:Coco Gauff 5",
    "major tennis",
    "?:Cu29"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "player",
   "$some_player"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "player",
   "$some_not_player"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "most active",
   "$some_most_active",
   "?:Cu35"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "most active",
   "$some_not_most_active",
   "?:Cu36"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "female",
   "$some_female",
   "?:Cu37"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "female",
   "$some_not_female",
   "?:Cu38"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "male",
   "$some_male",
   "?:Cu39"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "coco gauff",
    "?:X"
   ],
   [
    "isa",
    "gauff",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "coco",
    "?:X"
   ],
   [
    "-isa",
    "gauff",
    "?:X"
   ],
   [
    "isa",
    "coco gauff",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "iga swiatek",
    "?:X"
   ],
   [
    "isa",
    "swiatek",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "iga",
    "?:X"
   ],
   [
    "-isa",
    "swiatek",
    "?:X"
   ],
   [
    "isa",
    "iga swiatek",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "rafael nadal",
    "?:X"
   ],
   [
    "isa",
    "nadal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "rafael",
    "?:X"
   ],
   [
    "-isa",
    "nadal",
    "?:X"
   ],
   [
    "isa",
    "rafael nadal",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "roland garros 2022",
    "?:X"
   ],
   [
    "isa",
    "2022",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "roland garro",
    "?:X"
   ],
   [
    "-isa",
    "2022",
    "?:X"
   ],
   [
    "isa",
    "roland garros 2022",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "tennis player",
    "?:X"
   ],
   [
    "isa",
    "player",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "tennis",
    "?:X"
   ],
   [
    "-isa",
    "player",
    "?:X"
   ],
   [
    "isa",
    "tennis player",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "women's tennis association",
    "?:X"
   ],
   [
    "isa",
    "association",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "women's tennis",
    "?:X"
   ],
   [
    "-isa",
    "association",
    "?:X"
   ],
   [
    "isa",
    "women's tennis association",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "female",
    "?:X",
    "?:Fv35"
   ],
   [
    "-has property",
    "male",
    "?:X",
    "?:Fv35"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]