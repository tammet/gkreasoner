[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "boy",
   "#:boy 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "girl",
   "#:girl 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:boy 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:girl 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "show",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has recipient",
   "sk0_activity",
   "#:boy 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:girl 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:boy 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has degree property",
   "good",
   "#:boy 1",
   "none",
   "person",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has degree property",
    "good",
    "?:X",
    "none",
    "person",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "person",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0",
   "?:X"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has degree property",
    "good",
    "?:Br1",
    "none",
    "person",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree property",
    "good",
    "?:Br1",
    "none",
    "person",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "good",
      "?:Br1",
      "none",
      "person",
      [
       "$ctxt",
       "past",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "boy",
    "?:X",
    "?:Fv9"
   ],
   [
    "-has property",
    "girl",
    "?:X",
    "?:Fv9"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "boy",
   "$some_boy"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "girl",
   "$some_girl"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 }
]