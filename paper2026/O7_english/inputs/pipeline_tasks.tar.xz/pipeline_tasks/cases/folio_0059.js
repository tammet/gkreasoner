[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Billings 1"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "place",
   "U.S. 3"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "place",
   "#:Butte 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "place",
   "#:Helena 5"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "place",
   "#:Missoula 6"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "place",
   "#:White Sulphur Springs 7"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "white sulphur spring",
   "#:White Sulphur Springs 7"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "place",
   "#:St Pierre 8"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "st pierre",
   "#:St Pierre 8"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "place",
   "#:Bristol 9"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "place",
   "#:Texarkana 10"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "place",
   "#:Texhoma 11"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "place",
   "#:Union City 12"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "union city",
   "#:Union City 12"
  ]
 },
 {
  "@name": "entity_S13",
  "@logic": [
   "isa",
   "place",
   "#:Bismarck 13"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "city",
   "#:Montana 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "in",
   "#:Montana 2",
   "#:Montana 2",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "state",
   "#:Montana 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "in",
   "#:Montana 2",
   "https://en.wikipedia.org/wiki/United_States",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "in",
   "#:Montana 2",
   "#:Montana 2",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "in",
   "#:Montana 2",
   "#:Montana 2",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "in",
   "#:Montana 2",
   "#:Montana 2",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "city",
   "#:Montana 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "in",
   "#:Montana 2",
   "https://en.wikipedia.org/wiki/United_States",
   "?:Cu24"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "state",
   "sk0_state"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "in",
   "#:Montana 2",
   "sk0_state",
   "?:Cu26"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "in",
   "#:Montana 2",
   "sk0_state",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "city",
   "https://en.wikipedia.org/wiki/Saint_Pierre"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "-is rel2",
   "in",
   "https://en.wikipedia.org/wiki/Saint_Pierre",
   "#:Montana 2",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:Montana 2",
    "?:Cu30"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "https://en.wikipedia.org/wiki/Saint_Pierre",
    "?:Cu30"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "https://en.wikipedia.org/wiki/United_States",
    "?:Cu31"
   ],
   [
    "=",
    "?:X",
    "#:Bristol 9"
   ],
   [
    "=",
    "?:X",
    "#:Texarkana 10"
   ],
   [
    "=",
    "?:X",
    "#:Texhoma 11"
   ],
   [
    "=",
    "?:X",
    "#:Union City 12"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "?:S1",
    "?:Cu31"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "?:S2",
    "?:Cu31"
   ],
   [
    "=",
    "?:S1",
    "?:S2"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "state",
    "sk0_state"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Saint_Pierre",
    "sk0_state",
    "?:Cu33"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Bismarck,_North_Dakota",
    "sk0_state",
    "?:Cu34"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "state",
    "?:S"
   ],
   [
    "-is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Saint_Pierre",
    "?:S",
    "?:Cu35"
   ],
   [
    "-is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Bismarck,_North_Dakota",
    "?:S",
    "?:Cu35"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "state",
   "$some_not_state"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "st pierre",
    "?:X"
   ],
   [
    "isa",
    "pierre",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "st",
    "?:X"
   ],
   [
    "-isa",
    "pierre",
    "?:X"
   ],
   [
    "isa",
    "st pierre",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "union city",
    "?:X"
   ],
   [
    "isa",
    "city",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "union",
    "?:X"
   ],
   [
    "-isa",
    "city",
    "?:X"
   ],
   [
    "isa",
    "union city",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "white sulphur spring",
    "?:X"
   ],
   [
    "isa",
    "spring",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "white sulphur",
    "?:X"
   ],
   [
    "-isa",
    "spring",
    "?:X"
   ],
   [
    "isa",
    "white sulphur spring",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]