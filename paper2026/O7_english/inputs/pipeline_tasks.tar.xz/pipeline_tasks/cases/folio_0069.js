[
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "organization",
   "#:Pappy's 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "bbc three",
   "#:BBC Three 3"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "the secret dude society",
   "#:The Secret Dude Society 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "man",
   "#:Andrew Collins 5"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "andrew collin",
   "#:Andrew Collins 5"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "sitcom series",
   "#:Badults 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "British",
   "#:Badults 1",
   "?:Cu7"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "star",
   "#:Badults 1",
   "#:Pappy's 2",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "organization",
   "#:BBC Three 3"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "pilot",
   "#:Badults 1",
   "#:BBC Three 3",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv9"
   ],
   [
    "$datetime",
    "July 2013"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is_past_world",
   "W0"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "artifact",
   "#:Badults 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "abstract",
   "#:The Secret Dude Society 4"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "working title of",
   "#:The Secret Dude Society 4",
   "#:Badults 1",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Andrew Collins 5"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "artifact",
   "#:Badults 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "script editor for",
   "#:Andrew Collins 5",
   "#:Badults 1",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "script editor for",
    "#:Andrew Collins 5",
    "#:Badults 1",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "script editor for",
    "#:Andrew Collins 5",
    "#:Badults 1",
    "?:Cu20"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "sitcom series",
    "?:X"
   ],
   [
    "isa",
    "series",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "sitcom",
    "?:X"
   ],
   [
    "-isa",
    "series",
    "?:X"
   ],
   [
    "isa",
    "sitcom series",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "andrew collin",
    "?:X"
   ],
   [
    "isa",
    "collin",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "andrew",
    "?:X"
   ],
   [
    "-isa",
    "collin",
    "?:X"
   ],
   [
    "isa",
    "andrew collin",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "bbc three",
    "?:X"
   ],
   [
    "isa",
    "three",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "bbc",
    "?:X"
   ],
   [
    "-isa",
    "three",
    "?:X"
   ],
   [
    "isa",
    "bbc three",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "the secret dude society",
    "?:X"
   ],
   [
    "isa",
    "society",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "the secret dude",
    "?:X"
   ],
   [
    "-isa",
    "society",
    "?:X"
   ],
   [
    "isa",
    "the secret dude society",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa_xg",
  "@logic": [
   [
    "-isa",
    "artifact",
    "?:X"
   ],
   [
    "-isa",
    "star",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa_xg",
  "@logic": [
   [
    "-isa",
    "artifact",
    "?:X"
   ],
   [
    "-isa",
    "star",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]