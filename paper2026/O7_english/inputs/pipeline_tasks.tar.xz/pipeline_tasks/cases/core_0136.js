[
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "she",
   "#:she 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "apple",
   "#:apple 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "-has degree property",
   "good",
   "#:apple 1",
   "none",
   "?:Fv17",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:she 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "room",
   "#:room 3"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "in",
   "#:she 2",
   "#:room 3",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "apple",
    "sk0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "room",
    "sk1_room"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "sk0",
    "sk1_room",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "apple",
    "?:X"
   ],
   [
    "-isa",
    "room",
    "?:Y"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "?:Y",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "in",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "in",
      "?:Br1",
      "?:Br2",
      [
       "$ctxt",
       "past",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 }
]