[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Susan 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has degree property",
   "new",
   "#:car 2",
   "none",
   "artifact",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "buy",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:Susan 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:car 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has recipient",
   "sk0_activity",
   "#:Susan 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "person",
    "#:Tom 2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "car",
    "sk1_car"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk2_activity",
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv12",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk2_activity",
    "#:Tom 2",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has target",
    "sk2_activity",
    "sk1_car",
    [
     "$ctxt",
     "past",
     "?:Fv16",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has time",
    "sk2_activity",
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv18",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "actuality",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Tom 2"
   ],
   [
    "-isa",
    "car",
    "?:X"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv26",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:Tom 2",
    [
     "$ctxt",
     "past",
     "?:Fv28",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv30",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv34",
     "?:Fv35",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv34",
     "?:Fv35",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv34",
     "?:Fv35",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "-next",
    "?:Fv35",
    "?:Fv36"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv36",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "?:Owner",
      "?:Obj",
      [
       "$ctxt",
       "present",
       "?:Fv36",
       "?:Fv37",
       "?:Fv38"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv39",
     "?:Fv40",
     "?:Fv42",
     "?:Fv43"
    ]
   ],
   [
    "-has beneficiary",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv39",
     "?:Fv40",
     "?:Fv42",
     "?:Fv43"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv39",
     "?:Fv40",
     "?:Fv42",
     "?:Fv43"
    ]
   ],
   [
    "-next",
    "?:Fv40",
    "?:Fv41"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv41",
     "?:Fv42",
     "?:Fv43"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv44",
     "?:Fv45",
     "?:Fv47",
     "?:Fv48"
    ]
   ],
   [
    "-has recipient",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv44",
     "?:Fv45",
     "?:Fv47",
     "?:Fv48"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv44",
     "?:Fv45",
     "?:Fv47",
     "?:Fv48"
    ]
   ],
   [
    "-next",
    "?:Fv45",
    "?:Fv46"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv46",
     "?:Fv47",
     "?:Fv48"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]