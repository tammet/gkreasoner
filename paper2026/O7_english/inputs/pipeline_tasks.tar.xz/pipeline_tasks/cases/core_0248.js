[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "uncle",
   "#:uncle 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Mary 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "uncle",
   [
    "$theof1",
    "uncle",
    "#:Mary 1",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "arrive",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   [
    "$theof1",
    "uncle",
    "#:Mary 1",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "uncle",
   [
    "$theof1",
    "uncle",
    "#:Mary 1",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:Mary 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "isa",
    "uncle",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "have",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    [
     "$ctxt",
     "present",
     "?:Fv10",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "uncle",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0",
   "?:X"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.97,
  "@logic": [
   [
    "-have",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "have",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "?:Br1",
      "?:Br2",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_theof",
  "@logic": [
   "have",
   "#:Mary 1",
   [
    "$theof1",
    "uncle",
    "#:Mary 1",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "frm_theof",
  "@logic": [
   "is rel2",
   "uncle of",
   [
    "$theof1",
    "uncle",
    "?:S",
    "?:C"
   ],
   "?:S",
   "?:C"
  ]
 },
 {
  "@name": "frm_theof",
  "@logic": [
   "isa",
   "uncle",
   [
    "$theof1",
    "uncle",
    "?:S",
    "?:C"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "uncle",
   "$some_uncle"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]