[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "plunger",
    "?:X"
   ],
   [
    "has property",
    "suck",
    "?:X",
    "?:Cu1"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "vacuum",
    "?:X"
   ],
   [
    "has property",
    "suck",
    "?:X",
    "?:Cu2"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "vampire",
    "?:X"
   ],
   [
    "has property",
    "suck",
    "?:X",
    "?:Cu3"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "vacuum",
   "#:Space 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "duster",
    "?:X"
   ],
   [
    "isa",
    "household appliance",
    "?:X"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "duster",
    "?:X"
   ],
   [
    "-has property",
    "suck",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "-isa",
    "household appliance",
    "?:X"
   ],
   [
    "has property",
    "suck",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "household appliance",
    "?:X"
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "suck",
    "?:X",
    "?:Cu9"
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0",
   "?:X"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "plunger",
   "$some_plunger"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "plunger",
   "$some_not_plunger"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "vacuum",
   "$some_not_vacuum"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "vampire",
   "$some_vampire"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "vampire",
   "$some_not_vampire"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "duster",
   "$some_duster"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "duster",
   "$some_not_duster"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "household appliance",
   "$some_household_appliance"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "household appliance",
   "$some_not_household_appliance"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "suck",
   "$some_suck",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "suck",
   "$some_not_suck",
   "?:Cu20"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "household appliance",
    "?:X"
   ],
   [
    "isa",
    "appliance",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "household",
    "?:X"
   ],
   [
    "-isa",
    "appliance",
    "?:X"
   ],
   [
    "isa",
    "household appliance",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]