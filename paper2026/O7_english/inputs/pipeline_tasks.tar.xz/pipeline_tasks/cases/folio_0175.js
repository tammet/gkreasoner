[
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "woman",
   "#:Taylor 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "eat",
    "?:X",
    "salad",
    "?:Cu2"
   ],
   [
    "has property",
    "conscious",
    "?:X",
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "eat",
    "?:X",
    "salad",
    "?:Cu3"
   ],
   [
    "is rel2",
    "conscious about",
    "?:X",
    "health",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "eat",
    "?:X",
    "salad",
    "?:Cu4"
   ],
   [
    "is rel2",
    "conscious about",
    "?:X",
    "eating habits",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "grow up",
    "?:X",
    "health-conscious childhood home",
    "?:Cu5"
   ],
   [
    "is rel2",
    "eat",
    "?:X",
    "salad",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "fulfill",
    "?:X",
    "daily nutritional intakes",
    "?:Cu6"
   ],
   [
    "is rel2",
    "grow up",
    "?:X",
    "health-conscious childhood home",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "ignore",
    "?:X",
    "physical well-being",
    "?:Cu7"
   ],
   [
    "has property",
    "conscious",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "ignore",
    "?:X",
    "physical well-being",
    "?:Cu8"
   ],
   [
    "-has property",
    "conscious",
    "?:X",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "ignore",
    "?:X",
    "physical well-being",
    "?:Cu9"
   ],
   [
    "-is rel2",
    "conscious about",
    "?:X",
    "health",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "ignore",
    "?:X",
    "physical well-being",
    "?:Cu10"
   ],
   [
    "-is rel2",
    "conscious about",
    "?:X",
    "eating habits",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "gym",
   "sk0_gym"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "visit",
    "?:X",
    "sk0_gym",
    "?:Cu12"
   ],
   [
    "is rel2",
    "fulfill",
    "?:X",
    "daily nutritional intakes",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Taylor 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "grow up",
    "#:Taylor 1",
    "health-conscious childhood home",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "ignore",
    "#:Taylor 1",
    "physical well-being",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "ignore",
    "#:Taylor 1",
    "physical well-being",
    "?:Cu16"
   ],
   [
    "-is rel2",
    "grow up",
    "#:Taylor 1",
    "health-conscious childhood home",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "grow up",
    "#:Taylor 1",
    "health-conscious childhood home",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "gym",
    "?:G"
   ],
   [
    "-is rel2",
    "visit",
    "#:Taylor 1",
    "?:G",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "grow up",
    "#:Taylor 1",
    "health-conscious childhood home",
    "?:Cu21"
   ],
   [
    "isa",
    "gym",
    "sk0_gym"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "grow up",
    "#:Taylor 1",
    "health-conscious childhood home",
    "?:Cu22"
   ],
   [
    "is rel2",
    "visit",
    "#:Taylor 1",
    "sk0_gym",
    "?:Cu22"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "gym",
   "$some_gym"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "gym",
   "$some_not_gym"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "conscious",
   "$some_conscious",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "conscious",
   "$some_not_conscious",
   "?:Cu28"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]