[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "penguin",
    "?:X"
   ],
   [
    "isa",
    "bird",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "penguin",
    "?:X"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "fly",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-capability",
    "?:E"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "has type",
    [
     "sk0",
     "?:X"
    ],
    "fly",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "has actor",
    [
     "sk0",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "capability",
    [
     "sk0",
     "?:X"
    ]
   ],
   [
    "$block",
    [
     "$",
     "bird",
     1
    ],
    [
     "$not",
     [
      "capability",
      [
       "sk0",
       "?:X"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "penguin",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk1_activity"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk1_activity",
    "fly",
    [
     "$ctxt",
     "?:Fv22",
     "?:Fv21",
     "?:Fv15",
     "?:Fv16"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk1_activity",
    "#:John 1",
    [
     "$ctxt",
     "?:Fv24",
     "?:Fv23",
     "?:Fv15",
     "?:Fv16"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "capability",
    "sk1_activity"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "fly",
    [
     "$ctxt",
     "?:Fv28",
     "?:Fv27",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:John 1",
    [
     "$ctxt",
     "?:Fv30",
     "?:Fv29",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "-capability",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "penguin",
   "$some_not_penguin"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "bird",
   "$some_bird"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bird",
   "$some_not_bird"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "fly",
    "?:Fv31"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv31"
   ]
  ],
  "@confidence": 0.52
 }
]