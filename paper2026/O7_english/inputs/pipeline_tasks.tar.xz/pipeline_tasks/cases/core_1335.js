[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "man",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has degree property",
   "good",
   "#:John 1",
   "none",
   "person",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "apple",
   "#:apple 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "have",
   "#:John 1",
   "#:apple 2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "man",
   "#:Mike 3"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has degree property",
   "good",
   "#:Mike 3",
   "none",
   "person",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "man",
   "#:Greg 4"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "-has degree property",
   "good",
   "#:Greg 4",
   "none",
   "person",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "pear",
   "#:pear 5"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "have",
   "#:Mike 3",
   "#:pear 5",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv9",
    "?:Fv10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "isa",
    "man",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has degree property",
    "good",
    "?:X",
    "none",
    "person",
    [
     "$ctxt",
     "?:Fv18",
     "?:Fv17",
     "?:Fv11",
     "?:Fv12"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "isa",
    "pear",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "have",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    [
     "$ctxt",
     "present",
     "?:Fv21",
     "?:Fv11",
     "?:Fv12"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "man",
    "?:X"
   ],
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "person",
    [
     "$ctxt",
     "?:Fv25",
     "?:Fv24",
     "?:Fv11",
     "?:Fv12"
    ]
   ],
   [
    "-isa",
    "pear",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    [
     "$ctxt",
     "present",
     "?:Fv28",
     "?:Fv11",
     "?:Fv12"
    ]
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0",
   "?:X"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question_bridge",
  "@confidence": 0.97,
  "@logic": [
   [
    "-have",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "have",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "?:Br1",
      "?:Br2",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "apple",
    "?:X"
   ],
   [
    "-isa",
    "pear",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "apple",
    "?:X"
   ],
   [
    "-isa",
    "pear",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "pear",
   "$some_pear"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "apple",
   "$some_apple"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "man",
   "$some_man"
  ]
 }
]