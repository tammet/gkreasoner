[
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "person",
   "#:James 1"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "man",
   "#:James 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "place",
   "sk0_place"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "schedule",
    "?:X",
    "customer",
    "?:Cu4"
   ],
   [
    "is rel2",
    "go",
    "?:X",
    "sk0_place",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "place",
   "sk0_place"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu6"
   ],
   [
    "is rel2",
    "schedule",
    "?:X",
    "customer",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "place",
   "sk0_place"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "-is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu10"
   ],
   [
    "isa",
    "home",
    [
     "sk3",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu11"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "?:C",
    "?:Cu12"
   ],
   [
    "isa",
    "home",
    [
     "sk4",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "?:C",
    "?:Cu13"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    [
     "sk4",
     "?:X"
    ],
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "manager",
    "?:X"
   ],
   [
    "isa",
    "home",
    [
     "sk5",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "manager",
    "?:X"
   ],
   [
    "-is rel2",
    "work",
    "?:X",
    [
     "sk5",
     "?:X"
    ],
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "place",
   "sk0_place"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "appear",
    "#:James 1",
    "sk0_place",
    "?:Cu17"
   ],
   [
    "isa",
    "manager",
    "#:James 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "manager",
    "#:James 1"
   ],
   [
    "is rel2",
    "appear",
    "#:James 1",
    "sk0_place",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "place",
    "sk0_place"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "place",
    "?:W"
   ],
   [
    "is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu21"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "place",
   "$some_place"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "place",
   "$some_not_place"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "employee",
   "$some_employee"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "employee",
   "$some_not_employee"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "home",
   "$some_home"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "home",
   "$some_not_home"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "country",
   "$some_country"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "country",
   "$some_not_country"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "manager",
   "$some_not_manager"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv35"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv35"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "receive",
    "?:Fv36"
   ],
   [
    "has type",
    "?:E",
    "have",
    "?:Fv36"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "country",
    "?:X"
   ],
   [
    "isa",
    "state",
    "?:X"
   ]
  ],
  "@confidence": 0.92
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "state",
    "?:X"
   ],
   [
    "isa",
    "country",
    "?:X"
   ]
  ],
  "@confidence": 0.92
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]