[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:People's Republic of China 3"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "people's republic of china",
   "#:People's Republic of China 3"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "northern china",
   "#:Northern China 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "2008 summer olympics",
   "2008 Summer Olympics 5"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "2008 summer paralympics",
   "2008 Summer Paralympics 6"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "event",
   "#:Winter Olympics 8"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "winter olympics",
   "#:Winter Olympics 8"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "event",
   "#:Winter Paralympics 10"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "winter paralympics",
   "#:Winter Paralympics 10"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "place",
   "Southern China"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "southern china",
   "Southern China"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "capital",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "place",
   "https://en.wikipedia.org/wiki/China"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "capital of",
   "#:capital 2",
   "https://en.wikipedia.org/wiki/China",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "capital",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "place",
   "https://en.wikipedia.org/wiki/China"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "capital of",
   "#:capital 2",
   "https://en.wikipedia.org/wiki/China",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "capital",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "place",
   "https://en.wikipedia.org/wiki/China"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "capital of",
   "#:capital 2",
   "https://en.wikipedia.org/wiki/China",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "place",
   "#:Northern China 4"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "in",
   "#:capital 2",
   "#:Northern China 4",
   "?:Cu25"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "event",
   "2008 Summer Olympics 5"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "host",
   "#:capital 2",
   "2008 Summer Olympics 5",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "event",
   "2008 Summer Paralympics 6"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "host",
   "#:capital 2",
   "2008 Summer Paralympics 6",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "event",
   "https://en.wikipedia.org/wiki/Summer_Paralympic_Games"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "host",
   "#:capital 2",
   "https://en.wikipedia.org/wiki/Summer_Paralympic_Games",
   "?:Cu34"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "event",
   "https://en.wikipedia.org/wiki/Summer_Paralympic_Games"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "host",
   "#:capital 2",
   "https://en.wikipedia.org/wiki/Summer_Paralympic_Games",
   "?:Cu37"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "event",
   "https://en.wikipedia.org/wiki/Summer_Paralympic_Games"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "host",
   "#:capital 2",
   "https://en.wikipedia.org/wiki/Summer_Paralympic_Games",
   "?:Cu40"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "event",
   "https://en.wikipedia.org/wiki/Summer_Paralympic_Games"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "is rel2",
   "host",
   "#:capital 2",
   "https://en.wikipedia.org/wiki/Summer_Paralympic_Games",
   "?:Cu43"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "isa",
   "place",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "=",
   91,
   [
    "$count",
    [
     "$setof",
     "id",
     "set_719478c7",
     [
      "$and",
      [
       "isa",
       "university",
       "$arg1"
      ],
      [
       "is rel2",
       "of",
       "$arg1",
       "#:capital 2"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "set_719478c7",
     [
      "$and",
      [
       "isa",
       "university",
       "$arg1"
      ],
      [
       "is rel2",
       "of",
       "$arg1",
       "#:capital 2"
      ]
     ]
    ]
   ],
   [
    "has property",
    "best",
    "?:M",
    "?:Cu46"
   ]
  ],
  "@confidence": 0.4
 },
 {
  "@name": "sent_S11_el1",
  "@logic": [
   "isa",
   "university",
   "$set1_el1"
  ]
 },
 {
  "@name": "sent_S11_el1",
  "@logic": [
   "is rel2",
   "of",
   "$set1_el1",
   "#:capital 2",
   "?:Cu48"
  ]
 },
 {
  "@name": "sent_S11_el1",
  "@logic": [
   "member",
   "$set1_el1",
   [
    "$setof",
    "id",
    "set_719478c7",
    [
     "$and",
     [
      "isa",
      "university",
      "$arg1"
     ],
     [
      "is rel2",
      "of",
      "$arg1",
      "#:capital 2"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S11_el2",
  "@logic": [
   "isa",
   "university",
   "$set1_el2"
  ]
 },
 {
  "@name": "sent_S11_el2",
  "@logic": [
   "is rel2",
   "of",
   "$set1_el2",
   "#:capital 2",
   "?:Cu51"
  ]
 },
 {
  "@name": "sent_S11_el2",
  "@logic": [
   "member",
   "$set1_el2",
   [
    "$setof",
    "id",
    "set_719478c7",
    [
     "$and",
     [
      "isa",
      "university",
      "$arg1"
     ],
     [
      "is rel2",
      "of",
      "$arg1",
      "#:capital 2"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S11_el3",
  "@logic": [
   "isa",
   "university",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S11_el3",
  "@logic": [
   "is rel2",
   "of",
   "$set1_el3",
   "#:capital 2",
   "?:Cu54"
  ]
 },
 {
  "@name": "sent_S11_el3",
  "@logic": [
   "member",
   "$set1_el3",
   [
    "$setof",
    "id",
    "set_719478c7",
    [
     "$and",
     [
      "isa",
      "university",
      "$arg1"
     ],
     [
      "is rel2",
      "of",
      "$arg1",
      "#:capital 2"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S11_dist",
  "@logic": [
   "-=",
   "$set1_el1",
   "$set1_el2"
  ]
 },
 {
  "@name": "sent_S11_dist",
  "@logic": [
   "-=",
   "$set1_el1",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S11_dist",
  "@logic": [
   "-=",
   "$set1_el2",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "place",
    "#:capital 2"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "#:capital 2",
    "Southern China",
    "?:Cu60"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "place",
    "#:capital 2"
   ],
   [
    "-is rel2",
    "in",
    "#:capital 2",
    "Southern China",
    "?:Cu61"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "have",
   "https://en.wikipedia.org/wiki/China",
   "#:capital 2",
   "?:Cu62"
  ]
 },
 {
  "@name": "sent_S12",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-isa",
    "?:c",
    "?:M"
   ],
   [
    "-is rel2",
    "?:D",
    "?:M",
    "?:E"
   ],
   [
    "member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:c",
       "$arg1"
      ],
      [
       "is rel2",
       "?:D",
       "$arg1",
       "?:E"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:c",
       "$arg1"
      ],
      [
       "is rel2",
       "?:D",
       "$arg1",
       "?:E"
      ]
     ]
    ]
   ],
   [
    "isa",
    "?:c",
    "?:M"
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:c",
       "$arg1"
      ],
      [
       "is rel2",
       "?:D",
       "$arg1",
       "?:E"
      ]
     ]
    ]
   ],
   [
    "is rel2",
    "?:D",
    "?:M",
    "?:E"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "best",
   "$some_best",
   "?:Cu67"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "best",
   "$some_not_best",
   "?:Cu68"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "2008 summer olympics",
    "?:X"
   ],
   [
    "isa",
    "olympics",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "2008 summer",
    "?:X"
   ],
   [
    "-isa",
    "olympics",
    "?:X"
   ],
   [
    "isa",
    "2008 summer olympics",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "2008 summer paralympics",
    "?:X"
   ],
   [
    "isa",
    "paralympics",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "2008 summer",
    "?:X"
   ],
   [
    "-isa",
    "paralympics",
    "?:X"
   ],
   [
    "isa",
    "2008 summer paralympics",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "northern china",
    "?:X"
   ],
   [
    "isa",
    "china",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "northern",
    "?:X"
   ],
   [
    "-isa",
    "china",
    "?:X"
   ],
   [
    "isa",
    "northern china",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "people's republic of china",
    "?:X"
   ],
   [
    "isa",
    "china",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "people's republic of",
    "?:X"
   ],
   [
    "-isa",
    "china",
    "?:X"
   ],
   [
    "isa",
    "people's republic of china",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "southern china",
    "?:X"
   ],
   [
    "isa",
    "china",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "isa",
    "northern",
    "?:X"
   ],
   [
    "-isa",
    "china",
    "?:X"
   ],
   [
    "isa",
    "southern china",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "winter olympics",
    "?:X"
   ],
   [
    "isa",
    "olympics",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "winter",
    "?:X"
   ],
   [
    "-isa",
    "olympics",
    "?:X"
   ],
   [
    "isa",
    "winter olympics",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "winter paralympics",
    "?:X"
   ],
   [
    "isa",
    "paralympics",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "winter",
    "?:X"
   ],
   [
    "-isa",
    "paralympics",
    "?:X"
   ],
   [
    "isa",
    "winter paralympics",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]