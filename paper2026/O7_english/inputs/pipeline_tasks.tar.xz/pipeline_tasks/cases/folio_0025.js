[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Beijing 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:People's Republic of China 3"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "people's republic of china",
   "#:People's Republic of China 3"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "place",
   "#:Northern China 6"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "northern china",
   "#:Northern China 6"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "event",
   "2008 Summer Olympics 7"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "2008 summer olympics",
   "2008 Summer Olympics 7"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "event",
   "2008 Summer Paralympics Games 8"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "2008 summer paralympics games",
   "2008 Summer Paralympics Games 8"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "event",
   "#:Winter Olympics 10"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "winter olympics",
   "#:Winter Olympics 10"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "event",
   "#:Summer Paralympics 11"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "summer paralympics",
   "#:Summer Paralympics 11"
  ]
 },
 {
  "@name": "entity_S11",
  "@logic": [
   "isa",
   "event",
   "#:Winter Paralympics 12"
  ]
 },
 {
  "@name": "entity_S11",
  "@logic": [
   "isa",
   "winter paralympics",
   "#:Winter Paralympics 12"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "capital",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "capital of",
   "#:Beijing 1",
   "#:Northern China 6",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "capital",
   "#:capital 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "capital of",
   "#:Beijing 1",
   "#:Northern China 6",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "capital city",
   "#:capital city 4"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "nation",
   "#:nation 5"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has property",
   "populous",
   "#:nation 5",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "capital city of",
   "#:Beijing 1",
   "#:nation 5",
   "?:Cu23"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "capital city",
   "#:capital city 4"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "nation",
   "#:nation 5"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "capital city of",
   "#:Beijing 1",
   "#:nation 5",
   "?:Cu26"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "in",
   "#:Beijing 1",
   "#:Northern China 6",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "host",
   "#:Beijing 1",
   "2008 Summer Olympics 7",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "host",
   "#:Beijing 1",
   "2008 Summer Paralympics Games 8",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "host",
   "#:Beijing 1",
   "2008 Summer Olympics 7",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "host",
   "#:Beijing 1",
   "#:Winter Olympics 10",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "is rel2",
   "host",
   "#:Beijing 1",
   "#:Summer Paralympics 11",
   "?:Cu32"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "is rel2",
   "host",
   "#:Beijing 1",
   "#:Winter Paralympics 12",
   "?:Cu33"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "=",
   91,
   [
    "$count",
    [
     "$setof",
     "id",
     "set_ee285d98",
     [
      "$and",
      [
       "isa",
       "university",
       "$arg1"
      ],
      [
       "is rel2",
       "in",
       "$arg1",
       "#:Beijing 1"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S12_el1",
  "@logic": [
   "isa",
   "university",
   "$set1_el1"
  ]
 },
 {
  "@name": "sent_S12_el1",
  "@logic": [
   "is rel2",
   "in",
   "$set1_el1",
   "#:Beijing 1",
   "?:Cu36"
  ]
 },
 {
  "@name": "sent_S12_el1",
  "@logic": [
   "member",
   "$set1_el1",
   [
    "$setof",
    "id",
    "set_ee285d98",
    [
     "$and",
     [
      "isa",
      "university",
      "$arg1"
     ],
     [
      "is rel2",
      "in",
      "$arg1",
      "#:Beijing 1"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S12_el2",
  "@logic": [
   "isa",
   "university",
   "$set1_el2"
  ]
 },
 {
  "@name": "sent_S12_el2",
  "@logic": [
   "is rel2",
   "in",
   "$set1_el2",
   "#:Beijing 1",
   "?:Cu39"
  ]
 },
 {
  "@name": "sent_S12_el2",
  "@logic": [
   "member",
   "$set1_el2",
   [
    "$setof",
    "id",
    "set_ee285d98",
    [
     "$and",
     [
      "isa",
      "university",
      "$arg1"
     ],
     [
      "is rel2",
      "in",
      "$arg1",
      "#:Beijing 1"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S12_el3",
  "@logic": [
   "isa",
   "university",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S12_el3",
  "@logic": [
   "is rel2",
   "in",
   "$set1_el3",
   "#:Beijing 1",
   "?:Cu42"
  ]
 },
 {
  "@name": "sent_S12_el3",
  "@logic": [
   "member",
   "$set1_el3",
   [
    "$setof",
    "id",
    "set_ee285d98",
    [
     "$and",
     [
      "isa",
      "university",
      "$arg1"
     ],
     [
      "is rel2",
      "in",
      "$arg1",
      "#:Beijing 1"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S12_dist",
  "@logic": [
   "-=",
   "$set1_el1",
   "$set1_el2"
  ]
 },
 {
  "@name": "sent_S12_dist",
  "@logic": [
   "-=",
   "$set1_el1",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S12_dist",
  "@logic": [
   "-=",
   "$set1_el2",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S13",
  "@logic": [
   "isa",
   "university",
   "sk0_university"
  ],
  "@confidence": 0.7368
 },
 {
  "@name": "sent_S13",
  "@logic": [
   "is rel2",
   "in",
   "sk0_university",
   "#:Beijing 1",
   "?:Cu48"
  ],
  "@confidence": 0.7368
 },
 {
  "@name": "sent_S13",
  "@logic": [
   "has property",
   "best",
   "sk0_university",
   "?:Cu49"
  ],
  "@confidence": 0.7368
 },
 {
  "@name": "sent_S14",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "host",
    "#:Beijing 1",
    "2008 Summer Olympics 7",
    "?:Cu50"
   ]
  ]
 },
 {
  "@name": "sent_S14",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "host",
    "#:Beijing 1",
    "#:Winter Olympics 10",
    "?:Cu51"
   ]
  ]
 },
 {
  "@name": "sent_S14",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "host",
    "#:Beijing 1",
    "2008 Summer Olympics 7",
    "?:Cu52"
   ],
   [
    "-is rel2",
    "host",
    "#:Beijing 1",
    "#:Winter Olympics 10",
    "?:Cu52"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S14",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-isa",
    "?:c",
    "?:M"
   ],
   [
    "-is rel2",
    "?:D",
    "?:M",
    "?:E"
   ],
   [
    "member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:c",
       "$arg1"
      ],
      [
       "is rel2",
       "?:D",
       "$arg1",
       "?:E"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:c",
       "$arg1"
      ],
      [
       "is rel2",
       "?:D",
       "$arg1",
       "?:E"
      ]
     ]
    ]
   ],
   [
    "isa",
    "?:c",
    "?:M"
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:c",
       "$arg1"
      ],
      [
       "is rel2",
       "?:D",
       "$arg1",
       "?:E"
      ]
     ]
    ]
   ],
   [
    "is rel2",
    "?:D",
    "?:M",
    "?:E"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "university",
   "$some_university"
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "university",
   "$some_not_university"
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "best",
   "$some_best",
   "?:Cu60"
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "best",
   "$some_not_best",
   "?:Cu61"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "2008 summer olympics",
    "?:X"
   ],
   [
    "isa",
    "olympics",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "2008 summer",
    "?:X"
   ],
   [
    "-isa",
    "olympics",
    "?:X"
   ],
   [
    "isa",
    "2008 summer olympics",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "2008 summer paralympics games",
    "?:X"
   ],
   [
    "isa",
    "games",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "2008 summer paralympics",
    "?:X"
   ],
   [
    "-isa",
    "games",
    "?:X"
   ],
   [
    "isa",
    "2008 summer paralympics games",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "capital city",
    "?:X"
   ],
   [
    "isa",
    "city",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "capital",
    "?:X"
   ],
   [
    "-isa",
    "city",
    "?:X"
   ],
   [
    "isa",
    "capital city",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "northern china",
    "?:X"
   ],
   [
    "isa",
    "china",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "northern",
    "?:X"
   ],
   [
    "-isa",
    "china",
    "?:X"
   ],
   [
    "isa",
    "northern china",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "people's republic of china",
    "?:X"
   ],
   [
    "isa",
    "china",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "people's republic of",
    "?:X"
   ],
   [
    "-isa",
    "china",
    "?:X"
   ],
   [
    "isa",
    "people's republic of china",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "summer paralympics",
    "?:X"
   ],
   [
    "isa",
    "paralympics",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "summer",
    "?:X"
   ],
   [
    "-isa",
    "paralympics",
    "?:X"
   ],
   [
    "isa",
    "summer paralympics",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "winter olympics",
    "?:X"
   ],
   [
    "isa",
    "olympics",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "winter",
    "?:X"
   ],
   [
    "-isa",
    "olympics",
    "?:X"
   ],
   [
    "isa",
    "winter olympics",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "winter paralympics",
    "?:X"
   ],
   [
    "isa",
    "paralympics",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "winter",
    "?:X"
   ],
   [
    "-isa",
    "paralympics",
    "?:X"
   ],
   [
    "isa",
    "winter paralympics",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "nation",
    "?:X"
   ],
   [
    "isa",
    "state",
    "?:X"
   ]
  ],
  "@confidence": 0.93
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "state",
    "?:X"
   ],
   [
    "isa",
    "nation",
    "?:X"
   ]
  ],
  "@confidence": 0.93
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]