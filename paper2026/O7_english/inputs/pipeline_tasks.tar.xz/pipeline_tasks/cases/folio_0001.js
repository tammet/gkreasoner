[
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "club",
   "#:club 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu2"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu2"
   ],
   [
    "is rel2",
    "attend",
    "?:X",
    "school event",
    "?:Cu2"
   ]
  ],
  "@confidence": 0.96
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu3"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu3"
   ],
   [
    "isa",
    "school event",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu4"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu4"
   ],
   [
    "is rel2",
    "engaged with",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu4"
   ]
  ],
  "@confidence": 0.96
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu5"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu5"
   ],
   [
    "isa",
    "community member",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu6"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu6"
   ],
   [
    "=",
    "?:X",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu7"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu7"
   ],
   [
    "has property",
    "inactive",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu8"
   ],
   [
    "is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu8"
   ],
   [
    "has property",
    "disinterested",
    "?:X",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu9"
   ],
   [
    "-is rel2",
    "perform",
    "?:X",
    "school talent show",
    "?:Cu9"
   ],
   [
    "-isa",
    "community member",
    "?:Z"
   ],
   [
    "-=",
    "?:X",
    "?:Z"
   ],
   [
    "-has property",
    "inactive",
    "?:X",
    "?:Cu9"
   ],
   [
    "-has property",
    "disinterested",
    "?:X",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu10"
   ],
   [
    "-is rel2",
    "chaperone",
    "?:X",
    "high school dance",
    "?:Cu10"
   ],
   [
    "-isa",
    "student",
    "?:S"
   ],
   [
    "-=",
    "?:X",
    "?:S"
   ],
   [
    "-is rel2",
    "attend",
    "?:S",
    "school",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu11"
   ],
   [
    "-has property",
    "inactive",
    "?:X",
    "?:Cu11"
   ],
   [
    "-has property",
    "disinterested",
    "?:X",
    "?:Cu11"
   ],
   [
    "is rel2",
    "chaperone",
    "?:X",
    "high school dance",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-has property",
    "young",
    "?:X",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu12"
   ],
   [
    "isa",
    "student",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-has property",
    "young",
    "?:X",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu13"
   ],
   [
    "is rel2",
    "attend",
    "?:X",
    "school",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu14"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu14"
   ],
   [
    "isa",
    "student",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "this club",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "wish",
    "?:X",
    "attend",
    "?:Cu15"
   ],
   [
    "is rel2",
    "attend",
    "?:X",
    "school",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:Bonnie 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "organization",
   "#:club 2"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "in",
   "#:Bonnie 1",
   "#:club 2",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu20"
   ],
   [
    "-isa",
    "school event",
    "?:Z"
   ],
   [
    "-is rel2",
    "engaged with",
    "#:Bonnie 1",
    "?:Z",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu21"
   ],
   [
    "-isa",
    "student",
    "?:S"
   ],
   [
    "-=",
    "#:Bonnie 1",
    "?:S"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "school event",
    "sk2_school event"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "school event",
    "sk2_school event"
   ],
   [
    "-isa",
    "school event",
    "?:Z"
   ],
   [
    "-is rel2",
    "engaged with",
    "#:Bonnie 1",
    "?:Z",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "school event",
    "sk2_school event"
   ],
   [
    "-isa",
    "student",
    "?:S"
   ],
   [
    "-=",
    "#:Bonnie 1",
    "?:S"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "engaged with",
    "#:Bonnie 1",
    "sk2_school event",
    "?:Cu25"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "engaged with",
    "#:Bonnie 1",
    "sk2_school event",
    "?:Cu26"
   ],
   [
    "-isa",
    "school event",
    "?:Z"
   ],
   [
    "-is rel2",
    "engaged with",
    "#:Bonnie 1",
    "?:Z",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "engaged with",
    "#:Bonnie 1",
    "sk2_school event",
    "?:Cu27"
   ],
   [
    "-isa",
    "student",
    "?:S"
   ],
   [
    "-=",
    "#:Bonnie 1",
    "?:S"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu27"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "student",
    "sk3_student"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "student",
    "sk3_student"
   ],
   [
    "-isa",
    "school event",
    "?:Z"
   ],
   [
    "-is rel2",
    "engaged with",
    "#:Bonnie 1",
    "?:Z",
    "?:Cu29"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "student",
    "sk3_student"
   ],
   [
    "-isa",
    "student",
    "?:S"
   ],
   [
    "-=",
    "#:Bonnie 1",
    "?:S"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu30"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "=",
    "#:Bonnie 1",
    "sk3_student"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu31"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "=",
    "#:Bonnie 1",
    "sk3_student"
   ],
   [
    "-isa",
    "school event",
    "?:Z"
   ],
   [
    "-is rel2",
    "engaged with",
    "#:Bonnie 1",
    "?:Z",
    "?:Cu32"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "=",
    "#:Bonnie 1",
    "sk3_student"
   ],
   [
    "-isa",
    "student",
    "?:S"
   ],
   [
    "-=",
    "#:Bonnie 1",
    "?:S"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu33"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu34"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu34"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu35"
   ],
   [
    "-isa",
    "school event",
    "?:Z"
   ],
   [
    "-is rel2",
    "engaged with",
    "#:Bonnie 1",
    "?:Z",
    "?:Cu35"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu43"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "perform",
    "#:Bonnie 1",
    "school talent show",
    "?:Cu44"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "school event",
   "$some_school_event"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "school event",
   "$some_not_school_event"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "community member",
   "$some_community_member"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "student",
   "$some_student"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "student",
   "$some_not_student"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "inactive",
   "$some_inactive",
   "?:Cu50"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "inactive",
   "$some_not_inactive",
   "?:Cu51"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "disinterested",
   "$some_disinterested",
   "?:Cu52"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "disinterested",
   "$some_not_disinterested",
   "?:Cu53"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "young",
   "$some_young",
   "?:Cu54"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "young",
   "$some_not_young",
   "?:Cu55"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "community member",
    "?:X"
   ],
   [
    "isa",
    "member",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "community",
    "?:X"
   ],
   [
    "-isa",
    "member",
    "?:X"
   ],
   [
    "isa",
    "community member",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "school event",
    "?:X"
   ],
   [
    "isa",
    "event",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "school",
    "?:X"
   ],
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "isa",
    "school event",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "attend",
    "#:Bonnie 1",
    "school event",
    "?:Cu67"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 1"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu67"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "school event",
    "sk2_school event"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 1"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu68"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "is rel2",
    "engaged with",
    "#:Bonnie 1",
    "sk2_school event",
    "?:Cu69"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 1"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu69"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "isa",
    "student",
    "sk3_student"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 1"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu70"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "=",
    "#:Bonnie 1",
    "sk3_student"
   ],
   [
    "-isa",
    "student",
    "#:Bonnie 1"
   ],
   [
    "-is rel2",
    "attend",
    "#:Bonnie 1",
    "school",
    "?:Cu71"
   ]
  ]
 }
]