[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "occur in",
    "Monkeypox virus",
    "?:X",
    "?:Cu1"
   ],
   [
    "is rel2",
    "give",
    "?:X",
    "Monkeypox",
    "?:Cu1"
   ]
  ],
  "@confidence": 0.2
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "is rel2",
    "occur in",
    "Monkeypox virus",
    "?:X",
    "?:Cu2"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "human",
    "?:X"
   ],
   [
    "isa",
    "mammal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "mammal",
    "?:X"
   ],
   [
    "isa",
    "animal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "symptom of",
   "fever",
   "Monkeypox",
   "?:Cu5"
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "symptom of",
   "worry",
   "Monkeypox",
   "?:Cu6"
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "symptom of",
   "muscle pains",
   "Monkeypox",
   "?:Cu7"
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "symptom of",
   "tiredness",
   "Monkeypox",
   "?:Cu8"
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "-is rel2",
    "give",
    "?:X",
    "flu",
    "?:Cu9"
   ],
   [
    "has property",
    "tired",
    "?:X",
    "?:Cu9"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "give",
    "?:X",
    "flu",
    "?:Cu10"
   ],
   [
    "-isa",
    "people",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "person",
    "sk0_person"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "give",
    "sk0_person",
    "flu",
    "?:Cu12"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "people",
    "sk0_person"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_animal"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "human",
   "$some_human"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "human",
   "$some_not_human"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "mammal",
   "$some_mammal"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "mammal",
   "$some_not_mammal"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "tired",
   "$some_tired",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "tired",
   "$some_not_tired",
   "?:Cu22"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv49"
   ],
   [
    "has type",
    "?:E",
    "give",
    "?:Fv49"
   ]
  ],
  "@confidence": 0.91
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "people",
    "?:X"
   ],
   [
    "isa",
    "following",
    "?:X"
   ]
  ],
  "@confidence": 0.61
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "following",
    "?:X"
   ],
   [
    "isa",
    "people",
    "?:X"
   ]
  ],
  "@confidence": 0.61
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]