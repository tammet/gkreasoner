[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "breeding back",
   "#:Breeding back 1"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "heck cattle",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "animal",
   "#:aurochs 2"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "auroch",
   "#:aurochs 2"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "auroch",
   "#:aurochs 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "abstract",
   "#:Breeding back 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "artificial selection",
   "#:artificial selection 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "form of",
   "#:Breeding back 1",
   "#:artificial selection 2",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "breed",
   "#:Breeding back 1",
   "domestic animal",
   "?:Cu9"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "animal",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has property",
   "breed",
   "#:Heck cattle 1",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv9"
   ],
   [
    "$datetime",
    "1920s"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is_past_world",
   "W0"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "animal",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "animal",
   "https://en.wikipedia.org/wiki/Aurochs"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "resembling",
   "#:Heck cattle 1",
   "https://en.wikipedia.org/wiki/Aurochs",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "animal",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "animal",
   "https://en.wikipedia.org/wiki/Aurochs"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "animal",
   "sk0_animal"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "animal",
   "sk1_animal"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "has property",
   "extinct",
   "sk1_animal",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "resembling",
   "sk0_animal",
   "sk1_animal",
   "?:Cu22"
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "has property",
    "extinct",
    "?:X",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "animal",
    "sk2_animal"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "extinct",
    "sk2_animal",
    "?:Cu25"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "extinct",
   "$some_extinct",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "extinct",
   "$some_not_extinct",
   "?:Cu28"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "artificial selection",
    "?:X"
   ],
   [
    "isa",
    "selection",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "bogus",
    "?:X"
   ],
   [
    "-isa",
    "selection",
    "?:X"
   ],
   [
    "isa",
    "artificial selection",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "breeding back",
    "?:X"
   ],
   [
    "isa",
    "back",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "breeding",
    "?:X"
   ],
   [
    "-isa",
    "back",
    "?:X"
   ],
   [
    "isa",
    "breeding back",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "heck cattle",
    "?:X"
   ],
   [
    "isa",
    "cattle",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "heck",
    "?:X"
   ],
   [
    "-isa",
    "cattle",
    "?:X"
   ],
   [
    "isa",
    "heck cattle",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]