[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "elephant",
   "sk0_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "isa",
    "animal",
    "sk0_elephant"
   ],
   [
    "$block",
    [
     "$",
     "$generic",
     1
    ],
    [
     "$not",
     [
      "isa",
      "animal",
      "sk0_elephant"
     ]
    ]
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "elephant",
    "sk1_elephant"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "animal",
    "sk1_elephant"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "isa",
    "animal",
    "?:X"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "elephant",
   "$some_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "elephant",
   "$some_not_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 }
]