[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "man",
   "#:man 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has degree property",
   "tall",
   "#:man 1",
   "none",
   "person",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "-has degree property",
   "active",
   "#:man 1",
   "none",
   "person",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "enter",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:man 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "woman",
    "sk1_woman"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk2_activity",
    "enter",
    [
     "$ctxt",
     "past",
     "?:Fv10",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk2_activity",
    "sk1_woman",
    [
     "$ctxt",
     "past",
     "?:Fv12",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has time",
    "sk2_activity",
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "actuality",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "woman",
    "?:X"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "enter",
    [
     "$ctxt",
     "past",
     "?:Fv20",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv22",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has degree property",
    "tall",
    "?:X",
    "none",
    "?:Fv43",
    "?:Fv26"
   ],
   [
    "has degree property",
    "high",
    "?:X",
    "none",
    "?:Fv44",
    "?:Fv26"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has degree property",
    "high",
    "?:X",
    "none",
    "?:Fv45",
    "?:Fv27"
   ],
   [
    "has degree property",
    "tall",
    "?:X",
    "none",
    "?:Fv46",
    "?:Fv27"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "man",
    "?:X",
    "?:Fv28"
   ],
   [
    "-has property",
    "woman",
    "?:X",
    "?:Fv28"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "tall",
    "?:X",
    "none",
    "?:Fv47",
    [
     "$ctxt",
     "past",
     "?:Fv29",
     "?:Fv30",
     "?:Fv31"
    ]
   ],
   [
    "has degree property",
    "tall",
    "?:X",
    "none",
    "?:Fv48",
    [
     "$ctxt",
     "present",
     "?:Fv29",
     "?:Fv30",
     "?:Fv31"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "tall",
      "?:X",
      "none",
      "?:Fv49",
      [
       "$ctxt",
       "present",
       "?:Fv29",
       "?:Fv30",
       "?:Fv31"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "tall",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv32",
     "?:Fv33",
     "?:Fv34"
    ]
   ],
   [
    "has degree property",
    "tall",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv32",
     "?:Fv33",
     "?:Fv34"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "tall",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv32",
       "?:Fv33",
       "?:Fv34"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]