[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "event",
   "1992 du Maurier Classic 2"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "1992 du maurier classic",
   "1992 du Maurier Classic 2"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:Steinhauer 3"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "place",
   "#:Belgium 7"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "winner",
   "#:Steinhauer 3"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "winner",
   "#:Steinhauer 3"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "winner of",
   "#:Steinhauer 3",
   "1992 du Maurier Classic 2",
   "?:Cu7"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "participate",
   "#:Steinhauer 3",
   "1992 du Maurier Classic 2",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "six-way tie",
   "#:six-way tie 4"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "leaderboard",
   "#:leaderboard 5"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "on",
   "#:six-way tie 4",
   "#:leaderboard 5",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:person 6"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "six-way tie",
   "#:six-way tie 4"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "in",
   "#:person 6",
   "#:six-way tie 4",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "from",
   "#:person 6",
   "#:Belgium 7",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Descampe 8"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "from",
   "#:Descampe 8",
   "#:Belgium 7",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Descampe 8"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "leaderboard",
   "#:leaderboard 5"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "on",
   "#:Descampe 8",
   "#:leaderboard 5",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-is rel2",
    "on",
    "?:X",
    "#:leaderboard 5",
    "?:Cu21"
   ],
   [
    "is rel2",
    "participate",
    "?:X",
    "1992 du Maurier Classic 2",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "winner",
    "#:Steinhauer 3"
   ],
   [
    "-is rel2",
    "winner of",
    "#:Steinhauer 3",
    "1992 du Maurier Classic 2",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "winner",
    "#:Steinhauer 3"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "winner of",
    "#:Steinhauer 3",
    "1992 du Maurier Classic 2",
    "?:Cu25"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "have",
   "1992 du Maurier Classic 2",
   "#:Steinhauer 3",
   "?:Cu26"
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "1992 du maurier classic",
    "?:X"
   ],
   [
    "isa",
    "classic",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "1992 du maurier",
    "?:X"
   ],
   [
    "-isa",
    "classic",
    "?:X"
   ],
   [
    "isa",
    "1992 du maurier classic",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "six-way tie",
    "?:X"
   ],
   [
    "isa",
    "tie",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "six-way",
    "?:X"
   ],
   [
    "-isa",
    "tie",
    "?:X"
   ],
   [
    "isa",
    "six-way tie",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]