[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "diamond mine",
   "#:Diamond Mine 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "organization",
   "#:WWE 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "person",
   "#:Roderick Strong 3"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "roderick strong",
   "#:Roderick Strong 3"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "organization",
   "#:Creed Brothers 4"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "creed brother",
   "#:Creed Brothers 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "person",
   "#:Ivy Nile 5"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "woman",
   "#:Ivy Nile 5"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "ivy nile",
   "#:Ivy Nile 5"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "organization",
   "#:Imperium 6"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "professional wrestling stable",
   "#:Diamond Mine 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "formed in",
   "#:Diamond Mine 1",
   "#:WWE 2",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "lead",
   "#:Roderick Strong 3",
   "#:Diamond Mine 1",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "includes",
   "#:Diamond Mine 1",
   "#:Creed Brothers 4",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "includes",
   "#:Diamond Mine 1",
   "#:Ivy Nile 5",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "feud with",
   "#:Imperium 6",
   "#:Diamond Mine 1",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "professional wrestling stable",
    "sk0_professional wrestling stable"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "lead",
    "#:Roderick Strong 3",
    "sk0_professional wrestling stable",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "professional wrestling stable",
    "?:X"
   ],
   [
    "-is rel2",
    "lead",
    "#:Roderick Strong 3",
    "?:X",
    "?:Cu19"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "creed brother",
    "?:X"
   ],
   [
    "isa",
    "brother",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "creed",
    "?:X"
   ],
   [
    "-isa",
    "brother",
    "?:X"
   ],
   [
    "isa",
    "creed brother",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "diamond mine",
    "?:X"
   ],
   [
    "isa",
    "mine",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "diamond",
    "?:X"
   ],
   [
    "-isa",
    "mine",
    "?:X"
   ],
   [
    "isa",
    "diamond mine",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "ivy nile",
    "?:X"
   ],
   [
    "isa",
    "nile",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "ivy",
    "?:X"
   ],
   [
    "-isa",
    "nile",
    "?:X"
   ],
   [
    "isa",
    "ivy nile",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "professional wrestling stable",
    "?:X"
   ],
   [
    "isa",
    "stable",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "professional wrestling",
    "?:X"
   ],
   [
    "-isa",
    "stable",
    "?:X"
   ],
   [
    "isa",
    "professional wrestling stable",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "roderick strong",
    "?:X"
   ],
   [
    "isa",
    "strong",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "roderick",
    "?:X"
   ],
   [
    "-isa",
    "strong",
    "?:X"
   ],
   [
    "isa",
    "roderick strong",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "brother",
    "?:Xg"
   ],
   [
    "isa",
    "man",
    "?:Xg"
   ]
  ]
 }
]