[
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "class",
   "#:class 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "man",
    "?:X"
   ],
   [
    "-is rel2",
    "taller than",
    "?:X",
    "?:Y",
    "?:Cu2"
   ],
   [
    "isa",
    "shooting",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "man",
    "?:X"
   ],
   [
    "-is rel2",
    "taller than",
    "?:X",
    "?:Y",
    "?:Cu3"
   ],
   [
    "is rel2",
    "of",
    [
     "sk0",
     "?:X"
    ],
    "?:Y",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "man",
    "?:X"
   ],
   [
    "-is rel2",
    "taller than",
    "?:X",
    "?:Y",
    "?:Cu4"
   ],
   [
    "is rel2",
    "block",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu4"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "man",
   "#:Michael 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "member of",
    "?:X",
    "#:class 2",
    "?:Cu6"
   ],
   [
    "=",
    "?:X",
    "#:Michael 1"
   ],
   [
    "is rel2",
    "taller than",
    "#:Michael 1",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "organization",
   "#:class 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "member of",
   "#:Michael 1",
   "#:class 2",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "taller than",
    "?:X",
    "?:Y",
    "?:Cu9"
   ],
   [
    "-is rel2",
    "taller than",
    "?:Y",
    "?:Z",
    "?:Cu9"
   ],
   [
    "is rel2",
    "taller than",
    "?:X",
    "?:Z",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "man",
   "#:Peter 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Peter 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Michael 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "taller than",
   "#:Peter 3",
   "#:Michael 1",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "has property",
    "jump",
    "?:X",
    "?:Cu14"
   ],
   [
    "isa",
    "shooting",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "has property",
    "jump",
    "?:X",
    "?:Cu15"
   ],
   [
    "is rel2",
    "of",
    [
     "sk1",
     "?:X"
    ],
    "?:X",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "has property",
    "jump",
    "?:X",
    "?:Cu16"
   ],
   [
    "is rel2",
    "block",
    "#:Michael 1",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu16"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "person",
   "#:Michael 1"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "person",
   "#:Windy 4"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "shooting",
   "#:shooting 5"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "of",
   "#:shooting 5",
   "#:Windy 4",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "-is rel2",
   "block",
   "#:Michael 1",
   "#:shooting 5",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "person",
   "#:Windy 4"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "shooter",
   "#:Windy 4"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-isa",
    "shooter",
    "?:X"
   ],
   [
    "-has property",
    "jump",
    "?:X",
    "?:Cu24"
   ],
   [
    "isa",
    "great shooter",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-isa",
    "shooter",
    "?:X"
   ],
   [
    "-has property",
    "jump",
    "?:X",
    "?:Cu25"
   ],
   [
    "has property",
    "great",
    "?:X",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "great shooter",
    "#:Windy 4"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "great",
    "#:Windy 4",
    "?:Cu27"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "great shooter",
    "#:Windy 4"
   ],
   [
    "-has property",
    "great",
    "#:Windy 4",
    "?:Cu28"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "man",
   "$some_not_man"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "shooting",
   "$some_not_shooting"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "shooter",
   "$some_not_shooter"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "great shooter",
   "$some_great_shooter"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "great shooter",
   "$some_not_great_shooter"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "jump",
   "$some_jump",
   "?:Cu36"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "jump",
   "$some_not_jump",
   "?:Cu37"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "great",
   "$some_great",
   "?:Cu38"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "great",
   "$some_not_great",
   "?:Cu39"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "shooter",
   "$some_jump_shooter"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "jump",
   "$some_jump_shooter",
   "?:Cu41"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "great shooter",
    "?:X"
   ],
   [
    "isa",
    "shooter",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "great",
    "?:X"
   ],
   [
    "-isa",
    "shooter",
    "?:X"
   ],
   [
    "isa",
    "great shooter",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]