[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "penguin",
    "?:X"
   ],
   [
    "isa",
    "bird",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "penguin",
    "?:X"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "fly",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-capability",
    "?:E"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "has type",
    [
     "sk0",
     "?:X"
    ],
    "fly",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "has actor",
    [
     "sk0",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "capability",
    [
     "sk0",
     "?:X"
    ]
   ],
   [
    "$block",
    [
     "$",
     "bird",
     1
    ],
    [
     "$not",
     [
      "capability",
      [
       "sk0",
       "?:X"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "penguin",
    "sk1_penguin"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk2_activity",
    "fly",
    [
     "$ctxt",
     "?:Fv22",
     "?:Fv21",
     "?:Fv13",
     "?:Fv14"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk2_activity",
    "sk1_penguin",
    [
     "$ctxt",
     "?:Fv24",
     "?:Fv23",
     "?:Fv13",
     "?:Fv14"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "capability",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "penguin",
    "?:X"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "fly",
    [
     "$ctxt",
     "?:Fv30",
     "?:Fv29",
     "?:Fv13",
     "?:Fv14"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "?:Fv32",
     "?:Fv31",
     "?:Fv13",
     "?:Fv14"
    ]
   ],
   [
    "-capability",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "penguin",
   "$some_penguin"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "penguin",
   "$some_not_penguin"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "bird",
   "$some_bird"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bird",
   "$some_not_bird"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "fly",
    "?:Fv33"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv33"
   ]
  ],
  "@confidence": 0.52
 }
]