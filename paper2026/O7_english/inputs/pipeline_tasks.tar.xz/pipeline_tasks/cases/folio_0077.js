[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "woman",
   "#:Mary 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "school",
   "#:school 2"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "woman",
   "#:Hannah 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu4"
   ],
   [
    "-is rel2",
    "work",
    "?:X",
    "campus",
    "?:Cu4"
   ],
   [
    "is rel2",
    "earn",
    "?:X",
    "money",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "work",
    "?:X",
    "campus",
    "?:Cu5"
   ],
   [
    "is rel2",
    "pay",
    "?:X",
    "college tuition",
    "?:Cu5"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "college",
   "sk0_college"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu7"
   ],
   [
    "-is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu7"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    "campus",
    "?:Cu7"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "college",
   "sk0_college"
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu9"
   ],
   [
    "isa",
    "dining hall meal",
    [
     "sk2",
     "?:X"
    ]
   ],
   [
    "isa",
    "recipes",
    [
     "sk3",
     "?:X"
    ]
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu9"
   ]
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu10"
   ],
   [
    "isa",
    "dining hall meal",
    [
     "sk2",
     "?:X"
    ]
   ],
   [
    "is rel2",
    "enjoy",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu10"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu10"
   ]
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu11"
   ],
   [
    "is rel2",
    "enjoy",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu11"
   ],
   [
    "isa",
    "recipes",
    [
     "sk3",
     "?:X"
    ]
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu11"
   ]
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu12"
   ],
   [
    "is rel2",
    "enjoy",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu12"
   ],
   [
    "is rel2",
    "enjoy",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu12"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu12"
   ]
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu13"
   ],
   [
    "-isa",
    "dining hall meal",
    "?:M"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:M",
    "?:Cu13"
   ],
   [
    "-isa",
    "recipes",
    "?:R"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:R",
    "?:Cu13"
   ],
   [
    "-isa",
    "picky eater",
    "?:P"
   ],
   [
    "-=",
    "?:X",
    "?:P"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu14"
   ],
   [
    "-isa",
    "dining hall meal",
    "?:M"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:M",
    "?:Cu14"
   ],
   [
    "-isa",
    "recipes",
    "?:R"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:R",
    "?:Cu14"
   ],
   [
    "is rel2",
    "eat",
    "?:X",
    "campus dining halls",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:school 2",
    "?:Cu15"
   ],
   [
    "-isa",
    "dining hall meal",
    "?:M"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:M",
    "?:Cu15"
   ],
   [
    "-isa",
    "recipes",
    "?:R"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:R",
    "?:Cu15"
   ],
   [
    "is rel2",
    "catch up",
    "?:X",
    "campus dining halls",
    "?:Cu15"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Hannah 3"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Mary 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "organization",
   "#:school 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "at",
   "#:Hannah 3",
   "#:school 2",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Hannah 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "work",
   "#:Hannah 3",
   "campus",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-is rel2",
    "earn",
    "#:Hannah 3",
    "money",
    "?:Cu22"
   ],
   [
    "-is rel2",
    "pay",
    "#:Hannah 3",
    "college tuition",
    "?:Cu22"
   ],
   [
    "-isa",
    "picky eater",
    "#:Hannah 3"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-is rel2",
    "earn",
    "#:Hannah 3",
    "money",
    "?:Cu23"
   ],
   [
    "-is rel2",
    "pay",
    "#:Hannah 3",
    "college tuition",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-is rel2",
    "earn",
    "#:Hannah 3",
    "money",
    "?:Cu24"
   ],
   [
    "-is rel2",
    "pay",
    "#:Hannah 3",
    "college tuition",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "at",
    "#:Hannah 3",
    "#:school 2",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "picky eater",
    "#:Hannah 3"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "eat",
    "#:Hannah 3",
    "campus dining halls",
    "?:Cu27"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "catch up",
    "#:Hannah 3",
    "campus dining halls",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "at",
    "#:Hannah 3",
    "#:school 2",
    "?:Cu29"
   ],
   [
    "isa",
    "picky eater",
    "#:Hannah 3"
   ],
   [
    "-is rel2",
    "eat",
    "#:Hannah 3",
    "campus dining halls",
    "?:Cu29"
   ],
   [
    "-is rel2",
    "catch up",
    "#:Hannah 3",
    "campus dining halls",
    "?:Cu29"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "college",
   "$some_college"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "college",
   "$some_not_college"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "dining hall meal",
   "$some_dining_hall_meals"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "dining hall meal",
   "$some_not_dining_hall_meals"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "recipes",
   "$some_recipes"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "recipes",
   "$some_not_recipes"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "picky eater",
   "$some_picky_eater"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "dining hall meal",
    "?:X"
   ],
   [
    "isa",
    "meal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "dining hall",
    "?:X"
   ],
   [
    "-isa",
    "meal",
    "?:X"
   ],
   [
    "isa",
    "dining hall meal",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "picky eater",
    "?:X"
   ],
   [
    "isa",
    "eater",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "picky",
    "?:X"
   ],
   [
    "-isa",
    "eater",
    "?:X"
   ],
   [
    "isa",
    "picky eater",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]