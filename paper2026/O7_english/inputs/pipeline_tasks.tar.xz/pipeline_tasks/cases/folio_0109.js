[
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "man",
   "#:Peter 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "clothing",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Cu2"
   ],
   [
    "-is rel2",
    "spill",
    "?:X",
    "food",
    "?:Cu2"
   ],
   [
    "-has property",
    "tidy",
    "?:X",
    "?:Cu2"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "clumsy foodie",
    "?:X"
   ],
   [
    "-has property",
    "clumsy",
    "?:X",
    "?:Cu3"
   ],
   [
    "-has property",
    "go out",
    "?:X",
    "?:Cu3"
   ],
   [
    "-isa",
    "food restaurant",
    "?:Z"
   ],
   [
    "-has property",
    "new",
    "?:Z",
    "?:Cu3"
   ],
   [
    "isa",
    "clothing",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "clumsy foodie",
    "?:X"
   ],
   [
    "-has property",
    "clumsy",
    "?:X",
    "?:Cu4"
   ],
   [
    "-has property",
    "go out",
    "?:X",
    "?:Cu4"
   ],
   [
    "-isa",
    "food restaurant",
    "?:Z"
   ],
   [
    "-has property",
    "new",
    "?:Z",
    "?:Cu4"
   ],
   [
    "have",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "clumsy foodie",
    "?:X"
   ],
   [
    "-has property",
    "clumsy",
    "?:X",
    "?:Cu5"
   ],
   [
    "-has property",
    "go out",
    "?:X",
    "?:Cu5"
   ],
   [
    "-isa",
    "food restaurant",
    "?:Z"
   ],
   [
    "-has property",
    "new",
    "?:Z",
    "?:Cu5"
   ],
   [
    "is rel2",
    "spill",
    "?:X",
    "food",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-has property",
    "cleanly",
    "?:X",
    "?:Cu6"
   ],
   [
    "has property",
    "tidy",
    "?:X",
    "?:Cu6"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-have",
    "?:X",
    "?:O",
    "?:Cu7"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-have",
    "?:X",
    "?:SP",
    "?:Cu7"
   ],
   [
    "has property",
    "cleanly",
    "?:X",
    "?:Cu7"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "?:X",
    "?:F",
    "?:Cu8"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu8"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu8"
   ],
   [
    "isa",
    "order",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "?:X",
    "?:F",
    "?:Cu9"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu9"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu9"
   ],
   [
    "have",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "?:X",
    "?:F",
    "?:Cu10"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu10"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu10"
   ],
   [
    "isa",
    "spotlessness",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "?:X",
    "?:F",
    "?:Cu11"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu11"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu11"
   ],
   [
    "have",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Peter 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "clothing",
    "sk3_clothing"
   ],
   [
    "-isa",
    "clothing",
    "?:Y"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:Y",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "clothing",
    "sk3_clothing"
   ],
   [
    "-has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "have",
    "#:Peter 1",
    "sk3_clothing",
    "?:Cu15"
   ],
   [
    "-isa",
    "clothing",
    "?:Y"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:Y",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "have",
    "#:Peter 1",
    "sk3_clothing",
    "?:Cu16"
   ],
   [
    "-has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu18"
   ],
   [
    "-has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu19"
   ],
   [
    "-isa",
    "clothing",
    "?:Y"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:Y",
    "?:Cu19"
   ],
   [
    "-is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "person",
    "#:Peter 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "family",
    "sk5_family"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "have",
    "#:Peter 1",
    "sk5_family",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "order",
    "sk6_order"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk6_order",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "isa",
    "spotlessness",
    "sk10_spotlessness"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk10_spotlessness",
    "?:Cu30"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu31"
   ],
   [
    "isa",
    "family",
    "sk5_family"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu32"
   ],
   [
    "have",
    "#:Peter 1",
    "sk5_family",
    "?:Cu32"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu33"
   ],
   [
    "isa",
    "order",
    "sk6_order"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu34"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk6_order",
    "?:Cu34"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu35"
   ],
   [
    "isa",
    "spotlessness",
    "sk10_spotlessness"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu36"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk10_spotlessness",
    "?:Cu36"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "go out",
    "#:Peter 1",
    "?:Cu37"
   ],
   [
    "isa",
    "family",
    "sk5_family"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "go out",
    "#:Peter 1",
    "?:Cu38"
   ],
   [
    "have",
    "#:Peter 1",
    "sk5_family",
    "?:Cu38"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "go out",
    "#:Peter 1",
    "?:Cu39"
   ],
   [
    "isa",
    "order",
    "sk6_order"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "go out",
    "#:Peter 1",
    "?:Cu40"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk6_order",
    "?:Cu40"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "go out",
    "#:Peter 1",
    "?:Cu41"
   ],
   [
    "isa",
    "spotlessness",
    "sk10_spotlessness"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "go out",
    "#:Peter 1",
    "?:Cu42"
   ],
   [
    "is rel2",
    "prioritize",
    "sk5_family",
    "sk10_spotlessness",
    "?:Cu42"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu43"
   ],
   [
    "-has property",
    "go out",
    "#:Peter 1",
    "?:Cu43"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu43"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu43"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu43"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu47"
   ],
   [
    "-has property",
    "go out",
    "#:Peter 1",
    "?:Cu47"
   ],
   [
    "isa",
    "family",
    "sk8_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu48"
   ],
   [
    "-has property",
    "go out",
    "#:Peter 1",
    "?:Cu48"
   ],
   [
    "have",
    "#:Peter 1",
    "sk8_family",
    "?:Cu48"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu49"
   ],
   [
    "-has property",
    "go out",
    "#:Peter 1",
    "?:Cu49"
   ],
   [
    "isa",
    "order",
    "sk6_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu50"
   ],
   [
    "-has property",
    "go out",
    "#:Peter 1",
    "?:Cu50"
   ],
   [
    "is rel2",
    "prioritize",
    "sk8_family",
    "sk6_order",
    "?:Cu50"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu51"
   ],
   [
    "-has property",
    "go out",
    "#:Peter 1",
    "?:Cu51"
   ],
   [
    "isa",
    "spotlessness",
    "sk10_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "-has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu52"
   ],
   [
    "-has property",
    "go out",
    "#:Peter 1",
    "?:Cu52"
   ],
   [
    "is rel2",
    "prioritize",
    "sk8_family",
    "sk10_spotlessness",
    "?:Cu52"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu53"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu53"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu53"
   ],
   [
    "isa",
    "clumsy foodie",
    "#:Peter 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu54"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu54"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu54"
   ],
   [
    "has property",
    "clumsy",
    "#:Peter 1",
    "?:Cu54"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu55"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu55"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu55"
   ],
   [
    "has property",
    "go out",
    "#:Peter 1",
    "?:Cu55"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu56"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu56"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu56"
   ],
   [
    "isa",
    "family",
    "sk8_family"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu57"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu57"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu57"
   ],
   [
    "have",
    "#:Peter 1",
    "sk8_family",
    "?:Cu57"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu58"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu58"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu58"
   ],
   [
    "isa",
    "order",
    "sk6_order"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu59"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu59"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu59"
   ],
   [
    "is rel2",
    "prioritize",
    "sk8_family",
    "sk6_order",
    "?:Cu59"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu60"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu60"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu60"
   ],
   [
    "isa",
    "spotlessness",
    "sk10_spotlessness"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Peter 1"
   ],
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:F",
    "?:Cu61"
   ],
   [
    "-isa",
    "order",
    "?:O"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:O",
    "?:Cu61"
   ],
   [
    "-isa",
    "spotlessness",
    "?:SP"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:F",
    "?:SP",
    "?:Cu61"
   ],
   [
    "is rel2",
    "prioritize",
    "sk8_family",
    "sk10_spotlessness",
    "?:Cu61"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "clothing",
   "$some_clothing"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "clothing",
   "$some_not_clothing"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "clumsy foodie",
   "$some_clumsy_foodie"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "clumsy foodie",
   "$some_not_clumsy_foodie"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "food restaurant",
   "$some_food_restaurant"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "food restaurant",
   "$some_not_food_restaurant"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "order",
   "$some_order"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "order",
   "$some_not_order"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "family",
   "$some_family"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "family",
   "$some_not_family"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "tidy",
   "$some_tidy",
   "?:Cu77"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "tidy",
   "$some_not_tidy",
   "?:Cu78"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "clumsy",
   "$some_clumsy",
   "?:Cu79"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "clumsy",
   "$some_not_clumsy",
   "?:Cu80"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "go out",
   "$some_go_out",
   "?:Cu81"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "go out",
   "$some_not_go_out",
   "?:Cu82"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "new",
   "$some_new",
   "?:Cu83"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "new",
   "$some_not_new",
   "?:Cu84"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "clumsy foodie",
   "$some_clumsy_clumsy_foodie"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "clumsy",
   "$some_clumsy_clumsy_foodie",
   "?:Cu86"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "clumsy foodie",
   "$some_go_out_clumsy_foodie"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "go out",
   "$some_go_out_clumsy_foodie",
   "?:Cu88"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_cleanly_person"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "cleanly",
   "$some_cleanly_person",
   "?:Cu90"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "clumsy foodie",
    "?:X"
   ],
   [
    "isa",
    "foodie",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "clumsy",
    "?:X"
   ],
   [
    "-isa",
    "foodie",
    "?:X"
   ],
   [
    "isa",
    "clumsy foodie",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "food restaurant",
    "?:X"
   ],
   [
    "isa",
    "restaurant",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "food",
    "?:X"
   ],
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "isa",
    "food restaurant",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]