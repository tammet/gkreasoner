[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "legend of zelda",
   "#:Legend of Zelda 2"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "abstract",
   "#:Top 10 list 3"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "top 10 list",
   "#:Top 10 list 3"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "artifact",
   "#:FIFA 22 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "fifa 22",
   "#:FIFA 22 4"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "game company",
   "#:game company 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "Japanese",
   "#:game company 1",
   "?:Cu7"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "artifact",
   "#:Legend of Zelda 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "create",
   "#:game company 1",
   "#:Legend of Zelda 2",
   "?:Cu9"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "on",
    "?:X",
    "#:Top 10 list 3",
    "?:Cu11"
   ],
   [
    "isa",
    "game company",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "on",
    "?:X",
    "#:Top 10 list 3",
    "?:Cu12"
   ],
   [
    "has property",
    "Japanese",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "on",
    "?:X",
    "#:Top 10 list 3",
    "?:Cu13"
   ],
   [
    "is rel2",
    "make",
    [
     "sk0",
     "?:X"
    ],
    "?:X",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "game",
    "?:X"
   ],
   [
    "-isa",
    "copies",
    "?:Y"
   ],
   [
    "-is rel2",
    "sell",
    "?:X",
    "?:Y",
    "?:Cu14"
   ],
   [
    "is rel2",
    "included in",
    "?:X",
    "#:Top 10 list 3",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "artifact",
   "#:Legend of Zelda 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "copies",
   "sk1_copies"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "sell",
   "#:Legend of Zelda 2",
   "sk1_copies",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "game company",
    "sk2_game company"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "Japanese",
    "sk2_game company",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "make",
    "sk2_game company",
    "#:FIFA 22 4",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "game company",
    "?:X"
   ],
   [
    "-has property",
    "Japanese",
    "?:X",
    "?:Cu21"
   ],
   [
    "-is rel2",
    "make",
    "?:X",
    "#:FIFA 22 4",
    "?:Cu21"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "game company",
   "$some_not_game_company"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "game",
   "$some_game"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "game",
   "$some_not_game"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "copies",
   "$some_copies"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "copies",
   "$some_not_copies"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "Japanese",
   "$some_not_Japanese",
   "?:Cu28"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "fifa 22",
    "?:X"
   ],
   [
    "isa",
    "22",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "fifa",
    "?:X"
   ],
   [
    "-isa",
    "22",
    "?:X"
   ],
   [
    "isa",
    "fifa 22",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "game company",
    "?:X"
   ],
   [
    "isa",
    "company",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "game",
    "?:X"
   ],
   [
    "-isa",
    "company",
    "?:X"
   ],
   [
    "isa",
    "game company",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "legend of zelda",
    "?:X"
   ],
   [
    "isa",
    "zelda",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "legend of",
    "?:X"
   ],
   [
    "-isa",
    "zelda",
    "?:X"
   ],
   [
    "isa",
    "legend of zelda",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "top 10 list",
    "?:X"
   ],
   [
    "isa",
    "list",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "top 10",
    "?:X"
   ],
   [
    "-isa",
    "list",
    "?:X"
   ],
   [
    "isa",
    "top 10 list",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "create",
    "?:Fv24"
   ],
   [
    "has type",
    "?:E",
    "make",
    "?:Fv24"
   ]
  ],
  "@confidence": 0.94
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "make",
    "?:Fv25"
   ],
   [
    "has type",
    "?:E",
    "create",
    "?:Fv25"
   ]
  ],
  "@confidence": 0.94
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "game",
    "?:X"
   ],
   [
    "isa",
    "activity",
    "?:X"
   ]
  ],
  "@confidence": 0.76
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:X"
   ],
   [
    "isa",
    "game",
    "?:X"
   ]
  ],
  "@confidence": 0.76
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]