[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "have",
   "#:John 1",
   "#:car 2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has degree property",
   "good",
   "#:car 2",
   "none",
   "car",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "red",
   "#:car 2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "car",
    "#:car 2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "red",
    "#:car 2",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "good",
    "#:car 2",
    "none",
    "car",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "car",
    "#:car 2"
   ],
   [
    "-has property",
    "red",
    "#:car 2",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has degree property",
    "good",
    "#:car 2",
    "none",
    "car",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has property",
    "red",
    "#:car 2",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has property",
    "red",
    "#:car 2",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "#:car 2",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has degree property",
    "good",
    "#:car 2",
    "none",
    "car",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree property",
    "good",
    "#:car 2",
    "none",
    "car",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "good",
      "#:car 2",
      "none",
      "car",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv11",
       "?:Fv12",
       "?:Fv13"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv14",
       "?:Fv15",
       "?:Fv16"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]