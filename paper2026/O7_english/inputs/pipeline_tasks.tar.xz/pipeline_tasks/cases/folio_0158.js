[
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "person",
   "Professor David"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "professor david",
   "Professor David"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "man",
   "#:James 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "work",
    "?:X",
    "library",
    "?:Cu4"
   ],
   [
    "-isa",
    "computer science department",
    "?:Y"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "?:Y",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "part-time job",
    "?:Z"
   ],
   [
    "-have",
    "?:X",
    "?:Z",
    "?:Cu5"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:Z",
    "?:U",
    "?:Cu5"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    "library",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "computer science department",
    "?:Y"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "?:Y",
    "?:Cu6"
   ],
   [
    "isa",
    "database course",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "computer science department",
    "?:Y"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "?:Y",
    "?:Cu7"
   ],
   [
    "is rel2",
    "take",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "class",
    "?:CL"
   ],
   [
    "-is rel2",
    "take",
    "?:X",
    "?:CL",
    "?:Cu8"
   ],
   [
    "isa",
    "database course",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "class",
    "?:CL"
   ],
   [
    "-is rel2",
    "take",
    "?:X",
    "?:CL",
    "?:Cu9"
   ],
   [
    "is rel2",
    "take",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "work",
    "?:X",
    "lab",
    "?:Cu10"
   ],
   [
    "isa",
    "class",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "work",
    "?:X",
    "lab",
    "?:Cu11"
   ],
   [
    "is rel2",
    "take",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "student",
   "#:James 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:James 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "lab",
   "#:lab 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "work",
   "#:James 1",
   "#:lab 2",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:James 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "lab",
   "#:lab 2"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "-is rel2",
   "work",
   "#:James 1",
   "#:lab 2",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:Z"
   ],
   [
    "-have",
    "#:James 1",
    "?:Z",
    "?:Cu19"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:Z",
    "?:U",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "part-time job",
    "?:Z"
   ],
   [
    "-have",
    "#:James 1",
    "?:Z",
    "?:Cu20"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:Z",
    "?:U",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "part-time job",
    "sk3_part-time job"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "have",
    "#:James 1",
    "sk3_part-time job",
    "?:Cu22"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "university",
    "sk4_university"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "offered by",
    "sk3_part-time job",
    "sk4_university",
    "?:Cu24"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "computer science department",
   "$some_computer_science_department"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "computer science department",
   "$some_not_computer_science_department"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "student",
   "$some_not_student"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "part-time job",
   "$some_part-time_job"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "part-time job",
   "$some_not_part-time_job"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "university",
   "$some_university"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "university",
   "$some_not_university"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "database course",
   "$some_database_course"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "database course",
   "$some_not_database_course"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "computer science department",
    "?:X"
   ],
   [
    "isa",
    "department",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "computer science",
    "?:X"
   ],
   [
    "-isa",
    "department",
    "?:X"
   ],
   [
    "isa",
    "computer science department",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "database course",
    "?:X"
   ],
   [
    "isa",
    "course",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "database",
    "?:X"
   ],
   [
    "-isa",
    "course",
    "?:X"
   ],
   [
    "isa",
    "database course",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:X"
   ],
   [
    "isa",
    "job",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "part-time",
    "?:X"
   ],
   [
    "-isa",
    "job",
    "?:X"
   ],
   [
    "isa",
    "part-time job",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "professor david",
    "?:X"
   ],
   [
    "isa",
    "david",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "professor",
    "?:X"
   ],
   [
    "-isa",
    "david",
    "?:X"
   ],
   [
    "isa",
    "professor david",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]