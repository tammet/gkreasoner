[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Estonia 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "#:John 1",
    "https://en.wikipedia.org/wiki/Estonia",
    [
     "$ctxt",
     "present",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "in",
    "#:John 1",
    "https://en.wikipedia.org/wiki/Estonia",
    [
     "$ctxt",
     "present",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "in",
    "#:John 1",
    "https://en.wikipedia.org/wiki/Estonia",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "in",
    "#:John 1",
    "https://en.wikipedia.org/wiki/Estonia",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "in",
      "#:John 1",
      "https://en.wikipedia.org/wiki/Estonia",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 }
]