[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "United States"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "united states",
   "United States"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "event",
   "2024 United States presidential election"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "2024 united states presidential election",
   "2024 United States presidential election"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "organization",
   "#:Gazprom 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "register",
    "?:X",
    "United States",
    "?:Cu6"
   ],
   [
    "is rel2",
    "participate",
    "?:X",
    "2024 United States presidential election",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-have",
    "?:X",
    "United States citizenship",
    "?:Cu7"
   ],
   [
    "is rel2",
    "register",
    "?:X",
    "United States",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "have",
    "?:X",
    "United States citizenship",
    "?:Cu8"
   ],
   [
    "have",
    "?:X",
    "Taiwanese citizenship",
    "?:Cu8"
   ]
  ],
  "@confidence": 0.9899
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-have",
    "?:X",
    "United States citizenship",
    "?:Cu9"
   ],
   [
    "-have",
    "?:X",
    "Taiwanese citizenship",
    "?:Cu9"
   ]
  ],
  "@confidence": 0.9899
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "russian federation official",
    "?:X"
   ],
   [
    "-have",
    "?:X",
    "Taiwanese citizenship",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Vladimir 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "-have",
   "#:Vladimir 1",
   "Taiwanese citizenship",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Vladimir 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "manager",
    "?:Z"
   ],
   [
    "-=",
    "#:Vladimir 1",
    "?:Z"
   ],
   [
    "-is rel2",
    "at",
    "?:Z",
    "#:Gazprom 2",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Ekaterina 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "is rel2",
    "register",
    "#:Ekaterina 3",
    "United States",
    "?:Cu16"
   ],
   [
    "isa",
    "russian federation official",
    "#:Ekaterina 3"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "participate",
    "#:Ekaterina 3",
    "2024 United States presidential election",
    "?:Cu17"
   ],
   [
    "isa",
    "manager",
    "sk0_manager"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "participate",
    "#:Ekaterina 3",
    "2024 United States presidential election",
    "?:Cu18"
   ],
   [
    "=",
    "#:Ekaterina 3",
    "sk0_manager"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "participate",
    "#:Ekaterina 3",
    "2024 United States presidential election",
    "?:Cu19"
   ],
   [
    "is rel2",
    "at",
    "sk0_manager",
    "#:Gazprom 2",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "participate",
    "#:Ekaterina 3",
    "2024 United States presidential election",
    "?:Cu20"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "manager",
    "?:Z"
   ],
   [
    "-=",
    "#:Ekaterina 3",
    "?:Z"
   ],
   [
    "-is rel2",
    "at",
    "?:Z",
    "#:Gazprom 2",
    "?:Cu21"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "russian federation official",
   "$some_not_Russian_Federation_official"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "manager",
   "$some_manager"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "manager",
   "$some_not_manager"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "2024 united states presidential election",
    "?:X"
   ],
   [
    "isa",
    "election",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "2024 united states presidential",
    "?:X"
   ],
   [
    "-isa",
    "election",
    "?:X"
   ],
   [
    "isa",
    "2024 united states presidential election",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "russian federation official",
    "?:X"
   ],
   [
    "isa",
    "official",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "russian federation",
    "?:X"
   ],
   [
    "-isa",
    "official",
    "?:X"
   ],
   [
    "isa",
    "russian federation official",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "united states",
    "?:X"
   ],
   [
    "isa",
    "states",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "united",
    "?:X"
   ],
   [
    "-isa",
    "states",
    "?:X"
   ],
   [
    "isa",
    "united states",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "event",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "manager",
    "#:Vladimir 1"
   ],
   [
    "-is rel2",
    "at",
    "#:Vladimir 1",
    "#:Gazprom 2",
    "?:Cu41"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "manager",
    "#:Ekaterina 3"
   ],
   [
    "-is rel2",
    "at",
    "#:Ekaterina 3",
    "#:Gazprom 2",
    "?:Cu42"
   ],
   [
    "$defq0"
   ]
  ]
 }
]