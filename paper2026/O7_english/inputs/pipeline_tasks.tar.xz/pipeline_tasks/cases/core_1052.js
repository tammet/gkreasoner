[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "city",
   "#:city 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "destroy",
   "#:city 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "intact",
    "#:city 1",
    [
     "$ctxt",
     "present",
     "W1",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "intact",
    "#:city 1",
    [
     "$ctxt",
     "present",
     "W1",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has property",
    "intact",
    "#:city 1",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has property",
    "intact",
    "#:city 1",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "intact",
      "#:city 1",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_verb_result",
  "@logic": [
   [
    "-has type",
    "?:E",
    "destroy",
    [
     "$ctxt",
     "?:Fv6",
     "?:Fv7",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "?:Fv6",
     "?:Fv7",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-next",
    "?:Fv7",
    "?:Fv8"
   ],
   [
    "has property",
    "destroyed",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv8",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "destroyed",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv8",
       "?:Fv9",
       "?:Fv10"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_verb_result",
  "@logic": [
   [
    "-has property",
    "destroy",
    "?:X",
    [
     "$ctxt",
     "?:Fv11",
     "?:Fv12",
     "?:Fv14",
     "?:Fv15"
    ]
   ],
   [
    "-next",
    "?:Fv12",
    "?:Fv13"
   ],
   [
    "has property",
    "destroyed",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv14",
     "?:Fv15"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "destroyed",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv13",
       "?:Fv14",
       "?:Fv15"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "destroyed",
    "?:X",
    "?:Fv16"
   ],
   [
    "-has property",
    "intact",
    "?:X",
    "?:Fv16"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "intact",
     "?:X",
     "?:Fv16"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "destroyed",
    "?:X",
    "?:Fv17"
   ],
   [
    "-has property",
    "intact",
    "?:X",
    "?:Fv17"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "destroyed",
     "?:X",
     "?:Fv17"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]