[
 {
  "@name": "sent_S1",
  "@logic": [
   "-isa",
   "round",
   "#:square 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "nail",
   "#:nail 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "red",
   "#:square 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "have",
   "#:square 1",
   "#:nail 2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "-isa",
   "round",
   "#:square 3"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "hole",
   "#:hole 4"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has property",
   "blue",
   "#:square 3",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "have",
   "#:square 3",
   "#:hole 4",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "round",
    "sk0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "red",
    "sk0",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "hole",
    "sk1_hole"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "have",
    "sk0",
    "sk1_hole",
    [
     "$ctxt",
     "present",
     "?:Fv15",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "round",
    "?:X"
   ],
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "?:Fv19",
     "?:Fv18",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-isa",
    "hole",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    [
     "$ctxt",
     "present",
     "?:Fv22",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.97,
  "@logic": [
   [
    "-have",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "have",
    "?:Br1",
    "?:Br2",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "?:Br1",
      "?:Br2",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv23"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv23"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "red",
     "?:X",
     "?:Fv23"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv24"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv24"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "blue",
     "?:X",
     "?:Fv24"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv25",
     "?:Fv26",
     "?:Fv27"
    ]
   ],
   [
    "has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv25",
     "?:Fv26",
     "?:Fv27"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "blue",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv25",
       "?:Fv26",
       "?:Fv27"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv28",
     "?:Fv29",
     "?:Fv30"
    ]
   ],
   [
    "has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv28",
     "?:Fv29",
     "?:Fv30"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "blue",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv28",
       "?:Fv29",
       "?:Fv30"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv31",
     "?:Fv32",
     "?:Fv33"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv31",
     "?:Fv32",
     "?:Fv33"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv31",
       "?:Fv32",
       "?:Fv33"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv34",
     "?:Fv35",
     "?:Fv36"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv34",
     "?:Fv35",
     "?:Fv36"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv34",
       "?:Fv35",
       "?:Fv36"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]