[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "yale university",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "organization",
   "Ivy League"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "ivy league",
   "Ivy League"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "place",
   "#:New Haven 2"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "new haven",
   "#:New Haven 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "measure",
   "$42.3 billion"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "benjamin franklin college",
   "#:Benjamin Franklin College 4"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "organization",
   "#:Berkeley College 5"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "berkeley college",
   "#:Berkeley College 5"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "organization",
   "#:Branford College 6"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "branford college",
   "#:Branford College 6"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "organization",
   "#:Davenport College 7"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "davenport college",
   "#:Davenport College 7"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "organization",
   "#:Ezra Stiles College 8"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "ezra stiles college",
   "#:Ezra Stiles College 8"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "organization",
   "#:Grace Hopper College 9"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "grace hopper college",
   "#:Grace Hopper College 9"
  ]
 },
 {
  "@name": "entity_S11",
  "@logic": [
   "isa",
   "organization",
   "#:Jonathan Edwards College 10"
  ]
 },
 {
  "@name": "entity_S11",
  "@logic": [
   "isa",
   "jonathan edwards college",
   "#:Jonathan Edwards College 10"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "organization",
   "#:Morse College 11"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "morse college",
   "#:Morse College 11"
  ]
 },
 {
  "@name": "entity_S13",
  "@logic": [
   "isa",
   "organization",
   "#:Pauli Murray College 12"
  ]
 },
 {
  "@name": "entity_S13",
  "@logic": [
   "isa",
   "pauli murray college",
   "#:Pauli Murray College 12"
  ]
 },
 {
  "@name": "entity_S14",
  "@logic": [
   "isa",
   "organization",
   "#:Pierson College 13"
  ]
 },
 {
  "@name": "entity_S14",
  "@logic": [
   "isa",
   "pierson college",
   "#:Pierson College 13"
  ]
 },
 {
  "@name": "entity_S15",
  "@logic": [
   "isa",
   "organization",
   "#:Saybrook College 14"
  ]
 },
 {
  "@name": "entity_S15",
  "@logic": [
   "isa",
   "saybrook college",
   "#:Saybrook College 14"
  ]
 },
 {
  "@name": "entity_S16",
  "@logic": [
   "isa",
   "organization",
   "#:Silliman College 15"
  ]
 },
 {
  "@name": "entity_S16",
  "@logic": [
   "isa",
   "silliman college",
   "#:Silliman College 15"
  ]
 },
 {
  "@name": "entity_S17",
  "@logic": [
   "isa",
   "organization",
   "#:Timothy Dwight College 16"
  ]
 },
 {
  "@name": "entity_S17",
  "@logic": [
   "isa",
   "timothy dwight college",
   "#:Timothy Dwight College 16"
  ]
 },
 {
  "@name": "entity_S18",
  "@logic": [
   "isa",
   "organization",
   "#:Trumbull College 17"
  ]
 },
 {
  "@name": "entity_S18",
  "@logic": [
   "isa",
   "trumbull college",
   "#:Trumbull College 17"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "university",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "private",
   "#:Yale University 1",
   "?:Cu35"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "Ivy League",
   "#:Yale University 1",
   "?:Cu36"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "research",
   "#:Yale University 1",
   "?:Cu37"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "go",
   "#:Yale University 1",
   "https://en.wikipedia.org/wiki/New_Haven,_Connecticut",
   "?:Cu38"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv5"
   ],
   [
    "$datetime",
    1716
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is_past_world",
   "W0"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "university",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "=",
   [
    "$measure_of",
    "endowment",
    "#:Yale University 1",
    "W0"
   ],
   [
    "$list",
    42,
    "#:billion dollar"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "endowment",
   "#:endowment 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "#:Yale University 1",
   "#:endowment 3",
   "?:Cu45"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "college",
   "#:Benjamin Franklin College 4"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "has property",
   "residential",
   "#:Benjamin Franklin College 4",
   "?:Cu47"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "at",
   "#:Benjamin Franklin College 4",
   "#:Yale University 1",
   "?:Cu48"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu50"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu51"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu53"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu54"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu56"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu57"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu59"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu60"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu62"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu63"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu65"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu66"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu68"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu69"
  ]
 },
 {
  "@name": "sent_S13",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S13",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu71"
  ]
 },
 {
  "@name": "sent_S13",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu72"
  ]
 },
 {
  "@name": "sent_S14",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S14",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu74"
  ]
 },
 {
  "@name": "sent_S14",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu75"
  ]
 },
 {
  "@name": "sent_S15",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S15",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu77"
  ]
 },
 {
  "@name": "sent_S15",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu78"
  ]
 },
 {
  "@name": "sent_S16",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S16",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu80"
  ]
 },
 {
  "@name": "sent_S16",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu81"
  ]
 },
 {
  "@name": "sent_S17",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S17",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu83"
  ]
 },
 {
  "@name": "sent_S17",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu84"
  ]
 },
 {
  "@name": "sent_S18",
  "@logic": [
   "isa",
   "college",
   "#:Yale University 1"
  ]
 },
 {
  "@name": "sent_S18",
  "@logic": [
   "has property",
   "residential",
   "#:Yale University 1",
   "?:Cu86"
  ]
 },
 {
  "@name": "sent_S18",
  "@logic": [
   "is rel2",
   "at",
   "#:Yale University 1",
   "#:Yale University 1",
   "?:Cu87"
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "endowment",
    "sk0_endowment"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "have",
    "#:Yale University 1",
    "sk0_endowment",
    "?:Cu89"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "educational institution",
    "?:Y"
   ],
   [
    "-isa",
    "endowment",
    "?:Z"
   ],
   [
    "-have",
    "?:Y",
    "?:Z",
    "?:Cu90"
   ],
   [
    "is rel2",
    "large",
    "sk0_endowment",
    "?:Z",
    "?:Cu90"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "endowment",
    "?:X"
   ],
   [
    "-have",
    "#:Yale University 1",
    "?:X",
    "?:Cu91"
   ],
   [
    "isa",
    "educational institution",
    "sk1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "endowment",
    "?:X"
   ],
   [
    "-have",
    "#:Yale University 1",
    "?:X",
    "?:Cu92"
   ],
   [
    "isa",
    "endowment",
    "sk2"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "endowment",
    "?:X"
   ],
   [
    "-have",
    "#:Yale University 1",
    "?:X",
    "?:Cu93"
   ],
   [
    "have",
    "sk1",
    "sk2",
    "?:Cu93"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "endowment",
    "?:X"
   ],
   [
    "-have",
    "#:Yale University 1",
    "?:X",
    "?:Cu94"
   ],
   [
    "-is rel2",
    "large",
    "?:X",
    "sk2",
    "?:Cu94"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S19",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "endowment",
    "?:S",
    "?:W"
   ],
   "?:Cu95"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "endowment",
   [
    "$measure_of",
    "endowment",
    "?:S",
    "?:W"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "endowment",
   "$some_not_endowment"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "benjamin franklin college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "benjamin franklin",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "benjamin franklin college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "berkeley college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "berkeley",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "berkeley college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "branford college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "branford",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "branford college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "davenport college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "davenport",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "davenport college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "educational institution",
    "?:X"
   ],
   [
    "isa",
    "institution",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "educational",
    "?:X"
   ],
   [
    "-isa",
    "institution",
    "?:X"
   ],
   [
    "isa",
    "educational institution",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "ezra stiles college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "ezra stiles",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "ezra stiles college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "grace hopper college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "grace hopper",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "grace hopper college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "ivy league",
    "?:X"
   ],
   [
    "isa",
    "league",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "ivy",
    "?:X"
   ],
   [
    "-isa",
    "league",
    "?:X"
   ],
   [
    "isa",
    "ivy league",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "jonathan edwards college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "jonathan edward",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "jonathan edwards college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "morse college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "morse",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "morse college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "new haven",
    "?:X"
   ],
   [
    "isa",
    "haven",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "new",
    "?:X"
   ],
   [
    "-isa",
    "haven",
    "?:X"
   ],
   [
    "isa",
    "new haven",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "pauli murray college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "pauli murray",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "pauli murray college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "pierson college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "pierson",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "pierson college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "saybrook college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "saybrook",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "saybrook college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "silliman college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "silliman",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "silliman college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "timothy dwight college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "timothy dwight",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "timothy dwight college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "trumbull college",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "trumbull",
    "?:X"
   ],
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "trumbull college",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "yale university",
    "?:X"
   ],
   [
    "isa",
    "university",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "yale",
    "?:X"
   ],
   [
    "-isa",
    "university",
    "?:X"
   ],
   [
    "isa",
    "yale university",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "university",
    "?:X"
   ],
   [
    "isa",
    "college",
    "?:X"
   ]
  ],
  "@confidence": 0.94
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "college",
    "?:X"
   ],
   [
    "isa",
    "university",
    "?:X"
   ]
  ],
  "@confidence": 0.94
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv44"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv44"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]