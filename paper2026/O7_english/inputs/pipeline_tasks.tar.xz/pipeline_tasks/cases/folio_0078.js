[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "mary's school",
   "#:Mary's school 1"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "woman",
   "#:Hannah 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu3"
   ],
   [
    "-is rel2",
    "work",
    "?:X",
    "campus",
    "?:Cu3"
   ],
   [
    "is rel2",
    "earn",
    "?:X",
    "money",
    "?:Cu3"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "college",
   "sk0_college"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu5"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    "campus",
    "?:Cu5"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "college",
   "sk0_college"
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu7"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu7"
   ],
   [
    "isa",
    "dining hall meal",
    [
     "sk2",
     "?:X"
    ]
   ]
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu8"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu8"
   ],
   [
    "is rel2",
    "enjoy",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu8"
   ]
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu9"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu9"
   ],
   [
    "isa",
    "recipes",
    [
     "sk3",
     "?:X"
    ]
   ]
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu10"
   ],
   [
    "is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu10"
   ],
   [
    "is rel2",
    "enjoy",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu10"
   ]
  ],
  "@confidence": 0.9791
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "order",
    "?:X",
    "takeout",
    "?:Cu11"
   ],
   [
    "-isa",
    "dining hall meal",
    "?:M"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:M",
    "?:Cu11"
   ],
   [
    "-isa",
    "recipes",
    "?:R"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:R",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu12"
   ],
   [
    "-isa",
    "dining hall meal",
    "?:M"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:M",
    "?:Cu12"
   ],
   [
    "-isa",
    "recipes",
    "?:R"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:R",
    "?:Cu12"
   ],
   [
    "-isa",
    "picky eater",
    "?:X"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "#:Mary's school 1",
    "?:Cu13"
   ],
   [
    "-isa",
    "dining hall meal",
    "?:M"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:M",
    "?:Cu13"
   ],
   [
    "-isa",
    "recipes",
    "?:R"
   ],
   [
    "-is rel2",
    "enjoy",
    "?:X",
    "?:R",
    "?:Cu13"
   ],
   [
    "is rel2",
    "spend",
    "?:X",
    "campus dining halls",
    "?:Cu13"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Hannah 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "organization",
   "#:Mary's school 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "at",
   "#:Hannah 2",
   "#:Mary's school 1",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Hannah 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "work",
   "#:Hannah 2",
   "campus",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-is rel2",
    "earn",
    "#:Hannah 2",
    "money",
    "?:Cu19"
   ],
   [
    "-isa",
    "picky eater",
    "#:Hannah 2"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "-is rel2",
   "earn",
   "#:Hannah 2",
   "money",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "person",
    "#:Hannah 2"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "organization",
    "#:Mary's school 1"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "at",
    "#:Hannah 2",
    "#:Mary's school 1",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "picky eater",
    "#:Hannah 2"
   ],
   [
    "is rel2",
    "spend",
    "#:Hannah 2",
    "campus dining halls",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "picky eater",
    "#:Hannah 2"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "picky eater",
    "#:Hannah 2"
   ],
   [
    "-is rel2",
    "spend",
    "#:Hannah 2",
    "campus dining halls",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Hannah 2"
   ],
   [
    "-isa",
    "organization",
    "#:Mary's school 1"
   ],
   [
    "-is rel2",
    "at",
    "#:Hannah 2",
    "#:Mary's school 1",
    "?:Cu31"
   ],
   [
    "-is rel2",
    "spend",
    "#:Hannah 2",
    "campus dining halls",
    "?:Cu31"
   ],
   [
    "-isa",
    "picky eater",
    "#:Hannah 2"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "college",
   "$some_college"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "college",
   "$some_not_college"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "dining hall meal",
   "$some_dining_hall_meals"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "dining hall meal",
   "$some_not_dining_hall_meals"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "recipes",
   "$some_recipes"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "recipes",
   "$some_not_recipes"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "picky eater",
   "$some_picky_eater"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "dining hall meal",
    "?:X"
   ],
   [
    "isa",
    "meal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "dining hall",
    "?:X"
   ],
   [
    "-isa",
    "meal",
    "?:X"
   ],
   [
    "isa",
    "dining hall meal",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "mary's school",
    "?:X"
   ],
   [
    "isa",
    "school",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "mary'",
    "?:X"
   ],
   [
    "-isa",
    "school",
    "?:X"
   ],
   [
    "isa",
    "mary's school",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "picky eater",
    "?:X"
   ],
   [
    "isa",
    "eater",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "picky",
    "?:X"
   ],
   [
    "-isa",
    "eater",
    "?:X"
   ],
   [
    "isa",
    "picky eater",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "spend",
    "?:Fv85"
   ],
   [
    "has type",
    "?:E",
    "pass",
    "?:Fv85"
   ]
  ],
  "@confidence": 0.88
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv86"
   ],
   [
    "has type",
    "?:E",
    "spend",
    "?:Fv86"
   ]
  ],
  "@confidence": 0.88
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]