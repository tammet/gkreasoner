[
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "organization",
   "products from Baked by Melissa"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "products from baked by melissa",
   "products from Baked by Melissa"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "baked sweet",
    "?:X"
   ],
   [
    "-has property",
    "spicy",
    "?:X",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "cupcake",
    "?:X"
   ],
   [
    "isa",
    "baked sweet",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "mala hotpot",
    "?:X"
   ],
   [
    "has property",
    "spicy",
    "?:X",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "product from baked by melissa",
    "?:X"
   ],
   [
    "isa",
    "cupcake",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "dried thai chili",
    "?:X"
   ],
   [
    "has property",
    "spicy",
    "?:X",
    "?:Cu7"
   ],
   [
    "isa",
    "mala hotpot",
    "?:X"
   ],
   [
    "-isa",
    "baked sweet",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "dried thai chili",
    "?:X"
   ],
   [
    "isa",
    "product from baked by melissa",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "dried thai chili",
    "sk0_dried thai chili"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "product from baked by melissa",
    "sk0_dried thai chili"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "baked sweet",
   "$some_baked_sweet"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "baked sweet",
   "$some_not_baked_sweet"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "cupcake",
   "$some_cupcake"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "cupcake",
   "$some_not_cupcake"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "mala hotpot",
   "$some_mala_hotpot"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "mala hotpot",
   "$some_not_mala_hotpot"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "product from baked by melissa",
   "$some_product_from_Baked_by_Melissa"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "product from baked by melissa",
   "$some_not_product_from_Baked_by_Melissa"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "dried thai chili",
   "$some_dried_Thai_chili"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "dried thai chili",
   "$some_not_dried_Thai_chili"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "spicy",
   "$some_spicy",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "spicy",
   "$some_not_spicy",
   "?:Cu22"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "baked sweet",
    "?:X"
   ],
   [
    "isa",
    "sweet",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "baked",
    "?:X"
   ],
   [
    "-isa",
    "sweet",
    "?:X"
   ],
   [
    "isa",
    "baked sweet",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "dried thai chili",
    "?:X"
   ],
   [
    "isa",
    "chili",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "dried thai",
    "?:X"
   ],
   [
    "-isa",
    "chili",
    "?:X"
   ],
   [
    "isa",
    "dried thai chili",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "mala hotpot",
    "?:X"
   ],
   [
    "isa",
    "hotpot",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "mala",
    "?:X"
   ],
   [
    "-isa",
    "hotpot",
    "?:X"
   ],
   [
    "isa",
    "mala hotpot",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "product from baked by melissa",
    "?:X"
   ],
   [
    "isa",
    "melissa",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "product from baked by",
    "?:X"
   ],
   [
    "-isa",
    "melissa",
    "?:X"
   ],
   [
    "isa",
    "product from baked by melissa",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "products from baked by melissa",
    "?:X"
   ],
   [
    "isa",
    "melissa",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "products from baked by",
    "?:X"
   ],
   [
    "-isa",
    "melissa",
    "?:X"
   ],
   [
    "isa",
    "products from baked by melissa",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]