[
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "person",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "good",
    "?:X",
    "?:Y",
    "?:Cu2"
   ],
   [
    "-is rel2",
    "mean",
    "?:X",
    "?:Y",
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "sk0_person"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has property",
   "grumpy",
   "sk0_person",
   "?:Cu4"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:Y"
   ],
   [
    "is rel2",
    "mean",
    "sk0_person",
    "?:Y",
    "?:Cu5"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "animal lover",
    "?:X"
   ],
   [
    "-isa",
    "animal",
    "?:Y"
   ],
   [
    "is rel2",
    "good",
    "?:X",
    "?:Y",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "pet owner",
    "?:X"
   ],
   [
    "has property",
    "animal lover",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "pet owner",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "grumpy",
    "#:Tom 1",
    "?:Cu10"
   ],
   [
    "-has property",
    "animal lover",
    "#:Tom 1",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "animal",
    "sk1_animal"
   ],
   [
    "-has property",
    "grumpy",
    "#:Tom 1",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "animal",
    "sk1_animal"
   ],
   [
    "-has property",
    "animal lover",
    "#:Tom 1",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "mean",
    "#:Tom 1",
    "sk1_animal",
    "?:Cu13"
   ],
   [
    "-has property",
    "grumpy",
    "#:Tom 1",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "mean",
    "#:Tom 1",
    "sk1_animal",
    "?:Cu14"
   ],
   [
    "-has property",
    "animal lover",
    "#:Tom 1",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "animal",
    "sk1_animal"
   ],
   [
    "-has property",
    "grumpy",
    "#:Tom 1",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "animal",
    "sk1_animal"
   ],
   [
    "-has property",
    "animal lover",
    "#:Tom 1",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "grumpy",
    "#:Tom 1",
    "?:Cu17"
   ],
   [
    "-isa",
    "animal",
    "?:Y"
   ],
   [
    "-is rel2",
    "mean",
    "#:Tom 1",
    "?:Y",
    "?:Cu17"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "has property",
    "grumpy",
    "#:Tom 1",
    "?:Cu18"
   ],
   [
    "has property",
    "animal lover",
    "#:Tom 1",
    "?:Cu18"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_animal"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal lover",
   "$some_animal_lover"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal lover",
   "$some_not_animal_lover"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "pet owner",
   "$some_not_pet_owner"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "grumpy",
   "$some_grumpy",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "grumpy",
   "$some_not_grumpy",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "animal lover",
   "$some_animal_lover",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "animal lover",
   "$some_not_animal_lover",
   "?:Cu32"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "animal lover",
    "?:X"
   ],
   [
    "isa",
    "lover",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-isa",
    "lover",
    "?:X"
   ],
   [
    "isa",
    "animal lover",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "pet owner",
    "?:X"
   ],
   [
    "isa",
    "owner",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "pet",
    "?:X"
   ],
   [
    "-isa",
    "owner",
    "?:X"
   ],
   [
    "isa",
    "pet owner",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]