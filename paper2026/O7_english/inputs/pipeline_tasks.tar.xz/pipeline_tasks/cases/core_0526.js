[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-isa",
    "boxer",
    "?:Y"
   ],
   [
    "isa",
    "activity",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-isa",
    "boxer",
    "?:Y"
   ],
   [
    "has type",
    [
     "sk0",
     "?:X"
    ],
    "eat",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-isa",
    "boxer",
    "?:Y"
   ],
   [
    "has actor",
    [
     "sk0",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-isa",
    "boxer",
    "?:Y"
   ],
   [
    "has target",
    [
     "sk0",
     "?:X"
    ],
    "?:Y",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-isa",
    "boxer",
    "?:Y"
   ],
   [
    "typical",
    [
     "sk0",
     "?:X"
    ],
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "boxer",
     1
    ],
    [
     "$not",
     [
      "typical",
      [
       "sk0",
       "?:X"
      ],
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.6
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "boxer",
   "#:Mike 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "bear",
   "#:Greg 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "bear",
    "sk1_bear"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk2_activity",
    "eat",
    [
     "$ctxt",
     "?:Fv18",
     "?:Fv17",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk2_activity",
    "sk1_bear",
    [
     "$ctxt",
     "?:Fv20",
     "?:Fv19",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has target",
    "sk2_activity",
    "#:Mike 1",
    [
     "$ctxt",
     "?:Fv22",
     "?:Fv21",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "typical",
    "sk2_activity",
    [
     "$ctxt",
     "?:Fv24",
     "?:Fv23",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "eat",
    [
     "$ctxt",
     "?:Fv30",
     "?:Fv29",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "?:Fv32",
     "?:Fv31",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-has target",
    "?:E",
    "#:Mike 1",
    [
     "$ctxt",
     "?:Fv34",
     "?:Fv33",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-typical",
    "?:E",
    [
     "$ctxt",
     "?:Fv36",
     "?:Fv35",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bear",
   "$some_not_bear"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "boxer",
   "$some_not_boxer"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 }
]