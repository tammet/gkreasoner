[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:Robert Lewandowski 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "man",
   "#:Robert Lewandowski 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "robert lewandowski",
   "#:Robert Lewandowski 1"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "organization",
   "#:Bayern Munchen 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "bayern munchen",
   "#:Bayern Munchen 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "striker",
   "#:Robert Lewandowski 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "striker",
    "?:X"
   ],
   [
    "isa",
    "soccer player",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "organization",
   "https://en.wikipedia.org/wiki/FC_Bayern_Munich"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "leave",
   "#:Robert Lewandowski 1",
   "https://en.wikipedia.org/wiki/FC_Bayern_Munich",
   "?:Cu9"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "team",
   "https://en.wikipedia.org/wiki/FC_Bayern_Munich"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "player",
    "?:X"
   ],
   [
    "-is rel2",
    "leave",
    "?:X",
    "?:Y",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "play",
    "?:X",
    "?:Y",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "star",
    "#:Robert Lewandowski 1"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "star",
    "#:Robert Lewandowski 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "striker",
   "$some_not_striker"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "soccer player",
   "$some_soccer_player"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "soccer player",
   "$some_not_soccer_player"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "player",
   "$some_player"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "player",
   "$some_not_player"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "bayern munchen",
    "?:X"
   ],
   [
    "isa",
    "munchen",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "bayern",
    "?:X"
   ],
   [
    "-isa",
    "munchen",
    "?:X"
   ],
   [
    "isa",
    "bayern munchen",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "robert lewandowski",
    "?:X"
   ],
   [
    "isa",
    "lewandowski",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "robert",
    "?:X"
   ],
   [
    "-isa",
    "lewandowski",
    "?:X"
   ],
   [
    "isa",
    "robert lewandowski",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "soccer player",
    "?:X"
   ],
   [
    "isa",
    "player",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "soccer",
    "?:X"
   ],
   [
    "-isa",
    "player",
    "?:X"
   ],
   [
    "isa",
    "soccer player",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]