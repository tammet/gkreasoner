[
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "man",
   "#:Peter 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "clothing",
    "?:Z"
   ],
   [
    "-have",
    "?:X",
    "?:Z",
    "?:Cu2"
   ],
   [
    "-is rel2",
    "spill",
    "?:X",
    "food",
    "?:Cu2"
   ],
   [
    "-has property",
    "tidy",
    "?:X",
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-has property",
    "clumsy",
    "?:X",
    "?:Cu3"
   ],
   [
    "-is rel2",
    "go out",
    "?:X",
    "food restaurant",
    "?:Cu3"
   ],
   [
    "isa",
    "clothing",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-has property",
    "clumsy",
    "?:X",
    "?:Cu4"
   ],
   [
    "-is rel2",
    "go out",
    "?:X",
    "food restaurant",
    "?:Cu4"
   ],
   [
    "have",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-has property",
    "clumsy",
    "?:X",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "go out",
    "?:X",
    "food restaurant",
    "?:Cu5"
   ],
   [
    "is rel2",
    "spill",
    "?:X",
    "food",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-has property",
    "cleanly",
    "?:X",
    "?:Cu6"
   ],
   [
    "has property",
    "tidy",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "value",
    "?:X",
    "order",
    "?:Cu7"
   ],
   [
    "-is rel2",
    "value",
    "?:X",
    "spotlessness",
    "?:Cu7"
   ],
   [
    "has property",
    "cleanly",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:Y"
   ],
   [
    "-is rel2",
    "family of",
    "?:Y",
    "?:X",
    "?:Cu8"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:Y",
    "order",
    "?:Cu8"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:Y",
    "spotlessness",
    "?:Cu8"
   ],
   [
    "is rel2",
    "value",
    "?:X",
    "order",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:Y"
   ],
   [
    "-is rel2",
    "family of",
    "?:Y",
    "?:X",
    "?:Cu9"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:Y",
    "order",
    "?:Cu9"
   ],
   [
    "-is rel2",
    "prioritize",
    "?:Y",
    "spotlessness",
    "?:Cu9"
   ],
   [
    "is rel2",
    "value",
    "?:X",
    "spotlessness",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Peter 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "clothing",
    "sk1_clothing"
   ],
   [
    "-isa",
    "clothing",
    "?:Z"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:Z",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "clothing",
    "sk1_clothing"
   ],
   [
    "-has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "have",
    "#:Peter 1",
    "sk1_clothing",
    "?:Cu13"
   ],
   [
    "-isa",
    "clothing",
    "?:Z"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:Z",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "have",
    "#:Peter 1",
    "sk1_clothing",
    "?:Cu14"
   ],
   [
    "-has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu16"
   ],
   [
    "-has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "has property",
    "cleanly",
    "#:Peter 1",
    "?:Cu17"
   ],
   [
    "-isa",
    "clothing",
    "?:Z"
   ],
   [
    "-have",
    "#:Peter 1",
    "?:Z",
    "?:Cu17"
   ],
   [
    "-is rel2",
    "spill",
    "#:Peter 1",
    "food",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "tidy",
    "#:Peter 1",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "tidy",
    "#:Peter 1",
    "?:Cu23"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "clothing",
   "$some_clothing"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "clothing",
   "$some_not_clothing"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "family",
   "$some_family"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "family",
   "$some_not_family"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "tidy",
   "$some_tidy",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "tidy",
   "$some_not_tidy",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "clumsy",
   "$some_clumsy",
   "?:Cu32"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "clumsy",
   "$some_not_clumsy",
   "?:Cu33"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_cleanly_person"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "cleanly",
   "$some_cleanly_person",
   "?:Cu35"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]