[
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "car",
   "#:car 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "red",
   "#:car 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "blue",
   "#:car 2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has degree rel2",
   "fast",
   "#:car 1",
   "#:car 2",
   "high",
   "car",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "car",
    "#:car 3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "car",
    "#:car 1"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "green",
    "#:car 3",
    [
     "$ctxt",
     "?:Fv12",
     "?:Fv11",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "red",
    "#:car 1",
    [
     "$ctxt",
     "?:Fv14",
     "?:Fv13",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree rel2",
    "fast",
    "#:car 3",
    "#:car 1",
    "high",
    "?:Fv47",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "car",
    "#:car 3"
   ],
   [
    "-isa",
    "car",
    "#:car 1"
   ],
   [
    "-has property",
    "green",
    "#:car 3",
    [
     "$ctxt",
     "?:Fv20",
     "?:Fv19",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has property",
    "red",
    "#:car 1",
    [
     "$ctxt",
     "?:Fv22",
     "?:Fv21",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has degree rel2",
    "fast",
    "#:car 3",
    "#:car 1",
    "high",
    "?:Fv48",
    [
     "$ctxt",
     "present",
     "?:Fv5",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-has degree rel2",
    "fast",
    "#:car 3",
    "#:car 1",
    "high",
    "car",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree rel2",
    "fast",
    "#:car 3",
    "#:car 1",
    "high",
    "car",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree rel2",
      "fast",
      "#:car 3",
      "#:car 1",
      "high",
      "car",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv23"
   ],
   [
    "-has property",
    "green",
    "?:X",
    "?:Fv23"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "green",
     "?:X",
     "?:Fv23"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv24"
   ],
   [
    "-has property",
    "green",
    "?:X",
    "?:Fv24"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "blue",
     "?:X",
     "?:Fv24"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv25"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv25"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "red",
     "?:X",
     "?:Fv25"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv26"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv26"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "blue",
     "?:X",
     "?:Fv26"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "green",
    "?:X",
    "?:Fv27"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv27"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "red",
     "?:X",
     "?:Fv27"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "green",
    "?:X",
    "?:Fv28"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv28"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "green",
     "?:X",
     "?:Fv28"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv29",
     "?:Fv30",
     "?:Fv31"
    ]
   ],
   [
    "has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv29",
     "?:Fv30",
     "?:Fv31"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "blue",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv29",
       "?:Fv30",
       "?:Fv31"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv32",
     "?:Fv33",
     "?:Fv34"
    ]
   ],
   [
    "has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv32",
     "?:Fv33",
     "?:Fv34"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "blue",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv32",
       "?:Fv33",
       "?:Fv34"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "green",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv35",
     "?:Fv36",
     "?:Fv37"
    ]
   ],
   [
    "has property",
    "green",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv35",
     "?:Fv36",
     "?:Fv37"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "green",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv35",
       "?:Fv36",
       "?:Fv37"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "green",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv38",
     "?:Fv39",
     "?:Fv40"
    ]
   ],
   [
    "has property",
    "green",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv38",
     "?:Fv39",
     "?:Fv40"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "green",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv38",
       "?:Fv39",
       "?:Fv40"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv41",
     "?:Fv42",
     "?:Fv43"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv41",
     "?:Fv42",
     "?:Fv43"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv41",
       "?:Fv42",
       "?:Fv43"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv44",
     "?:Fv45",
     "?:Fv46"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv44",
     "?:Fv45",
     "?:Fv46"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv44",
       "?:Fv45",
       "?:Fv46"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]