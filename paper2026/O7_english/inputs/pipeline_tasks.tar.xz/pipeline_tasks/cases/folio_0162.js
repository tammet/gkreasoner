[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:George 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "man",
   "#:George 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "like",
    "#:George 1",
    "music",
    "?:Cu3"
   ],
   [
    "is rel2",
    "want",
    "#:George 1",
    "compose",
    "?:Cu3"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "#:George 1"
   ],
   [
    "-isa",
    "program",
    "?:Y"
   ],
   [
    "-is rel2",
    "access to",
    "#:George 1",
    "?:Y",
    "?:Cu4"
   ],
   [
    "has property",
    "compose",
    "#:George 1",
    "?:Cu4"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "compose",
    "#:George 1",
    "?:Cu7"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "has property",
    "compose",
    "#:George 1",
    "?:Cu8"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "program",
   "$some_program"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "program",
   "$some_not_program"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]