[
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "organization",
   "members of Pappy's"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "members of pappy'",
   "members of Pappy's"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "organization",
   "#:BBC Three 3"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "bbc three",
   "#:BBC Three 3"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "the secret dude society",
   "#:The Secret Dude Society 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "man",
   "#:Andrew Collins 5"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "andrew collin",
   "#:Andrew Collins 5"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "organization",
   "#:BBC Two 7"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "bbc two",
   "#:BBC Two 7"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "british sitcom series",
   "#:Badults 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "British",
   "#:Badults 1",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "sk0_person"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "member of",
   "sk0_person",
   "https://en.wikipedia.org/wiki/Pappy%27s_(comedy_trio)",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "star",
   "sk0_person",
   "#:Badults 1",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "pilot",
   "#:Badults 1",
   "#:BBC Three 3",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv7"
   ],
   [
    "$datetime",
    "July 2013"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is_past_world",
   "W0"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "abstract",
   "#:The Secret Dude Society 4"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "working title of",
   "#:The Secret Dude Society 4",
   "#:Badults 1",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Andrew Collins 5"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "script editor",
   "#:script editor 6"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "script editor for",
   "#:Andrew Collins 5",
   "#:Badults 1",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "script editor",
   "#:script editor 6"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "script editor of",
   "#:script editor 6",
   "#:Badults 1",
   "?:Cu24"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "member of",
    "?:X",
    "https://en.wikipedia.org/wiki/Pappy%27s_(comedy_trio)",
    "?:Cu25"
   ],
   [
    "-isa",
    "show",
    "?:Y"
   ],
   [
    "-is rel2",
    "star",
    "?:X",
    "?:Y",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "person",
    "sk1_person"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "member of",
    "sk1_person",
    "https://en.wikipedia.org/wiki/Pappy%27s_(comedy_trio)",
    "?:Cu27"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "show",
    "sk2_show"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "star",
    "sk1_person",
    "sk2_show",
    "?:Cu29"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "have",
   "#:Badults 1",
   "#:script editor 6",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "british sitcom series",
    "?:X"
   ],
   [
    "isa",
    "series",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "british sitcom",
    "?:X"
   ],
   [
    "-isa",
    "series",
    "?:X"
   ],
   [
    "isa",
    "british sitcom series",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "andrew collin",
    "?:X"
   ],
   [
    "isa",
    "collin",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "andrew",
    "?:X"
   ],
   [
    "-isa",
    "collin",
    "?:X"
   ],
   [
    "isa",
    "andrew collin",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "bbc three",
    "?:X"
   ],
   [
    "isa",
    "three",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "bbc",
    "?:X"
   ],
   [
    "-isa",
    "three",
    "?:X"
   ],
   [
    "isa",
    "bbc three",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "bbc two",
    "?:X"
   ],
   [
    "isa",
    "two",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "bbc",
    "?:X"
   ],
   [
    "-isa",
    "two",
    "?:X"
   ],
   [
    "isa",
    "bbc two",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "members of pappy'",
    "?:X"
   ],
   [
    "isa",
    "pappy'",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "members of",
    "?:X"
   ],
   [
    "-isa",
    "pappy'",
    "?:X"
   ],
   [
    "isa",
    "members of pappy'",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "script editor",
    "?:X"
   ],
   [
    "isa",
    "editor",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "script",
    "?:X"
   ],
   [
    "-isa",
    "editor",
    "?:X"
   ],
   [
    "isa",
    "script editor",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "the secret dude society",
    "?:X"
   ],
   [
    "isa",
    "society",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "the secret dude",
    "?:X"
   ],
   [
    "-isa",
    "society",
    "?:X"
   ],
   [
    "isa",
    "the secret dude society",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]