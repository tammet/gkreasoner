[
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "state-of-the-art text summarization model",
   "#:state-of-the-art text summarization model 1"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "abstract",
   "Machine Learning algorithms"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "machine learning algorithm",
   "Machine Learning algorithms"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "machine learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "supervised learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "machine learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "unsupervised learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "machine learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "reinforcement learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "unsupervised learning algorithm",
    "?:X"
   ],
   [
    "-isa",
    "data",
    "?:Y"
   ],
   [
    "-has property",
    "labeled",
    "?:Y",
    "?:Cu7"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "unsupervised learning",
    "?:X"
   ],
   [
    "isa",
    "unsupervised learning algorithm",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "model",
   "#:state-of-the-art text summarization model 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "has property",
   "state-of-the-art",
   "#:state-of-the-art text summarization model 1",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "machine learning algorithm",
   "sk0_machine learning algorithm"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "train",
   "#:state-of-the-art text summarization model 1",
   "sk0_machine learning algorithm",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "model",
   "#:state-of-the-art text summarization model 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "reinforcement learning",
    "?:X"
   ],
   [
    "-is rel2",
    "train",
    "#:state-of-the-art text summarization model 1",
    "?:X",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "text summarization model",
   "sk1_text summarization model"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "train",
   "sk1_text summarization model",
   "Machine Learning algorithms",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "data",
   "sk2_data"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "has property",
   "labeled",
   "sk2_data",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "have",
   "Machine Learning algorithms",
   "sk2_data",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "unsupervised learning",
    "sk3_unsupervised learning"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "train",
    "#:state-of-the-art text summarization model 1",
    "sk3_unsupervised learning",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "unsupervised learning",
    "?:X"
   ],
   [
    "-is rel2",
    "train",
    "#:state-of-the-art text summarization model 1",
    "?:X",
    "?:Cu22"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "machine learning algorithm",
   "$some_Machine_Learning_algorithm"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "machine learning algorithm",
   "$some_not_Machine_Learning_algorithm"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "supervised learning",
   "$some_supervised_learning"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "supervised learning",
   "$some_not_supervised_learning"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "unsupervised learning",
   "$some_unsupervised_learning"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "unsupervised learning",
   "$some_not_unsupervised_learning"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "reinforcement learning",
   "$some_reinforcement_learning"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "reinforcement learning",
   "$some_not_reinforcement_learning"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "unsupervised learning algorithm",
   "$some_unsupervised_learning_algorithm"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "unsupervised learning algorithm",
   "$some_not_unsupervised_learning_algorithm"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "data",
   "$some_data"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "data",
   "$some_not_data"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "text summarization model",
   "$some_text_summarization_model"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "text summarization model",
   "$some_not_text_summarization_model"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "labeled",
   "$some_labeled",
   "?:Cu38"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "labeled",
   "$some_not_labeled",
   "?:Cu39"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "machine learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "algorithm",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "machine learning",
    "?:X"
   ],
   [
    "-isa",
    "algorithm",
    "?:X"
   ],
   [
    "isa",
    "machine learning algorithm",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "machine learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "algorithm",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "machine learning",
    "?:X"
   ],
   [
    "-isa",
    "algorithm",
    "?:X"
   ],
   [
    "isa",
    "machine learning algorithm",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "reinforcement learning",
    "?:X"
   ],
   [
    "isa",
    "learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "reinforcement",
    "?:X"
   ],
   [
    "-isa",
    "learning",
    "?:X"
   ],
   [
    "isa",
    "reinforcement learning",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "state-of-the-art text summarization model",
    "?:X"
   ],
   [
    "isa",
    "model",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "state-of-the-art text summarization model",
    "?:X"
   ],
   [
    "isa",
    "text summarization model",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "state-of-the-art text summarization",
    "?:X"
   ],
   [
    "-isa",
    "model",
    "?:X"
   ],
   [
    "isa",
    "state-of-the-art text summarization model",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "supervised learning",
    "?:X"
   ],
   [
    "isa",
    "learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "supervised",
    "?:X"
   ],
   [
    "-isa",
    "learning",
    "?:X"
   ],
   [
    "isa",
    "supervised learning",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "text summarization model",
    "?:X"
   ],
   [
    "isa",
    "model",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "text summarization",
    "?:X"
   ],
   [
    "-isa",
    "model",
    "?:X"
   ],
   [
    "isa",
    "text summarization model",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "unsupervised learning",
    "?:X"
   ],
   [
    "isa",
    "learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "unsupervised",
    "?:X"
   ],
   [
    "-isa",
    "learning",
    "?:X"
   ],
   [
    "isa",
    "unsupervised learning",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "unsupervised learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "algorithm",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "unsupervised learning",
    "?:X"
   ],
   [
    "-isa",
    "algorithm",
    "?:X"
   ],
   [
    "isa",
    "unsupervised learning algorithm",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]