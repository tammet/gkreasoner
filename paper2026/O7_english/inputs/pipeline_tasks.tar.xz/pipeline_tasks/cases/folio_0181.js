[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:LGA airport 2"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "lga airport",
   "#:LGA airport 2"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "man",
   "#:John 5"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Susan 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "airport",
   "https://en.wikipedia.org/wiki/LaGuardia_Airport"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "fly",
   "#:Susan 1",
   "https://en.wikipedia.org/wiki/LaGuardia_Airport",
   "?:Cu6"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "airport",
   "https://en.wikipedia.org/wiki/LaGuardia_Airport"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "flight",
   "#:flight 3"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "arrival airport of",
   "https://en.wikipedia.org/wiki/LaGuardia_Airport",
   "#:flight 3",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "flight",
    "?:X"
   ],
   [
    "-is rel2",
    "departure airport of",
    "?:Y",
    "?:X",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "arrival airport of",
    "?:Z",
    "?:X",
    "?:Cu11"
   ],
   [
    "-=",
    "?:Y",
    "?:Z"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "person",
   "#:John 5"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "airport",
   "https://en.wikipedia.org/wiki/LaGuardia_Airport"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "fly",
   "#:John 5",
   "https://en.wikipedia.org/wiki/LaGuardia_Airport",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "next",
   "W1",
   "W2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "airport",
   "https://en.wikipedia.org/wiki/LaGuardia_Airport"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "flight",
   "#:flight 6"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "departure airport of",
   "https://en.wikipedia.org/wiki/LaGuardia_Airport",
   "#:flight 6",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "fly",
    "#:John 5",
    "https://en.wikipedia.org/wiki/LaGuardia_Airport",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "fly",
    "#:John 5",
    "https://en.wikipedia.org/wiki/LaGuardia_Airport",
    "?:Cu20"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "flight",
   "$some_not_flight"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "lga airport",
    "?:X"
   ],
   [
    "isa",
    "airport",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "lga",
    "?:X"
   ],
   [
    "-isa",
    "airport",
    "?:X"
   ],
   [
    "isa",
    "lga airport",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "fly",
    "?:Fv16"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv16"
   ]
  ],
  "@confidence": 0.52
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W1",
   "W2"
  ]
 }
]