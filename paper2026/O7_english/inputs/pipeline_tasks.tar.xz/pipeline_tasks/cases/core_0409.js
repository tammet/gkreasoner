[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "=",
   3,
   [
    "$count",
    [
     "$setof",
     "have",
     "#:John 1",
     [
      "$and",
      [
       "$isa",
       "car",
       "$arg1"
      ],
      [
       "$has_degree_property",
       "good",
       "$arg1",
       "none",
       "car"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1_el1",
  "@logic": [
   "isa",
   "car",
   "$set1_el1"
  ]
 },
 {
  "@name": "sent_S1_el1",
  "@logic": [
   "has degree property",
   "good",
   "$set1_el1",
   "none",
   "car",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1_el1",
  "@logic": [
   "have",
   "#:John 1",
   "$set1_el1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1_el1",
  "@logic": [
   "member",
   "$set1_el1",
   [
    "$setof",
    "have",
    "#:John 1",
    [
     "$and",
     [
      "$isa",
      "car",
      "$arg1"
     ],
     [
      "$has_degree_property",
      "good",
      "$arg1",
      "none",
      "car"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1_el2",
  "@logic": [
   "isa",
   "car",
   "$set1_el2"
  ]
 },
 {
  "@name": "sent_S1_el2",
  "@logic": [
   "has degree property",
   "good",
   "$set1_el2",
   "none",
   "car",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1_el2",
  "@logic": [
   "have",
   "#:John 1",
   "$set1_el2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1_el2",
  "@logic": [
   "member",
   "$set1_el2",
   [
    "$setof",
    "have",
    "#:John 1",
    [
     "$and",
     [
      "$isa",
      "car",
      "$arg1"
     ],
     [
      "$has_degree_property",
      "good",
      "$arg1",
      "none",
      "car"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1_el3",
  "@logic": [
   "isa",
   "car",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S1_el3",
  "@logic": [
   "has degree property",
   "good",
   "$set1_el3",
   "none",
   "car",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1_el3",
  "@logic": [
   "have",
   "#:John 1",
   "$set1_el3",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1_el3",
  "@logic": [
   "member",
   "$set1_el3",
   [
    "$setof",
    "have",
    "#:John 1",
    [
     "$and",
     [
      "$isa",
      "car",
      "$arg1"
     ],
     [
      "$has_degree_property",
      "good",
      "$arg1",
      "none",
      "car"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1_dist",
  "@logic": [
   "-=",
   "$set1_el1",
   "$set1_el2"
  ]
 },
 {
  "@name": "sent_S1_dist",
  "@logic": [
   "-=",
   "$set1_el1",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S1_dist",
  "@logic": [
   "-=",
   "$set1_el2",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:N"
   ],
   [
    "=",
    "?:N",
    [
     "$count",
     [
      "$setof",
      "have",
      "#:John 1",
      [
       "$and",
       [
        "$isa",
        "car",
        "$arg1"
       ],
       [
        "$has_degree_property",
        "good",
        "$arg1",
        "none",
        "car"
       ]
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-=",
    "?:N",
    [
     "$count",
     [
      "$setof",
      "have",
      "#:John 1",
      [
       "$and",
       [
        "$isa",
        "car",
        "$arg1"
       ],
       [
        "$has_degree_property",
        "good",
        "$arg1",
        "none",
        "car"
       ]
      ]
     ]
    ]
   ],
   [
    "$defq0",
    "?:N"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0",
   "?:N"
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-isa",
    "?:C",
    "?:M"
   ],
   [
    "-has property",
    "?:D",
    "?:M"
   ],
   [
    "-have",
    "?:S",
    "?:M"
   ],
   [
    "member",
    "?:M",
    [
     "$setof",
     "have",
     "?:S",
     [
      "$and",
      [
       "$isa",
       "?:C",
       "$arg1"
      ],
      [
       "$has_degree_property",
       "?:D",
       "$arg1",
       "?:E",
       "?:C"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "have",
     "?:S",
     [
      "$and",
      [
       "$isa",
       "?:C",
       "$arg1"
      ],
      [
       "$has_degree_property",
       "?:D",
       "$arg1",
       "?:E",
       "?:C"
      ]
     ]
    ]
   ],
   [
    "isa",
    "?:C",
    "?:M"
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "have",
     "?:S",
     [
      "$and",
      [
       "$isa",
       "?:C",
       "$arg1"
      ],
      [
       "$has_degree_property",
       "?:D",
       "$arg1",
       "?:E",
       "?:C"
      ]
     ]
    ]
   ],
   [
    "has property",
    "?:D",
    "?:M"
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "have",
     "?:S",
     [
      "$and",
      [
       "$isa",
       "?:C",
       "$arg1"
      ],
      [
       "$has_degree_property",
       "?:D",
       "$arg1",
       "?:E",
       "?:C"
      ]
     ]
    ]
   ],
   [
    "have",
    "?:S",
    "?:M"
   ]
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "receive",
    "?:Fv7"
   ],
   [
    "has type",
    "?:E",
    "have",
    "?:Fv7"
   ]
  ],
  "@confidence": 0.89
 }
]