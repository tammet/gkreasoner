[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "book",
   "#:book 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "buy",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:John 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:book 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:Bill 3"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:Peter 4"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "activity",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has type",
   "sk1_activity",
   "say",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has actor",
   "sk1_activity",
   "#:Bill 3",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has time",
   "sk1_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has content",
   "sk1_activity",
   "sk2_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "activity",
   "sk2_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has type",
   "sk2_activity",
   "buy",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has actor",
   "sk2_activity",
   "#:Peter 4",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has time",
   "sk2_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "book",
   "sk3_book"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has target",
   "sk2_activity",
   "sk3_book",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "speech_act",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk4_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk4_activity",
    "say",
    [
     "$ctxt",
     "past",
     "?:Fv10",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk4_activity",
    "#:Bill 3",
    [
     "$ctxt",
     "past",
     "?:Fv12",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has time",
    "sk4_activity",
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has content",
    "sk4_activity",
    "sk5_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk5_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk5_activity",
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv18",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk5_activity",
    "#:Peter 4",
    [
     "$ctxt",
     "past",
     "?:Fv20",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has time",
    "sk5_activity",
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv22",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "book",
    "sk6_book"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has target",
    "sk5_activity",
    "sk6_book",
    [
     "$ctxt",
     "past",
     "?:Fv26",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "speech_act",
    "sk4_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E1"
   ],
   [
    "-has type",
    "?:E1",
    "say",
    [
     "$ctxt",
     "past",
     "?:Fv30",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has actor",
    "?:E1",
    "#:Bill 3",
    [
     "$ctxt",
     "past",
     "?:Fv32",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has content",
    "?:E1",
    "?:E2"
   ],
   [
    "-isa",
    "activity",
    "?:E2"
   ],
   [
    "-has type",
    "?:E2",
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv38",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has actor",
    "?:E2",
    "#:Peter 4",
    [
     "$ctxt",
     "past",
     "?:Fv40",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-isa",
    "book",
    "?:Y"
   ],
   [
    "-has target",
    "?:E2",
    "?:Y",
    [
     "$ctxt",
     "past",
     "?:Fv46",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-speech_act",
    "?:E1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "book",
   "$some_not_book"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv48",
     "?:Fv49",
     "?:Fv51",
     "?:Fv52"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv48",
     "?:Fv49",
     "?:Fv51",
     "?:Fv52"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv48",
     "?:Fv49",
     "?:Fv51",
     "?:Fv52"
    ]
   ],
   [
    "-next",
    "?:Fv49",
    "?:Fv50"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv50",
     "?:Fv51",
     "?:Fv52"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "?:Owner",
      "?:Obj",
      [
       "$ctxt",
       "present",
       "?:Fv50",
       "?:Fv51",
       "?:Fv52"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv53",
     "?:Fv54",
     "?:Fv56",
     "?:Fv57"
    ]
   ],
   [
    "-has beneficiary",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv53",
     "?:Fv54",
     "?:Fv56",
     "?:Fv57"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv53",
     "?:Fv54",
     "?:Fv56",
     "?:Fv57"
    ]
   ],
   [
    "-next",
    "?:Fv54",
    "?:Fv55"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv55",
     "?:Fv56",
     "?:Fv57"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv58",
     "?:Fv59",
     "?:Fv61",
     "?:Fv62"
    ]
   ],
   [
    "-has recipient",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv58",
     "?:Fv59",
     "?:Fv61",
     "?:Fv62"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv58",
     "?:Fv59",
     "?:Fv61",
     "?:Fv62"
    ]
   ],
   [
    "-next",
    "?:Fv59",
    "?:Fv60"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv60",
     "?:Fv61",
     "?:Fv62"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]