[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Sandra 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "kitchen",
   "#:kitchen 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "go",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:Sandra 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has destination",
   "sk0_activity",
   "#:kitchen 2",
   "at",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:Sandra 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "hallway",
   "#:hallway 3"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "activity",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has type",
   "sk1_activity",
   "go",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has actor",
   "sk1_activity",
   "#:Sandra 1",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has destination",
   "sk1_activity",
   "#:hallway 3",
   "at",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has time",
   "sk1_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "actuality",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "next",
   "W1",
   "W2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "person",
   "#:Mary 4"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "bathroom",
   "#:bathroom 5"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "activity",
   "sk2_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has type",
   "sk2_activity",
   "go",
   [
    "$ctxt",
    "past",
    "W2",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has actor",
   "sk2_activity",
   "#:Mary 4",
   [
    "$ctxt",
    "past",
    "W2",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has destination",
   "sk2_activity",
   "#:bathroom 5",
   "at",
   [
    "$ctxt",
    "past",
    "W2",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has time",
   "sk2_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W2",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "actuality",
   "sk2_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "next",
   "W2",
   "W3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "person",
   "#:Sandra 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "garden",
   "#:garden 6"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "activity",
   "sk3_activity"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has type",
   "sk3_activity",
   "go",
   [
    "$ctxt",
    "past",
    "W3",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has actor",
   "sk3_activity",
   "#:Sandra 1",
   [
    "$ctxt",
    "past",
    "W3",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has destination",
   "sk3_activity",
   "#:garden 6",
   "at",
   [
    "$ctxt",
    "past",
    "W3",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has time",
   "sk3_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W3",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "actuality",
   "sk3_activity"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "next",
   "W3",
   "W4"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "in",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0",
    "in",
    "?:Q1"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "in",
    "?:Q1"
   ],
   [
    "is rel2",
    "in",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "on",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0",
    "on",
    "?:Q1"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "on",
    "?:Q1"
   ],
   [
    "is rel2",
    "on",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "at",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0",
    "at",
    "?:Q1"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "at",
    "?:Q1"
   ],
   [
    "is rel2",
    "at",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has degree rel2",
    "near",
    "#:Sandra 1",
    "?:Q1",
    "none",
    "?:Fv26",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0",
    "near",
    "?:Q1"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "near",
    "?:Q1"
   ],
   [
    "has degree rel2",
    "near",
    "#:Sandra 1",
    "?:Q1",
    "none",
    "?:Fv27",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "above",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0",
    "above",
    "?:Q1"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "above",
    "?:Q1"
   ],
   [
    "is rel2",
    "above",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "under",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0",
    "under",
    "?:Q1"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "under",
    "?:Q1"
   ],
   [
    "is rel2",
    "under",
    "#:Sandra 1",
    "?:Q1",
    [
     "$ctxt",
     "present",
     "W4",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@question": [
   "$defq0",
   "?:Rel",
   "?:Q1"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-has degree rel2",
    "near",
    "#:Sandra 1",
    "?:Br1",
    "none",
    "?:Fv23",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree rel2",
    "near",
    "#:Sandra 1",
    "?:Br1",
    "none",
    "?:Fv24",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree rel2",
      "near",
      "#:Sandra 1",
      "?:Br1",
      "none",
      "?:Fv25",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "in",
    "#:Sandra 1",
    "?:Br2",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "in",
    "#:Sandra 1",
    "?:Br2",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "in",
      "#:Sandra 1",
      "?:Br2",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "on",
    "#:Sandra 1",
    "?:Br3",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "on",
    "#:Sandra 1",
    "?:Br3",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "on",
      "#:Sandra 1",
      "?:Br3",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "at",
    "#:Sandra 1",
    "?:Br4",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "at",
    "#:Sandra 1",
    "?:Br4",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "at",
      "#:Sandra 1",
      "?:Br4",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "under",
    "#:Sandra 1",
    "?:Br5",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "under",
    "#:Sandra 1",
    "?:Br5",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "under",
      "#:Sandra 1",
      "?:Br5",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "above",
    "#:Sandra 1",
    "?:Br6",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "above",
    "#:Sandra 1",
    "?:Br6",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "above",
      "#:Sandra 1",
      "?:Br6",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv12"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv12"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "hallway",
   "$some_hallway"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "garden",
   "$some_garden"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "bathroom",
   "$some_bathroom"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "kitchen",
   "$some_kitchen"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W1",
   "W2"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W2",
   "W3"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W3",
   "W4"
  ]
 }
]