[
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "machine translation",
   "#:Machine translation 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "natural language processing task",
    "?:X"
   ],
   [
    "isa",
    "language generation task",
    "?:X"
   ],
   [
    "isa",
    "language understanding task",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "natural language processing task",
    "?:X"
   ],
   [
    "-isa",
    "language generation task",
    "?:X"
   ],
   [
    "-isa",
    "language understanding task",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "natural language processing task",
    "?:X"
   ],
   [
    "-isa",
    "text sequence",
    "?:Y"
   ],
   [
    "-is rel2",
    "output of",
    "?:X",
    "?:Y",
    "?:Cu4"
   ],
   [
    "isa",
    "language generation task",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "natural language processing task",
   "#:Machine translation 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "output",
   "#:output 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "text sequence",
   "sk0_text sequence"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "output of",
   "#:Machine translation 1",
   "#:output 2",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "output",
   "#:output 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "output of",
   "#:Machine translation 1",
   "#:output 2",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "language generation task",
    "#:Machine translation 1"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "language generation task",
    "#:Machine translation 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "natural language processing task",
   "$some_not_natural_language_processing_task"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "language generation task",
   "$some_language_generation_task"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "language generation task",
   "$some_not_language_generation_task"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "language understanding task",
   "$some_language_understanding_task"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "text sequence",
   "$some_text_sequence"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "text sequence",
   "$some_not_text_sequence"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "language generation task",
    "?:X"
   ],
   [
    "isa",
    "task",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "language generation",
    "?:X"
   ],
   [
    "-isa",
    "task",
    "?:X"
   ],
   [
    "isa",
    "language generation task",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "language understanding task",
    "?:X"
   ],
   [
    "isa",
    "task",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "language understanding",
    "?:X"
   ],
   [
    "-isa",
    "task",
    "?:X"
   ],
   [
    "isa",
    "language understanding task",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "machine translation",
    "?:X"
   ],
   [
    "isa",
    "translation",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "machine",
    "?:X"
   ],
   [
    "-isa",
    "translation",
    "?:X"
   ],
   [
    "isa",
    "machine translation",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "natural language processing task",
    "?:X"
   ],
   [
    "isa",
    "task",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "natural language processing",
    "?:X"
   ],
   [
    "-isa",
    "task",
    "?:X"
   ],
   [
    "isa",
    "natural language processing task",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "text sequence",
    "?:X"
   ],
   [
    "isa",
    "sequence",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "text",
    "?:X"
   ],
   [
    "-isa",
    "sequence",
    "?:X"
   ],
   [
    "isa",
    "text sequence",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]