[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "sk0_campus",
    "?:Cu2"
   ],
   [
    "has property",
    "cute",
    "?:X",
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "turtle",
   "sk2_turtle"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "spot",
   "sk2_turtle",
   "sk0_campus",
   "?:Cu5"
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "sk0_campus",
    "?:Cu7"
   ],
   [
    "isa",
    "rabbit",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "sk0_campus",
    "?:Cu9"
   ],
   [
    "isa",
    "squirrel",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-has property",
    "skittish",
    "?:X",
    "?:Cu10"
   ],
   [
    "-has property",
    "calm",
    "?:X",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-is rel2",
    "spot",
    "?:X",
    "sk0_campus",
    "?:Cu12"
   ],
   [
    "has property",
    "skittish",
    "?:X",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "campus",
   "sk0_campus"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "animal",
   "#:Rockie 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "spot",
   "#:Rockie 1",
   "sk0_campus",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "animal",
   "#:Rockie 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "has property",
   "calm",
   "#:Rockie 1",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "turtle",
    "#:Rockie 1"
   ],
   [
    "has property",
    "cute",
    "#:Rockie 1",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "turtle",
    "#:Rockie 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "cute",
    "#:Rockie 1",
    "?:Cu20"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "campus",
   "$some_campus"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "campus",
   "$some_not_campus"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "turtle",
   "$some_turtle"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "turtle",
   "$some_not_turtle"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "rabbit",
   "$some_rabbit"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "rabbit",
   "$some_not_rabbit"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "squirrel",
   "$some_squirrel"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "squirrel",
   "$some_not_squirrel"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "cute",
   "$some_cute",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "cute",
   "$some_not_cute",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "skittish",
   "$some_skittish",
   "?:Cu32"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "skittish",
   "$some_not_skittish",
   "?:Cu33"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "calm",
   "$some_not_calm",
   "?:Cu34"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]