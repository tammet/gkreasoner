[
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "artifact",
   "#:KO 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "growth stock",
    "?:X"
   ],
   [
    "has property",
    "buy",
    "?:X",
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "stock",
    "?:X"
   ],
   [
    "-has property",
    "buy",
    "?:X",
    "?:Cu3"
   ],
   [
    "-has property",
    "suitable for",
    "?:X",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "stock",
   "sk0_stock"
  ],
  "@confidence": 0.9899
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "growth stock",
   "sk0_stock"
  ],
  "@confidence": 0.9899
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "mature stock",
    "?:X"
   ],
   [
    "-has property",
    "mature",
    "?:X",
    "?:Cu6"
   ],
   [
    "isa",
    "retirement fund",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "mature stock",
    "?:X"
   ],
   [
    "-has property",
    "mature",
    "?:X",
    "?:Cu7"
   ],
   [
    "has property",
    "suitable for",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "mature stock",
   "https://en.wikipedia.org/wiki/The_Coca-Cola_Company"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "has property",
   "mature",
   "https://en.wikipedia.org/wiki/The_Coca-Cola_Company",
   "?:Cu9"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "stock",
    "https://en.wikipedia.org/wiki/The_Coca-Cola_Company"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "stock",
    "https://en.wikipedia.org/wiki/The_Coca-Cola_Company"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "growth stock",
   "$some_growth_stock"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "growth stock",
   "$some_not_growth_stock"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "stock",
   "$some_stock"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "stock",
   "$some_not_stock"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "mature stock",
   "$some_not_mature_stock"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "retirement fund",
   "$some_retirement_fund"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "retirement fund",
   "$some_not_retirement_fund"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "buy",
   "$some_buy",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "buy",
   "$some_not_buy",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "suitable for",
   "$some_suitable_for",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "suitable for",
   "$some_not_suitable_for",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "mature",
   "$some_not_mature",
   "?:Cu23"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "stock",
   "$some_buy_stock"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "buy",
   "$some_buy_stock",
   "?:Cu25"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "growth stock",
    "?:X"
   ],
   [
    "isa",
    "stock",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "growth",
    "?:X"
   ],
   [
    "-isa",
    "stock",
    "?:X"
   ],
   [
    "isa",
    "growth stock",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "mature stock",
    "?:X"
   ],
   [
    "isa",
    "stock",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "mature",
    "?:X"
   ],
   [
    "-isa",
    "stock",
    "?:X"
   ],
   [
    "isa",
    "mature stock",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "retirement fund",
    "?:X"
   ],
   [
    "isa",
    "fund",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "retirement",
    "?:X"
   ],
   [
    "-isa",
    "fund",
    "?:X"
   ],
   [
    "isa",
    "retirement fund",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    "?:Cu32"
   ],
   [
    "-has actor",
    "?:E",
    "?:Owner",
    "?:Cu32"
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    "?:Cu32"
   ],
   [
    "-next",
    "?:Fv26",
    "?:Fv27"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    "?:Cu32"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    "?:Cu33"
   ],
   [
    "-has beneficiary",
    "?:E",
    "?:Owner",
    "?:Cu33"
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    "?:Cu33"
   ],
   [
    "-next",
    "?:Fv31",
    "?:Fv32"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    "?:Cu33"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    "?:Cu34"
   ],
   [
    "-has recipient",
    "?:E",
    "?:Owner",
    "?:Cu34"
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    "?:Cu34"
   ],
   [
    "-next",
    "?:Fv36",
    "?:Fv37"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    "?:Cu34"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]