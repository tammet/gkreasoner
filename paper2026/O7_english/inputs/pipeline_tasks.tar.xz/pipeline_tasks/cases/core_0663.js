[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:garden 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "garden",
   "#:garden 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "isa",
    "activity",
    [
     "sk0",
     "?:M"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "has type",
    [
     "sk0",
     "?:M"
    ],
    "laugh",
    [
     "$ctxt",
     "past",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "has actor",
    [
     "sk0",
     "?:M"
    ],
    "?:M",
    [
     "$ctxt",
     "past",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "has time",
    [
     "sk0",
     "?:M"
    ],
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "actuality",
    [
     "sk0",
     "?:M"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1_exist",
  "@logic": [
   "member",
   "$some_person",
   [
    "$setof",
    "id",
    "#:set 1",
    [
     "$and",
     [
      "isa",
      "person",
      "$arg1"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "isa",
    "activity",
    [
     "sk1",
     "?:M"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "has type",
    [
     "sk1",
     "?:M"
    ],
    "play",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "has actor",
    [
     "sk1",
     "?:M"
    ],
    "?:M",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "has location",
    [
     "sk1",
     "?:M"
    ],
    "#:garden 1",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "has time",
    [
     "sk1",
     "?:M"
    ],
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "actuality",
    [
     "sk1",
     "?:M"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "is rel2",
    "in",
    "?:M",
    "#:garden 1",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "member",
    "sk2",
    [
     "$setof",
     "id",
     "#:set 1",
     [
      "$and",
      [
       "isa",
       "person",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "in",
    "sk2",
    "#:garden 1",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "in",
    "sk2",
    "#:garden 1",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "in",
    "sk2",
    "#:garden 1",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "in",
      "sk2",
      "#:garden 1",
      [
       "$ctxt",
       "past",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-isa",
    "?:C",
    "?:M"
   ],
   [
    "member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:C",
       "$arg1"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:C",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "isa",
    "?:C",
    "?:M"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 }
]