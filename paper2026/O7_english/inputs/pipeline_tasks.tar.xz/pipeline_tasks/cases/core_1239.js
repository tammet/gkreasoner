[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Tallinn 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Estonia 2"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "place",
   "#:Europe 3"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "place",
   "#:Earth 4"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "place",
   "#:Tartu 5"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "place",
   "#:Riga 6"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "in",
   "https://en.wikipedia.org/wiki/Tallinn",
   "https://en.wikipedia.org/wiki/Estonia",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "-is rel2",
   "outside",
   "https://en.wikipedia.org/wiki/Estonia",
   "https://en.wikipedia.org/wiki/Europe",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "in",
   "https://en.wikipedia.org/wiki/Europe",
   "https://en.wikipedia.org/wiki/Earth",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "in",
   "https://en.wikipedia.org/wiki/Tartu",
   "https://en.wikipedia.org/wiki/Estonia",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "-is rel2",
   "in",
   "https://en.wikipedia.org/wiki/Riga",
   "https://en.wikipedia.org/wiki/Estonia",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv9",
    "?:Fv10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Riga",
    "https://en.wikipedia.org/wiki/Estonia",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv11",
     "?:Fv12"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Riga",
    "https://en.wikipedia.org/wiki/Estonia",
    [
     "$ctxt",
     "present",
     "?:Fv13",
     "?:Fv11",
     "?:Fv12"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question_bridge",
  "@confidence": 0.95,
  "@logic": [
   [
    "-is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Riga",
    "https://en.wikipedia.org/wiki/Estonia",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "is rel2",
    "in",
    "https://en.wikipedia.org/wiki/Riga",
    "https://en.wikipedia.org/wiki/Estonia",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "is rel2",
      "in",
      "https://en.wikipedia.org/wiki/Riga",
      "https://en.wikipedia.org/wiki/Estonia",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "in",
    "?:X",
    "?:Fv15"
   ],
   [
    "-has property",
    "outside",
    "?:X",
    "?:Fv15"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "outside",
     "?:X",
     "?:Fv15"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "in",
    "?:X",
    "?:Fv16"
   ],
   [
    "-has property",
    "outside",
    "?:X",
    "?:Fv16"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "in",
     "?:X",
     "?:Fv16"
    ]
   ]
  ],
  "@confidence": 0.95
 }
]