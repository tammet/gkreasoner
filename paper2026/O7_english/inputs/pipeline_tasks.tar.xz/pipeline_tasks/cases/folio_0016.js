[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "square",
    "?:X"
   ],
   [
    "has property",
    "four-sided",
    "?:X",
    "?:Cu1"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-has property",
    "four-sided",
    "?:X",
    "?:Cu2"
   ],
   [
    "isa",
    "shape",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "square",
    "?:X"
   ],
   [
    "isa",
    "shape",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "square",
    "sk0_square"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "shape",
    "sk0_square"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "square",
   "$some_square"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "square",
   "$some_not_square"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "shape",
   "$some_shape"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "shape",
   "$some_not_shape"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "four-sided",
   "$some_four-sided",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "four-sided",
   "$some_not_four-sided",
   "?:Cu11"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]