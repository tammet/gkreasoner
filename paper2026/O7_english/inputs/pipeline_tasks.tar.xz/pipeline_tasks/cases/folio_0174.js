[
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "woman",
   "#:Taylor 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "eat",
    "?:X",
    "salad",
    "?:Cu2"
   ],
   [
    "has property",
    "conscious",
    "?:X",
    "?:Cu2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "eat",
    "?:X",
    "salad",
    "?:Cu3"
   ],
   [
    "is rel2",
    "conscious about",
    "?:X",
    "health",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "eat",
    "?:X",
    "salad",
    "?:Cu4"
   ],
   [
    "is rel2",
    "conscious about",
    "?:X",
    "eating habits",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-has property",
    "health-conscious",
    "?:H",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "grow up",
    "?:X",
    "?:H",
    "?:Cu5"
   ],
   [
    "is rel2",
    "eat",
    "?:X",
    "salad",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "fulfill",
    "?:X",
    "daily nutritional intake",
    "?:Cu6"
   ],
   [
    "isa",
    "home",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "fulfill",
    "?:X",
    "daily nutritional intake",
    "?:Cu7"
   ],
   [
    "has property",
    "health-conscious",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "fulfill",
    "?:X",
    "daily nutritional intake",
    "?:Cu8"
   ],
   [
    "is rel2",
    "grow up",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "ignore",
    "?:X",
    "physical well-being",
    "?:Cu9"
   ],
   [
    "has property",
    "conscious",
    "?:X",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "ignore",
    "?:X",
    "physical well-being",
    "?:Cu10"
   ],
   [
    "-has property",
    "conscious",
    "?:X",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "ignore",
    "?:X",
    "physical well-being",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "conscious about",
    "?:X",
    "health",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "ignore",
    "?:X",
    "physical well-being",
    "?:Cu12"
   ],
   [
    "-is rel2",
    "conscious about",
    "?:X",
    "eating habits",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "gym",
   "sk1_gym"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "visit",
    "?:X",
    "sk1_gym",
    "?:Cu14"
   ],
   [
    "is rel2",
    "fulfill",
    "?:X",
    "daily nutritional intake",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Taylor 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "home",
    "sk2_home"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-has property",
    "health-conscious",
    "?:H",
    "?:Cu16"
   ],
   [
    "-is rel2",
    "grow up",
    "#:Taylor 1",
    "?:H",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "home",
    "sk2_home"
   ],
   [
    "-is rel2",
    "ignore",
    "#:Taylor 1",
    "physical well-being",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "has property",
    "health-conscious",
    "sk2_home",
    "?:Cu18"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-has property",
    "health-conscious",
    "?:H",
    "?:Cu18"
   ],
   [
    "-is rel2",
    "grow up",
    "#:Taylor 1",
    "?:H",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "has property",
    "health-conscious",
    "sk2_home",
    "?:Cu19"
   ],
   [
    "-is rel2",
    "ignore",
    "#:Taylor 1",
    "physical well-being",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "grow up",
    "#:Taylor 1",
    "sk2_home",
    "?:Cu20"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-has property",
    "health-conscious",
    "?:H",
    "?:Cu20"
   ],
   [
    "-is rel2",
    "grow up",
    "#:Taylor 1",
    "?:H",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "grow up",
    "#:Taylor 1",
    "sk2_home",
    "?:Cu21"
   ],
   [
    "-is rel2",
    "ignore",
    "#:Taylor 1",
    "physical well-being",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "ignore",
    "#:Taylor 1",
    "physical well-being",
    "?:Cu22"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-has property",
    "health-conscious",
    "?:H",
    "?:Cu22"
   ],
   [
    "-is rel2",
    "grow up",
    "#:Taylor 1",
    "?:H",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "gym",
    "sk1_gym"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "visit",
    "#:Taylor 1",
    "sk1_gym",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "gym",
    "?:G"
   ],
   [
    "-is rel2",
    "visit",
    "#:Taylor 1",
    "?:G",
    "?:Cu29"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "home",
   "$some_home"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "home",
   "$some_not_home"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "gym",
   "$some_gym"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "gym",
   "$some_not_gym"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "conscious",
   "$some_conscious",
   "?:Cu36"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "conscious",
   "$some_not_conscious",
   "?:Cu37"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "health-conscious",
   "$some_health-conscious",
   "?:Cu38"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "health-conscious",
   "$some_not_health-conscious",
   "?:Cu39"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]