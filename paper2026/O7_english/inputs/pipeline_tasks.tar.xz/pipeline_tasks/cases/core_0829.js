[
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "person",
   "#:Mike 4"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Eve 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "have",
   "#:John 1",
   "#:car 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "buy",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:Eve 3",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:car 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "car",
    "sk1_car"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "have",
    "#:John 1",
    "sk1_car",
    [
     "$ctxt",
     "past",
     "?:Fv8",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk2_activity",
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk2_activity",
    "#:Mike 4",
    [
     "$ctxt",
     "past",
     "?:Fv13",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has target",
    "sk2_activity",
    "sk1_car",
    [
     "$ctxt",
     "past",
     "?:Fv15",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has time",
    "sk2_activity",
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv17",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "actuality",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "car",
    "?:Y"
   ],
   [
    "-have",
    "#:John 1",
    "?:Y",
    [
     "$ctxt",
     "past",
     "?:Fv21",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv24",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:Mike 4",
    [
     "$ctxt",
     "past",
     "?:Fv26",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Y",
    [
     "$ctxt",
     "past",
     "?:Fv28",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question_bridge",
  "@confidence": 0.97,
  "@logic": [
   [
    "-have",
    "#:John 1",
    "?:Br1",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "have",
    "#:John 1",
    "?:Br1",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "#:John 1",
      "?:Br1",
      [
       "$ctxt",
       "past",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv32",
     "?:Fv33",
     "?:Fv35",
     "?:Fv36"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv32",
     "?:Fv33",
     "?:Fv35",
     "?:Fv36"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv32",
     "?:Fv33",
     "?:Fv35",
     "?:Fv36"
    ]
   ],
   [
    "-next",
    "?:Fv33",
    "?:Fv34"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv34",
     "?:Fv35",
     "?:Fv36"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "?:Owner",
      "?:Obj",
      [
       "$ctxt",
       "present",
       "?:Fv34",
       "?:Fv35",
       "?:Fv36"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv37",
     "?:Fv38",
     "?:Fv40",
     "?:Fv41"
    ]
   ],
   [
    "-has beneficiary",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv37",
     "?:Fv38",
     "?:Fv40",
     "?:Fv41"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv37",
     "?:Fv38",
     "?:Fv40",
     "?:Fv41"
    ]
   ],
   [
    "-next",
    "?:Fv38",
    "?:Fv39"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv39",
     "?:Fv40",
     "?:Fv41"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv42",
     "?:Fv43",
     "?:Fv45",
     "?:Fv46"
    ]
   ],
   [
    "-has recipient",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv42",
     "?:Fv43",
     "?:Fv45",
     "?:Fv46"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv42",
     "?:Fv43",
     "?:Fv45",
     "?:Fv46"
    ]
   ],
   [
    "-next",
    "?:Fv43",
    "?:Fv44"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv44",
     "?:Fv45",
     "?:Fv46"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]