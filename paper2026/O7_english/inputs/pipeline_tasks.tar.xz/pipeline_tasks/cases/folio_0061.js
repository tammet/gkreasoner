[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:US 1"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "man",
   "#:Mike 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "https://en.wikipedia.org/wiki/United_States",
    "?:Cu3"
   ],
   [
    "have",
    "?:X",
    "F1 visa",
    "?:Cu3"
   ],
   [
    "have",
    "?:X",
    "J1 visa",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "https://en.wikipedia.org/wiki/United_States",
    "?:Cu4"
   ],
   [
    "-have",
    "?:X",
    "F1 visa",
    "?:Cu4"
   ],
   [
    "-have",
    "?:X",
    "J1 visa",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "https://en.wikipedia.org/wiki/United_States",
    "?:Cu5"
   ],
   [
    "-have",
    "?:X",
    "F1 visa",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "want",
    "?:X",
    "work",
    "?:Cu5"
   ],
   [
    "is rel2",
    "apply",
    "?:X",
    "CPT",
    "?:Cu5"
   ],
   [
    "is rel2",
    "apply",
    "?:X",
    "OPT",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "person",
   "#:Mike 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "international student",
   "#:Mike 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "want",
    "#:Mike 2",
    "work",
    "?:Cu8"
   ],
   [
    "is rel2",
    "apply",
    "#:Mike 2",
    "CPT",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "have",
    "#:Mike 2",
    "F1 visa",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-have",
    "#:Mike 2",
    "F1 visa",
    "?:Cu10"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "international student",
    "?:X"
   ],
   [
    "isa",
    "student",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "international",
    "?:X"
   ],
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "isa",
    "international student",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]