[
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "person",
   "#:James 1"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "man",
   "#:James 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "place",
   "sk0_place"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "-is rel2",
    "schedule",
    "?:X",
    "customer",
    "?:Cu4"
   ],
   [
    "is rel2",
    "go",
    "?:X",
    "sk0_place",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "place",
   "sk0_place"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu6"
   ],
   [
    "is rel2",
    "schedule",
    "?:X",
    "customer",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "place",
   "sk0_place"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu9"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    "?:H",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "?:C",
    "?:Cu10"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    "?:H",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "manager",
    "?:X"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-is rel2",
    "work",
    "?:X",
    "?:H",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "place",
   "sk0_place"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "appear",
    "#:James 1",
    "sk0_place",
    "?:Cu13"
   ],
   [
    "isa",
    "manager",
    "#:James 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "manager",
    "#:James 1"
   ],
   [
    "is rel2",
    "appear",
    "#:James 1",
    "sk0_place",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "place",
    "sk0_place"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "place",
    "?:W"
   ],
   [
    "-is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu17"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "place",
   "$some_place"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "place",
   "$some_not_place"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "employee",
   "$some_employee"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "employee",
   "$some_not_employee"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "home",
   "$some_home"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "home",
   "$some_not_home"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "manager",
   "$some_not_manager"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv35"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv35"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "receive",
    "?:Fv36"
   ],
   [
    "has type",
    "?:E",
    "have",
    "?:Fv36"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]