[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "has type",
    [
     "sk0",
     "?:X"
    ],
    "eat",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "has actor",
    [
     "sk0",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "isa",
    "berry",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "has target",
    [
     "sk0",
     "?:X"
    ],
    [
     "sk1",
     "?:X"
    ],
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "isa",
    "forest",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "has degree property",
    "deep",
    [
     "sk2",
     "?:X"
    ],
    "none",
    "forest",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "has location",
    [
     "sk0",
     "?:X"
    ],
    [
     "sk2",
     "?:X"
    ],
    "in",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "has manner",
    [
     "sk0",
     "?:X"
    ],
    "quickly",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "bear",
    "?:X"
   ],
   [
    "typical",
    [
     "sk0",
     "?:X"
    ],
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "bear",
     1
    ],
    [
     "$not",
     [
      "typical",
      [
       "sk0",
       "?:X"
      ],
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "bear",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk3_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk3_activity",
    "eat",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk3_activity",
    "#:John 1",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "berry",
    "sk4_berry"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has target",
    "sk3_activity",
    "sk4_berry",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "forest",
    "sk5_forest"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "deep",
    "sk5_forest",
    "none",
    "forest",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has location",
    "sk3_activity",
    "sk5_forest",
    "in",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has manner",
    "sk3_activity",
    "quickly",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "typical",
    "sk3_activity",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "eat",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:John 1",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-isa",
    "berry",
    "?:Y"
   ],
   [
    "-has target",
    "?:E",
    "?:Y",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-isa",
    "forest",
    "?:Z"
   ],
   [
    "-has degree property",
    "deep",
    "?:Z",
    "none",
    "forest",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-has location",
    "?:E",
    "?:Z",
    "in",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-has manner",
    "?:E",
    "quickly",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-typical",
    "?:E",
    [
     "$ctxt",
     "?:Fv10",
     "?:Fv9",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bear",
   "$some_not_bear"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "berry",
   "$some_berry"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "berry",
   "$some_not_berry"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "forest",
   "$some_forest"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "forest",
   "$some_not_forest"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "deep",
   "$some_deep_forest",
   "none",
   "forest",
   [
    "$ctxt",
    "?:Fv48",
    "?:Fv45",
    "?:Fv46",
    "?:Fv47"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "forest",
   "$some_deep_forest"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "deep",
   "$some_not_deep_forest",
   "none",
   "forest",
   [
    "$ctxt",
    "?:Fv56",
    "?:Fv53",
    "?:Fv54",
    "?:Fv55"
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "deep",
    "?:X",
    "none",
    "?:Fv57",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "has degree property",
    "deep",
    "?:X",
    "none",
    "?:Fv58",
    [
     "$ctxt",
     "present",
     "?:Fv11",
     "?:Fv12",
     "?:Fv13"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "deep",
      "?:X",
      "none",
      "?:Fv59",
      [
       "$ctxt",
       "present",
       "?:Fv11",
       "?:Fv12",
       "?:Fv13"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "deep",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "has degree property",
    "deep",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv14",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "deep",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv14",
       "?:Fv15",
       "?:Fv16"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]