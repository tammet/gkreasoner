[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "-isa",
    "animal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "elephant",
    "sk0_elephant"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "animal",
    "sk0_elephant"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "elephant",
   "$some_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "elephant",
   "$some_not_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 }
]