[
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "person",
   "#:Professor David 1"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "professor david",
   "#:Professor David 1"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "man",
   "#:James 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "work",
    "?:X",
    "library",
    "?:Cu4"
   ],
   [
    "-isa",
    "computer science department",
    "?:D"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "?:D",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "?:X",
    "?:J",
    "?:Cu5"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu5"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    "library",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "computer science department",
    "?:D"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "?:D",
    "?:Cu6"
   ],
   [
    "isa",
    "database course",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "computer science department",
    "?:D"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "?:D",
    "?:Cu7"
   ],
   [
    "is rel2",
    "take",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "class",
    "?:CL"
   ],
   [
    "-is rel2",
    "take",
    "?:X",
    "?:CL",
    "?:Cu8"
   ],
   [
    "-is rel2",
    "with",
    "?:CL",
    "#:Professor David 1",
    "?:Cu8"
   ],
   [
    "isa",
    "database course",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "student",
    "?:X"
   ],
   [
    "-isa",
    "class",
    "?:CL"
   ],
   [
    "-is rel2",
    "take",
    "?:X",
    "?:CL",
    "?:Cu9"
   ],
   [
    "-is rel2",
    "with",
    "?:CL",
    "#:Professor David 1",
    "?:Cu9"
   ],
   [
    "is rel2",
    "take",
    "?:X",
    [
     "sk1",
     "?:X"
    ],
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "work",
    "?:X",
    "lab",
    "?:Cu10"
   ],
   [
    "isa",
    "class",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "work",
    "?:X",
    "lab",
    "?:Cu11"
   ],
   [
    "is rel2",
    "take",
    "?:X",
    [
     "sk2",
     "?:X"
    ],
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "work",
    "?:X",
    "lab",
    "?:Cu12"
   ],
   [
    "is rel2",
    "with",
    [
     "sk2",
     "?:X"
    ],
    "#:Professor David 1",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "student",
   "#:James 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:James 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "lab",
   "#:lab 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "work",
   "#:James 2",
   "#:lab 3",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:James 2"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "lab",
   "#:lab 3"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "-is rel2",
   "work",
   "#:James 2",
   "#:lab 3",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "#:James 2",
    "?:J",
    "?:Cu20"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "database course",
    "sk3_database course"
   ],
   [
    "isa",
    "part-time job",
    "sk4_part-time job"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "database course",
    "sk3_database course"
   ],
   [
    "have",
    "#:James 2",
    "sk4_part-time job",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "database course",
    "sk3_database course"
   ],
   [
    "isa",
    "university",
    "sk5_university"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "database course",
    "sk3_database course"
   ],
   [
    "is rel2",
    "offered by",
    "sk4_part-time job",
    "sk5_university",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "take",
    "#:James 2",
    "sk3_database course",
    "?:Cu25"
   ],
   [
    "isa",
    "part-time job",
    "sk4_part-time job"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "take",
    "#:James 2",
    "sk3_database course",
    "?:Cu26"
   ],
   [
    "have",
    "#:James 2",
    "sk4_part-time job",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "take",
    "#:James 2",
    "sk3_database course",
    "?:Cu27"
   ],
   [
    "isa",
    "university",
    "sk5_university"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "take",
    "#:James 2",
    "sk3_database course",
    "?:Cu28"
   ],
   [
    "is rel2",
    "offered by",
    "sk4_part-time job",
    "sk5_university",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "database course",
    "?:C"
   ],
   [
    "-is rel2",
    "take",
    "#:James 2",
    "?:C",
    "?:Cu29"
   ],
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "#:James 2",
    "?:J",
    "?:Cu29"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu29"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "database course",
    "?:C"
   ],
   [
    "-is rel2",
    "take",
    "#:James 2",
    "?:C",
    "?:Cu30"
   ],
   [
    "isa",
    "database course",
    "sk6_database course"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "database course",
    "?:C"
   ],
   [
    "-is rel2",
    "take",
    "#:James 2",
    "?:C",
    "?:Cu31"
   ],
   [
    "is rel2",
    "take",
    "#:James 2",
    "sk6_database course",
    "?:Cu31"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "database course",
    "?:C"
   ],
   [
    "-is rel2",
    "take",
    "#:James 2",
    "?:C",
    "?:Cu32"
   ],
   [
    "isa",
    "part-time job",
    "sk7_part-time job"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "database course",
    "?:C"
   ],
   [
    "-is rel2",
    "take",
    "#:James 2",
    "?:C",
    "?:Cu33"
   ],
   [
    "have",
    "#:James 2",
    "sk7_part-time job",
    "?:Cu33"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "database course",
    "?:C"
   ],
   [
    "-is rel2",
    "take",
    "#:James 2",
    "?:C",
    "?:Cu34"
   ],
   [
    "isa",
    "university",
    "sk5_university"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "database course",
    "?:C"
   ],
   [
    "-is rel2",
    "take",
    "#:James 2",
    "?:C",
    "?:Cu35"
   ],
   [
    "is rel2",
    "offered by",
    "sk7_part-time job",
    "sk5_university",
    "?:Cu35"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "#:James 2",
    "?:J",
    "?:Cu36"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu36"
   ],
   [
    "isa",
    "database course",
    "sk6_database course"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "#:James 2",
    "?:J",
    "?:Cu37"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu37"
   ],
   [
    "is rel2",
    "take",
    "#:James 2",
    "sk6_database course",
    "?:Cu37"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "#:James 2",
    "?:J",
    "?:Cu38"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu38"
   ],
   [
    "isa",
    "part-time job",
    "sk7_part-time job"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "#:James 2",
    "?:J",
    "?:Cu39"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu39"
   ],
   [
    "have",
    "#:James 2",
    "sk7_part-time job",
    "?:Cu39"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "#:James 2",
    "?:J",
    "?:Cu40"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu40"
   ],
   [
    "isa",
    "university",
    "sk5_university"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:J"
   ],
   [
    "-have",
    "#:James 2",
    "?:J",
    "?:Cu41"
   ],
   [
    "-isa",
    "university",
    "?:U"
   ],
   [
    "-is rel2",
    "offered by",
    "?:J",
    "?:U",
    "?:Cu41"
   ],
   [
    "is rel2",
    "offered by",
    "sk7_part-time job",
    "sk5_university",
    "?:Cu41"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "computer science department",
   "$some_computer_science_department"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "computer science department",
   "$some_not_computer_science_department"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "student",
   "$some_not_student"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "part-time job",
   "$some_part-time_job"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "part-time job",
   "$some_not_part-time_job"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "university",
   "$some_university"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "university",
   "$some_not_university"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "database course",
   "$some_database_course"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "database course",
   "$some_not_database_course"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "computer science department",
    "?:X"
   ],
   [
    "isa",
    "department",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "computer science",
    "?:X"
   ],
   [
    "-isa",
    "department",
    "?:X"
   ],
   [
    "isa",
    "computer science department",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "database course",
    "?:X"
   ],
   [
    "isa",
    "course",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "database",
    "?:X"
   ],
   [
    "-isa",
    "course",
    "?:X"
   ],
   [
    "isa",
    "database course",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "part-time job",
    "?:X"
   ],
   [
    "isa",
    "job",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "part-time",
    "?:X"
   ],
   [
    "-isa",
    "job",
    "?:X"
   ],
   [
    "isa",
    "part-time job",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "professor david",
    "?:X"
   ],
   [
    "isa",
    "david",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "professor",
    "?:X"
   ],
   [
    "-isa",
    "david",
    "?:X"
   ],
   [
    "isa",
    "professor david",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]