[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "place",
   "#:Istanbul 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "number",
   "35"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "number",
   "34"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "#:Istanbul 1",
    "?:Cu4"
   ],
   [
    "is rel2",
    "begin",
    "?:X",
    "34",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "plate",
    "?:X"
   ],
   [
    "is rel2",
    "begin",
    "?:X",
    "34",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "#:Istanbul 1",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "person",
   "#:Joe 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "vehicle registration plate",
   "#:vehicle registration plate 3"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "have",
   "#:Joe 2",
   "#:vehicle registration plate 3",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "from",
   "#:vehicle registration plate 3",
   "#:Istanbul 1",
   "?:Cu9"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "vehicle registration plate",
   "#:vehicle registration plate 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "person",
   "#:Joe 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "#:Joe 2",
   "#:vehicle registration plate 3",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Tom 4"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "vehicle registration plate",
   "#:vehicle registration plate 5"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "have",
   "#:Tom 4",
   "#:vehicle registration plate 5",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "begin",
   "#:vehicle registration plate 5",
   "35",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "vehicle registration plate",
   "#:vehicle registration plate 5"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "person",
   "#:Tom 4"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "have",
   "#:Tom 4",
   "#:vehicle registration plate 5",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "begin",
    "?:X",
    "35",
    "?:Cu20"
   ],
   [
    "-is rel2",
    "begin",
    "?:X",
    "34",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "begin",
    "#:vehicle registration plate 3",
    "34",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "begin",
    "#:vehicle registration plate 3",
    "34",
    "?:Cu22"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "plate",
   "$some_plate"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "plate",
   "$some_not_plate"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "vehicle registration plate",
    "?:X"
   ],
   [
    "isa",
    "plate",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "vehicle registration",
    "?:X"
   ],
   [
    "-isa",
    "plate",
    "?:X"
   ],
   [
    "isa",
    "vehicle registration plate",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_carrier_lift",
  "@logic": [
   [
    "-isa",
    "plate",
    "?:X",
    "?:Fv25"
   ],
   [
    "isa",
    "carrier",
    "?:X",
    "?:Fv25"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]