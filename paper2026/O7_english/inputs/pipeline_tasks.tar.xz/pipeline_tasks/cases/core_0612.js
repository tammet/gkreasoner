[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "buy",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:John 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:car 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "car",
   "#:car 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has property",
   "red",
   "#:car 2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "bicycle",
   "#:bicycle 3"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "activity",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has type",
   "sk1_activity",
   "buy",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has actor",
   "sk1_activity",
   "#:John 1",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has target",
   "sk1_activity",
   "#:bicycle 3",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has time",
   "sk1_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W1",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "actuality",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "next",
   "W1",
   "W2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "bicycle",
   "#:bicycle 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "blue",
   "#:bicycle 3",
   [
    "$ctxt",
    "present",
    "W1",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has type",
    [
     "sk2",
     "?:X"
    ],
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has actor",
    [
     "sk2",
     "?:X"
    ],
    "#:John 1",
    [
     "$ctxt",
     "past",
     "?:Fv16",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has target",
    [
     "sk2",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv18",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has time",
    [
     "sk2",
     "?:X"
    ],
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv20",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "actuality",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "past",
     "?:Fv24",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:John 1",
    [
     "$ctxt",
     "past",
     "?:Fv26",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv28",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@question": [
   "$defq0",
   "?:X"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "bicycle",
    "?:X"
   ],
   [
    "-isa",
    "car",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "bicycle",
    "?:X"
   ],
   [
    "-isa",
    "car",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv32"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv32"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "red",
     "?:X",
     "?:Fv32"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv33"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv33"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "blue",
     "?:X",
     "?:Fv33"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv34",
     "?:Fv35",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv34",
     "?:Fv35",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv34",
     "?:Fv35",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "-next",
    "?:Fv35",
    "?:Fv36"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv36",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "?:Owner",
      "?:Obj",
      [
       "$ctxt",
       "present",
       "?:Fv36",
       "?:Fv37",
       "?:Fv38"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv39",
     "?:Fv40",
     "?:Fv42",
     "?:Fv43"
    ]
   ],
   [
    "-has beneficiary",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv39",
     "?:Fv40",
     "?:Fv42",
     "?:Fv43"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv39",
     "?:Fv40",
     "?:Fv42",
     "?:Fv43"
    ]
   ],
   [
    "-next",
    "?:Fv40",
    "?:Fv41"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv41",
     "?:Fv42",
     "?:Fv43"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv44",
     "?:Fv45",
     "?:Fv47",
     "?:Fv48"
    ]
   ],
   [
    "-has recipient",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv44",
     "?:Fv45",
     "?:Fv47",
     "?:Fv48"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv44",
     "?:Fv45",
     "?:Fv47",
     "?:Fv48"
    ]
   ],
   [
    "-next",
    "?:Fv45",
    "?:Fv46"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv46",
     "?:Fv47",
     "?:Fv48"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv49",
     "?:Fv50",
     "?:Fv51"
    ]
   ],
   [
    "has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv49",
     "?:Fv50",
     "?:Fv51"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "blue",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv49",
       "?:Fv50",
       "?:Fv51"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv52",
     "?:Fv53",
     "?:Fv54"
    ]
   ],
   [
    "has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv52",
     "?:Fv53",
     "?:Fv54"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "blue",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv52",
       "?:Fv53",
       "?:Fv54"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv55",
     "?:Fv56",
     "?:Fv57"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv55",
     "?:Fv56",
     "?:Fv57"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv55",
       "?:Fv56",
       "?:Fv57"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv58",
     "?:Fv59",
     "?:Fv60"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv58",
     "?:Fv59",
     "?:Fv60"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv58",
       "?:Fv59",
       "?:Fv60"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "bicycle",
   "$some_bicycle"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "car",
   "$some_car"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W1",
   "W2"
  ]
 }
]