[
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "abstract",
   "#:German 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "romance language",
    "?:X"
   ],
   [
    "isa",
    "indo-european language",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "language family",
   "sk0_language family"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "romance language",
   "sk0_language family"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "?:Y",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "in",
    "?:Z",
    "?:Y",
    "?:Cu5"
   ],
   [
    "is rel2",
    "related",
    "?:X",
    "?:Z",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "romance language",
   "#:French 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "romance language",
   "#:Spanish 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "related",
   "#:German 3",
   "#:Spanish 2",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "language",
    "?:X"
   ],
   [
    "-is rel2",
    "related",
    "#:Basque 4",
    "?:X",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "romance language",
    "#:Basque 4"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "romance language",
    "#:Basque 4"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "romance language",
   "$some_not_Romance_language"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "indo-european language",
   "$some_Indo-European_language"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "indo-european language",
   "$some_not_Indo-European_language"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "language family",
   "$some_language_family"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "language family",
   "$some_not_language_family"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "language",
   "$some_language"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "language",
   "$some_not_language"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "indo-european language",
    "?:X"
   ],
   [
    "isa",
    "language",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "indo-european",
    "?:X"
   ],
   [
    "-isa",
    "language",
    "?:X"
   ],
   [
    "isa",
    "indo-european language",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "romance language",
    "?:X"
   ],
   [
    "isa",
    "language",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "romance",
    "?:X"
   ],
   [
    "-isa",
    "language",
    "?:X"
   ],
   [
    "isa",
    "romance language",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "language family",
    "?:X"
   ],
   [
    "isa",
    "family",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "language",
    "?:X"
   ],
   [
    "-isa",
    "family",
    "?:X"
   ],
   [
    "isa",
    "language family",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]