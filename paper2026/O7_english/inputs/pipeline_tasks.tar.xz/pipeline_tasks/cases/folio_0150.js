[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "new vessel press",
   "#:New Vessel Press 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "abstract",
   "English"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "neapolitan chronicles",
   "#:Neapolitan Chronicles 2"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "abstract",
   "Italian"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "palace of flies",
   "#:Palace of Flies 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "publishing house",
   "#:New Vessel Press 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "translate",
   "#:New Vessel Press 1",
   "foreign literature",
   "?:Cu7"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "publish",
    "#:New Vessel Press 1",
    "?:X",
    "?:Cu8"
   ],
   [
    "is rel2",
    "in",
    "?:X",
    "English",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "book",
   "#:Neapolitan Chronicles 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "publish",
   "#:New Vessel Press 1",
   "#:Neapolitan Chronicles 2",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "translate",
   "#:Neapolitan Chronicles 2",
   "Italian",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "book",
   "#:Palace of Flies 3"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "publish",
   "#:New Vessel Press 1",
   "#:Palace of Flies 3",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "book",
    "#:Neapolitan Chronicles 2"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "#:Neapolitan Chronicles 2",
    "English",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "book",
    "#:Neapolitan Chronicles 2"
   ],
   [
    "-is rel2",
    "in",
    "#:Neapolitan Chronicles 2",
    "English",
    "?:Cu16"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "neapolitan chronicles",
    "?:X"
   ],
   [
    "isa",
    "chronicles",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "neapolitan",
    "?:X"
   ],
   [
    "-isa",
    "chronicles",
    "?:X"
   ],
   [
    "isa",
    "neapolitan chronicles",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "new vessel press",
    "?:X"
   ],
   [
    "isa",
    "press",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "new vessel",
    "?:X"
   ],
   [
    "-isa",
    "press",
    "?:X"
   ],
   [
    "isa",
    "new vessel press",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "palace of flies",
    "?:X"
   ],
   [
    "isa",
    "flies",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "palace of",
    "?:X"
   ],
   [
    "-isa",
    "flies",
    "?:X"
   ],
   [
    "isa",
    "palace of flies",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "publishing house",
    "?:X"
   ],
   [
    "isa",
    "house",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "publishing",
    "?:X"
   ],
   [
    "-isa",
    "house",
    "?:X"
   ],
   [
    "isa",
    "publishing house",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "English",
    "?:X",
    "?:Fv29"
   ],
   [
    "-has property",
    "Italian",
    "?:X",
    "?:Fv29"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "English",
    "?:X",
    "?:Fv30"
   ],
   [
    "-has property",
    "Italian",
    "?:X",
    "?:Fv30"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]