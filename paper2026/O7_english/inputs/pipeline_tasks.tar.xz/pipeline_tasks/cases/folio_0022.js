[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "stranger thing",
   "#:Stranger Things 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "black mirror",
   "#:Black Mirror 3"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "person",
   "#:Lisa 4"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "netflix show",
   "#:Stranger Things 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has property",
   "popular",
   "#:Stranger Things 1",
   "?:Cu5"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "netflix show",
    "?:X"
   ],
   [
    "-has property",
    "popular",
    "?:X",
    "?:Cu6"
   ],
   [
    "is rel2",
    "binge-watch",
    "#:Karen 2",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "netflix show",
    "?:X"
   ],
   [
    "-is rel2",
    "binge-watch",
    "#:Karen 2",
    "?:X",
    "?:Cu7"
   ],
   [
    "is rel2",
    "download",
    "#:Karen 2",
    "?:X",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "netflix show",
    "?:X"
   ],
   [
    "-is rel2",
    "download",
    "#:Karen 2",
    "?:X",
    "?:Cu8"
   ],
   [
    "is rel2",
    "binge-watch",
    "#:Karen 2",
    "?:X",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Karen 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "netflix show",
   "#:Black Mirror 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "-is rel2",
   "download",
   "#:Karen 2",
   "#:Black Mirror 3",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "netflix show",
   "#:Black Mirror 3"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "binge-watch",
    "#:Karen 2",
    "?:X",
    "?:Cu13"
   ],
   [
    "is rel2",
    "share",
    "#:Karen 2",
    "#:Lisa 4",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "share",
    "#:Karen 2",
    "#:Lisa 4",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "share",
    "#:Karen 2",
    "#:Lisa 4",
    "?:Cu15"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "netflix show",
   "$some_not_netflix_show"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "popular",
   "$some_not_popular",
   "?:Cu17"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "black mirror",
    "?:X"
   ],
   [
    "isa",
    "mirror",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "black",
    "?:X"
   ],
   [
    "-isa",
    "mirror",
    "?:X"
   ],
   [
    "isa",
    "black mirror",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "netflix show",
    "?:X"
   ],
   [
    "isa",
    "show",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "netflix",
    "?:X"
   ],
   [
    "-isa",
    "show",
    "?:X"
   ],
   [
    "isa",
    "netflix show",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "stranger thing",
    "?:X"
   ],
   [
    "isa",
    "thing",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "stranger",
    "?:X"
   ],
   [
    "-isa",
    "thing",
    "?:X"
   ],
   [
    "isa",
    "stranger thing",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]