[
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "animal",
   "#:cat 3"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "olive garden",
   "#:Olive Garden 1"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "measure",
   "$2000"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "measure",
   "$1500"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "managed building",
   "sk0_managed building"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "pet",
    "?:X"
   ],
   [
    "is rel2",
    "allowed in",
    "?:X",
    "sk0_managed building",
    "?:Cu6"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-is rel2",
    "in",
    "?:A",
    "?:Z",
    "?:Cu7"
   ],
   [
    "isa",
    "deposit",
    [
     "sk1",
     "?:Z"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-is rel2",
    "in",
    "?:A",
    "?:Z",
    "?:Cu8"
   ],
   [
    "is rel2",
    "rent",
    "?:A",
    "?:Z",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "isa",
    "monthly rent",
    [
     "sk2",
     "?:Z"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "is rel2",
    "at",
    [
     "sk2",
     "?:Z"
    ],
    "?:Z",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "isa",
    "security deposit",
    [
     "sk3",
     "?:Z"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "=",
    [
     "$measure_of",
     "amount",
     [
      "sk3",
      "?:Z"
     ],
     "W0"
    ],
    [
     "$measure_of",
     "amount",
     [
      "sk2",
      "?:Z"
     ],
     "W0"
    ]
   ],
   [
    "less_measure",
    [
     "$measure_of",
     "amount",
     [
      "sk2",
      "?:Z"
     ],
     "W0"
    ],
    [
     "$measure_of",
     "amount",
     [
      "sk3",
      "?:Z"
     ],
     "W0"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-=",
    [
     "$measure_of",
     "amount",
     [
      "sk3",
      "?:Z"
     ],
     "W0"
    ],
    [
     "$measure_of",
     "amount",
     [
      "sk2",
      "?:Z"
     ],
     "W0"
    ]
   ],
   [
    "not",
    [
     "less_measure",
     [
      "$measure_of",
      "amount",
      [
       "sk2",
       "?:Z"
      ],
      "W0"
     ],
     [
      "$measure_of",
      "amount",
      [
       "sk3",
       "?:Z"
      ],
      "W0"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "animal",
   "#:cat 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "cat",
   "#:cat 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "person",
   "#:Tom 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "#:Tom 2",
   "#:cat 3",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Tom 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "animal",
   "#:cat 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "have",
   "#:Tom 2",
   "#:cat 3",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "cat",
    "?:X"
   ],
   [
    "isa",
    "pet",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "place",
   "#:Olive Garden 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "managed building",
   "#:Olive Garden 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "place",
   "#:Olive Garden 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "=",
   [
    "$measure_of",
    "monthly rent",
    "#:Olive Garden 1",
    "W0"
   ],
   [
    "$list",
    2000,
    "#:dollar"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "place",
   "#:Olive Garden 1"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "monthly rent at",
   "#:monthly rent 2",
   "#:Olive Garden 1",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "less_measure",
   [
    "$list",
    1500,
    "#:dollar"
   ],
   [
    "$list",
    2000,
    "#:dollar"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-is rel2",
    "allowed to move in with",
    "#:Tom 2",
    "#:cat 3",
    "?:Cu29"
   ],
   [
    "-isa",
    "security deposit",
    "?:D"
   ],
   [
    "less_measure",
    [
     "$list",
     1500,
     "#:dollar"
    ],
    [
     "$measure_of",
     "amount",
     "?:D",
     "W0"
    ]
   ],
   [
    "isa",
    "apartment",
    [
     "sk4",
     "?:Z"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-is rel2",
    "allowed to move in with",
    "#:Tom 2",
    "#:cat 3",
    "?:Cu30"
   ],
   [
    "-isa",
    "security deposit",
    "?:D"
   ],
   [
    "less_measure",
    [
     "$list",
     1500,
     "#:dollar"
    ],
    [
     "$measure_of",
     "amount",
     "?:D",
     "W0"
    ]
   ],
   [
    "is rel2",
    "in",
    [
     "sk4",
     "?:Z"
    ],
    "?:Z",
    "?:Cu30"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:Z"
   ],
   [
    "-is rel2",
    "allowed to move in with",
    "#:Tom 2",
    "#:cat 3",
    "?:Cu31"
   ],
   [
    "-isa",
    "security deposit",
    "?:D"
   ],
   [
    "less_measure",
    [
     "$list",
     1500,
     "#:dollar"
    ],
    [
     "$measure_of",
     "amount",
     "?:D",
     "W0"
    ]
   ],
   [
    "is rel2",
    "rent",
    "#:Tom 2",
    [
     "sk4",
     "?:Z"
    ],
    "?:Cu31"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S12",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:B"
   ],
   [
    "isa",
    "pet",
    [
     "sk5",
     "?:B"
    ]
   ],
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "isa",
    "pet",
    [
     "sk6",
     "?:B"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:B"
   ],
   [
    "isa",
    "pet",
    [
     "sk5",
     "?:B"
    ]
   ],
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "go",
    "?:X",
    [
     "sk6",
     "?:B"
    ],
    "?:Cu33"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:B"
   ],
   [
    "-is rel2",
    "allowed in",
    [
     "sk5",
     "?:B"
    ],
    "?:B",
    "?:Cu34"
   ],
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "isa",
    "pet",
    [
     "sk6",
     "?:B"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:B"
   ],
   [
    "-is rel2",
    "allowed in",
    [
     "sk5",
     "?:B"
    ],
    "?:B",
    "?:Cu35"
   ],
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "is rel2",
    "go",
    "?:X",
    [
     "sk6",
     "?:B"
    ],
    "?:Cu35"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "person",
    "#:Tom 2"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "place",
    "#:Olive Garden 1"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "animal",
    "#:cat 3"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "apartment",
    "sk7_apartment"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "sk7_apartment",
    "#:Olive Garden 1",
    "?:Cu40"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "go",
    "#:Tom 2",
    "sk7_apartment",
    "?:Cu41"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "person",
    "#:Tom 2"
   ],
   [
    "-isa",
    "place",
    "#:Olive Garden 1"
   ],
   [
    "-isa",
    "animal",
    "#:cat 3"
   ],
   [
    "-isa",
    "apartment",
    "?:A"
   ],
   [
    "-is rel2",
    "in",
    "?:A",
    "#:Olive Garden 1",
    "?:Cu42"
   ],
   [
    "-is rel2",
    "go",
    "#:Tom 2",
    "?:A",
    "?:Cu42"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "monthly rent",
    "?:S",
    "?:W"
   ],
   "?:Cu45"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "monthly rent",
   [
    "$measure_of",
    "monthly rent",
    "?:S",
    "?:W"
   ]
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "amount",
    "?:S",
    "?:W"
   ],
   "?:Cu47"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "amount",
   [
    "$measure_of",
    "amount",
    "?:S",
    "?:W"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "managed building",
   "$some_not_managed_building"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "pet",
   "$some_pet"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "pet",
   "$some_not_pet"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "deposit",
   "$some_deposit"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "deposit",
   "$some_not_deposit"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "monthly rent",
   "$some_monthly_rent"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "monthly rent",
   "$some_not_monthly_rent"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "security deposit",
   "$some_security_deposit"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "security deposit",
   "$some_not_security_deposit"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "cat",
   "$some_not_cat"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "apartment",
   "$some_apartment"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "apartment",
   "$some_not_apartment"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "managed building",
    "?:X"
   ],
   [
    "isa",
    "building",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "managed",
    "?:X"
   ],
   [
    "-isa",
    "building",
    "?:X"
   ],
   [
    "isa",
    "managed building",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "monthly rent",
    "?:X"
   ],
   [
    "isa",
    "rent",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "monthly",
    "?:X"
   ],
   [
    "-isa",
    "rent",
    "?:X"
   ],
   [
    "isa",
    "monthly rent",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "olive garden",
    "?:X"
   ],
   [
    "isa",
    "garden",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "olive",
    "?:X"
   ],
   [
    "-isa",
    "garden",
    "?:X"
   ],
   [
    "isa",
    "olive garden",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "security deposit",
    "?:X"
   ],
   [
    "isa",
    "deposit",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "security",
    "?:X"
   ],
   [
    "-isa",
    "deposit",
    "?:X"
   ],
   [
    "isa",
    "security deposit",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv57"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv57"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-isa",
    "place",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "cat",
    "?:Xg"
   ],
   [
    "isa",
    "woman",
    "?:Xg"
   ]
  ]
 }
]