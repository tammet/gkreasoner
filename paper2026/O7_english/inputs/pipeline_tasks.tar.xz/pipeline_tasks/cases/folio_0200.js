[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:Ailton Silva 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "ailton silva",
   "#:Ailton Silva 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "known as",
   "#:Ailton Silva 1",
   "Ailton",
   "?:Cu3"
  ],
  "@confidence": 0.96
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has property",
   "born",
   "#:Ailton Silva 1",
   "?:Cu4"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv5"
   ],
   [
    "$datetime",
    1995
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is_past_world",
   "W0"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "football player",
   "#:Ailton Silva 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "loan",
   "#:Ailton Silva 1",
   "#:Braga 2",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "football player",
   "#:Ailton Silva 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "has property",
   "Brazilian",
   "#:Ailton Silva 1",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "play",
   "#:Ailton Silva 1",
   "#:Nautico 3",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "football club",
   "#:Nautico 3"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "football club",
   "#:Braga 2"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "football club",
   "#:Fluminense 4"
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "football club",
    "?:Y"
   ],
   [
    "-is rel2",
    "play",
    "#:Ailton Silva 1",
    "?:Y",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "football club",
    "sk0_football club"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "play",
    "#:Ailton Silva 1",
    "sk0_football club",
    "?:Cu17"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "football club",
   "$some_not_football_club"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "ailton silva",
    "?:X"
   ],
   [
    "isa",
    "silva",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "ailton",
    "?:X"
   ],
   [
    "-isa",
    "silva",
    "?:X"
   ],
   [
    "isa",
    "ailton silva",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "football club",
    "?:X"
   ],
   [
    "isa",
    "club",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "football",
    "?:X"
   ],
   [
    "-isa",
    "club",
    "?:X"
   ],
   [
    "isa",
    "football club",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "football player",
    "?:X"
   ],
   [
    "isa",
    "player",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "football",
    "?:X"
   ],
   [
    "-isa",
    "player",
    "?:X"
   ],
   [
    "isa",
    "football player",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]