[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "buy",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:John 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:car 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "car",
   "#:car 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has property",
   "red",
   "#:car 2",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "bicycle",
   "#:bicycle 3"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "activity",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has type",
   "sk1_activity",
   "buy",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has actor",
   "sk1_activity",
   "#:John 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has target",
   "sk1_activity",
   "#:bicycle 3",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has time",
   "sk1_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv5",
    "?:Fv6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "actuality",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "bicycle",
   "#:bicycle 3"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "blue",
   "#:bicycle 3",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "bicycle",
    "#:bicycle 3"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "blue",
    "#:bicycle 3",
    [
     "$ctxt",
     "past",
     "W0",
     "?:Fv9",
     "?:Fv10"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "bicycle",
    "#:bicycle 3"
   ],
   [
    "-has property",
    "blue",
    "#:bicycle 3",
    [
     "$ctxt",
     "past",
     "W0",
     "?:Fv9",
     "?:Fv10"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has property",
    "blue",
    "#:bicycle 3",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has property",
    "blue",
    "#:bicycle 3",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "blue",
      "#:bicycle 3",
      [
       "$ctxt",
       "past",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "bicycle",
    "?:X"
   ],
   [
    "-isa",
    "car",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "bicycle",
    "?:X"
   ],
   [
    "-isa",
    "car",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv16"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv16"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "red",
     "?:X",
     "?:Fv16"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    "?:Fv17"
   ],
   [
    "-has property",
    "red",
    "?:X",
    "?:Fv17"
   ],
   [
    "$block",
    0,
    [
     "has property",
     "blue",
     "?:X",
     "?:Fv17"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv18",
     "?:Fv19",
     "?:Fv21",
     "?:Fv22"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv18",
     "?:Fv19",
     "?:Fv21",
     "?:Fv22"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv18",
     "?:Fv19",
     "?:Fv21",
     "?:Fv22"
    ]
   ],
   [
    "-next",
    "?:Fv19",
    "?:Fv20"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv20",
     "?:Fv21",
     "?:Fv22"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "?:Owner",
      "?:Obj",
      [
       "$ctxt",
       "present",
       "?:Fv20",
       "?:Fv21",
       "?:Fv22"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv23",
     "?:Fv24",
     "?:Fv26",
     "?:Fv27"
    ]
   ],
   [
    "-has beneficiary",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv23",
     "?:Fv24",
     "?:Fv26",
     "?:Fv27"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv23",
     "?:Fv24",
     "?:Fv26",
     "?:Fv27"
    ]
   ],
   [
    "-next",
    "?:Fv24",
    "?:Fv25"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv25",
     "?:Fv26",
     "?:Fv27"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_acquire_have",
  "@logic": [
   [
    "-has type",
    "?:E",
    "buy",
    [
     "$ctxt",
     "?:Fv28",
     "?:Fv29",
     "?:Fv31",
     "?:Fv32"
    ]
   ],
   [
    "-has recipient",
    "?:E",
    "?:Owner",
    [
     "$ctxt",
     "?:Fv28",
     "?:Fv29",
     "?:Fv31",
     "?:Fv32"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:Obj",
    [
     "$ctxt",
     "?:Fv28",
     "?:Fv29",
     "?:Fv31",
     "?:Fv32"
    ]
   ],
   [
    "-next",
    "?:Fv29",
    "?:Fv30"
   ],
   [
    "have",
    "?:Owner",
    "?:Obj",
    [
     "$ctxt",
     "present",
     "?:Fv30",
     "?:Fv31",
     "?:Fv32"
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv33",
     "?:Fv34",
     "?:Fv35"
    ]
   ],
   [
    "has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv33",
     "?:Fv34",
     "?:Fv35"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "blue",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv33",
       "?:Fv34",
       "?:Fv35"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv36",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "has property",
    "blue",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv36",
     "?:Fv37",
     "?:Fv38"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "blue",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv36",
       "?:Fv37",
       "?:Fv38"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv39",
     "?:Fv40",
     "?:Fv41"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv39",
     "?:Fv40",
     "?:Fv41"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv39",
       "?:Fv40",
       "?:Fv41"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv42",
     "?:Fv43",
     "?:Fv44"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv42",
     "?:Fv43",
     "?:Fv44"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv42",
       "?:Fv43",
       "?:Fv44"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]