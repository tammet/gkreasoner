[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "legend of zelda",
   "#:Legend of Zelda 2"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "abstract",
   "#:Top 10 list 1"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "top 10 list",
   "#:Top 10 list 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "number",
   "1000000"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "game company",
   "#:game company 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "Japanese",
   "#:game company 1",
   "?:Cu6"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "game",
   "#:Legend of Zelda 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "create",
   "#:game company 1",
   "#:Legend of Zelda 2",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "game company",
   "#:game company 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "game",
   "#:Legend of Zelda 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "on",
    "?:X",
    "#:Top 10 list 1",
    "?:Cu11"
   ],
   [
    "isa",
    "game company",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "on",
    "?:X",
    "#:Top 10 list 1",
    "?:Cu12"
   ],
   [
    "has property",
    "Japanese",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "on",
    "?:X",
    "#:Top 10 list 1",
    "?:Cu13"
   ],
   [
    "is rel2",
    "made by",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "sell",
    "?:X",
    "copy",
    "?:Cu14"
   ],
   [
    "is rel2",
    "on",
    "?:X",
    "#:Top 10 list 1",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "game",
   "#:Legend of Zelda 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "sell",
   "#:Legend of Zelda 2",
   "copy",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "on",
    "#:Legend of Zelda 2",
    "#:Top 10 list 1",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "on",
    "#:Legend of Zelda 2",
    "#:Top 10 list 1",
    "?:Cu18"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "game company",
   "$some_not_game_company"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "Japanese",
   "$some_not_Japanese",
   "?:Cu21"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "game company",
    "?:X"
   ],
   [
    "isa",
    "company",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "game",
    "?:X"
   ],
   [
    "-isa",
    "company",
    "?:X"
   ],
   [
    "isa",
    "game company",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "legend of zelda",
    "?:X"
   ],
   [
    "isa",
    "zelda",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "legend of",
    "?:X"
   ],
   [
    "-isa",
    "zelda",
    "?:X"
   ],
   [
    "isa",
    "legend of zelda",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "top 10 list",
    "?:X"
   ],
   [
    "isa",
    "list",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "top 10",
    "?:X"
   ],
   [
    "-isa",
    "list",
    "?:X"
   ],
   [
    "isa",
    "top 10 list",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "game",
    "?:X"
   ],
   [
    "isa",
    "activity",
    "?:X"
   ]
  ],
  "@confidence": 0.76
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:X"
   ],
   [
    "isa",
    "game",
    "?:X"
   ]
  ],
  "@confidence": 0.76
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]