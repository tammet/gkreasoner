[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "brother",
   "#:brother 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "person",
   "#:sister 4"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "sister",
   "#:sister 4"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "brother",
   [
    "$theof1",
    "brother",
    "#:John 1",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "car",
   "#:car 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "have",
   [
    "$theof1",
    "brother",
    "#:John 1",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   "#:car 3",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "brother",
   [
    "$theof1",
    "brother",
    "#:John 1",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "car",
    "sk0_car"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "have",
    "#:sister 4",
    "sk0_car",
    [
     "$ctxt",
     "present",
     "?:Fv11",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "car",
    "?:X"
   ],
   [
    "-have",
    "#:sister 4",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv14",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.97,
  "@logic": [
   [
    "-have",
    "#:sister 4",
    "?:Br1",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "have",
    "#:sister 4",
    "?:Br1",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "have",
      "#:sister 4",
      "?:Br1",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_theof",
  "@logic": [
   "have",
   "#:John 1",
   [
    "$theof1",
    "brother",
    "#:John 1",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "frm_theof",
  "@logic": [
   "is rel2",
   "brother of",
   [
    "$theof1",
    "brother",
    "?:S",
    "?:C"
   ],
   "?:S",
   "?:C"
  ]
 },
 {
  "@name": "frm_theof",
  "@logic": [
   "isa",
   "brother",
   [
    "$theof1",
    "brother",
    "?:S",
    "?:C"
   ]
  ]
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "brother",
    "?:X",
    "?:Fv15"
   ],
   [
    "-has property",
    "sister",
    "?:X",
    "?:Fv15"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_kin_excl",
  "@logic": [
   [
    "-isa",
    "sister",
    "?:X"
   ],
   [
    "-isa",
    "brother",
    "?:X"
   ]
  ]
 },
 {
  "@name": "frm_kin_excl",
  "@logic": [
   [
    "-is rel2",
    "sister of",
    "?:X",
    "?:Y",
    "?:Fv16"
   ],
   [
    "-is rel2",
    "brother of",
    "?:X",
    "?:Y",
    "?:Fv16"
   ]
  ]
 },
 {
  "@name": "frm_kin_excl",
  "@logic": [
   [
    "-is rel2",
    "sister of",
    "?:X",
    "?:Y",
    "?:Fv17"
   ],
   [
    "isa",
    "sister",
    "?:X"
   ]
  ]
 },
 {
  "@name": "frm_kin_excl",
  "@logic": [
   [
    "-is rel2",
    "brother of",
    "?:X",
    "?:Y",
    "?:Fv18"
   ],
   [
    "isa",
    "brother",
    "?:X"
   ]
  ]
 }
]