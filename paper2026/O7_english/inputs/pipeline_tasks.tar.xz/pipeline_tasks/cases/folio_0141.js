[
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "artifact",
   "#:Frozen series 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "frozen series",
   "#:Frozen series 1"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "hachi: a dog's tale",
   "Hachi: A Dog's Tale 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "appropriate for",
    "?:X",
    "all ages",
    "?:Cu4"
   ],
   [
    "-isa",
    "child",
    "?:Y"
   ],
   [
    "is rel2",
    "watch",
    "?:Y",
    "?:X",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "film",
    "?:X"
   ],
   [
    "-isa",
    "erotic and violent content",
    "?:Z"
   ],
   [
    "-has property",
    "excessive",
    "?:Z",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "contain",
    "?:X",
    "?:Z",
    "?:Cu5"
   ],
   [
    "-isa",
    "child",
    "?:Y"
   ],
   [
    "-is rel2",
    "watch",
    "?:Y",
    "?:X",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "rated",
    "?:X",
    "General Audience",
    "?:Cu6"
   ],
   [
    "is rel2",
    "appropriate for",
    "?:X",
    "all ages",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "film",
    "?:X"
   ],
   [
    "-has property",
    "family-friendly",
    "?:X",
    "?:Cu7"
   ],
   [
    "-has property",
    "animated",
    "?:X",
    "?:Cu7"
   ],
   [
    "is rel2",
    "rated",
    "?:X",
    "General Audience",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "in series",
    "?:X",
    "https://en.wikipedia.org/wiki/Frozen_(franchise)",
    "?:Cu8"
   ],
   [
    "isa",
    "film",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "in series",
    "?:X",
    "https://en.wikipedia.org/wiki/Frozen_(franchise)",
    "?:Cu9"
   ],
   [
    "has property",
    "family-friendly",
    "?:X",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "in series",
    "?:X",
    "https://en.wikipedia.org/wiki/Frozen_(franchise)",
    "?:Cu10"
   ],
   [
    "has property",
    "animated",
    "?:X",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "film",
   "Hachi: A Dog's Tale 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "has property",
    "family-friendly",
    "Hachi: A Dog's Tale 1",
    "?:Cu12"
   ],
   [
    "is rel2",
    "appropriate for",
    "Hachi: A Dog's Tale 1",
    "all ages",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "has property",
    "animated",
    "Hachi: A Dog's Tale 1",
    "?:Cu13"
   ],
   [
    "is rel2",
    "appropriate for",
    "Hachi: A Dog's Tale 1",
    "all ages",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-has property",
    "family-friendly",
    "Hachi: A Dog's Tale 1",
    "?:Cu14"
   ],
   [
    "-has property",
    "animated",
    "Hachi: A Dog's Tale 1",
    "?:Cu14"
   ],
   [
    "-is rel2",
    "appropriate for",
    "Hachi: A Dog's Tale 1",
    "all ages",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "erotic and violent content",
    "sk0_erotic and violent content"
   ],
   [
    "is rel2",
    "in series",
    "Hachi: A Dog's Tale 1",
    "https://en.wikipedia.org/wiki/Frozen_(franchise)",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "excessive",
    "sk0_erotic and violent content",
    "?:Cu16"
   ],
   [
    "is rel2",
    "in series",
    "Hachi: A Dog's Tale 1",
    "https://en.wikipedia.org/wiki/Frozen_(franchise)",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "contain",
    "Hachi: A Dog's Tale 1",
    "sk0_erotic and violent content",
    "?:Cu17"
   ],
   [
    "is rel2",
    "in series",
    "Hachi: A Dog's Tale 1",
    "https://en.wikipedia.org/wiki/Frozen_(franchise)",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "erotic and violent content",
    "?:Z"
   ],
   [
    "-has property",
    "excessive",
    "?:Z",
    "?:Cu18"
   ],
   [
    "-is rel2",
    "contain",
    "Hachi: A Dog's Tale 1",
    "?:Z",
    "?:Cu18"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "in series",
    "Hachi: A Dog's Tale 1",
    "https://en.wikipedia.org/wiki/Frozen_(franchise)",
    "?:Cu19"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "child",
   "$some_child"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "child",
   "$some_not_child"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "film",
   "$some_not_film"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "erotic and violent content",
   "$some_erotic_and_violent_content"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "erotic and violent content",
   "$some_not_erotic_and_violent_content"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "excessive",
   "$some_excessive",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "excessive",
   "$some_not_excessive",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "family-friendly",
   "$some_not_family-friendly",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "animated",
   "$some_not_animated",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "film",
   "$some_family-friendly_film"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "family-friendly",
   "$some_family-friendly_film",
   "?:Cu33"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "film",
   "$some_animated_film"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "animated",
   "$some_animated_film",
   "?:Cu35"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "erotic and violent content",
    "?:X"
   ],
   [
    "isa",
    "content",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "erotic and violent",
    "?:X"
   ],
   [
    "-isa",
    "content",
    "?:X"
   ],
   [
    "isa",
    "erotic and violent content",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "frozen series",
    "?:X"
   ],
   [
    "isa",
    "series",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "frozen",
    "?:X"
   ],
   [
    "-isa",
    "series",
    "?:X"
   ],
   [
    "isa",
    "frozen series",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "hachi: a dog's tale",
    "?:X"
   ],
   [
    "isa",
    "story",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "hachi: a dog'",
    "?:X"
   ],
   [
    "-isa",
    "story",
    "?:X"
   ],
   [
    "isa",
    "hachi: a dog's tale",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_perception_factive",
  "@logic": [
   [
    "-has type",
    "?:E1",
    "watch",
    "?:Ct1"
   ],
   [
    "-has content",
    "?:E1",
    "?:E2"
   ],
   [
    "actuality",
    "?:E2"
   ]
  ],
  "@confidence": 0.95
 }
]