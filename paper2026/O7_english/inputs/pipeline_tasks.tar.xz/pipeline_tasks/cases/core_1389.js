[
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "?:Fv61",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has degree property",
    "simple",
    "?:X",
    "none",
    "?:Fv62",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "has degree property",
    "cute",
    "?:X",
    "none",
    "?:Fv63",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "$generic",
     3
    ],
    [
     "$not",
     [
      "has degree property",
      "cute",
      "?:X",
      "none",
      "?:Fv64",
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9487
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-has degree property",
    "good",
    "?:X",
    "none",
    "?:Fv65",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has degree property",
    "simple",
    "?:X",
    "none",
    "?:Fv66",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "has degree property",
    "cute",
    "?:X",
    "none",
    "?:Fv67",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "$generic",
     3
    ],
    [
     "$not",
     [
      "has degree property",
      "cute",
      "?:X",
      "none",
      "?:Fv68",
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9487
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "cute",
    "#:John 1",
    "none",
    "?:Fv69",
    [
     "$ctxt",
     "present",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has degree property",
    "cute",
    "#:John 1",
    "none",
    "?:Fv70",
    [
     "$ctxt",
     "present",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has degree property",
    "cute",
    "#:John 1",
    "none",
    "?:Fv71",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree property",
    "cute",
    "#:John 1",
    "none",
    "?:Fv72",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "cute",
      "#:John 1",
      "none",
      "?:Fv73",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "bird",
   "$some_bird"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bird",
   "$some_not_bird"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "good",
   "$some_nice_entity",
   "none",
   "?:Fv74",
   [
    "$ctxt",
    "?:Fv28",
    "?:Fv25",
    "?:Fv26",
    "?:Fv27"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "good",
   "$some_not_nice_entity",
   "none",
   "?:Fv75",
   [
    "$ctxt",
    "?:Fv36",
    "?:Fv33",
    "?:Fv34",
    "?:Fv35"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "simple",
   "$some_simple_entity",
   "none",
   "?:Fv76",
   [
    "$ctxt",
    "?:Fv40",
    "?:Fv37",
    "?:Fv38",
    "?:Fv39"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "simple",
   "$some_not_simple_entity",
   "none",
   "?:Fv77",
   [
    "$ctxt",
    "?:Fv48",
    "?:Fv45",
    "?:Fv46",
    "?:Fv47"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "cute",
   "$some_cute_entity",
   "none",
   "?:Fv78",
   [
    "$ctxt",
    "?:Fv52",
    "?:Fv49",
    "?:Fv50",
    "?:Fv51"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "cute",
   "$some_not_cute_entity",
   "none",
   "?:Fv79",
   [
    "$ctxt",
    "?:Fv60",
    "?:Fv57",
    "?:Fv58",
    "?:Fv59"
   ]
  ]
 }
]