[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Tom 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "house",
   "#:house 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "build",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:Tom 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:house 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk1_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk1_activity",
    "destroy",
    [
     "$ctxt",
     "past",
     "?:Fv8",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk1_activity",
    "#:Tom 1",
    [
     "$ctxt",
     "past",
     "?:Fv10",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has target",
    "sk1_activity",
    "#:house 2",
    [
     "$ctxt",
     "past",
     "?:Fv12",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has time",
    "sk1_activity",
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "actuality",
    "sk1_activity"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "destroy",
    [
     "$ctxt",
     "past",
     "?:Fv18",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:Tom 1",
    [
     "$ctxt",
     "past",
     "?:Fv20",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has target",
    "?:E",
    "#:house 2",
    [
     "$ctxt",
     "past",
     "?:Fv22",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_verb_result",
  "@logic": [
   [
    "-has type",
    "?:E",
    "destroy",
    [
     "$ctxt",
     "?:Fv26",
     "?:Fv27",
     "?:Fv29",
     "?:Fv30"
    ]
   ],
   [
    "-has target",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "?:Fv26",
     "?:Fv27",
     "?:Fv29",
     "?:Fv30"
    ]
   ],
   [
    "-next",
    "?:Fv27",
    "?:Fv28"
   ],
   [
    "has property",
    "destroyed",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv28",
     "?:Fv29",
     "?:Fv30"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "destroyed",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv28",
       "?:Fv29",
       "?:Fv30"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_verb_result",
  "@logic": [
   [
    "-has property",
    "destroy",
    "?:X",
    [
     "$ctxt",
     "?:Fv31",
     "?:Fv32",
     "?:Fv34",
     "?:Fv35"
    ]
   ],
   [
    "-next",
    "?:Fv32",
    "?:Fv33"
   ],
   [
    "has property",
    "destroyed",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv33",
     "?:Fv34",
     "?:Fv35"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "destroyed",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv33",
       "?:Fv34",
       "?:Fv35"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]