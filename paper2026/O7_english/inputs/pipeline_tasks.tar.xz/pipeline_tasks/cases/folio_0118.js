[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "barutin cove",
   "#:Barutin Cove 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "settlement",
   "#:settlement 2"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "coast",
   "#:coast 4"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "snow island",
   "#:Snow Island 5"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "place",
   "#:South Shetland Islands 6"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "south shetland island",
   "#:South Shetland Islands 6"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "place",
   "#:Greenwich Island 7"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "greenwich island",
   "#:Greenwich Island 7"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "place",
   "#:Deception Island 8"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "deception island",
   "#:Deception Island 8"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "place",
   "#:Antarctica 9"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "barutin cove",
    "?:X"
   ],
   [
    "isa",
    "cove",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "barutin",
    "?:X"
   ],
   [
    "-isa",
    "cove",
    "?:X"
   ],
   [
    "isa",
    "barutin cove",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "deception island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "deception",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "deception island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "greenwich island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "greenwich",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "greenwich island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "snow island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "snow",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "snow island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "south shetland island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "south shetland",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "south shetland island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]