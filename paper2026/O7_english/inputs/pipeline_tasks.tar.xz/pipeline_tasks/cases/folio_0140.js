[
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "artifact",
   "films in the Frozen series"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "films in the frozen series",
   "films in the Frozen series"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "hachi: a dog's tale",
   "Hachi: A Dog's Tale 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "film",
    "?:X"
   ],
   [
    "isa",
    "person",
    [
     "sk0",
     "?:X"
    ]
   ],
   [
    "-isa",
    "child",
    "?:Y"
   ],
   [
    "is rel2",
    "watch",
    "?:Y",
    "?:X",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "film",
    "?:X"
   ],
   [
    "-is rel2",
    "appropriate for",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu5"
   ],
   [
    "-isa",
    "child",
    "?:Y"
   ],
   [
    "is rel2",
    "watch",
    "?:Y",
    "?:X",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "film",
    "?:X"
   ],
   [
    "-isa",
    "content",
    "?:Z"
   ],
   [
    "-has property",
    "erotic",
    "?:Z",
    "?:Cu6"
   ],
   [
    "-has property",
    "violent",
    "?:Z",
    "?:Cu6"
   ],
   [
    "-has part",
    "?:X",
    "?:Z",
    "?:Cu6"
   ],
   [
    "-isa",
    "child",
    "?:Y"
   ],
   [
    "-is rel2",
    "watch",
    "?:Y",
    "?:X",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "rated",
    "?:X",
    "General Audience",
    "?:Cu7"
   ],
   [
    "-isa",
    "person",
    "?:P"
   ],
   [
    "is rel2",
    "appropriate for",
    "?:X",
    "?:P",
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "film",
    "?:X"
   ],
   [
    "-has property",
    "family-friendly",
    "?:X",
    "?:Cu8"
   ],
   [
    "-has property",
    "animated",
    "?:X",
    "?:Cu8"
   ],
   [
    "is rel2",
    "rated",
    "?:X",
    "General Audience",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "https://en.wikipedia.org/wiki/Frozen_(franchise)",
    "?:Cu9"
   ],
   [
    "has property",
    "family-friendly",
    "?:X",
    "?:Cu9"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "https://en.wikipedia.org/wiki/Frozen_(franchise)",
    "?:Cu10"
   ],
   [
    "has property",
    "animated",
    "?:X",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "film",
   "Hachi: A Dog's Tale 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "has property",
    "family-friendly",
    "Hachi: A Dog's Tale 1",
    "?:Cu12"
   ],
   [
    "-isa",
    "person",
    "?:P"
   ],
   [
    "is rel2",
    "appropriate for",
    "Hachi: A Dog's Tale 1",
    "?:P",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "has property",
    "animated",
    "Hachi: A Dog's Tale 1",
    "?:Cu13"
   ],
   [
    "-isa",
    "person",
    "?:P"
   ],
   [
    "is rel2",
    "appropriate for",
    "Hachi: A Dog's Tale 1",
    "?:P",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-has property",
    "family-friendly",
    "Hachi: A Dog's Tale 1",
    "?:Cu14"
   ],
   [
    "-has property",
    "animated",
    "Hachi: A Dog's Tale 1",
    "?:Cu14"
   ],
   [
    "isa",
    "person",
    "sk1_person"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-has property",
    "family-friendly",
    "Hachi: A Dog's Tale 1",
    "?:Cu15"
   ],
   [
    "-has property",
    "animated",
    "Hachi: A Dog's Tale 1",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "appropriate for",
    "Hachi: A Dog's Tale 1",
    "sk1_person",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "rated",
    "Hachi: A Dog's Tale 1",
    "General Audience",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "rated",
    "Hachi: A Dog's Tale 1",
    "General Audience",
    "?:Cu17"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_haspart_bridge",
  "@logic": [
   [
    "-isa",
    "content",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ],
   [
    "has part",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "film",
   "$some_not_film"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "child",
   "$some_child"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "child",
   "$some_not_child"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "content",
   "$some_content"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "content",
   "$some_not_content"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "erotic",
   "$some_erotic",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "erotic",
   "$some_not_erotic",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "violent",
   "$some_violent",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "violent",
   "$some_not_violent",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "family-friendly",
   "$some_not_family-friendly",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "animated",
   "$some_not_animated",
   "?:Cu32"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "film",
   "$some_family-friendly_film"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "family-friendly",
   "$some_family-friendly_film",
   "?:Cu34"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "film",
   "$some_animated_film"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "animated",
   "$some_animated_film",
   "?:Cu36"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "films in the frozen series",
    "?:X"
   ],
   [
    "isa",
    "series",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "films in the frozen",
    "?:X"
   ],
   [
    "-isa",
    "series",
    "?:X"
   ],
   [
    "isa",
    "films in the frozen series",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "hachi: a dog's tale",
    "?:X"
   ],
   [
    "isa",
    "story",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "hachi: a dog'",
    "?:X"
   ],
   [
    "-isa",
    "story",
    "?:X"
   ],
   [
    "isa",
    "hachi: a dog's tale",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_in_haspart",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "?:Y",
    "?:C"
   ],
   [
    "has part",
    "?:Y",
    "?:X",
    "?:C"
   ]
  ]
 },
 {
  "@name": "frm_perception_factive",
  "@logic": [
   [
    "-has type",
    "?:E1",
    "watch",
    "?:Ct1"
   ],
   [
    "-has content",
    "?:E1",
    "?:E2"
   ],
   [
    "actuality",
    "?:E2"
   ]
  ],
  "@confidence": 0.95
 }
]