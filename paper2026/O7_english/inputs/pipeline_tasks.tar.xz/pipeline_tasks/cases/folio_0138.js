[
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "state-of-the-art text summarization model",
   "#:state-of-the-art text summarization model 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "abstract",
   "Machine Learning algorithms"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "machine learning algorithm",
   "Machine Learning algorithms"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "machine learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "supervised learning",
    "?:X"
   ],
   [
    "isa",
    "unsupervised learning",
    "?:X"
   ],
   [
    "isa",
    "reinforcement learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "unsupervised learning algorithm",
    "?:X"
   ],
   [
    "-is rel2",
    "need",
    "?:X",
    "labeled data",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "artifact",
   "#:state-of-the-art text summarization model 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "machine learning algorithm",
   "sk0_machine learning algorithm"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "train",
   "#:state-of-the-art text summarization model 1",
   "sk0_machine learning algorithm",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "artifact",
   "#:state-of-the-art text summarization model 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "reinforcement learning",
   "sk1_reinforcement learning"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "-is rel2",
   "train",
   "#:state-of-the-art text summarization model 1",
   "sk1_reinforcement learning",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "artifact",
   "#:state-of-the-art text summarization model 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "labeled data",
   "sk2_labeled data"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "need",
   "Machine Learning algorithms",
   "sk2_labeled data",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "supervised learning",
    "sk3_supervised learning"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "train",
    "#:state-of-the-art text summarization model 1",
    "sk3_supervised learning",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "supervised learning",
    "?:X"
   ],
   [
    "-is rel2",
    "train",
    "#:state-of-the-art text summarization model 1",
    "?:X",
    "?:Cu17"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "machine learning algorithm",
   "$some_Machine_Learning_algorithm"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "machine learning algorithm",
   "$some_not_Machine_Learning_algorithm"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "supervised learning",
   "$some_supervised_learning"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "supervised learning",
   "$some_not_supervised_learning"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "unsupervised learning",
   "$some_unsupervised_learning"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "unsupervised learning",
   "$some_not_unsupervised_learning"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "reinforcement learning",
   "$some_reinforcement_learning"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "reinforcement learning",
   "$some_not_reinforcement_learning"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "unsupervised learning algorithm",
   "$some_unsupervised_learning_algorithm"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "unsupervised learning algorithm",
   "$some_not_unsupervised_learning_algorithm"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "labeled data",
   "$some_labeled_data"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "labeled data",
   "$some_not_labeled_data"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "machine learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "algorithm",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "machine learning",
    "?:X"
   ],
   [
    "-isa",
    "algorithm",
    "?:X"
   ],
   [
    "isa",
    "machine learning algorithm",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "labeled data",
    "?:X"
   ],
   [
    "isa",
    "data",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "labeled",
    "?:X"
   ],
   [
    "-isa",
    "data",
    "?:X"
   ],
   [
    "isa",
    "labeled data",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "machine learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "algorithm",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "machine learning",
    "?:X"
   ],
   [
    "-isa",
    "algorithm",
    "?:X"
   ],
   [
    "isa",
    "machine learning algorithm",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "reinforcement learning",
    "?:X"
   ],
   [
    "isa",
    "learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "reinforcement",
    "?:X"
   ],
   [
    "-isa",
    "learning",
    "?:X"
   ],
   [
    "isa",
    "reinforcement learning",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "state-of-the-art text summarization model",
    "?:X"
   ],
   [
    "isa",
    "model",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "state-of-the-art text summarization",
    "?:X"
   ],
   [
    "-isa",
    "model",
    "?:X"
   ],
   [
    "isa",
    "state-of-the-art text summarization model",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "supervised learning",
    "?:X"
   ],
   [
    "isa",
    "learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "supervised",
    "?:X"
   ],
   [
    "-isa",
    "learning",
    "?:X"
   ],
   [
    "isa",
    "supervised learning",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "unsupervised learning",
    "?:X"
   ],
   [
    "isa",
    "learning",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "unsupervised",
    "?:X"
   ],
   [
    "-isa",
    "learning",
    "?:X"
   ],
   [
    "isa",
    "unsupervised learning",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "unsupervised learning algorithm",
    "?:X"
   ],
   [
    "isa",
    "algorithm",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "unsupervised learning",
    "?:X"
   ],
   [
    "-isa",
    "algorithm",
    "?:X"
   ],
   [
    "isa",
    "unsupervised learning algorithm",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]