[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "person",
   "#:Heinrich Schmidt 1"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "heinrich schmidt",
   "#:Heinrich Schmidt 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "organization",
   "#:Prussian State Parliament 2"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "prussian state parliament",
   "#:Prussian State Parliament 2"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "organization",
   "#:Nazi Reichstag 3"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "nazi reichstag",
   "#:Nazi Reichstag 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "politician",
   "#:Heinrich Schmidt 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "German",
   "#:Heinrich Schmidt 1",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "member of",
   "#:Heinrich Schmidt 1",
   "https://en.wikipedia.org/wiki/Prussian_Landtag",
   "?:Cu9"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "member of",
   "#:Heinrich Schmidt 1",
   "https://en.wikipedia.org/wiki/Reichstag_(Nazi_Germany)",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "politician",
    "sk0_politician"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "German",
    "sk0_politician",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "member of",
    "sk0_politician",
    "https://en.wikipedia.org/wiki/Prussian_Landtag",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "member of",
    "sk0_politician",
    "https://en.wikipedia.org/wiki/Reichstag_(Nazi_Germany)",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "politician",
    "?:X"
   ],
   [
    "-has property",
    "German",
    "?:X",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "member of",
    "?:X",
    "https://en.wikipedia.org/wiki/Prussian_Landtag",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "member of",
    "?:X",
    "https://en.wikipedia.org/wiki/Reichstag_(Nazi_Germany)",
    "?:Cu15"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "heinrich schmidt",
    "?:X"
   ],
   [
    "isa",
    "schmidt",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "heinrich",
    "?:X"
   ],
   [
    "-isa",
    "schmidt",
    "?:X"
   ],
   [
    "isa",
    "heinrich schmidt",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "nazi reichstag",
    "?:X"
   ],
   [
    "isa",
    "reichstag",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "nazi",
    "?:X"
   ],
   [
    "-isa",
    "reichstag",
    "?:X"
   ],
   [
    "isa",
    "nazi reichstag",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "prussian state parliament",
    "?:X"
   ],
   [
    "isa",
    "parliament",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "prussian state",
    "?:X"
   ],
   [
    "-isa",
    "parliament",
    "?:X"
   ],
   [
    "isa",
    "prussian state parliament",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]