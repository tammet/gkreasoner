[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Mary 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "promotion",
   "#:promotion 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "give",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has recipient",
   "sk0_activity",
   "#:Mary 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:promotion 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has type",
    [
     "sk1",
     "?:X"
    ],
    "give",
    [
     "$ctxt",
     "past",
     "?:Fv8",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has recipient",
    [
     "sk1",
     "?:X"
    ],
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv10",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "isa",
    "promotion",
    [
     "sk2",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has target",
    [
     "sk1",
     "?:X"
    ],
    [
     "sk2",
     "?:X"
    ],
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "has time",
    [
     "sk1",
     "?:X"
    ],
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv16",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:X"
   ],
   [
    "actuality",
    [
     "sk1",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "give",
    [
     "$ctxt",
     "past",
     "?:Fv20",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has recipient",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv22",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-isa",
    "promotion",
    "?:Y"
   ],
   [
    "-has target",
    "?:E",
    "?:Y",
    [
     "$ctxt",
     "past",
     "?:Fv26",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0",
   "?:X"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv30"
   ],
   [
    "has type",
    "?:E",
    "give",
    "?:Fv30"
   ]
  ],
  "@confidence": 0.91
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "promotion",
   "$some_promotion"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]