[
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "person",
   "#:James 1"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "man",
   "#:James 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "company building",
   "sk0_company building"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "schedule",
    "?:X",
    "customer",
    "?:Cu4"
   ],
   [
    "is rel2",
    "go",
    "?:X",
    "sk0_company building",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "company building",
   "sk1_company building"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu6"
   ],
   [
    "is rel2",
    "schedule",
    "?:X",
    "customer",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "company building",
   "sk2_company building"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu9"
   ],
   [
    "isa",
    "home",
    [
     "sk3",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "have",
    "?:X",
    "lunch",
    "?:Cu10"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "?:C",
    "?:Cu11"
   ],
   [
    "isa",
    "home",
    [
     "sk4",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "employee",
    "?:X"
   ],
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "?:C",
    "?:Cu12"
   ],
   [
    "is rel2",
    "work",
    "?:X",
    [
     "sk4",
     "?:X"
    ],
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "manager",
    "?:X"
   ],
   [
    "-isa",
    "home",
    "?:H"
   ],
   [
    "-is rel2",
    "work",
    "?:X",
    "?:H",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "company building",
   "sk5_company building"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "manager",
    "#:James 1"
   ],
   [
    "is rel2",
    "go",
    "#:James 1",
    "sk5_company building",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-is rel2",
    "go",
    "#:James 1",
    "sk5_company building",
    "?:Cu16"
   ],
   [
    "isa",
    "manager",
    "#:James 1"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "manager",
    "#:James 1"
   ],
   [
    "isa",
    "country",
    "sk6_country"
   ],
   [
    "-isa",
    "home",
    "?:H1"
   ],
   [
    "-is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "manager",
    "#:James 1"
   ],
   [
    "isa",
    "country",
    "sk6_country"
   ],
   [
    "-isa",
    "home",
    "?:H2"
   ],
   [
    "-is rel2",
    "work",
    "#:James 1",
    "?:H2",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "manager",
    "#:James 1"
   ],
   [
    "is rel2",
    "in",
    "#:James 1",
    "sk6_country",
    "?:Cu21"
   ],
   [
    "-isa",
    "home",
    "?:H1"
   ],
   [
    "-is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "manager",
    "#:James 1"
   ],
   [
    "is rel2",
    "in",
    "#:James 1",
    "sk6_country",
    "?:Cu22"
   ],
   [
    "-isa",
    "home",
    "?:H2"
   ],
   [
    "-is rel2",
    "work",
    "#:James 1",
    "?:H2",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "#:James 1",
    "?:C",
    "?:Cu23"
   ],
   [
    "isa",
    "manager",
    "#:James 1"
   ],
   [
    "-isa",
    "home",
    "?:H1"
   ],
   [
    "-is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "#:James 1",
    "?:C",
    "?:Cu24"
   ],
   [
    "isa",
    "manager",
    "#:James 1"
   ],
   [
    "-isa",
    "home",
    "?:H2"
   ],
   [
    "-is rel2",
    "work",
    "#:James 1",
    "?:H2",
    "?:Cu24"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "#:James 1",
    "?:C",
    "?:Cu25"
   ],
   [
    "isa",
    "country",
    "sk6_country"
   ],
   [
    "-isa",
    "home",
    "?:H1"
   ],
   [
    "-is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "#:James 1",
    "?:C",
    "?:Cu26"
   ],
   [
    "isa",
    "country",
    "sk6_country"
   ],
   [
    "-isa",
    "home",
    "?:H2"
   ],
   [
    "-is rel2",
    "work",
    "#:James 1",
    "?:H2",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "#:James 1",
    "?:C",
    "?:Cu27"
   ],
   [
    "is rel2",
    "in",
    "#:James 1",
    "sk6_country",
    "?:Cu27"
   ],
   [
    "-isa",
    "home",
    "?:H1"
   ],
   [
    "-is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu27"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "#:James 1",
    "?:C",
    "?:Cu28"
   ],
   [
    "is rel2",
    "in",
    "#:James 1",
    "sk6_country",
    "?:Cu28"
   ],
   [
    "-isa",
    "home",
    "?:H2"
   ],
   [
    "-is rel2",
    "work",
    "#:James 1",
    "?:H2",
    "?:Cu28"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "-isa",
    "home",
    "?:H1"
   ],
   [
    "-is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu29"
   ],
   [
    "-isa",
    "manager",
    "#:James 1"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "-isa",
    "home",
    "?:H1"
   ],
   [
    "-is rel2",
    "have",
    "#:James 1",
    "lunch",
    "?:Cu30"
   ],
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "#:James 1",
    "?:C",
    "?:Cu30"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "-isa",
    "home",
    "?:H2"
   ],
   [
    "-is rel2",
    "work",
    "#:James 1",
    "?:H2",
    "?:Cu31"
   ],
   [
    "-isa",
    "manager",
    "#:James 1"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "-isa",
    "home",
    "?:H2"
   ],
   [
    "-is rel2",
    "work",
    "#:James 1",
    "?:H2",
    "?:Cu32"
   ],
   [
    "-isa",
    "country",
    "?:C"
   ],
   [
    "-is rel2",
    "in",
    "#:James 1",
    "?:C",
    "?:Cu32"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "contrapositive form",
    "sk7_contrapositive form"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "natural",
    "sk7_contrapositive form",
    "?:Cu34"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "contrapositive form",
    "?:X"
   ],
   [
    "-has property",
    "natural",
    "?:X",
    "?:Cu35"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "company building",
   "$some_company_building"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "company building",
   "$some_not_company_building"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "employee",
   "$some_employee"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "employee",
   "$some_not_employee"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "home",
   "$some_home"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "home",
   "$some_not_home"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "country",
   "$some_country"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "country",
   "$some_not_country"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "company building",
    "?:X"
   ],
   [
    "isa",
    "building",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "company",
    "?:X"
   ],
   [
    "-isa",
    "building",
    "?:X"
   ],
   [
    "isa",
    "company building",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "contrapositive form",
    "?:X"
   ],
   [
    "isa",
    "form",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "contrapositive",
    "?:X"
   ],
   [
    "-isa",
    "form",
    "?:X"
   ],
   [
    "isa",
    "contrapositive form",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv43"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv43"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "receive",
    "?:Fv44"
   ],
   [
    "has type",
    "?:E",
    "have",
    "?:Fv44"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "country",
    "?:X"
   ],
   [
    "isa",
    "state",
    "?:X"
   ]
  ],
  "@confidence": 0.92
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-isa",
    "state",
    "?:X"
   ],
   [
    "isa",
    "country",
    "?:X"
   ]
  ],
  "@confidence": 0.92
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]