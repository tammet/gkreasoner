[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "-isa",
    "trunk",
    "?:Y"
   ],
   [
    "-has degree property",
    "long",
    "?:Y",
    "none",
    "trunk",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has property",
    "red",
    "?:Y",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has part",
    "?:X",
    "?:Y",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "elephant",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "trunk",
    "sk0_trunk"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "long",
    "sk0_trunk",
    "none",
    "trunk",
    [
     "$ctxt",
     "?:Fv14",
     "?:Fv13",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "red",
    "sk0_trunk",
    [
     "$ctxt",
     "?:Fv16",
     "?:Fv15",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has part",
    "#:John 1",
    "sk0_trunk",
    [
     "$ctxt",
     "present",
     "?:Fv17",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "trunk",
    "?:Y"
   ],
   [
    "-has degree property",
    "long",
    "?:Y",
    "none",
    "trunk",
    [
     "$ctxt",
     "?:Fv21",
     "?:Fv20",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-has property",
    "red",
    "?:Y",
    [
     "$ctxt",
     "?:Fv23",
     "?:Fv22",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-has part",
    "#:John 1",
    "?:Y",
    [
     "$ctxt",
     "present",
     "?:Fv24",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_haspart_bridge",
  "@logic": [
   [
    "-isa",
    "trunk",
    "?:Y"
   ],
   [
    "-have",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ],
   [
    "has part",
    "?:X",
    "?:Y",
    "?:Ctxt"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has part",
    "#:John 1",
    "?:Br1",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has part",
    "#:John 1",
    "?:Br1",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has part",
      "#:John 1",
      "?:Br1",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "elephant",
   "$some_not_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "trunk",
   "$some_trunk"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "trunk",
   "$some_not_trunk"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "long",
   "$some_long_trunk",
   "none",
   "trunk",
   [
    "$ctxt",
    "?:Fv52",
    "?:Fv49",
    "?:Fv50",
    "?:Fv51"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "trunk",
   "$some_long_trunk"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "long",
   "$some_not_long_trunk",
   "none",
   "trunk",
   [
    "$ctxt",
    "?:Fv60",
    "?:Fv57",
    "?:Fv58",
    "?:Fv59"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "red",
   "$some_red",
   [
    "$ctxt",
    "?:Fv64",
    "?:Fv61",
    "?:Fv62",
    "?:Fv63"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "red",
   "$some_not_red",
   [
    "$ctxt",
    "?:Fv68",
    "?:Fv65",
    "?:Fv66",
    "?:Fv67"
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "long",
    "?:X",
    "none",
    "?:Fv69",
    [
     "$ctxt",
     "past",
     "?:Fv25",
     "?:Fv26",
     "?:Fv27"
    ]
   ],
   [
    "has degree property",
    "long",
    "?:X",
    "none",
    "?:Fv70",
    [
     "$ctxt",
     "present",
     "?:Fv25",
     "?:Fv26",
     "?:Fv27"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "long",
      "?:X",
      "none",
      "?:Fv71",
      [
       "$ctxt",
       "present",
       "?:Fv25",
       "?:Fv26",
       "?:Fv27"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "long",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv28",
     "?:Fv29",
     "?:Fv30"
    ]
   ],
   [
    "has degree property",
    "long",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv28",
     "?:Fv29",
     "?:Fv30"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "long",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv28",
       "?:Fv29",
       "?:Fv30"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv31",
     "?:Fv32",
     "?:Fv33"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv31",
     "?:Fv32",
     "?:Fv33"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv31",
       "?:Fv32",
       "?:Fv33"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv34",
     "?:Fv35",
     "?:Fv36"
    ]
   ],
   [
    "has property",
    "red",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv34",
     "?:Fv35",
     "?:Fv36"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "red",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv34",
       "?:Fv35",
       "?:Fv36"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]