[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-has degree property",
    "cool",
    "?:X",
    "none",
    "animal",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has property",
    "defeated",
    "?:X",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "has property",
    "green",
    "?:X",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "animal",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has degree property",
   "cool",
   "#:John 1",
   "none",
   "animal",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv7",
    "?:Fv8"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "animal",
   "#:Mike 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "has degree property",
   "cool",
   "#:Mike 2",
   "none",
   "animal",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv11",
    "?:Fv12"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "has property",
   "defeated",
   "#:John 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv13",
    "?:Fv14"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-has property",
    "green",
    "#:John 1",
    [
     "$ctxt",
     "present",
     "?:Fv17",
     "?:Fv15",
     "?:Fv16"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "has property",
    "green",
    "#:John 1",
    [
     "$ctxt",
     "present",
     "?:Fv17",
     "?:Fv15",
     "?:Fv16"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has property",
    "green",
    "#:John 1",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has property",
    "green",
    "#:John 1",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "green",
      "#:John 1",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "cool",
   "$some_not_cool_animal",
   "none",
   "animal",
   [
    "$ctxt",
    "?:Fv32",
    "?:Fv29",
    "?:Fv30",
    "?:Fv31"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "defeated",
   "$some_not_defeated_animal",
   [
    "$ctxt",
    "?:Fv36",
    "?:Fv33",
    "?:Fv34",
    "?:Fv35"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "green",
   "$some_green_animal",
   [
    "$ctxt",
    "?:Fv40",
    "?:Fv37",
    "?:Fv38",
    "?:Fv39"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_green_animal"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "green",
   "$some_not_green_animal",
   [
    "$ctxt",
    "?:Fv48",
    "?:Fv45",
    "?:Fv46",
    "?:Fv47"
   ]
  ]
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "green",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv19",
     "?:Fv20",
     "?:Fv21"
    ]
   ],
   [
    "has property",
    "green",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv19",
     "?:Fv20",
     "?:Fv21"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "green",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv19",
       "?:Fv20",
       "?:Fv21"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has property",
    "green",
    "?:X",
    [
     "$ctxt",
     "past",
     "?:Fv22",
     "?:Fv23",
     "?:Fv24"
    ]
   ],
   [
    "has property",
    "green",
    "?:X",
    [
     "$ctxt",
     "present",
     "?:Fv22",
     "?:Fv23",
     "?:Fv24"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "green",
      "?:X",
      [
       "$ctxt",
       "present",
       "?:Fv22",
       "?:Fv23",
       "?:Fv24"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]