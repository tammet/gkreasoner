[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "barutin cove",
   "#:Barutin Cove 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "place",
   "#:Snow Island 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "snow island",
   "#:Snow Island 4"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "place",
   "#:South Shetland Islands 5"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "south shetland island",
   "#:South Shetland Islands 5"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "place",
   "#:Greenwich Island 6"
  ]
 },
 {
  "@name": "entity_S8",
  "@logic": [
   "isa",
   "greenwich island",
   "#:Greenwich Island 6"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "place",
   "#:Deception Island 7"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "deception island",
   "#:Deception Island 7"
  ]
 },
 {
  "@name": "entity_S10",
  "@logic": [
   "isa",
   "place",
   "#:Antarctica 8"
  ]
 },
 {
  "@name": "entity_S12",
  "@logic": [
   "isa",
   "place",
   "#:Bulgaria 9"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "cove",
   "#:Barutin Cove 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "named after",
   "#:Barutin Cove 1",
   "#:Barutin 2",
   "?:Cu13"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "settlement",
   "#:Barutin 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "Bulgarian",
   "#:Barutin 2",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "coast",
   "#:coast 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "has part",
   "#:Snow Island 4",
   "#:coast 3",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "has property",
   "southwest",
   "#:coast 3",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "on",
   "#:Barutin Cove 1",
   "#:coast 3",
   "?:Cu19"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "is rel2",
   "in",
   "#:Barutin Cove 1",
   "#:Snow Island 4",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "in",
   "#:Snow Island 4",
   "#:South Shetland Islands 5",
   "?:Cu21"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "in",
   "#:Greenwich Island 6",
   "#:South Shetland Islands 5",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "in",
   "#:Deception Island 7",
   "#:South Shetland Islands 5",
   "?:Cu23"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "is rel2",
   "in",
   "#:South Shetland Islands 5",
   "#:Antarctica 8",
   "?:Cu24"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "?:Y",
    "?:Cu25"
   ],
   [
    "-is rel2",
    "in",
    "?:Y",
    "?:Z",
    "?:Cu25"
   ],
   [
    "is rel2",
    "in",
    "?:X",
    "?:Z",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "cove",
    "sk0"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "sk0",
    "#:Antarctica 8",
    "?:Cu27"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "place",
    "sk1_place"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "cove",
    "sk1_place"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "sk1_place",
    "#:Bulgaria 9",
    "?:Cu30"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "named after",
    "sk0",
    "sk1_place",
    "?:Cu31"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "cove",
    "?:X"
   ],
   [
    "-is rel2",
    "in",
    "?:X",
    "#:Antarctica 8",
    "?:Cu32"
   ],
   [
    "-isa",
    "place",
    "?:Y"
   ],
   [
    "-isa",
    "cove",
    "?:Y"
   ],
   [
    "-is rel2",
    "in",
    "?:Y",
    "#:Bulgaria 9",
    "?:Cu32"
   ],
   [
    "-is rel2",
    "named after",
    "?:X",
    "?:Y",
    "?:Cu32"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S12",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "barutin cove",
    "?:X"
   ],
   [
    "isa",
    "cove",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "barutin",
    "?:X"
   ],
   [
    "-isa",
    "cove",
    "?:X"
   ],
   [
    "isa",
    "barutin cove",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "deception island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "deception",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "deception island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "greenwich island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "greenwich",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "greenwich island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "snow island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "snow",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "snow island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "south shetland island",
    "?:X"
   ],
   [
    "isa",
    "island",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "south shetland",
    "?:X"
   ],
   [
    "-isa",
    "island",
    "?:X"
   ],
   [
    "isa",
    "south shetland island",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_in_haspart",
  "@logic": [
   [
    "-is rel2",
    "in",
    "?:X",
    "?:Y",
    "?:C"
   ],
   [
    "has part",
    "?:Y",
    "?:X",
    "?:C"
   ]
  ]
 }
]