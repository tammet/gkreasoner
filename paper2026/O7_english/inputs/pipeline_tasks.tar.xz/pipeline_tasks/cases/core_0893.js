[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "student",
   "#:student 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:student 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "test",
   "#:test 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "pass",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:student 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has target",
   "sk0_activity",
   "#:test 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:student 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "activity",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has type",
   "sk1_activity",
   "study",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has actor",
   "sk1_activity",
   "#:student 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has manner",
   "sk1_activity",
   "a lot",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has time",
   "sk1_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv3",
    "?:Fv4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "actuality",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk2_activity",
    "fail",
    [
     "$ctxt",
     "past",
     "?:Fv10",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk2_activity",
    "#:student 1",
    [
     "$ctxt",
     "past",
     "?:Fv12",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has target",
    "sk2_activity",
    "#:test 2",
    [
     "$ctxt",
     "past",
     "?:Fv14",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has time",
    "sk2_activity",
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv16",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "actuality",
    "sk2_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "fail",
    [
     "$ctxt",
     "past",
     "?:Fv20",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:student 1",
    [
     "$ctxt",
     "past",
     "?:Fv22",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has target",
    "?:E",
    "#:test 2",
    [
     "$ctxt",
     "past",
     "?:Fv24",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv28"
   ],
   [
    "has type",
    "?:E",
    "give",
    "?:Fv28"
   ]
  ],
  "@confidence": 0.91
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv29"
   ],
   [
    "has type",
    "?:E",
    "go",
    "?:Fv29"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_verb_excl",
  "@logic": [
   [
    "-has type",
    "?:E1",
    "pass",
    "?:Fv30"
   ],
   [
    "-has actor",
    "?:E1",
    "?:Ag",
    "?:Fv30"
   ],
   [
    "-has target",
    "?:E1",
    "?:Tg",
    "?:Fv30"
   ],
   [
    "-has type",
    "?:E2",
    "fail",
    "?:Fv30"
   ],
   [
    "-has actor",
    "?:E2",
    "?:Ag",
    "?:Fv30"
   ],
   [
    "-has target",
    "?:E2",
    "?:Tg",
    "?:Fv30"
   ],
   [
    "$block",
    0,
    [
     "has type",
     "?:E2",
     "fail",
     "?:Fv30"
    ]
   ]
  ],
  "@confidence": 0.85
 },
 {
  "@name": "frm_verb_excl",
  "@logic": [
   [
    "-has type",
    "?:E1",
    "fail",
    "?:Fv31"
   ],
   [
    "-has actor",
    "?:E1",
    "?:Ag",
    "?:Fv31"
   ],
   [
    "-has target",
    "?:E1",
    "?:Tg",
    "?:Fv31"
   ],
   [
    "-has type",
    "?:E2",
    "pass",
    "?:Fv31"
   ],
   [
    "-has actor",
    "?:E2",
    "?:Ag",
    "?:Fv31"
   ],
   [
    "-has target",
    "?:E2",
    "?:Tg",
    "?:Fv31"
   ],
   [
    "$block",
    0,
    [
     "has type",
     "?:E2",
     "pass",
     "?:Fv31"
    ]
   ]
  ],
  "@confidence": 0.85
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]