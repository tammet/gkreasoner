[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "-isa",
    "bird",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "elephant",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "bird",
    "#:John 1"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "bird",
    "#:John 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "elephant",
   "$some_not_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "bird",
   "$some_bird"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bird",
   "$some_not_bird"
  ]
 }
]