[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "-isa",
    "bird",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "elephant",
    "?:X"
   ],
   [
    "-isa",
    "fish",
    "?:Y"
   ],
   [
    "-has degree property",
    "small",
    "?:Y",
    "none",
    "fish",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "fox",
    "?:X"
   ],
   [
    "-isa",
    "bird",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "fox",
    "?:X"
   ],
   [
    "-isa",
    "fish",
    "?:Y"
   ],
   [
    "-has degree property",
    "small",
    "?:Y",
    "none",
    "fish",
    [
     "$ctxt",
     "?:Fv16",
     "?:Fv15",
     "?:Fv13",
     "?:Fv14"
    ]
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "rabbit",
    "?:X"
   ],
   [
    "-isa",
    "bird",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "rabbit",
    "?:X"
   ],
   [
    "-isa",
    "fish",
    "?:Y"
   ],
   [
    "-has degree property",
    "small",
    "?:Y",
    "none",
    "fish",
    [
     "$ctxt",
     "?:Fv24",
     "?:Fv23",
     "?:Fv21",
     "?:Fv22"
    ]
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "rabbit",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "fish",
    "#:John 1"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has degree property",
    "small",
    "#:John 1",
    "none",
    "fish",
    [
     "$ctxt",
     "present",
     "?:Fv29",
     "?:Fv27",
     "?:Fv28"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "fish",
    "#:John 1"
   ],
   [
    "-has degree property",
    "small",
    "#:John 1",
    "none",
    "fish",
    [
     "$ctxt",
     "present",
     "?:Fv29",
     "?:Fv27",
     "?:Fv28"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has degree property",
    "small",
    "#:John 1",
    "none",
    "fish",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has degree property",
    "small",
    "#:John 1",
    "none",
    "fish",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "small",
      "#:John 1",
      "none",
      "fish",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "elephant",
   "$some_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "elephant",
   "$some_not_elephant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "bird",
   "$some_bird"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "bird",
   "$some_not_bird"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "fish",
   "$some_fish"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "fish",
   "$some_not_fish"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "fox",
   "$some_fox"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "fox",
   "$some_not_fox"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "rabbit",
   "$some_not_rabbit"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "has degree property",
   "small",
   "$some_small_fish",
   "none",
   "fish",
   [
    "$ctxt",
    "?:Fv82",
    "?:Fv79",
    "?:Fv80",
    "?:Fv81"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "fish",
   "$some_small_fish"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has degree property",
   "small",
   "$some_not_small_fish",
   "none",
   "fish",
   [
    "$ctxt",
    "?:Fv90",
    "?:Fv87",
    "?:Fv88",
    "?:Fv89"
   ]
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has degree property",
    "small",
    "?:X",
    "none",
    "?:Fv91",
    "?:Fv35"
   ],
   [
    "-has degree property",
    "high",
    "?:X",
    "none",
    "?:Fv92",
    "?:Fv35"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "has degree property",
    "high",
    "?:X",
    "none",
    "?:Fv93",
    "?:Fv36"
   ],
   [
    "has degree property",
    "small",
    "?:X",
    "none",
    "?:Fv94",
    "?:Fv36"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "-isa",
    "fish",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "bird",
    "?:X"
   ],
   [
    "-isa",
    "fish",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "small",
    "?:X",
    "none",
    "?:Fv95",
    [
     "$ctxt",
     "past",
     "?:Fv37",
     "?:Fv38",
     "?:Fv39"
    ]
   ],
   [
    "has degree property",
    "small",
    "?:X",
    "none",
    "?:Fv96",
    [
     "$ctxt",
     "present",
     "?:Fv37",
     "?:Fv38",
     "?:Fv39"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "small",
      "?:X",
      "none",
      "?:Fv97",
      [
       "$ctxt",
       "present",
       "?:Fv37",
       "?:Fv38",
       "?:Fv39"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_stable_persist",
  "@logic": [
   [
    "-has degree property",
    "small",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "past",
     "?:Fv40",
     "?:Fv41",
     "?:Fv42"
    ]
   ],
   [
    "has degree property",
    "small",
    "?:X",
    "?:D",
    "?:RC",
    [
     "$ctxt",
     "present",
     "?:Fv40",
     "?:Fv41",
     "?:Fv42"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has degree property",
      "small",
      "?:X",
      "?:D",
      "?:RC",
      [
       "$ctxt",
       "present",
       "?:Fv40",
       "?:Fv41",
       "?:Fv42"
      ]
     ]
    ]
   ]
  ],
  "@confidence": 0.95
 }
]