[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "organization",
   "#:Women's Tennis Association 3"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "women's tennis association",
   "#:Women's Tennis Association 3"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "person",
   "#:Iga Swiatek 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "iga swiatek",
   "#:Iga Swiatek 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "event",
   "#:Roland Garros 2022 2"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "roland garros 2022",
   "#:Roland Garros 2022 2"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "person",
   "#:Rafael Nadal 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "man",
   "#:Rafael Nadal 4"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "rafael nadal",
   "#:Rafael Nadal 4"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "coco gauff",
   "#:Coco Gauff 5"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-has property",
    "ranked highly by Women's Tennis Association 3",
    "?:X",
    "?:Cu11"
   ],
   [
    "has property",
    "most active",
    "?:X",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "lose",
    "?:X",
    "#:Iga Swiatek 1",
    "?:Cu12"
   ],
   [
    "has property",
    "ranked highly by Women's Tennis Association 3",
    "?:X",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-has property",
    "female",
    "?:X",
    "?:Cu13"
   ],
   [
    "-is rel2",
    "at",
    "?:X",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu13"
   ],
   [
    "is rel2",
    "lose",
    "?:X",
    "#:Iga Swiatek 1",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu14"
   ],
   [
    "has property",
    "female",
    "?:X",
    "?:Cu14"
   ],
   [
    "has property",
    "male",
    "?:X",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-is rel2",
    "at",
    "?:X",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu15"
   ],
   [
    "-has property",
    "female",
    "?:X",
    "?:Cu15"
   ],
   [
    "-has property",
    "male",
    "?:X",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-has property",
    "male",
    "?:X",
    "?:Cu16"
   ],
   [
    "-is rel2",
    "at",
    "?:X",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu16"
   ],
   [
    "is rel2",
    "lose",
    "?:X",
    "#:Rafael Nadal 4",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-has property",
    "ranked highly by Women's Tennis Association 3",
    "#:Coco Gauff 5",
    "?:Cu17"
   ],
   [
    "-has property",
    "male",
    "#:Coco Gauff 5",
    "?:Cu17"
   ],
   [
    "-is rel2",
    "at",
    "#:Coco Gauff 5",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-is rel2",
    "lose",
    "#:Coco Gauff 5",
    "#:Rafael Nadal 4",
    "?:Cu18"
   ],
   [
    "-has property",
    "male",
    "#:Coco Gauff 5",
    "?:Cu18"
   ],
   [
    "-is rel2",
    "at",
    "#:Coco Gauff 5",
    "https://en.wikipedia.org/wiki/2022_French_Open",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Coco Gauff 5"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is rel2",
   "at",
   "#:Coco Gauff 5",
   "https://en.wikipedia.org/wiki/2022_French_Open",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:Coco Gauff 5"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "tennis player",
   "#:Coco Gauff 5"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "lose",
    "#:Coco Gauff 5",
    "#:Rafael Nadal 4",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "lose",
    "#:Coco Gauff 5",
    "#:Rafael Nadal 4",
    "?:Cu24"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "ranked highly by Women's Tennis Association 3",
   "$some_not_ranked_highly_by_Women's_Tennis_Association_3",
   "?:Cu27"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "most active",
   "$some_most_active",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "most active",
   "$some_not_most_active",
   "?:Cu29"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "female",
   "$some_female",
   "?:Cu30"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "female",
   "$some_not_female",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "male",
   "$some_male",
   "?:Cu32"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "coco gauff",
    "?:X"
   ],
   [
    "isa",
    "gauff",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "coco",
    "?:X"
   ],
   [
    "-isa",
    "gauff",
    "?:X"
   ],
   [
    "isa",
    "coco gauff",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "iga swiatek",
    "?:X"
   ],
   [
    "isa",
    "swiatek",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "iga",
    "?:X"
   ],
   [
    "-isa",
    "swiatek",
    "?:X"
   ],
   [
    "isa",
    "iga swiatek",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "rafael nadal",
    "?:X"
   ],
   [
    "isa",
    "nadal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "rafael",
    "?:X"
   ],
   [
    "-isa",
    "nadal",
    "?:X"
   ],
   [
    "isa",
    "rafael nadal",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "roland garros 2022",
    "?:X"
   ],
   [
    "isa",
    "2022",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "roland garro",
    "?:X"
   ],
   [
    "-isa",
    "2022",
    "?:X"
   ],
   [
    "isa",
    "roland garros 2022",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "tennis player",
    "?:X"
   ],
   [
    "isa",
    "player",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "tennis",
    "?:X"
   ],
   [
    "-isa",
    "player",
    "?:X"
   ],
   [
    "isa",
    "tennis player",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "women's tennis association",
    "?:X"
   ],
   [
    "isa",
    "association",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "women's tennis",
    "?:X"
   ],
   [
    "-isa",
    "association",
    "?:X"
   ],
   [
    "isa",
    "women's tennis association",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "female",
    "?:X",
    "?:Fv31"
   ],
   [
    "-has property",
    "male",
    "?:X",
    "?:Fv31"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]