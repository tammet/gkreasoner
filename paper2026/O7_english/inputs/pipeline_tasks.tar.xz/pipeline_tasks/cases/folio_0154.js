[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "hydrocarbon",
    "?:X"
   ],
   [
    "isa",
    "organic compound",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "alkane",
    "?:X"
   ],
   [
    "isa",
    "hydrocarbon",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "organic compound",
    "?:X"
   ],
   [
    "isa",
    "chemical compound",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "organic compound",
    "?:X"
   ],
   [
    "is rel2",
    "in",
    "carbon",
    "?:X",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "chemical compound",
    "?:X"
   ],
   [
    "-isa",
    "element",
    "?:Y"
   ],
   [
    "-is rel2",
    "in",
    "?:Y",
    "?:X",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "mixture",
   "#:mixture 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "chemical compound",
    "#:mixture 1"
   ],
   [
    "-isa",
    "element",
    "?:Y"
   ],
   [
    "-is rel2",
    "in",
    "?:Y",
    "#:mixture 1",
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "element",
    "sk0_element"
   ],
   [
    "-isa",
    "chemical compound",
    "#:mixture 1"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "isa",
    "element",
    "sk0_element"
   ],
   [
    "-isa",
    "element",
    "?:Y"
   ],
   [
    "-is rel2",
    "in",
    "?:Y",
    "#:mixture 1",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "in",
    "sk0_element",
    "#:mixture 1",
    "?:Cu11"
   ],
   [
    "-isa",
    "chemical compound",
    "#:mixture 1"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "in",
    "sk0_element",
    "#:mixture 1",
    "?:Cu12"
   ],
   [
    "-isa",
    "element",
    "?:Y"
   ],
   [
    "-is rel2",
    "in",
    "?:Y",
    "#:mixture 1",
    "?:Cu12"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "alkane",
    "#:mixture 1"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "in",
    "carbon",
    "#:mixture 1",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "alkane",
    "#:mixture 1"
   ],
   [
    "-is rel2",
    "in",
    "carbon",
    "#:mixture 1",
    "?:Cu17"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "hydrocarbon",
   "$some_hydrocarbon"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "hydrocarbon",
   "$some_not_hydrocarbon"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "organic compound",
   "$some_organic_compound"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "organic compound",
   "$some_not_organic_compound"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "alkane",
   "$some_alkane"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "alkane",
   "$some_not_alkane"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "element",
   "$some_element"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "element",
   "$some_not_element"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "chemical compound",
    "?:X"
   ],
   [
    "isa",
    "compound",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "chemical",
    "?:X"
   ],
   [
    "-isa",
    "compound",
    "?:X"
   ],
   [
    "isa",
    "chemical compound",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "organic compound",
    "?:X"
   ],
   [
    "isa",
    "compound",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "organic",
    "?:X"
   ],
   [
    "-isa",
    "compound",
    "?:X"
   ],
   [
    "isa",
    "organic compound",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]