[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "occur in",
    "Monkeypox virus",
    "?:X",
    "?:Cu1"
   ],
   [
    "is rel2",
    "give",
    "?:X",
    "https://en.wikipedia.org/wiki/Mpox",
    "?:Cu1"
   ]
  ],
  "@confidence": 0.2
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:Y"
   ],
   [
    "is rel2",
    "happen",
    "Monkeypox virus",
    "?:Y",
    "?:Cu2"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "human",
    "?:X"
   ],
   [
    "isa",
    "mammal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "mammal",
    "?:X"
   ],
   [
    "isa",
    "animal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-isa",
    "fever",
    "?:X"
   ],
   [
    "is rel2",
    "symptom of",
    "?:X",
    "https://en.wikipedia.org/wiki/Mpox",
    "?:Cu5"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "worry",
    "?:X"
   ],
   [
    "is rel2",
    "symptom of",
    "?:X",
    "https://en.wikipedia.org/wiki/Mpox",
    "?:Cu6"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "muscle pain",
    "?:X"
   ],
   [
    "is rel2",
    "symptom of",
    "?:X",
    "https://en.wikipedia.org/wiki/Mpox",
    "?:Cu7"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "tiredness",
    "?:X"
   ],
   [
    "is rel2",
    "symptom of",
    "?:X",
    "https://en.wikipedia.org/wiki/Mpox",
    "?:Cu8"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S9",
  "@logic": [
   [
    "-is rel2",
    "give",
    "?:X",
    "https://en.wikipedia.org/wiki/Influenza",
    "?:Cu9"
   ],
   [
    "has property",
    "tired",
    "?:X",
    "?:Cu9"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "animal",
    "sk0_animal"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S10",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_animal"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "human",
   "$some_human"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "human",
   "$some_not_human"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "mammal",
   "$some_mammal"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "mammal",
   "$some_not_mammal"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "fever",
   "$some_fever"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "fever",
   "$some_not_fever"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "worry",
   "$some_headache"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "worry",
   "$some_not_headache"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "muscle pain",
   "$some_muscle_pain"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "muscle pain",
   "$some_not_muscle_pain"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "tiredness",
   "$some_tiredness"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "tiredness",
   "$some_not_tiredness"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "tired",
   "$some_tired",
   "?:Cu26"
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "tired",
   "$some_not_tired",
   "?:Cu27"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "muscle pain",
    "?:X"
   ],
   [
    "isa",
    "pain",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "muscle",
    "?:X"
   ],
   [
    "-isa",
    "pain",
    "?:X"
   ],
   [
    "isa",
    "muscle pain",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv45"
   ],
   [
    "has type",
    "?:E",
    "give",
    "?:Fv45"
   ]
  ],
  "@confidence": 0.91
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]