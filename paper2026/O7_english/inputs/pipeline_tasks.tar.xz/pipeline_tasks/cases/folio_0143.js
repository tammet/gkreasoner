[
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "animal",
   "#:aurochs 2"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "auroch",
   "#:aurochs 2"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "auroch",
   "#:aurochs 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "breeding back",
    "?:X"
   ],
   [
    "isa",
    "artificial selection",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "breeding back",
    "?:X"
   ],
   [
    "-isa",
    "domestic animal",
    "?:Y"
   ],
   [
    "is rel2",
    "breed",
    "?:X",
    "?:Y",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "heck cattle",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "animal",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has property",
   "breed",
   "#:Heck cattle 1",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv11"
   ],
   [
    "$datetime",
    "1920s"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is_past_world",
   "W0"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "heck cattle",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "animal",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "animal",
   "https://en.wikipedia.org/wiki/Aurochs"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "resembling aurochs",
   "#:Heck cattle 1",
   "https://en.wikipedia.org/wiki/Aurochs",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "heck cattle",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "breeding back",
   "#:Heck cattle 1"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "heck cattle",
    "?:X"
   ],
   [
    "isa",
    "animal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "-isa",
    "auroch",
    "?:X"
   ],
   [
    "isa",
    "animal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "-has property",
    "breed",
    "?:X",
    "?:Cu20"
   ],
   [
    "-isa",
    "animal",
    "?:Y"
   ],
   [
    "-has property",
    "extinct",
    "?:Y",
    "?:Cu20"
   ],
   [
    "is rel2",
    "resemble",
    "?:X",
    "?:Y",
    "?:Cu20"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "heck cattle",
    "sk0_heck cattle"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "artificially selected",
    "sk0_heck cattle",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "heck cattle",
    "?:X"
   ],
   [
    "-has property",
    "artificially selected",
    "?:X",
    "?:Cu23"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S9",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "breeding back",
   "$some_not_breeding_back"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "artificial selection",
   "$some_artificial_selection"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "artificial selection",
   "$some_not_artificial_selection"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "domestic animal",
   "$some_domestic_animal"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "domestic animal",
   "$some_not_domestic_animal"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "heck cattle",
   "$some_not_Heck_cattle"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "animal",
   "$some_not_animal"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "auroch",
   "$some_aurochs"
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "auroch",
   "$some_not_aurochs"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "breed",
   "$some_not_breed",
   "?:Cu33"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "extinct",
   "$some_extinct",
   "?:Cu34"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "extinct",
   "$some_not_extinct",
   "?:Cu35"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "animal",
   "$some_extinct_animal"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "extinct",
   "$some_extinct_animal",
   "?:Cu37"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "heck cattle",
    "?:X"
   ],
   [
    "isa",
    "cattle",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "heck",
    "?:X"
   ],
   [
    "-isa",
    "cattle",
    "?:X"
   ],
   [
    "isa",
    "heck cattle",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "artificial selection",
    "?:X"
   ],
   [
    "isa",
    "selection",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "bogus",
    "?:X"
   ],
   [
    "-isa",
    "selection",
    "?:X"
   ],
   [
    "isa",
    "artificial selection",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "breeding back",
    "?:X"
   ],
   [
    "isa",
    "back",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "breeding",
    "?:X"
   ],
   [
    "-isa",
    "back",
    "?:X"
   ],
   [
    "isa",
    "breeding back",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "domestic animal",
    "?:X"
   ],
   [
    "isa",
    "animal",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "domestic",
    "?:X"
   ],
   [
    "-isa",
    "animal",
    "?:X"
   ],
   [
    "isa",
    "domestic animal",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "heck cattle",
    "?:X"
   ],
   [
    "isa",
    "cattle",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "heck",
    "?:X"
   ],
   [
    "-isa",
    "cattle",
    "?:X"
   ],
   [
    "isa",
    "heck cattle",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]