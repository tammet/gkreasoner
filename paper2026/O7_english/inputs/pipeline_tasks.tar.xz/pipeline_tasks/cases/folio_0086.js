[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "organization",
   "#:Yelp 1"
  ]
 },
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "number",
   "four"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "organization",
   "#:Hamden Plaza Subway store 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "hamden plaza subway store",
   "#:Hamden Plaza Subway store 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "-isa",
    "recommendation",
    "?:Y"
   ],
   [
    "-have",
    "#:Yelp 1",
    "?:Y",
    "?:Cu5"
   ],
   [
    "-is rel2",
    "listed in",
    "?:X",
    "?:Y",
    "?:Cu5"
   ],
   [
    "-isa",
    "negative review",
    "?:Z"
   ],
   [
    "-is rel2",
    "give",
    "?:X",
    "?:Z",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "-isa",
    "rating",
    "?:V"
   ],
   [
    "-have",
    "?:X",
    "?:V",
    "?:Cu6"
   ],
   [
    "->",
    "?:V",
    4
   ],
   [
    "isa",
    "recommendation",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "-isa",
    "rating",
    "?:V"
   ],
   [
    "-have",
    "?:X",
    "?:V",
    "?:Cu7"
   ],
   [
    "->",
    "?:V",
    4
   ],
   [
    "have",
    "#:Yelp 1",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "-isa",
    "rating",
    "?:V"
   ],
   [
    "-have",
    "?:X",
    "?:V",
    "?:Cu8"
   ],
   [
    "->",
    "?:V",
    4
   ],
   [
    "is rel2",
    "listed in",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu8"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "restaurant",
   "sk1_restaurant"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "take-out service",
    "?:Y"
   ],
   [
    "-is rel2",
    "provide",
    "sk1_restaurant",
    "?:Y",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "negative review",
   "sk2_negative review"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "is rel2",
   "give",
   "sk1_restaurant",
   "sk2_negative review",
   "?:Cu12"
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "isa",
    "local resident",
    [
     "sk3",
     "?:X"
    ]
   ],
   [
    "isa",
    "rating",
    [
     "sk4",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "isa",
    "local resident",
    [
     "sk3",
     "?:X"
    ]
   ],
   [
    "have",
    "?:X",
    [
     "sk4",
     "?:X"
    ],
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "isa",
    "local resident",
    [
     "sk3",
     "?:X"
    ]
   ],
   [
    ">",
    [
     "sk4",
     "?:X"
    ],
    4
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "-is rel2",
    "popular",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu16"
   ],
   [
    "isa",
    "rating",
    [
     "sk4",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "-is rel2",
    "popular",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu17"
   ],
   [
    "have",
    "?:X",
    [
     "sk4",
     "?:X"
    ],
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "restaurant",
    "?:X"
   ],
   [
    "-is rel2",
    "popular",
    "?:X",
    [
     "sk3",
     "?:X"
    ],
    "?:Cu18"
   ],
   [
    ">",
    [
     "sk4",
     "?:X"
    ],
    4
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "restaurant",
   "https://en.wikipedia.org/wiki/Subway_(restaurant)"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "isa",
    "rating",
    "sk5_rating"
   ],
   [
    "isa",
    "local resident",
    "sk6_local resident"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "isa",
    "rating",
    "sk5_rating"
   ],
   [
    "is rel2",
    "popular",
    "https://en.wikipedia.org/wiki/Subway_(restaurant)",
    "sk6_local resident",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "have",
    "https://en.wikipedia.org/wiki/Subway_(restaurant)",
    "sk5_rating",
    "?:Cu22"
   ],
   [
    "isa",
    "local resident",
    "sk6_local resident"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "have",
    "https://en.wikipedia.org/wiki/Subway_(restaurant)",
    "sk5_rating",
    "?:Cu23"
   ],
   [
    "is rel2",
    "popular",
    "https://en.wikipedia.org/wiki/Subway_(restaurant)",
    "sk6_local resident",
    "?:Cu23"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    ">",
    "sk5_rating",
    4
   ],
   [
    "isa",
    "local resident",
    "sk6_local resident"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    ">",
    "sk5_rating",
    4
   ],
   [
    "is rel2",
    "popular",
    "https://en.wikipedia.org/wiki/Subway_(restaurant)",
    "sk6_local resident",
    "?:Cu25"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "-isa",
    "take-out service",
    "?:Y"
   ],
   [
    "-is rel2",
    "provide",
    "https://en.wikipedia.org/wiki/Subway_(restaurant)",
    "?:Y",
    "?:Cu26"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "isa",
    "take-out service",
    "sk7_take-out service"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "is rel2",
    "provide",
    "https://en.wikipedia.org/wiki/Subway_(restaurant)",
    "sk7_take-out service",
    "?:Cu28"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "restaurant",
   "$some_not_restaurant"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "recommendation",
   "$some_recommendation"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "recommendation",
   "$some_not_recommendation"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "negative review",
   "$some_negative_review"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "negative review",
   "$some_not_negative_review"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "rating",
   "$some_rating"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "rating",
   "$some_not_rating"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "take-out service",
   "$some_take-out_service"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "take-out service",
   "$some_not_take-out_service"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "local resident",
   "$some_local_resident"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "local resident",
   "$some_not_local_resident"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "hamden plaza subway store",
    "?:X"
   ],
   [
    "isa",
    "store",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "hamden plaza subway",
    "?:X"
   ],
   [
    "-isa",
    "store",
    "?:X"
   ],
   [
    "isa",
    "hamden plaza subway store",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "local resident",
    "?:X"
   ],
   [
    "isa",
    "resident",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "local",
    "?:X"
   ],
   [
    "-isa",
    "resident",
    "?:X"
   ],
   [
    "isa",
    "local resident",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "negative review",
    "?:X"
   ],
   [
    "isa",
    "review",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "negative",
    "?:X"
   ],
   [
    "-isa",
    "review",
    "?:X"
   ],
   [
    "isa",
    "negative review",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "take-out service",
    "?:X"
   ],
   [
    "isa",
    "service",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "take-out",
    "?:X"
   ],
   [
    "-isa",
    "service",
    "?:X"
   ],
   [
    "isa",
    "take-out service",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "pass",
    "?:Fv27"
   ],
   [
    "has type",
    "?:E",
    "give",
    "?:Fv27"
   ]
  ],
  "@confidence": 0.91
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "provide",
    "?:Fv28"
   ],
   [
    "has type",
    "?:E",
    "give",
    "?:Fv28"
   ]
  ],
  "@confidence": 0.84
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]