[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Eve 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Tom 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "report",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "#:Eve 1"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:Eve 1",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "#:Eve 1"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "#:Eve 1"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has content",
   "sk0_activity",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk1_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk1_activity",
   "arrive",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "#:Eve 1"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk1_activity",
   "#:Tom 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "#:Eve 1"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk1_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv1",
    "#:Eve 1"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "speech_act",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "kb force",
   "K_S1",
   "non_factive"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "kb holds",
   "K_S1",
   [
    "exists",
    [
     "E2"
    ],
    [
     "and",
     [
      "isa",
      "activity",
      "E2"
     ],
     [
      "has type",
      "E2",
      "arrive"
     ],
     [
      "has actor",
      "E2",
      "#:Tom 2"
     ],
     [
      "has time",
      "E2",
      "past",
      "in"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:Tom 2"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "activity",
   "sk2_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has type",
   "sk2_activity",
   "arrive",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv2",
    "?:Fv3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has actor",
   "sk2_activity",
   "#:Tom 2",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv2",
    "?:Fv3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "has time",
   "sk2_activity",
   "past",
   "in",
   [
    "$ctxt",
    "past",
    "W0",
    "?:Fv2",
    "?:Fv3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "actuality",
   "sk2_activity"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk3_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk3_activity",
    "depart",
    [
     "$ctxt",
     "past",
     "?:Fv9",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk3_activity",
    "#:Tom 2",
    [
     "$ctxt",
     "past",
     "?:Fv11",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has time",
    "sk3_activity",
    "past",
    "in",
    [
     "$ctxt",
     "past",
     "?:Fv13",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "actuality",
    "sk3_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "depart",
    [
     "$ctxt",
     "past",
     "?:Fv17",
     "?:Fv4",
     "?:Fv5"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:Tom 2",
    [
     "$ctxt",
     "past",
     "?:Fv19",
     "?:Fv4",
     "?:Fv5"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "report",
    "?:Fv23"
   ],
   [
    "has type",
    "?:E",
    "announce",
    "?:Fv23"
   ]
  ],
  "@confidence": 0.71
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "announce",
    "?:Fv24"
   ],
   [
    "has type",
    "?:E",
    "report",
    "?:Fv24"
   ]
  ],
  "@confidence": 0.71
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]
