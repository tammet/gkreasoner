[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "train",
   "#:train 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "leave",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:train 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has time",
   "sk0_activity",
   "noon",
   "at",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "actuality",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv3"
   ],
   [
    "$datetime",
    "noon"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "has type",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ],
    "leave",
    [
     "$ctxt",
     "?:Fv11",
     "?:Fv10",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "has actor",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ],
    "#:train 1",
    [
     "$ctxt",
     "?:Fv13",
     "?:Fv12",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "has time",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ],
    "?:X",
    "?:_Prep",
    [
     "$ctxt",
     "?:Fv15",
     "?:Fv14",
     "?:Fv4",
     "?:Fv5"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "actuality",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "leave",
    [
     "$ctxt",
     "?:Fv19",
     "?:Fv18",
     "?:Fv4",
     "?:Fv5"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:train 1",
    [
     "$ctxt",
     "?:Fv21",
     "?:Fv20",
     "?:Fv4",
     "?:Fv5"
    ]
   ],
   [
    "-has time",
    "?:E",
    "?:X",
    "?:_Prep",
    [
     "$ctxt",
     "?:Fv23",
     "?:Fv22",
     "?:Fv4",
     "?:Fv5"
    ]
   ],
   [
    "-actuality",
    "?:E"
   ],
   [
    "$defq0",
    "?:_Prep",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0",
   "?:Rel",
   "?:X"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 }
]