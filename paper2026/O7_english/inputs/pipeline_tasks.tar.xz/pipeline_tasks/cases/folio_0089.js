[
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "man",
   "#:Harry 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "man",
   "#:Henry Thoreau 3"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "henry thoreau",
   "#:Henry Thoreau 3"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "book",
    "?:X"
   ],
   [
    "have",
    "?:X",
    "knowledge",
    "?:Cu4"
   ]
  ],
  "@confidence": 0.98
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "book",
    "?:Y"
   ],
   [
    "is rel2",
    "read",
    "?:X",
    "?:Y",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "book",
    "?:Y"
   ],
   [
    "is rel2",
    "gain",
    "?:X",
    "knowledge",
    "?:Cu6"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "gain",
    "?:X",
    "knowledge",
    "?:Cu7"
   ],
   [
    "has property",
    "smart",
    "?:X",
    "?:Cu7"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "person",
   "#:Harry 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "book",
   "#:Walden 2"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "read",
   "#:Harry 1",
   "#:Walden 2",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "book",
   "#:Walden 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "person",
   "#:Henry Thoreau 3"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "by",
   "#:Walden 2",
   "#:Henry Thoreau 3",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "smart",
    "#:Harry 1",
    "#:Harry 1",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "smart",
    "#:Harry 1",
    "#:Harry 1",
    "?:Cu16"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "book",
   "$some_not_book"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "smart",
   "$some_smart",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "smart",
   "$some_not_smart",
   "?:Cu21"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "henry thoreau",
    "?:X"
   ],
   [
    "isa",
    "thoreau",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "henry",
    "?:X"
   ],
   [
    "-isa",
    "thoreau",
    "?:X"
   ],
   [
    "isa",
    "henry thoreau",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_reflexive_prop",
  "@logic": [
   [
    "-has property",
    "smart",
    "?:X",
    "?:C"
   ],
   [
    "is rel2",
    "smart",
    "?:X",
    "?:X",
    "?:C"
   ]
  ]
 },
 {
  "@name": "frm_reflexive_prop",
  "@logic": [
   [
    "-is rel2",
    "smart",
    "?:X",
    "?:X",
    "?:C"
   ],
   [
    "has property",
    "smart",
    "?:X",
    "?:C"
   ]
  ]
 },
 {
  "@name": "frm_world_geom",
  "@sourcetype": "world_geometry",
  "@logic": [
   "next",
   "W0",
   "W1"
  ]
 }
]