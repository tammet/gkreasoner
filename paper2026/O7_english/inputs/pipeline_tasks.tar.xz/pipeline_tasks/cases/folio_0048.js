[
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "abstract",
   "#:Fall 3"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "number",
   "4"
  ]
 },
 {
  "@name": "entity_S7",
  "@logic": [
   "isa",
   "woman",
   "#:Emma 5"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "woman",
   "#:Mia 7"
  ]
 },
 {
  "@name": "entity_S11",
  "@logic": [
   "isa",
   "man",
   "#:James 9"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "season",
   "#:Spring 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "season",
   "#:Summer 2"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "season",
   "https://en.wikipedia.org/wiki/Autumn"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "season",
   "#:Winter 4"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "=",
   4,
   [
    "$count",
    [
     "$setof",
     "id",
     "set_24989389",
     [
      "$and",
      [
       "isa",
       "season",
       "$arg1"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5_el1",
  "@logic": [
   "isa",
   "season",
   "$set1_el1"
  ]
 },
 {
  "@name": "sent_S5_el1",
  "@logic": [
   "member",
   "$set1_el1",
   [
    "$setof",
    "id",
    "set_24989389",
    [
     "$and",
     [
      "isa",
      "season",
      "$arg1"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5_el2",
  "@logic": [
   "isa",
   "season",
   "$set1_el2"
  ]
 },
 {
  "@name": "sent_S5_el2",
  "@logic": [
   "member",
   "$set1_el2",
   [
    "$setof",
    "id",
    "set_24989389",
    [
     "$and",
     [
      "isa",
      "season",
      "$arg1"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5_el3",
  "@logic": [
   "isa",
   "season",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S5_el3",
  "@logic": [
   "member",
   "$set1_el3",
   [
    "$setof",
    "id",
    "set_24989389",
    [
     "$and",
     [
      "isa",
      "season",
      "$arg1"
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S5_dist",
  "@logic": [
   "-=",
   "$set1_el1",
   "$set1_el2"
  ]
 },
 {
  "@name": "sent_S5_dist",
  "@logic": [
   "-=",
   "$set1_el1",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S5_dist",
  "@logic": [
   "-=",
   "$set1_el2",
   "$set1_el3"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-is rel2",
    "want",
    "?:X",
    "have",
    "?:Cu20"
   ],
   [
    "is rel2",
    "favorite season of",
    "#:Summer 2",
    "?:X",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "isa",
   "person",
   "#:Emma 5"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "person",
   "#:Emma 5"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "favorite season of",
   "#:Summer 2",
   "#:Emma 5",
   "?:Cu23"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "person",
   "#:Mia 7"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "person",
   "#:Emma 5"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "-=",
   "#:favorite season 8",
   "#:Summer 2"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "person",
   "#:Mia 7"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "is rel2",
   "favorite season of",
   "#:favorite season 8",
   "#:Mia 7",
   "?:Cu28"
  ]
 },
 {
  "@name": "sent_S11",
  "@logic": [
   "isa",
   "student",
   "#:James 9"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "isa",
   "person",
   "#:James 9"
  ]
 },
 {
  "@name": "sent_S12",
  "@logic": [
   "is rel2",
   "want",
   "#:James 9",
   "have",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "=",
    "#:favorite season 8",
    "#:Spring 1"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@sourcetype": "question",
  "@logic": [
   [
    "-=",
    "#:favorite season 8",
    "#:Spring 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S13",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-isa",
    "?:c",
    "?:M"
   ],
   [
    "member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:c",
       "$arg1"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "frm_set",
  "@logic": [
   [
    "-member",
    "?:M",
    [
     "$setof",
     "id",
     "?:S",
     [
      "$and",
      [
       "isa",
       "?:c",
       "$arg1"
      ]
     ]
    ]
   ],
   [
    "isa",
    "?:c",
    "?:M"
   ]
  ]
 },
 {
  "@name": "frm_syn",
  "@logic": [
   [
    "-has type",
    "?:E",
    "receive",
    "?:Fv31"
   ],
   [
    "has type",
    "?:E",
    "have",
    "?:Fv31"
   ]
  ],
  "@confidence": 0.89
 },
 {
  "@name": "frm_excl",
  "@logic": [
   [
    "-has property",
    "man",
    "?:X",
    "?:Fv32"
   ],
   [
    "-has property",
    "woman",
    "?:X",
    "?:Fv32"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]