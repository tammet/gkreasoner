[
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "place",
   "#:Mars 1"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "place",
   "#:Earth 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "alien",
    "?:X"
   ],
   [
    "isa",
    "extraterrestrial",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-is rel2",
    "from",
    "?:X",
    "#:Mars 1",
    "?:Cu4"
   ],
   [
    "isa",
    "alien",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "extraterrestrial",
    "?:X"
   ],
   [
    "-isa",
    "human",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-has property",
    "smart",
    "?:X",
    "?:Cu6"
   ],
   [
    "-is rel2",
    "from",
    "?:X",
    "#:Earth 1",
    "?:Cu6"
   ],
   [
    "isa",
    "human",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "being",
   "#:Marvin 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "has property",
   "smart",
   "#:Marvin 1",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "from",
    "#:Marvin 1",
    "#:Earth 1",
    "?:Cu10"
   ],
   [
    "-is rel2",
    "from",
    "#:Marvin 1",
    "#:Mars 1",
    "?:Cu10"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "is rel2",
    "from",
    "#:Marvin 1",
    "#:Mars 1",
    "?:Cu11"
   ],
   [
    "-is rel2",
    "from",
    "#:Marvin 1",
    "#:Earth 1",
    "?:Cu11"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   [
    "is rel2",
    "from",
    "#:Marvin 1",
    "#:Earth 1",
    "?:Cu14"
   ],
   [
    "isa",
    "extraterrestrial",
    "#:Marvin 1"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "alien",
    "#:Marvin 1"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "alien",
    "#:Marvin 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "alien",
   "$some_alien"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "alien",
   "$some_not_alien"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "extraterrestrial",
   "$some_not_extraterrestrial"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "human",
   "$some_human"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "human",
   "$some_not_human"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "smart",
   "$some_not_intelligent",
   "?:Cu22"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]