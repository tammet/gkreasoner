[
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "abstract",
   "#:Bile duct cancer 1"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "bile duct cancer",
   "#:Bile duct cancer 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "mild flu",
   "#:Mild flu 1"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "colorectal cancer",
   "#:Colorectal cancer 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "isa",
    "survival rate",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "-has property",
    "high",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "is rel2",
    "comes with",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu7"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "cancer",
    "?:X"
   ],
   [
    "-has property",
    "deep",
    "?:X",
    "?:Cu8"
   ],
   [
    "isa",
    "deadly disease",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "cancer",
   "Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "has property",
   "deep",
   "Cholangiocarcinoma",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   "isa",
   "bile duct cancer",
   "Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   [
    "-isa",
    "cholangiocarcinoma",
    "?:X"
   ],
   [
    "isa",
    "bile duct cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "flu",
   "#:Mild flu 1"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "has property",
   "mild",
   "#:Mild flu 1",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "survival rate",
   "sk1_survival rate"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "-has property",
   "high",
   "sk1_survival rate",
   "?:Cu16"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "comes with",
   "#:Mild flu 1",
   "sk1_survival rate",
   "?:Cu17"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "cancer",
   "#:Colorectal cancer 2"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "bile duct cancer",
    "#:Colorectal cancer 2"
   ],
   [
    "-isa",
    "survival rate",
    "?:Y"
   ],
   [
    "has property",
    "high",
    "?:Y",
    "?:Cu19"
   ],
   [
    "-is rel2",
    "comes with",
    "#:Colorectal cancer 2",
    "?:Y",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "cholangiocarcinoma",
    "#:Colorectal cancer 2"
   ],
   [
    "isa",
    "flu",
    "#:Colorectal cancer 2"
   ],
   [
    "isa",
    "bile duct cancer",
    "#:Colorectal cancer 2"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "cholangiocarcinoma",
    "#:Colorectal cancer 2"
   ],
   [
    "isa",
    "flu",
    "#:Colorectal cancer 2"
   ],
   [
    "isa",
    "bile duct cancer",
    "#:Colorectal cancer 2"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "cholangiocarcinoma",
    "#:Colorectal cancer 2"
   ],
   [
    "isa",
    "flu",
    "#:Colorectal cancer 2"
   ],
   [
    "isa",
    "bile duct cancer",
    "#:Colorectal cancer 2"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "cholangiocarcinoma",
    "#:Colorectal cancer 2"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "flu",
    "#:Colorectal cancer 2"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "bile duct cancer",
    "#:Colorectal cancer 2"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "cholangiocarcinoma",
    "#:Colorectal cancer 2"
   ],
   [
    "-isa",
    "flu",
    "#:Colorectal cancer 2"
   ],
   [
    "-isa",
    "bile duct cancer",
    "#:Colorectal cancer 2"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "deadly disease",
   "$some_deadly_disease"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "deadly disease",
   "$some_not_deadly_disease"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "survival rate",
   "$some_survival_rate"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "survival rate",
   "$some_not_survival_rate"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "cancer",
   "$some_not_cancer"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "cholangiocarcinoma",
   "$some_Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "cholangiocarcinoma",
   "$some_not_Cholangiocarcinoma"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "high",
   "$some_low",
   "?:Cu34"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "high",
   "$some_not_low",
   "?:Cu35"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "deep",
   "$some_not_severe",
   "?:Cu36"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "bile duct cancer",
    "?:X"
   ],
   [
    "isa",
    "cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "bile duct",
    "?:X"
   ],
   [
    "-isa",
    "cancer",
    "?:X"
   ],
   [
    "isa",
    "bile duct cancer",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "colorectal cancer",
    "?:X"
   ],
   [
    "isa",
    "cancer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "colorectal",
    "?:X"
   ],
   [
    "-isa",
    "cancer",
    "?:X"
   ],
   [
    "isa",
    "colorectal cancer",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "deadly disease",
    "?:X"
   ],
   [
    "isa",
    "disease",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "deadly",
    "?:X"
   ],
   [
    "-isa",
    "disease",
    "?:X"
   ],
   [
    "isa",
    "deadly disease",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "mild flu",
    "?:X"
   ],
   [
    "isa",
    "flu",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "mild",
    "?:X"
   ],
   [
    "-isa",
    "flu",
    "?:X"
   ],
   [
    "isa",
    "mild flu",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "survival rate",
    "?:X"
   ],
   [
    "isa",
    "rate",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "survival",
    "?:X"
   ],
   [
    "-isa",
    "rate",
    "?:X"
   ],
   [
    "isa",
    "survival rate",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]