[
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "person",
   "#:Dani Shapiro 1"
  ]
 },
 {
  "@name": "entity_S4",
  "@logic": [
   "isa",
   "dani shapiro",
   "#:Dani Shapiro 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "family history",
   "#:Family History 2"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "abstract",
   "#:Family Secrets 4"
  ]
 },
 {
  "@name": "entity_S9",
  "@logic": [
   "isa",
   "family secret",
   "#:Family Secrets 4"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "podcast",
    "?:X"
   ],
   [
    "-isa",
    "new",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "born in",
    "?:X",
    "?:Y",
    "?:Cu7"
   ],
   [
    "has property",
    "American",
    "?:X",
    "?:Cu7"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "written by",
    "?:X",
    "?:Y",
    "?:Cu8"
   ],
   [
    "isa",
    "novel writer",
    "?:Y"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "writer",
   "#:Dani Shapiro 1"
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "American",
   "#:Dani Shapiro 1",
   "?:Cu10"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "isa",
   "artifact",
   "#:Family History 2"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   "is rel2",
   "write",
   "#:Dani Shapiro 1",
   "#:Family History 2",
   "?:Cu12"
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "new",
   "#:Family History 2"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "has property",
   "write",
   "#:Family History 2",
   "?:Cu14"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "=",
   [
    "$theof1",
    "time",
    "W0",
    "?:Fv21"
   ],
   [
    "$datetime",
    2003
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "is_past_world",
   "W0"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "isa",
   "podcast",
   "#:podcast 3"
  ]
 },
 {
  "@name": "sent_S8",
  "@logic": [
   "is rel2",
   "create",
   "#:Dani Shapiro 1",
   "#:podcast 3",
   "?:Cu18"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "isa",
   "podcast",
   "#:podcast 3"
  ]
 },
 {
  "@name": "sent_S9",
  "@logic": [
   "is rel2",
   "called",
   "#:podcast 3",
   "#:Family Secrets 4",
   "?:Cu20"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "isa",
   "american city",
   "#:Boston 5"
  ]
 },
 {
  "@name": "sent_S10",
  "@logic": [
   "has property",
   "American",
   "#:Boston 5",
   "?:Cu22"
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "novel writer",
    "#:Dani Shapiro 1"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "novel writer",
    "#:Dani Shapiro 1"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S11",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "podcast",
   "$some_not_podcast"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "new",
   "$some_not_novel"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "novel writer",
   "$some_novel_writer"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "novel writer",
   "$some_not_novel_writer"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "American",
   "$some_not_American",
   "?:Cu31"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "american city",
    "?:X"
   ],
   [
    "isa",
    "city",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "american",
    "?:X"
   ],
   [
    "-isa",
    "city",
    "?:X"
   ],
   [
    "isa",
    "american city",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "dani shapiro",
    "?:X"
   ],
   [
    "isa",
    "shapiro",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "dani",
    "?:X"
   ],
   [
    "-isa",
    "shapiro",
    "?:X"
   ],
   [
    "isa",
    "dani shapiro",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "family history",
    "?:X"
   ],
   [
    "isa",
    "history",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "family",
    "?:X"
   ],
   [
    "-isa",
    "history",
    "?:X"
   ],
   [
    "isa",
    "family history",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "family secret",
    "?:X"
   ],
   [
    "isa",
    "secret",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "family",
    "?:X"
   ],
   [
    "-isa",
    "secret",
    "?:X"
   ],
   [
    "isa",
    "family secret",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "novel writer",
    "?:X"
   ],
   [
    "isa",
    "writer",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "new",
    "?:X"
   ],
   [
    "-isa",
    "writer",
    "?:X"
   ],
   [
    "isa",
    "novel writer",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]