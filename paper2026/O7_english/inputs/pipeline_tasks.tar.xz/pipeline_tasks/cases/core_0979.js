[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "hospital",
   "#:hospital 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "activity",
   "sk0_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has type",
   "sk0_activity",
   "work",
   [
    "$ctxt",
    "?:Fv4",
    "?:Fv3",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has actor",
   "sk0_activity",
   "#:John 1",
   [
    "$ctxt",
    "?:Fv4",
    "?:Fv3",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has location",
   "sk0_activity",
   "#:hospital 2",
   "at",
   [
    "$ctxt",
    "?:Fv4",
    "?:Fv3",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "typical",
    "sk0_activity",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "$block",
    [
     "$",
     "$generic",
     1
    ],
    [
     "$not",
     [
      "typical",
      "sk0_activity",
      [
       "$ctxt",
       "?:Fv4",
       "?:Fv3",
       "?:Fv1",
       "?:Fv2"
      ]
     ]
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "isa",
    "activity",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "has type",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ],
    "work",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "has actor",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ],
    "#:John 1",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "has location",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ],
    "?:X",
    "?:_Prep",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0",
    "?:_Prep",
    "?:X"
   ],
   [
    "typical",
    [
     "sk1",
     "?:X",
     "?:_Prep"
    ],
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "work",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:John 1",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-has location",
    "?:E",
    "?:X",
    "?:_Prep",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "-typical",
    "?:E",
    [
     "$ctxt",
     "?:Fv8",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0",
    "?:_Prep",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0",
   "?:Rel",
   "?:X"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "pop_what",
  "@logic": [
   "isa",
   "hospital",
   "$some_hospital"
  ]
 }
]