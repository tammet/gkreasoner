[
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "measure",
   "8 pm"
  ]
 },
 {
  "@name": "entity_S1",
  "@logic": [
   "isa",
   "abstract",
   "Monday"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "event",
   "#:The Bachelor 1"
  ]
 },
 {
  "@name": "entity_S3",
  "@logic": [
   "isa",
   "the bachelor",
   "#:The Bachelor 1"
  ]
 },
 {
  "@name": "entity_S6",
  "@logic": [
   "isa",
   "breaking bad",
   "#:Breaking Bad 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "show",
   "#:show 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "airs at",
   "#:show 1",
   "8 pm",
   "?:Cu7"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "is rel2",
   "airs on",
   "#:show 1",
   "Monday",
   "?:Cu8"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "show",
   "#:show 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "artifact",
   "TV"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "is rel2",
   "give out",
   "#:show 1",
   "rose",
   "?:Cu11"
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "give out",
    "?:X",
    "rose",
    "?:Cu12"
   ],
   [
    "isa",
    "episode",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "give out",
    "?:X",
    "rose",
    "?:Cu13"
   ],
   [
    "is rel2",
    "episode of",
    [
     "sk0",
     "?:X"
    ],
    "#:The Bachelor 1",
    "?:Cu13"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "give out",
    "?:X",
    "rose",
    "?:Cu14"
   ],
   [
    "=",
    "?:X",
    [
     "sk0",
     "?:X"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "is rel2",
   "portray",
   "#:The Bachelor 1",
   "person",
   "?:Cu15"
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-is rel2",
    "portray",
    "?:X",
    "person",
    "?:Cu16"
   ],
   [
    "isa",
    "reality tv show",
    "?:X"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   "isa",
   "show",
   "#:Breaking Bad 1"
  ]
 },
 {
  "@name": "sent_S7",
  "@logic": [
   "-isa",
   "reality tv show",
   "#:Breaking Bad 1"
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "airs on",
    "#:Breaking Bad 1",
    "Monday",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "is rel2",
    "airs at",
    "#:Breaking Bad 1",
    "8 pm",
    "?:Cu20"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@sourcetype": "question",
  "@logic": [
   [
    "-is rel2",
    "airs on",
    "#:Breaking Bad 1",
    "Monday",
    "?:Cu21"
   ],
   [
    "-is rel2",
    "airs at",
    "#:Breaking Bad 1",
    "8 pm",
    "?:Cu21"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-is rel2",
    "give out",
    "?:X",
    "rose",
    "?:Cu22"
   ],
   [
    "have",
    "#:The Bachelor 1",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S8",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "episode",
   "$some_episode"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "episode",
   "$some_not_episode"
  ]
 },
 {
  "@name": "sent_S5",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "reality tv show",
   "$some_reality_TV_show"
  ]
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "breaking bad",
    "?:X"
   ],
   [
    "isa",
    "bad",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "breaking",
    "?:X"
   ],
   [
    "-isa",
    "bad",
    "?:X"
   ],
   [
    "isa",
    "breaking bad",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "reality tv show",
    "?:X"
   ],
   [
    "isa",
    "show",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "reality tv",
    "?:X"
   ],
   [
    "-isa",
    "show",
    "?:X"
   ],
   [
    "isa",
    "reality tv show",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "compound_sub",
  "@logic": [
   [
    "-isa",
    "the bachelor",
    "?:X"
   ],
   [
    "isa",
    "bachelor",
    "?:X"
   ]
  ]
 },
 {
  "@name": "compound_comp",
  "@logic": [
   [
    "-isa",
    "the",
    "?:X"
   ],
   [
    "-isa",
    "bachelor",
    "?:X"
   ],
   [
    "isa",
    "the bachelor",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "artifact",
    "?:X"
   ],
   [
    "-isa",
    "event",
    "?:X"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_excl_isa",
  "@logic": [
   [
    "-isa",
    "artifact",
    "?:X"
   ],
   [
    "-isa",
    "event",
    "?:Y"
   ],
   [
    "-=",
    "?:X",
    "?:Y"
   ]
  ],
  "@confidence": 0.95
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_gender",
  "@logic": [
   [
    "-isa",
    "bachelor",
    "?:Xg"
   ],
   [
    "isa",
    "man",
    "?:Xg"
   ]
  ]
 }
]