[
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:Bill 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "=",
   [
    "$measure_of",
    "height",
    "#:John 1",
    "W0"
   ],
   [
    "$measure_of",
    "height",
    "#:Bill 2",
    "W0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "=",
    [
     "$measure_of",
     "height",
     "#:John 1",
     "W0"
    ],
    [
     "$measure_of",
     "height",
     "#:Bill 2",
     "W0"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "question",
  "@logic": [
   [
    "-=",
    [
     "$measure_of",
     "height",
     "#:John 1",
     "W0"
    ],
    [
     "$measure_of",
     "height",
     "#:Bill 2",
     "W0"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "have",
   "?:S",
   [
    "$measure_of",
    "height",
    "?:S",
    "?:W"
   ],
   [
    "$ctxt",
    "?:T",
    "?:W",
    "?:L",
    "?:K"
   ]
  ]
 },
 {
  "@name": "frm_measure",
  "@logic": [
   "isa",
   "height",
   [
    "$measure_of",
    "height",
    "?:S",
    "?:W"
   ]
  ]
 }
]