[
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "entity_S5",
  "@logic": [
   "isa",
   "man",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-is rel2",
    "make",
    "?:X",
    "wedding plan",
    "?:Cu3"
   ],
   [
    "has property",
    "busy",
    "?:X",
    "?:Cu3"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "isa",
    "person",
    [
     "sk0",
     "?:X"
    ]
   ],
   [
    "is rel2",
    "make",
    "?:X",
    "wedding plan",
    "?:Cu4"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-is rel2",
    "invite",
    "?:X",
    [
     "sk0",
     "?:X"
    ],
    "?:Cu5"
   ],
   [
    "is rel2",
    "make",
    "?:X",
    "wedding plan",
    "?:Cu5"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@logic": [
   [
    "-isa",
    "person",
    "?:X"
   ],
   [
    "-isa",
    "wedding",
    "?:V"
   ],
   [
    "-has property",
    "well-attended",
    "?:V",
    "?:Cu6"
   ],
   [
    "-have",
    "?:X",
    "?:V",
    "?:Cu6"
   ],
   [
    "-isa",
    "person",
    "?:Y"
   ],
   [
    "is rel2",
    "invite",
    "?:X",
    "?:Y",
    "?:Cu6"
   ]
  ]
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "person",
   "sk1_person"
  ],
  "@confidence": 0.9971
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "wedding",
   "sk2_wedding"
  ],
  "@confidence": 0.9971
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "well-attended",
   "sk2_wedding",
   "?:Cu9"
  ],
  "@confidence": 0.9971
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "sk1_person",
   "sk2_wedding",
   "?:Cu10"
  ],
  "@confidence": 0.9971
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "isa",
   "family",
   "sk3_family"
  ],
  "@confidence": 0.9971
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "has property",
   "large",
   "sk3_family",
   "?:Cu12"
  ],
  "@confidence": 0.9971
 },
 {
  "@name": "sent_S4",
  "@logic": [
   "have",
   "sk1_person",
   "sk3_family",
   "?:Cu13"
  ],
  "@confidence": 0.9971
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-has property",
    "busy",
    "#:John 1",
    "?:Cu14"
   ],
   [
    "-is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu14"
   ]
  ]
 },
 {
  "@name": "sent_S5",
  "@logic": [
   [
    "-has property",
    "busy",
    "#:John 1",
    "?:Cu15"
   ],
   [
    "-is rel2",
    "make",
    "#:John 1",
    "wedding plan",
    "?:Cu15"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-has property",
    "large",
    "?:F",
    "?:Cu16"
   ],
   [
    "-have",
    "#:John 1",
    "?:F",
    "?:Cu16"
   ],
   [
    "isa",
    "wedding",
    "sk4_wedding"
   ],
   [
    "is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu16"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-has property",
    "large",
    "?:F",
    "?:Cu17"
   ],
   [
    "-have",
    "#:John 1",
    "?:F",
    "?:Cu17"
   ],
   [
    "has property",
    "well-attended",
    "sk4_wedding",
    "?:Cu17"
   ],
   [
    "is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu17"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-has property",
    "large",
    "?:F",
    "?:Cu18"
   ],
   [
    "-have",
    "#:John 1",
    "?:F",
    "?:Cu18"
   ],
   [
    "have",
    "#:John 1",
    "sk4_wedding",
    "?:Cu18"
   ],
   [
    "is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu18"
   ]
  ]
 },
 {
  "@name": "sent_S6",
  "@logic": [
   [
    "-isa",
    "family",
    "?:F"
   ],
   [
    "-has property",
    "large",
    "?:F",
    "?:Cu19"
   ],
   [
    "-have",
    "#:John 1",
    "?:F",
    "?:Cu19"
   ],
   [
    "-isa",
    "wedding",
    "?:V"
   ],
   [
    "-has property",
    "well-attended",
    "?:V",
    "?:Cu19"
   ],
   [
    "-have",
    "#:John 1",
    "?:V",
    "?:Cu19"
   ],
   [
    "-is rel2",
    "invite",
    "#:John 1",
    "person",
    "?:Cu19"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "family",
    "sk5_family"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "large",
    "sk5_family",
    "?:Cu21"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "have",
    "#:John 1",
    "sk5_family",
    "?:Cu22"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "family",
    "?:X"
   ],
   [
    "-has property",
    "large",
    "?:X",
    "?:Cu23"
   ],
   [
    "-have",
    "#:John 1",
    "?:X",
    "?:Cu23"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S7",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "person",
   "$some_person"
  ]
 },
 {
  "@name": "sent_S2",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "person",
   "$some_not_person"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "wedding",
   "$some_wedding"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "wedding",
   "$some_not_wedding"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "family",
   "$some_family"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "family",
   "$some_not_family"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "busy",
   "$some_not_engaged",
   "?:Cu31"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "well-attended",
   "$some_well-attended",
   "?:Cu32"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "well-attended",
   "$some_not_well-attended",
   "?:Cu33"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "has property",
   "large",
   "$some_large",
   "?:Cu34"
  ]
 },
 {
  "@name": "sent_S4",
  "@sourcetype": "populate",
  "@logic": [
   "-has property",
   "large",
   "$some_not_large",
   "?:Cu35"
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "isa",
    "activity",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ]
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has type",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Vre",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has actor",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Are",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_rel2_event",
  "@logic": [
   [
    "-is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ],
   [
    "has target",
    [
     "$ev_of",
     "?:Vre",
     "?:Are",
     "?:Ore"
    ],
    "?:Ore",
    "?:Cre"
   ]
  ]
 },
 {
  "@name": "frm_event_rel2",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:Ere"
   ],
   [
    "-has type",
    "?:Ere",
    "?:Vre",
    "?:Cre"
   ],
   [
    "-has actor",
    "?:Ere",
    "?:Are",
    "?:Cre"
   ],
   [
    "-has target",
    "?:Ere",
    "?:Ore",
    "?:Cre"
   ],
   [
    "is rel2",
    "?:Vre",
    "?:Are",
    "?:Ore",
    "?:Cre"
   ]
  ]
 }
]