[
 {
  "@name": "entity_S2",
  "@logic": [
   "isa",
   "person",
   "#:Mike 2"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "isa",
   "person",
   "#:John 1"
  ]
 },
 {
  "@name": "sent_S1",
  "@logic": [
   "has property",
   "glad",
   "#:John 1",
   [
    "$ctxt",
    "present",
    "W0",
    "?:Fv1",
    "?:Fv2"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   [
    "-has property",
    "glad",
    "#:John 1",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ],
   [
    "-has property",
    "glad",
    "#:Mike 2",
    [
     "$ctxt",
     "present",
     "W0",
     "?:Fv3",
     "?:Fv4"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has property",
    "glad",
    "#:Mike 2",
    [
     "$ctxt",
     "present",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-has property",
    "glad",
    "#:Mike 2",
    [
     "$ctxt",
     "present",
     "?:Fv7",
     "?:Fv5",
     "?:Fv6"
    ]
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question_bridge",
  "@confidence": 0.99,
  "@logic": [
   [
    "-has property",
    "glad",
    "#:Mike 2",
    [
     "$ctxt",
     "past",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "has property",
    "glad",
    "#:Mike 2",
    [
     "$ctxt",
     "present",
     "?:W",
     "?:L",
     "?:K"
    ]
   ],
   [
    "$block",
    0,
    [
     "$not",
     [
      "has property",
      "glad",
      "#:Mike 2",
      [
       "$ctxt",
       "present",
       "?:W",
       "?:L",
       "?:K"
      ]
     ]
    ]
   ]
  ]
 }
]