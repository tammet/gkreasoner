[
 {
  "@name": "sent_S1",
  "@logic": [
   [
    "-isa",
    "american",
    "?:X"
   ],
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "disappear",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "?:X",
    [
     "$ctxt",
     "?:Fv4",
     "?:Fv3",
     "?:Fv1",
     "?:Fv2"
    ]
   ],
   [
    "-capability",
    "?:E"
   ]
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "person",
   "#:Mr Dursley 1"
  ]
 },
 {
  "@name": "sent_S2",
  "@logic": [
   "isa",
   "american",
   "#:Mr Dursley 1"
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "isa",
    "activity",
    "sk0_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has type",
    "sk0_activity",
    "disappear",
    [
     "$ctxt",
     "?:Fv14",
     "?:Fv13",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "has actor",
    "sk0_activity",
    "#:Mr Dursley 1",
    [
     "$ctxt",
     "?:Fv16",
     "?:Fv15",
     "?:Fv7",
     "?:Fv8"
    ]
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-$defq0"
   ],
   [
    "capability",
    "sk0_activity"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@sourcetype": "question",
  "@logic": [
   [
    "-isa",
    "activity",
    "?:E"
   ],
   [
    "-has type",
    "?:E",
    "disappear",
    [
     "$ctxt",
     "?:Fv20",
     "?:Fv19",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-has actor",
    "?:E",
    "#:Mr Dursley 1",
    [
     "$ctxt",
     "?:Fv22",
     "?:Fv21",
     "?:Fv7",
     "?:Fv8"
    ]
   ],
   [
    "-capability",
    "?:E"
   ],
   [
    "$defq0"
   ]
  ]
 },
 {
  "@name": "sent_S3",
  "@question": [
   "$defq0"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "american",
   "$some_not_american"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "isa",
   "activity",
   "$some_activity"
  ]
 },
 {
  "@name": "sent_S1",
  "@sourcetype": "populate",
  "@logic": [
   "-isa",
   "activity",
   "$some_not_activity"
  ]
 }
]