0.27::sw1.
university(univ0) :- sw1.
0.96::sw2.
department(dept0) :- sw2.
0.17::sw3.
subOrganizationOf(dept0,univ0) :- sw3.
0.72::sw4.
fullProfessor(full0_d0) :- sw4.
0.13::sw5.
worksFor(full0_d0,dept0) :- sw5.
0.29::sw6.
doctoralDegreeFrom(full0_d0,univ2) :- sw6.
emailAddress(full0_d0,mail_full0_d0).
0.25::sw7.
researchInterest(full0_d0,res18) :- sw7.
0.66::sw8.
fullProfessor(full1_d0) :- sw8.
0.49::sw9.
worksFor(full1_d0,dept0) :- sw9.
0.48::sw10.
doctoralDegreeFrom(full1_d0,univ1) :- sw10.
0.52::sw11.
emailAddress(full1_d0,mail_full1_d0) :- sw11.
0.23::sw12.
researchInterest(full1_d0,res8) :- sw12.
0.84::sw13.
associateProfessor(asso0_d0) :- sw13.
0.14::sw14.
worksFor(asso0_d0,dept0) :- sw14.
0.27::sw15.
doctoralDegreeFrom(asso0_d0,univ1) :- sw15.
0.07::sw16.
emailAddress(asso0_d0,mail_asso0_d0) :- sw16.
0.30::sw17.
researchInterest(asso0_d0,res15) :- sw17.
0.44::sw18.
associateProfessor(asso1_d0) :- sw18.
0.91::sw19.
worksFor(asso1_d0,dept0) :- sw19.
0.41::sw20.
doctoralDegreeFrom(asso1_d0,univ7) :- sw20.
0.16::sw21.
emailAddress(asso1_d0,mail_asso1_d0) :- sw21.
0.30::sw22.
researchInterest(asso1_d0,res15) :- sw22.
0.99::sw23.
assistantProfessor(assi0_d0) :- sw23.
0.11::sw24.
worksFor(assi0_d0,dept0) :- sw24.
0.64::sw25.
doctoralDegreeFrom(assi0_d0,univ6) :- sw25.
0.41::sw26.
emailAddress(assi0_d0,mail_assi0_d0) :- sw26.
0.68::sw27.
researchInterest(assi0_d0,res6) :- sw27.
0.37::sw28.
assistantProfessor(assi1_d0) :- sw28.
0.71::sw29.
worksFor(assi1_d0,dept0) :- sw29.
0.52::sw30.
doctoralDegreeFrom(assi1_d0,univ1) :- sw30.
0.67::sw31.
emailAddress(assi1_d0,mail_assi1_d0) :- sw31.
0.91::sw32.
researchInterest(assi1_d0,res15) :- sw32.
0.60::sw33.
lecturer(lect0_d0) :- sw33.
0.19::sw34.
worksFor(lect0_d0,dept0) :- sw34.
0.11::sw35.
doctoralDegreeFrom(lect0_d0,univ0) :- sw35.
0.95::sw36.
emailAddress(lect0_d0,mail_lect0_d0) :- sw36.
0.51::sw37.
researchInterest(lect0_d0,res12) :- sw37.
0.23::sw38.
headOf(full0_d0,dept0) :- sw38.
0.95::sw39.
course(course0_d0) :- sw39.
0.60::sw40.
teacherOf(asso1_d0,course0_d0) :- sw40.
0.74::sw41.
course(course1_d0) :- sw41.
0.89::sw42.
teacherOf(assi0_d0,course1_d0) :- sw42.
0.32::sw43.
course(course2_d0) :- sw43.
0.39::sw44.
teacherOf(lect0_d0,course2_d0) :- sw44.
0.88::sw45.
course(course3_d0) :- sw45.
0.18::sw46.
teacherOf(lect0_d0,course3_d0) :- sw46.
0.78::sw47.
course(course4_d0) :- sw47.
0.14::sw48.
teacherOf(full0_d0,course4_d0) :- sw48.
0.71::sw49.
graduateCourse(gradCourse0_d0) :- sw49.
0.72::sw50.
teacherOf(assi1_d0,gradCourse0_d0) :- sw50.
0.95::sw51.
graduateCourse(gradCourse1_d0) :- sw51.
0.85::sw52.
teacherOf(asso1_d0,gradCourse1_d0) :- sw52.
0.53::sw53.
undergraduateStudent(ugrad0_d0) :- sw53.
0.24::sw54.
memberOf(ugrad0_d0,dept0) :- sw54.
0.19::sw55.
takesCourse(ugrad0_d0,course2_d0) :- sw55.
0.55::sw56.
takesCourse(ugrad0_d0,course3_d0) :- sw56.
0.53::sw57.
undergraduateStudent(ugrad1_d0) :- sw57.
0.12::sw58.
memberOf(ugrad1_d0,dept0) :- sw58.
0.91::sw59.
takesCourse(ugrad1_d0,course0_d0) :- sw59.
0.53::sw60.
takesCourse(ugrad1_d0,course1_d0) :- sw60.
0.72::sw61.
advisor(ugrad1_d0,full0_d0) :- sw61.
0.26::sw62.
undergraduateStudent(ugrad2_d0) :- sw62.
0.28::sw63.
memberOf(ugrad2_d0,dept0) :- sw63.
0.06::sw64.
takesCourse(ugrad2_d0,course0_d0) :- sw64.
0.38::sw65.
takesCourse(ugrad2_d0,course1_d0) :- sw65.
0.30::sw66.
undergraduateStudent(ugrad3_d0) :- sw66.
0.45::sw67.
memberOf(ugrad3_d0,dept0) :- sw67.
0.41::sw68.
takesCourse(ugrad3_d0,course3_d0) :- sw68.
0.84::sw69.
takesCourse(ugrad3_d0,course2_d0) :- sw69.
0.90::sw70.
advisor(ugrad3_d0,full1_d0) :- sw70.
0.22::sw71.
undergraduateStudent(ugrad4_d0) :- sw71.
0.43::sw72.
memberOf(ugrad4_d0,dept0) :- sw72.
0.21::sw73.
takesCourse(ugrad4_d0,course3_d0) :- sw73.
0.68::sw74.
takesCourse(ugrad4_d0,course1_d0) :- sw74.
0.98::sw75.
undergraduateStudent(ugrad5_d0) :- sw75.
0.24::sw76.
memberOf(ugrad5_d0,dept0) :- sw76.
0.78::sw77.
takesCourse(ugrad5_d0,course2_d0) :- sw77.
0.34::sw78.
takesCourse(ugrad5_d0,course0_d0) :- sw78.
0.06::sw79.
undergraduateStudent(ugrad6_d0) :- sw79.
0.78::sw80.
memberOf(ugrad6_d0,dept0) :- sw80.
0.37::sw81.
takesCourse(ugrad6_d0,course3_d0) :- sw81.
0.21::sw82.
takesCourse(ugrad6_d0,course1_d0) :- sw82.
0.46::sw83.
undergraduateStudent(ugrad7_d0) :- sw83.
0.27::sw84.
memberOf(ugrad7_d0,dept0) :- sw84.
0.44::sw85.
takesCourse(ugrad7_d0,course3_d0) :- sw85.
0.47::sw86.
takesCourse(ugrad7_d0,course2_d0) :- sw86.
0.45::sw87.
undergraduateStudent(ugrad8_d0) :- sw87.
0.61::sw88.
memberOf(ugrad8_d0,dept0) :- sw88.
0.32::sw89.
takesCourse(ugrad8_d0,course0_d0) :- sw89.
0.14::sw90.
takesCourse(ugrad8_d0,course3_d0) :- sw90.
0.13::sw91.
undergraduateStudent(ugrad9_d0) :- sw91.
0.15::sw92.
memberOf(ugrad9_d0,dept0) :- sw92.
0.54::sw93.
takesCourse(ugrad9_d0,course2_d0) :- sw93.
0.39::sw94.
takesCourse(ugrad9_d0,course0_d0) :- sw94.
0.82::sw95.
undergraduateStudent(ugrad10_d0) :- sw95.
0.53::sw96.
memberOf(ugrad10_d0,dept0) :- sw96.
0.72::sw97.
takesCourse(ugrad10_d0,course3_d0) :- sw97.
0.98::sw98.
takesCourse(ugrad10_d0,course2_d0) :- sw98.
0.11::sw99.
undergraduateStudent(ugrad11_d0) :- sw99.
0.07::sw100.
memberOf(ugrad11_d0,dept0) :- sw100.
0.18::sw101.
takesCourse(ugrad11_d0,course1_d0) :- sw101.
0.42::sw102.
takesCourse(ugrad11_d0,course3_d0) :- sw102.
0.59::sw103.
undergraduateStudent(ugrad12_d0) :- sw103.
0.76::sw104.
memberOf(ugrad12_d0,dept0) :- sw104.
0.38::sw105.
takesCourse(ugrad12_d0,course3_d0) :- sw105.
0.97::sw106.
takesCourse(ugrad12_d0,course2_d0) :- sw106.
0.05::sw107.
undergraduateStudent(ugrad13_d0) :- sw107.
0.84::sw108.
memberOf(ugrad13_d0,dept0) :- sw108.
0.25::sw109.
takesCourse(ugrad13_d0,course0_d0) :- sw109.
0.88::sw110.
takesCourse(ugrad13_d0,course1_d0) :- sw110.
0.08::sw111.
undergraduateStudent(ugrad14_d0) :- sw111.
0.97::sw112.
memberOf(ugrad14_d0,dept0) :- sw112.
0.77::sw113.
takesCourse(ugrad14_d0,course3_d0) :- sw113.
0.99::sw114.
takesCourse(ugrad14_d0,course1_d0) :- sw114.
0.60::sw115.
undergraduateStudent(ugrad15_d0) :- sw115.
0.22::sw116.
memberOf(ugrad15_d0,dept0) :- sw116.
0.97::sw117.
takesCourse(ugrad15_d0,course2_d0) :- sw117.
0.47::sw118.
takesCourse(ugrad15_d0,course3_d0) :- sw118.
0.13::sw119.
undergraduateStudent(ugrad16_d0) :- sw119.
0.63::sw120.
memberOf(ugrad16_d0,dept0) :- sw120.
0.52::sw121.
takesCourse(ugrad16_d0,course2_d0) :- sw121.
0.50::sw122.
takesCourse(ugrad16_d0,course0_d0) :- sw122.
0.20::sw123.
undergraduateStudent(ugrad17_d0) :- sw123.
0.17::sw124.
memberOf(ugrad17_d0,dept0) :- sw124.
0.60::sw125.
takesCourse(ugrad17_d0,course0_d0) :- sw125.
0.48::sw126.
takesCourse(ugrad17_d0,course3_d0) :- sw126.
0.17::sw127.
undergraduateStudent(ugrad18_d0) :- sw127.
0.47::sw128.
memberOf(ugrad18_d0,dept0) :- sw128.
0.74::sw129.
takesCourse(ugrad18_d0,course3_d0) :- sw129.
0.73::sw130.
takesCourse(ugrad18_d0,course1_d0) :- sw130.
0.50::sw131.
undergraduateStudent(ugrad19_d0) :- sw131.
0.42::sw132.
memberOf(ugrad19_d0,dept0) :- sw132.
0.39::sw133.
takesCourse(ugrad19_d0,course0_d0) :- sw133.
0.26::sw134.
takesCourse(ugrad19_d0,course1_d0) :- sw134.
0.24::sw135.
advisor(ugrad19_d0,assi1_d0) :- sw135.
0.47::sw136.
undergraduateStudent(ugrad20_d0) :- sw136.
0.15::sw137.
memberOf(ugrad20_d0,dept0) :- sw137.
0.74::sw138.
takesCourse(ugrad20_d0,course3_d0) :- sw138.
0.72::sw139.
takesCourse(ugrad20_d0,course2_d0) :- sw139.
0.63::sw140.
advisor(ugrad20_d0,assi0_d0) :- sw140.
0.07::sw141.
undergraduateStudent(ugrad21_d0) :- sw141.
0.40::sw142.
memberOf(ugrad21_d0,dept0) :- sw142.
0.46::sw143.
takesCourse(ugrad21_d0,course1_d0) :- sw143.
0.14::sw144.
takesCourse(ugrad21_d0,course0_d0) :- sw144.
0.97::sw145.
undergraduateStudent(ugrad22_d0) :- sw145.
0.77::sw146.
memberOf(ugrad22_d0,dept0) :- sw146.
0.53::sw147.
takesCourse(ugrad22_d0,course1_d0) :- sw147.
0.72::sw148.
takesCourse(ugrad22_d0,course3_d0) :- sw148.
0.24::sw149.
undergraduateStudent(ugrad23_d0) :- sw149.
0.27::sw150.
memberOf(ugrad23_d0,dept0) :- sw150.
0.55::sw151.
takesCourse(ugrad23_d0,course2_d0) :- sw151.
0.76::sw152.
takesCourse(ugrad23_d0,course1_d0) :- sw152.
0.66::sw153.
undergraduateStudent(ugrad24_d0) :- sw153.
0.06::sw154.
memberOf(ugrad24_d0,dept0) :- sw154.
0.63::sw155.
takesCourse(ugrad24_d0,course0_d0) :- sw155.
0.91::sw156.
takesCourse(ugrad24_d0,course1_d0) :- sw156.
0.76::sw157.
undergraduateStudent(ugrad25_d0) :- sw157.
0.93::sw158.
memberOf(ugrad25_d0,dept0) :- sw158.
0.98::sw159.
takesCourse(ugrad25_d0,course1_d0) :- sw159.
0.26::sw160.
takesCourse(ugrad25_d0,course2_d0) :- sw160.
0.33::sw161.
undergraduateStudent(ugrad26_d0) :- sw161.
0.57::sw162.
memberOf(ugrad26_d0,dept0) :- sw162.
0.98::sw163.
takesCourse(ugrad26_d0,course1_d0) :- sw163.
0.40::sw164.
takesCourse(ugrad26_d0,course3_d0) :- sw164.
0.94::sw165.
undergraduateStudent(ugrad27_d0) :- sw165.
0.86::sw166.
memberOf(ugrad27_d0,dept0) :- sw166.
0.54::sw167.
takesCourse(ugrad27_d0,course3_d0) :- sw167.
0.64::sw168.
takesCourse(ugrad27_d0,course1_d0) :- sw168.
0.96::sw169.
undergraduateStudent(ugrad28_d0) :- sw169.
0.79::sw170.
memberOf(ugrad28_d0,dept0) :- sw170.
0.33::sw171.
takesCourse(ugrad28_d0,course1_d0) :- sw171.
0.85::sw172.
takesCourse(ugrad28_d0,course2_d0) :- sw172.
0.24::sw173.
undergraduateStudent(ugrad29_d0) :- sw173.
0.40::sw174.
memberOf(ugrad29_d0,dept0) :- sw174.
0.96::sw175.
takesCourse(ugrad29_d0,course2_d0) :- sw175.
0.85::sw176.
takesCourse(ugrad29_d0,course1_d0) :- sw176.
0.35::sw177.
undergraduateStudent(ugrad30_d0) :- sw177.
0.33::sw178.
memberOf(ugrad30_d0,dept0) :- sw178.
0.63::sw179.
takesCourse(ugrad30_d0,course2_d0) :- sw179.
0.85::sw180.
takesCourse(ugrad30_d0,course1_d0) :- sw180.
0.70::sw181.
undergraduateStudent(ugrad31_d0) :- sw181.
0.94::sw182.
memberOf(ugrad31_d0,dept0) :- sw182.
0.74::sw183.
takesCourse(ugrad31_d0,course1_d0) :- sw183.
0.83::sw184.
takesCourse(ugrad31_d0,course2_d0) :- sw184.
0.62::sw185.
advisor(ugrad31_d0,assi0_d0) :- sw185.
0.39::sw186.
undergraduateStudent(ugrad32_d0) :- sw186.
0.46::sw187.
memberOf(ugrad32_d0,dept0) :- sw187.
0.52::sw188.
takesCourse(ugrad32_d0,course1_d0) :- sw188.
0.55::sw189.
takesCourse(ugrad32_d0,course0_d0) :- sw189.
0.85::sw190.
undergraduateStudent(ugrad33_d0) :- sw190.
0.31::sw191.
memberOf(ugrad33_d0,dept0) :- sw191.
0.12::sw192.
takesCourse(ugrad33_d0,course2_d0) :- sw192.
0.75::sw193.
takesCourse(ugrad33_d0,course0_d0) :- sw193.
0.31::sw194.
undergraduateStudent(ugrad34_d0) :- sw194.
0.45::sw195.
memberOf(ugrad34_d0,dept0) :- sw195.
0.16::sw196.
takesCourse(ugrad34_d0,course0_d0) :- sw196.
0.84::sw197.
takesCourse(ugrad34_d0,course3_d0) :- sw197.
0.31::sw198.
undergraduateStudent(ugrad35_d0) :- sw198.
0.33::sw199.
memberOf(ugrad35_d0,dept0) :- sw199.
0.81::sw200.
takesCourse(ugrad35_d0,course3_d0) :- sw200.
0.53::sw201.
takesCourse(ugrad35_d0,course0_d0) :- sw201.
0.31::sw202.
undergraduateStudent(ugrad36_d0) :- sw202.
0.89::sw203.
memberOf(ugrad36_d0,dept0) :- sw203.
0.44::sw204.
takesCourse(ugrad36_d0,course2_d0) :- sw204.
0.39::sw205.
takesCourse(ugrad36_d0,course0_d0) :- sw205.
0.97::sw206.
graduateStudent(grad0_d0) :- sw206.
0.80::sw207.
memberOf(grad0_d0,dept0) :- sw207.
0.76::sw208.
undergraduateDegreeFrom(grad0_d0,univ9) :- sw208.
0.29::sw209.
advisor(grad0_d0,full1_d0) :- sw209.
0.82::sw210.
takesCourse(grad0_d0,gradCourse0_d0) :- sw210.
0.62::sw211.
takesCourse(grad0_d0,gradCourse1_d0) :- sw211.
0.84::sw212.
teachingAssistantOf(grad0_d0,course1_d0) :- sw212.
0.40::sw213.
graduateStudent(grad1_d0) :- sw213.
0.79::sw214.
memberOf(grad1_d0,dept0) :- sw214.
0.80::sw215.
undergraduateDegreeFrom(grad1_d0,univ4) :- sw215.
0.42::sw216.
advisor(grad1_d0,assi0_d0) :- sw216.
0.67::sw217.
takesCourse(grad1_d0,course4_d0) :- sw217.
0.79::sw218.
takesCourse(grad1_d0,gradCourse0_d0) :- sw218.
0.99::sw219.
graduateStudent(grad2_d0) :- sw219.
0.92::sw220.
memberOf(grad2_d0,dept0) :- sw220.
0.80::sw221.
undergraduateDegreeFrom(grad2_d0,univ4) :- sw221.
0.18::sw222.
advisor(grad2_d0,asso1_d0) :- sw222.
0.63::sw223.
takesCourse(grad2_d0,gradCourse1_d0) :- sw223.
0.70::sw224.
takesCourse(grad2_d0,gradCourse0_d0) :- sw224.
0.13::sw225.
graduateStudent(grad3_d0) :- sw225.
0.49::sw226.
memberOf(grad3_d0,dept0) :- sw226.
0.88::sw227.
undergraduateDegreeFrom(grad3_d0,univ1) :- sw227.
0.91::sw228.
advisor(grad3_d0,full0_d0) :- sw228.
0.93::sw229.
takesCourse(grad3_d0,gradCourse0_d0) :- sw229.
0.14::sw230.
takesCourse(grad3_d0,gradCourse1_d0) :- sw230.
0.63::sw231.
graduateStudent(grad4_d0) :- sw231.
0.87::sw232.
memberOf(grad4_d0,dept0) :- sw232.
0.67::sw233.
undergraduateDegreeFrom(grad4_d0,univ3) :- sw233.
0.35::sw234.
advisor(grad4_d0,asso0_d0) :- sw234.
0.09::sw235.
takesCourse(grad4_d0,course4_d0) :- sw235.
0.92::sw236.
takesCourse(grad4_d0,gradCourse0_d0) :- sw236.
0.87::sw237.
graduateStudent(grad5_d0) :- sw237.
0.67::sw238.
memberOf(grad5_d0,dept0) :- sw238.
0.40::sw239.
undergraduateDegreeFrom(grad5_d0,univ8) :- sw239.
0.84::sw240.
advisor(grad5_d0,full1_d0) :- sw240.
0.82::sw241.
takesCourse(grad5_d0,gradCourse1_d0) :- sw241.
0.74::sw242.
takesCourse(grad5_d0,gradCourse0_d0) :- sw242.
0.62::sw243.
graduateStudent(grad6_d0) :- sw243.
0.35::sw244.
memberOf(grad6_d0,dept0) :- sw244.
0.33::sw245.
undergraduateDegreeFrom(grad6_d0,univ0) :- sw245.
0.39::sw246.
advisor(grad6_d0,full1_d0) :- sw246.
0.36::sw247.
takesCourse(grad6_d0,course4_d0) :- sw247.
0.54::sw248.
takesCourse(grad6_d0,gradCourse0_d0) :- sw248.
0.16::sw249.
teachingAssistantOf(grad6_d0,course1_d0) :- sw249.
0.74::sw250.
graduateStudent(grad7_d0) :- sw250.
0.38::sw251.
memberOf(grad7_d0,dept0) :- sw251.
0.20::sw252.
undergraduateDegreeFrom(grad7_d0,univ7) :- sw252.
0.29::sw253.
advisor(grad7_d0,assi1_d0) :- sw253.
0.42::sw254.
takesCourse(grad7_d0,gradCourse1_d0) :- sw254.
0.46::sw255.
takesCourse(grad7_d0,gradCourse0_d0) :- sw255.
0.79::sw256.
graduateStudent(grad8_d0) :- sw256.
0.14::sw257.
memberOf(grad8_d0,dept0) :- sw257.
0.26::sw258.
undergraduateDegreeFrom(grad8_d0,univ3) :- sw258.
0.33::sw259.
advisor(grad8_d0,assi1_d0) :- sw259.
0.22::sw260.
takesCourse(grad8_d0,gradCourse1_d0) :- sw260.
0.76::sw261.
takesCourse(grad8_d0,gradCourse0_d0) :- sw261.
0.15::sw262.
teachingAssistantOf(grad8_d0,course0_d0) :- sw262.
0.10::sw263.
graduateStudent(grad9_d0) :- sw263.
0.58::sw264.
memberOf(grad9_d0,dept0) :- sw264.
0.75::sw265.
undergraduateDegreeFrom(grad9_d0,univ6) :- sw265.
0.83::sw266.
advisor(grad9_d0,assi1_d0) :- sw266.
0.58::sw267.
takesCourse(grad9_d0,gradCourse1_d0) :- sw267.
0.36::sw268.
takesCourse(grad9_d0,gradCourse0_d0) :- sw268.
0.89::sw269.
publication(pub0_d0) :- sw269.
0.75::sw270.
publicationAuthor(pub0_d0,asso1_d0) :- sw270.
0.50::sw271.
publicationAuthor(pub0_d0,ugrad19_d0) :- sw271.
0.58::sw272.
publication(pub1_d0) :- sw272.
0.94::sw273.
publicationAuthor(pub1_d0,full1_d0) :- sw273.
publication(pub2_d0).
0.93::sw274.
publicationAuthor(pub2_d0,full0_d0) :- sw274.
0.18::sw275.
publicationAuthor(pub2_d0,ugrad4_d0) :- sw275.
0.36::sw276.
publication(pub3_d0) :- sw276.
0.44::sw277.
publicationAuthor(pub3_d0,asso0_d0) :- sw277.
0.21::sw278.
publication(pub4_d0) :- sw278.
0.77::sw279.
publicationAuthor(pub4_d0,asso0_d0) :- sw279.
0.11::sw280.
publication(pub5_d0) :- sw280.
0.89::sw281.
publicationAuthor(pub5_d0,asso1_d0) :- sw281.
0.61::sw282.
publication(pub6_d0) :- sw282.
0.63::sw283.
publicationAuthor(pub6_d0,full1_d0) :- sw283.
0.44::sw284.
publicationAuthor(pub6_d0,ugrad2_d0) :- sw284.
0.94::sw285.
publication(pub7_d0) :- sw285.
0.60::sw286.
publicationAuthor(pub7_d0,assi0_d0) :- sw286.
0.90::sw287.
publication(pub8_d0) :- sw287.
0.93::sw288.
publicationAuthor(pub8_d0,assi0_d0) :- sw288.
0.71::sw289.
publicationAuthor(pub8_d0,grad8_d0) :- sw289.
0.98::sw290.
publication(pub9_d0) :- sw290.
0.52::sw291.
publicationAuthor(pub9_d0,assi0_d0) :- sw291.
0.40::sw292.
publication(pub10_d0) :- sw292.
0.85::sw293.
publicationAuthor(pub10_d0,asso1_d0) :- sw293.
0.55::sw294.
publicationAuthor(pub10_d0,ugrad6_d0) :- sw294.
0.34::sw295.
publication(pub11_d0) :- sw295.
0.70::sw296.
publicationAuthor(pub11_d0,full1_d0) :- sw296.
0.50::sw297.
publication(pub12_d0) :- sw297.
0.17::sw298.
publicationAuthor(pub12_d0,asso1_d0) :- sw298.
0.85::sw299.
publication(pub13_d0) :- sw299.
0.52::sw300.
publicationAuthor(pub13_d0,asso1_d0) :- sw300.
0.97::sw301.
publicationAuthor(pub13_d0,grad5_d0) :- sw301.
0.56::sw302.
publication(pub14_d0) :- sw302.
0.94::sw303.
publicationAuthor(pub14_d0,asso1_d0) :- sw303.
0.32::sw304.
publicationAuthor(pub14_d0,ugrad31_d0) :- sw304.
course(X) :- graduateCourse(X).
course(Y) :- teacherOf(X,Y).
course(Y) :- teachingAssistantOf(X,Y).
degreeFrom(X,Y) :- doctoralDegreeFrom(X,Y).
degreeFrom(X,Y) :- undergraduateDegreeFrom(X,Y).
faculty(X) :- lecturer(X).
faculty(X) :- teacherOf(X,Y).
hasAlumnus(Y,X) :- degreeFrom(X,Y).
member(Y,X) :- memberOf(X,Y).
memberOf(X,Y) :- worksFor(X,Y).
memberOf(Y,X) :- member(X,Y).
organization(X) :- department(X).
organization(X) :- member(X,Y).
organization(X) :- subOrganizationOf(X,Y).
organization(X) :- university(X).
organization(Y) :- subOrganizationOf(X,Y).
person(X) :- advisor(X,Y).
person(X) :- degreeFrom(X,Y).
person(X) :- doctoralDegreeFrom(X,Y).
person(X) :- emailAddress(X,Y).
person(X) :- graduateStudent(X).
person(X) :- undergraduateDegreeFrom(X,Y).
person(Y) :- hasAlumnus(X,Y).
person(Y) :- member(X,Y).
person(Y) :- publicationAuthor(X,Y).
professor(X) :- assistantProfessor(X).
professor(X) :- associateProfessor(X).
professor(X) :- fullProfessor(X).
professor(Y) :- advisor(X,Y).
publication(X) :- publicationAuthor(X,Y).
student(X) :- undergraduateStudent(X).
subOrganizationOf(X,Z) :- subOrganizationOf(X,Y), subOrganizationOf(Y,Z).
teachingAssistant(X) :- teachingAssistantOf(X,Y).
university(X) :- hasAlumnus(X,Y).
university(Y) :- degreeFrom(X,Y).
university(Y) :- doctoralDegreeFrom(X,Y).
university(Y) :- undergraduateDegreeFrom(X,Y).
work(X) :- course(X).
worksFor(X,Y) :- headOf(X,Y).
degreeFrom(Y,X) :- hasAlumnus(X,Y).
employee(X) :- faculty(X).
faculty(X) :- professor(X).
-researchInterest(full0_d0,res18).
