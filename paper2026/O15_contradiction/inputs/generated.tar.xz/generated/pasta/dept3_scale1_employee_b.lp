0.59::sw1.
university(univ0) :- sw1.
0.46::sw2.
department(dept0) :- sw2.
0.60::sw3.
subOrganizationOf(dept0,univ0) :- sw3.
0.25::sw4.
fullProfessor(full0_d0) :- sw4.
0.82::sw5.
worksFor(full0_d0,dept0) :- sw5.
0.83::sw6.
doctoralDegreeFrom(full0_d0,univ3) :- sw6.
0.67::sw7.
emailAddress(full0_d0,mail_full0_d0) :- sw7.
0.20::sw8.
researchInterest(full0_d0,res18) :- sw8.
0.54::sw9.
fullProfessor(full1_d0) :- sw9.
0.36::sw10.
worksFor(full1_d0,dept0) :- sw10.
0.29::sw11.
doctoralDegreeFrom(full1_d0,univ8) :- sw11.
0.96::sw12.
emailAddress(full1_d0,mail_full1_d0) :- sw12.
researchInterest(full1_d0,res4).
0.09::sw13.
fullProfessor(full2_d0) :- sw13.
0.87::sw14.
worksFor(full2_d0,dept0) :- sw14.
0.62::sw15.
doctoralDegreeFrom(full2_d0,univ5) :- sw15.
0.41::sw16.
emailAddress(full2_d0,mail_full2_d0) :- sw16.
0.32::sw17.
researchInterest(full2_d0,res19) :- sw17.
0.69::sw18.
fullProfessor(full3_d0) :- sw18.
0.48::sw19.
worksFor(full3_d0,dept0) :- sw19.
0.70::sw20.
doctoralDegreeFrom(full3_d0,univ7) :- sw20.
0.68::sw21.
emailAddress(full3_d0,mail_full3_d0) :- sw21.
0.18::sw22.
researchInterest(full3_d0,res18) :- sw22.
0.78::sw23.
fullProfessor(full4_d0) :- sw23.
0.98::sw24.
worksFor(full4_d0,dept0) :- sw24.
0.97::sw25.
doctoralDegreeFrom(full4_d0,univ1) :- sw25.
0.63::sw26.
emailAddress(full4_d0,mail_full4_d0) :- sw26.
0.09::sw27.
researchInterest(full4_d0,res19) :- sw27.
0.05::sw28.
fullProfessor(full5_d0) :- sw28.
0.18::sw29.
worksFor(full5_d0,dept0) :- sw29.
0.94::sw30.
doctoralDegreeFrom(full5_d0,univ0) :- sw30.
0.34::sw31.
emailAddress(full5_d0,mail_full5_d0) :- sw31.
0.40::sw32.
researchInterest(full5_d0,res15) :- sw32.
0.90::sw33.
fullProfessor(full6_d0) :- sw33.
0.35::sw34.
worksFor(full6_d0,dept0) :- sw34.
0.57::sw35.
doctoralDegreeFrom(full6_d0,univ4) :- sw35.
0.46::sw36.
emailAddress(full6_d0,mail_full6_d0) :- sw36.
0.11::sw37.
researchInterest(full6_d0,res17) :- sw37.
0.61::sw38.
fullProfessor(full7_d0) :- sw38.
0.85::sw39.
worksFor(full7_d0,dept0) :- sw39.
0.20::sw40.
doctoralDegreeFrom(full7_d0,univ3) :- sw40.
0.26::sw41.
emailAddress(full7_d0,mail_full7_d0) :- sw41.
0.44::sw42.
researchInterest(full7_d0,res6) :- sw42.
0.09::sw43.
associateProfessor(asso0_d0) :- sw43.
0.52::sw44.
worksFor(asso0_d0,dept0) :- sw44.
0.83::sw45.
doctoralDegreeFrom(asso0_d0,univ7) :- sw45.
0.67::sw46.
emailAddress(asso0_d0,mail_asso0_d0) :- sw46.
0.56::sw47.
researchInterest(asso0_d0,res17) :- sw47.
0.86::sw48.
associateProfessor(asso1_d0) :- sw48.
0.19::sw49.
worksFor(asso1_d0,dept0) :- sw49.
0.59::sw50.
doctoralDegreeFrom(asso1_d0,univ8) :- sw50.
0.41::sw51.
emailAddress(asso1_d0,mail_asso1_d0) :- sw51.
0.62::sw52.
researchInterest(asso1_d0,res15) :- sw52.
0.16::sw53.
associateProfessor(asso2_d0) :- sw53.
0.79::sw54.
worksFor(asso2_d0,dept0) :- sw54.
0.14::sw55.
doctoralDegreeFrom(asso2_d0,univ6) :- sw55.
0.21::sw56.
emailAddress(asso2_d0,mail_asso2_d0) :- sw56.
0.82::sw57.
researchInterest(asso2_d0,res4) :- sw57.
0.95::sw58.
associateProfessor(asso3_d0) :- sw58.
0.46::sw59.
worksFor(asso3_d0,dept0) :- sw59.
0.44::sw60.
doctoralDegreeFrom(asso3_d0,univ3) :- sw60.
0.28::sw61.
emailAddress(asso3_d0,mail_asso3_d0) :- sw61.
0.31::sw62.
researchInterest(asso3_d0,res4) :- sw62.
0.64::sw63.
associateProfessor(asso4_d0) :- sw63.
0.22::sw64.
worksFor(asso4_d0,dept0) :- sw64.
0.16::sw65.
doctoralDegreeFrom(asso4_d0,univ8) :- sw65.
0.48::sw66.
emailAddress(asso4_d0,mail_asso4_d0) :- sw66.
0.21::sw67.
researchInterest(asso4_d0,res12) :- sw67.
0.67::sw68.
associateProfessor(asso5_d0) :- sw68.
0.83::sw69.
worksFor(asso5_d0,dept0) :- sw69.
0.79::sw70.
doctoralDegreeFrom(asso5_d0,univ0) :- sw70.
0.51::sw71.
emailAddress(asso5_d0,mail_asso5_d0) :- sw71.
0.38::sw72.
researchInterest(asso5_d0,res2) :- sw72.
0.46::sw73.
associateProfessor(asso6_d0) :- sw73.
0.05::sw74.
worksFor(asso6_d0,dept0) :- sw74.
0.73::sw75.
doctoralDegreeFrom(asso6_d0,univ2) :- sw75.
0.37::sw76.
emailAddress(asso6_d0,mail_asso6_d0) :- sw76.
0.35::sw77.
researchInterest(asso6_d0,res18) :- sw77.
0.13::sw78.
associateProfessor(asso7_d0) :- sw78.
0.48::sw79.
worksFor(asso7_d0,dept0) :- sw79.
0.60::sw80.
doctoralDegreeFrom(asso7_d0,univ0) :- sw80.
0.42::sw81.
emailAddress(asso7_d0,mail_asso7_d0) :- sw81.
0.88::sw82.
researchInterest(asso7_d0,res9) :- sw82.
0.69::sw83.
associateProfessor(asso8_d0) :- sw83.
0.28::sw84.
worksFor(asso8_d0,dept0) :- sw84.
0.55::sw85.
doctoralDegreeFrom(asso8_d0,univ0) :- sw85.
0.92::sw86.
emailAddress(asso8_d0,mail_asso8_d0) :- sw86.
0.54::sw87.
researchInterest(asso8_d0,res8) :- sw87.
0.62::sw88.
associateProfessor(asso9_d0) :- sw88.
0.11::sw89.
worksFor(asso9_d0,dept0) :- sw89.
0.51::sw90.
doctoralDegreeFrom(asso9_d0,univ7) :- sw90.
0.49::sw91.
emailAddress(asso9_d0,mail_asso9_d0) :- sw91.
0.43::sw92.
researchInterest(asso9_d0,res19) :- sw92.
0.45::sw93.
assistantProfessor(assi0_d0) :- sw93.
0.61::sw94.
worksFor(assi0_d0,dept0) :- sw94.
0.56::sw95.
doctoralDegreeFrom(assi0_d0,univ6) :- sw95.
0.52::sw96.
emailAddress(assi0_d0,mail_assi0_d0) :- sw96.
0.21::sw97.
researchInterest(assi0_d0,res13) :- sw97.
0.47::sw98.
assistantProfessor(assi1_d0) :- sw98.
0.97::sw99.
worksFor(assi1_d0,dept0) :- sw99.
0.44::sw100.
doctoralDegreeFrom(assi1_d0,univ6) :- sw100.
0.08::sw101.
emailAddress(assi1_d0,mail_assi1_d0) :- sw101.
0.05::sw102.
researchInterest(assi1_d0,res18) :- sw102.
0.56::sw103.
assistantProfessor(assi2_d0) :- sw103.
0.10::sw104.
worksFor(assi2_d0,dept0) :- sw104.
0.14::sw105.
doctoralDegreeFrom(assi2_d0,univ7) :- sw105.
0.15::sw106.
emailAddress(assi2_d0,mail_assi2_d0) :- sw106.
0.48::sw107.
researchInterest(assi2_d0,res4) :- sw107.
0.99::sw108.
assistantProfessor(assi3_d0) :- sw108.
0.51::sw109.
worksFor(assi3_d0,dept0) :- sw109.
0.49::sw110.
doctoralDegreeFrom(assi3_d0,univ5) :- sw110.
0.46::sw111.
emailAddress(assi3_d0,mail_assi3_d0) :- sw111.
0.53::sw112.
researchInterest(assi3_d0,res3) :- sw112.
0.47::sw113.
assistantProfessor(assi4_d0) :- sw113.
0.74::sw114.
worksFor(assi4_d0,dept0) :- sw114.
0.90::sw115.
doctoralDegreeFrom(assi4_d0,univ0) :- sw115.
0.71::sw116.
emailAddress(assi4_d0,mail_assi4_d0) :- sw116.
0.45::sw117.
researchInterest(assi4_d0,res4) :- sw117.
0.67::sw118.
assistantProfessor(assi5_d0) :- sw118.
0.91::sw119.
worksFor(assi5_d0,dept0) :- sw119.
0.20::sw120.
doctoralDegreeFrom(assi5_d0,univ7) :- sw120.
0.28::sw121.
emailAddress(assi5_d0,mail_assi5_d0) :- sw121.
0.64::sw122.
researchInterest(assi5_d0,res6) :- sw122.
0.70::sw123.
assistantProfessor(assi6_d0) :- sw123.
0.66::sw124.
worksFor(assi6_d0,dept0) :- sw124.
0.61::sw125.
doctoralDegreeFrom(assi6_d0,univ4) :- sw125.
0.84::sw126.
emailAddress(assi6_d0,mail_assi6_d0) :- sw126.
0.50::sw127.
researchInterest(assi6_d0,res13) :- sw127.
0.82::sw128.
assistantProfessor(assi7_d0) :- sw128.
0.96::sw129.
worksFor(assi7_d0,dept0) :- sw129.
0.46::sw130.
doctoralDegreeFrom(assi7_d0,univ4) :- sw130.
0.87::sw131.
emailAddress(assi7_d0,mail_assi7_d0) :- sw131.
0.73::sw132.
researchInterest(assi7_d0,res13) :- sw132.
0.89::sw133.
assistantProfessor(assi8_d0) :- sw133.
0.09::sw134.
worksFor(assi8_d0,dept0) :- sw134.
0.92::sw135.
doctoralDegreeFrom(assi8_d0,univ8) :- sw135.
0.78::sw136.
emailAddress(assi8_d0,mail_assi8_d0) :- sw136.
0.96::sw137.
researchInterest(assi8_d0,res12) :- sw137.
0.98::sw138.
assistantProfessor(assi9_d0) :- sw138.
0.32::sw139.
worksFor(assi9_d0,dept0) :- sw139.
0.69::sw140.
doctoralDegreeFrom(assi9_d0,univ9) :- sw140.
0.18::sw141.
emailAddress(assi9_d0,mail_assi9_d0) :- sw141.
0.62::sw142.
researchInterest(assi9_d0,res11) :- sw142.
0.92::sw143.
lecturer(lect0_d0) :- sw143.
0.23::sw144.
worksFor(lect0_d0,dept0) :- sw144.
0.38::sw145.
doctoralDegreeFrom(lect0_d0,univ8) :- sw145.
0.13::sw146.
emailAddress(lect0_d0,mail_lect0_d0) :- sw146.
0.23::sw147.
researchInterest(lect0_d0,res18) :- sw147.
0.25::sw148.
lecturer(lect1_d0) :- sw148.
0.14::sw149.
worksFor(lect1_d0,dept0) :- sw149.
doctoralDegreeFrom(lect1_d0,univ6).
0.89::sw150.
emailAddress(lect1_d0,mail_lect1_d0) :- sw150.
0.49::sw151.
researchInterest(lect1_d0,res18) :- sw151.
0.76::sw152.
lecturer(lect2_d0) :- sw152.
0.71::sw153.
worksFor(lect2_d0,dept0) :- sw153.
0.55::sw154.
doctoralDegreeFrom(lect2_d0,univ3) :- sw154.
0.45::sw155.
emailAddress(lect2_d0,mail_lect2_d0) :- sw155.
0.68::sw156.
researchInterest(lect2_d0,res10) :- sw156.
0.58::sw157.
lecturer(lect3_d0) :- sw157.
0.30::sw158.
worksFor(lect3_d0,dept0) :- sw158.
0.40::sw159.
doctoralDegreeFrom(lect3_d0,univ0) :- sw159.
0.65::sw160.
emailAddress(lect3_d0,mail_lect3_d0) :- sw160.
0.65::sw161.
researchInterest(lect3_d0,res8) :- sw161.
0.25::sw162.
lecturer(lect4_d0) :- sw162.
0.63::sw163.
worksFor(lect4_d0,dept0) :- sw163.
0.88::sw164.
doctoralDegreeFrom(lect4_d0,univ9) :- sw164.
0.88::sw165.
emailAddress(lect4_d0,mail_lect4_d0) :- sw165.
0.67::sw166.
researchInterest(lect4_d0,res5) :- sw166.
0.12::sw167.
headOf(full0_d0,dept0) :- sw167.
0.45::sw168.
course(course0_d0) :- sw168.
0.13::sw169.
teacherOf(assi2_d0,course0_d0) :- sw169.
0.10::sw170.
course(course1_d0) :- sw170.
0.29::sw171.
teacherOf(full6_d0,course1_d0) :- sw171.
0.48::sw172.
course(course2_d0) :- sw172.
0.77::sw173.
teacherOf(asso5_d0,course2_d0) :- sw173.
0.65::sw174.
course(course3_d0) :- sw174.
0.32::sw175.
teacherOf(asso9_d0,course3_d0) :- sw175.
0.71::sw176.
course(course4_d0) :- sw176.
0.53::sw177.
teacherOf(assi0_d0,course4_d0) :- sw177.
0.53::sw178.
course(course5_d0) :- sw178.
0.30::sw179.
teacherOf(full7_d0,course5_d0) :- sw179.
0.47::sw180.
course(course6_d0) :- sw180.
0.37::sw181.
teacherOf(full4_d0,course6_d0) :- sw181.
0.74::sw182.
course(course7_d0) :- sw182.
0.51::sw183.
teacherOf(lect2_d0,course7_d0) :- sw183.
0.47::sw184.
course(course8_d0) :- sw184.
0.50::sw185.
teacherOf(lect2_d0,course8_d0) :- sw185.
0.51::sw186.
course(course9_d0) :- sw186.
0.71::sw187.
teacherOf(full5_d0,course9_d0) :- sw187.
0.73::sw188.
course(course10_d0) :- sw188.
0.81::sw189.
teacherOf(assi4_d0,course10_d0) :- sw189.
0.43::sw190.
course(course11_d0) :- sw190.
0.80::sw191.
teacherOf(full4_d0,course11_d0) :- sw191.
0.97::sw192.
course(course12_d0) :- sw192.
0.99::sw193.
teacherOf(assi8_d0,course12_d0) :- sw193.
0.73::sw194.
course(course13_d0) :- sw194.
0.11::sw195.
teacherOf(asso1_d0,course13_d0) :- sw195.
0.85::sw196.
course(course14_d0) :- sw196.
0.84::sw197.
teacherOf(full1_d0,course14_d0) :- sw197.
0.07::sw198.
course(course15_d0) :- sw198.
0.36::sw199.
teacherOf(assi0_d0,course15_d0) :- sw199.
0.36::sw200.
course(course16_d0) :- sw200.
0.75::sw201.
teacherOf(assi9_d0,course16_d0) :- sw201.
0.63::sw202.
course(course17_d0) :- sw202.
0.32::sw203.
teacherOf(assi8_d0,course17_d0) :- sw203.
0.23::sw204.
course(course18_d0) :- sw204.
0.21::sw205.
teacherOf(full7_d0,course18_d0) :- sw205.
0.14::sw206.
course(course19_d0) :- sw206.
0.80::sw207.
teacherOf(full2_d0,course19_d0) :- sw207.
0.94::sw208.
graduateCourse(gradCourse0_d0) :- sw208.
0.26::sw209.
teacherOf(full2_d0,gradCourse0_d0) :- sw209.
0.76::sw210.
graduateCourse(gradCourse1_d0) :- sw210.
0.95::sw211.
teacherOf(assi6_d0,gradCourse1_d0) :- sw211.
0.23::sw212.
graduateCourse(gradCourse2_d0) :- sw212.
0.59::sw213.
teacherOf(assi3_d0,gradCourse2_d0) :- sw213.
0.47::sw214.
graduateCourse(gradCourse3_d0) :- sw214.
0.98::sw215.
teacherOf(asso9_d0,gradCourse3_d0) :- sw215.
0.88::sw216.
graduateCourse(gradCourse4_d0) :- sw216.
0.07::sw217.
teacherOf(lect4_d0,gradCourse4_d0) :- sw217.
0.24::sw218.
graduateCourse(gradCourse5_d0) :- sw218.
0.86::sw219.
teacherOf(asso7_d0,gradCourse5_d0) :- sw219.
0.60::sw220.
graduateCourse(gradCourse6_d0) :- sw220.
0.55::sw221.
teacherOf(full2_d0,gradCourse6_d0) :- sw221.
0.82::sw222.
graduateCourse(gradCourse7_d0) :- sw222.
0.78::sw223.
teacherOf(assi1_d0,gradCourse7_d0) :- sw223.
0.96::sw224.
graduateCourse(gradCourse8_d0) :- sw224.
0.36::sw225.
teacherOf(full0_d0,gradCourse8_d0) :- sw225.
0.10::sw226.
graduateCourse(gradCourse9_d0) :- sw226.
0.71::sw227.
teacherOf(full4_d0,gradCourse9_d0) :- sw227.
0.10::sw228.
undergraduateStudent(ugrad0_d0) :- sw228.
0.59::sw229.
memberOf(ugrad0_d0,dept0) :- sw229.
0.87::sw230.
takesCourse(ugrad0_d0,course3_d0) :- sw230.
0.43::sw231.
takesCourse(ugrad0_d0,course17_d0) :- sw231.
0.62::sw232.
advisor(ugrad0_d0,asso4_d0) :- sw232.
0.21::sw233.
undergraduateStudent(ugrad1_d0) :- sw233.
0.20::sw234.
memberOf(ugrad1_d0,dept0) :- sw234.
0.63::sw235.
takesCourse(ugrad1_d0,course13_d0) :- sw235.
0.87::sw236.
takesCourse(ugrad1_d0,course9_d0) :- sw236.
undergraduateStudent(ugrad2_d0).
0.08::sw237.
memberOf(ugrad2_d0,dept0) :- sw237.
0.92::sw238.
takesCourse(ugrad2_d0,course4_d0) :- sw238.
0.54::sw239.
takesCourse(ugrad2_d0,course1_d0) :- sw239.
0.38::sw240.
undergraduateStudent(ugrad3_d0) :- sw240.
0.43::sw241.
memberOf(ugrad3_d0,dept0) :- sw241.
0.60::sw242.
takesCourse(ugrad3_d0,course10_d0) :- sw242.
0.38::sw243.
takesCourse(ugrad3_d0,course19_d0) :- sw243.
0.19::sw244.
undergraduateStudent(ugrad4_d0) :- sw244.
0.87::sw245.
memberOf(ugrad4_d0,dept0) :- sw245.
0.72::sw246.
takesCourse(ugrad4_d0,course4_d0) :- sw246.
0.63::sw247.
takesCourse(ugrad4_d0,course12_d0) :- sw247.
0.74::sw248.
undergraduateStudent(ugrad5_d0) :- sw248.
0.99::sw249.
memberOf(ugrad5_d0,dept0) :- sw249.
0.22::sw250.
takesCourse(ugrad5_d0,course16_d0) :- sw250.
0.83::sw251.
takesCourse(ugrad5_d0,course12_d0) :- sw251.
0.83::sw252.
undergraduateStudent(ugrad6_d0) :- sw252.
0.38::sw253.
memberOf(ugrad6_d0,dept0) :- sw253.
0.58::sw254.
takesCourse(ugrad6_d0,course19_d0) :- sw254.
0.49::sw255.
takesCourse(ugrad6_d0,course17_d0) :- sw255.
0.23::sw256.
advisor(ugrad6_d0,lect4_d0) :- sw256.
0.46::sw257.
undergraduateStudent(ugrad7_d0) :- sw257.
0.19::sw258.
memberOf(ugrad7_d0,dept0) :- sw258.
0.94::sw259.
takesCourse(ugrad7_d0,course8_d0) :- sw259.
0.23::sw260.
takesCourse(ugrad7_d0,course13_d0) :- sw260.
0.65::sw261.
undergraduateStudent(ugrad8_d0) :- sw261.
0.59::sw262.
memberOf(ugrad8_d0,dept0) :- sw262.
0.98::sw263.
takesCourse(ugrad8_d0,course7_d0) :- sw263.
0.80::sw264.
takesCourse(ugrad8_d0,course9_d0) :- sw264.
0.39::sw265.
undergraduateStudent(ugrad9_d0) :- sw265.
0.41::sw266.
memberOf(ugrad9_d0,dept0) :- sw266.
0.10::sw267.
takesCourse(ugrad9_d0,course8_d0) :- sw267.
0.10::sw268.
takesCourse(ugrad9_d0,course16_d0) :- sw268.
0.35::sw269.
undergraduateStudent(ugrad10_d0) :- sw269.
0.95::sw270.
memberOf(ugrad10_d0,dept0) :- sw270.
0.10::sw271.
takesCourse(ugrad10_d0,course10_d0) :- sw271.
0.22::sw272.
takesCourse(ugrad10_d0,course0_d0) :- sw272.
0.65::sw273.
undergraduateStudent(ugrad11_d0) :- sw273.
0.39::sw274.
memberOf(ugrad11_d0,dept0) :- sw274.
0.23::sw275.
takesCourse(ugrad11_d0,course18_d0) :- sw275.
0.95::sw276.
takesCourse(ugrad11_d0,course10_d0) :- sw276.
0.09::sw277.
advisor(ugrad11_d0,asso0_d0) :- sw277.
0.62::sw278.
undergraduateStudent(ugrad12_d0) :- sw278.
0.46::sw279.
memberOf(ugrad12_d0,dept0) :- sw279.
0.38::sw280.
takesCourse(ugrad12_d0,course1_d0) :- sw280.
0.24::sw281.
takesCourse(ugrad12_d0,course10_d0) :- sw281.
0.20::sw282.
undergraduateStudent(ugrad13_d0) :- sw282.
0.44::sw283.
memberOf(ugrad13_d0,dept0) :- sw283.
0.76::sw284.
takesCourse(ugrad13_d0,course11_d0) :- sw284.
0.49::sw285.
takesCourse(ugrad13_d0,course8_d0) :- sw285.
0.79::sw286.
undergraduateStudent(ugrad14_d0) :- sw286.
0.88::sw287.
memberOf(ugrad14_d0,dept0) :- sw287.
0.21::sw288.
takesCourse(ugrad14_d0,course0_d0) :- sw288.
0.89::sw289.
takesCourse(ugrad14_d0,course18_d0) :- sw289.
0.60::sw290.
advisor(ugrad14_d0,full1_d0) :- sw290.
0.45::sw291.
undergraduateStudent(ugrad15_d0) :- sw291.
0.54::sw292.
memberOf(ugrad15_d0,dept0) :- sw292.
0.90::sw293.
takesCourse(ugrad15_d0,course11_d0) :- sw293.
0.42::sw294.
takesCourse(ugrad15_d0,course8_d0) :- sw294.
0.14::sw295.
undergraduateStudent(ugrad16_d0) :- sw295.
0.96::sw296.
memberOf(ugrad16_d0,dept0) :- sw296.
0.16::sw297.
takesCourse(ugrad16_d0,course9_d0) :- sw297.
0.15::sw298.
takesCourse(ugrad16_d0,course18_d0) :- sw298.
0.74::sw299.
undergraduateStudent(ugrad17_d0) :- sw299.
0.35::sw300.
memberOf(ugrad17_d0,dept0) :- sw300.
0.33::sw301.
takesCourse(ugrad17_d0,course5_d0) :- sw301.
0.67::sw302.
takesCourse(ugrad17_d0,course11_d0) :- sw302.
0.90::sw303.
advisor(ugrad17_d0,assi5_d0) :- sw303.
0.38::sw304.
undergraduateStudent(ugrad18_d0) :- sw304.
0.91::sw305.
memberOf(ugrad18_d0,dept0) :- sw305.
0.64::sw306.
takesCourse(ugrad18_d0,course19_d0) :- sw306.
0.63::sw307.
takesCourse(ugrad18_d0,course8_d0) :- sw307.
0.56::sw308.
undergraduateStudent(ugrad19_d0) :- sw308.
0.06::sw309.
memberOf(ugrad19_d0,dept0) :- sw309.
0.20::sw310.
takesCourse(ugrad19_d0,course12_d0) :- sw310.
0.69::sw311.
takesCourse(ugrad19_d0,course3_d0) :- sw311.
0.71::sw312.
undergraduateStudent(ugrad20_d0) :- sw312.
0.14::sw313.
memberOf(ugrad20_d0,dept0) :- sw313.
0.66::sw314.
takesCourse(ugrad20_d0,course0_d0) :- sw314.
0.50::sw315.
takesCourse(ugrad20_d0,course18_d0) :- sw315.
0.60::sw316.
undergraduateStudent(ugrad21_d0) :- sw316.
0.43::sw317.
memberOf(ugrad21_d0,dept0) :- sw317.
0.26::sw318.
takesCourse(ugrad21_d0,course4_d0) :- sw318.
0.39::sw319.
takesCourse(ugrad21_d0,course9_d0) :- sw319.
0.97::sw320.
undergraduateStudent(ugrad22_d0) :- sw320.
0.23::sw321.
memberOf(ugrad22_d0,dept0) :- sw321.
0.87::sw322.
takesCourse(ugrad22_d0,course8_d0) :- sw322.
0.55::sw323.
takesCourse(ugrad22_d0,course7_d0) :- sw323.
0.12::sw324.
undergraduateStudent(ugrad23_d0) :- sw324.
0.82::sw325.
memberOf(ugrad23_d0,dept0) :- sw325.
0.07::sw326.
takesCourse(ugrad23_d0,course13_d0) :- sw326.
0.85::sw327.
takesCourse(ugrad23_d0,course3_d0) :- sw327.
0.37::sw328.
advisor(ugrad23_d0,assi2_d0) :- sw328.
0.92::sw329.
undergraduateStudent(ugrad24_d0) :- sw329.
0.74::sw330.
memberOf(ugrad24_d0,dept0) :- sw330.
0.39::sw331.
takesCourse(ugrad24_d0,course10_d0) :- sw331.
0.64::sw332.
takesCourse(ugrad24_d0,course7_d0) :- sw332.
0.99::sw333.
undergraduateStudent(ugrad25_d0) :- sw333.
0.21::sw334.
memberOf(ugrad25_d0,dept0) :- sw334.
0.25::sw335.
takesCourse(ugrad25_d0,course5_d0) :- sw335.
0.32::sw336.
takesCourse(ugrad25_d0,course2_d0) :- sw336.
0.83::sw337.
undergraduateStudent(ugrad26_d0) :- sw337.
0.28::sw338.
memberOf(ugrad26_d0,dept0) :- sw338.
0.28::sw339.
takesCourse(ugrad26_d0,course6_d0) :- sw339.
0.63::sw340.
takesCourse(ugrad26_d0,course18_d0) :- sw340.
0.61::sw341.
undergraduateStudent(ugrad27_d0) :- sw341.
0.45::sw342.
memberOf(ugrad27_d0,dept0) :- sw342.
0.57::sw343.
takesCourse(ugrad27_d0,course7_d0) :- sw343.
0.08::sw344.
takesCourse(ugrad27_d0,course3_d0) :- sw344.
0.06::sw345.
advisor(ugrad27_d0,asso4_d0) :- sw345.
0.08::sw346.
undergraduateStudent(ugrad28_d0) :- sw346.
0.10::sw347.
memberOf(ugrad28_d0,dept0) :- sw347.
0.78::sw348.
takesCourse(ugrad28_d0,course10_d0) :- sw348.
0.98::sw349.
takesCourse(ugrad28_d0,course18_d0) :- sw349.
0.17::sw350.
advisor(ugrad28_d0,asso9_d0) :- sw350.
0.42::sw351.
undergraduateStudent(ugrad29_d0) :- sw351.
0.06::sw352.
memberOf(ugrad29_d0,dept0) :- sw352.
0.46::sw353.
takesCourse(ugrad29_d0,course10_d0) :- sw353.
0.68::sw354.
takesCourse(ugrad29_d0,course2_d0) :- sw354.
0.64::sw355.
undergraduateStudent(ugrad30_d0) :- sw355.
0.91::sw356.
memberOf(ugrad30_d0,dept0) :- sw356.
0.57::sw357.
takesCourse(ugrad30_d0,course11_d0) :- sw357.
0.10::sw358.
takesCourse(ugrad30_d0,course18_d0) :- sw358.
0.41::sw359.
advisor(ugrad30_d0,assi0_d0) :- sw359.
0.49::sw360.
undergraduateStudent(ugrad31_d0) :- sw360.
0.37::sw361.
memberOf(ugrad31_d0,dept0) :- sw361.
0.08::sw362.
takesCourse(ugrad31_d0,course16_d0) :- sw362.
0.65::sw363.
takesCourse(ugrad31_d0,course8_d0) :- sw363.
0.51::sw364.
undergraduateStudent(ugrad32_d0) :- sw364.
0.72::sw365.
memberOf(ugrad32_d0,dept0) :- sw365.
0.40::sw366.
takesCourse(ugrad32_d0,course13_d0) :- sw366.
0.12::sw367.
takesCourse(ugrad32_d0,course9_d0) :- sw367.
0.30::sw368.
undergraduateStudent(ugrad33_d0) :- sw368.
0.22::sw369.
memberOf(ugrad33_d0,dept0) :- sw369.
0.49::sw370.
takesCourse(ugrad33_d0,course13_d0) :- sw370.
0.20::sw371.
takesCourse(ugrad33_d0,course1_d0) :- sw371.
0.12::sw372.
undergraduateStudent(ugrad34_d0) :- sw372.
0.55::sw373.
memberOf(ugrad34_d0,dept0) :- sw373.
0.18::sw374.
takesCourse(ugrad34_d0,course4_d0) :- sw374.
0.15::sw375.
takesCourse(ugrad34_d0,course6_d0) :- sw375.
0.16::sw376.
advisor(ugrad34_d0,lect4_d0) :- sw376.
0.72::sw377.
undergraduateStudent(ugrad35_d0) :- sw377.
0.82::sw378.
memberOf(ugrad35_d0,dept0) :- sw378.
0.82::sw379.
takesCourse(ugrad35_d0,course13_d0) :- sw379.
0.60::sw380.
takesCourse(ugrad35_d0,course17_d0) :- sw380.
0.65::sw381.
undergraduateStudent(ugrad36_d0) :- sw381.
0.77::sw382.
memberOf(ugrad36_d0,dept0) :- sw382.
0.46::sw383.
takesCourse(ugrad36_d0,course7_d0) :- sw383.
0.53::sw384.
takesCourse(ugrad36_d0,course1_d0) :- sw384.
0.73::sw385.
undergraduateStudent(ugrad37_d0) :- sw385.
0.65::sw386.
memberOf(ugrad37_d0,dept0) :- sw386.
0.63::sw387.
takesCourse(ugrad37_d0,course16_d0) :- sw387.
0.66::sw388.
takesCourse(ugrad37_d0,course9_d0) :- sw388.
0.56::sw389.
undergraduateStudent(ugrad38_d0) :- sw389.
0.25::sw390.
memberOf(ugrad38_d0,dept0) :- sw390.
0.34::sw391.
takesCourse(ugrad38_d0,course7_d0) :- sw391.
0.71::sw392.
takesCourse(ugrad38_d0,course2_d0) :- sw392.
0.45::sw393.
undergraduateStudent(ugrad39_d0) :- sw393.
0.87::sw394.
memberOf(ugrad39_d0,dept0) :- sw394.
0.41::sw395.
takesCourse(ugrad39_d0,course9_d0) :- sw395.
0.69::sw396.
takesCourse(ugrad39_d0,course3_d0) :- sw396.
0.16::sw397.
undergraduateStudent(ugrad40_d0) :- sw397.
0.33::sw398.
memberOf(ugrad40_d0,dept0) :- sw398.
0.86::sw399.
takesCourse(ugrad40_d0,course1_d0) :- sw399.
0.22::sw400.
takesCourse(ugrad40_d0,course19_d0) :- sw400.
0.64::sw401.
undergraduateStudent(ugrad41_d0) :- sw401.
0.08::sw402.
memberOf(ugrad41_d0,dept0) :- sw402.
0.63::sw403.
takesCourse(ugrad41_d0,course16_d0) :- sw403.
0.48::sw404.
takesCourse(ugrad41_d0,course6_d0) :- sw404.
0.90::sw405.
undergraduateStudent(ugrad42_d0) :- sw405.
0.83::sw406.
memberOf(ugrad42_d0,dept0) :- sw406.
0.78::sw407.
takesCourse(ugrad42_d0,course13_d0) :- sw407.
0.37::sw408.
takesCourse(ugrad42_d0,course18_d0) :- sw408.
0.69::sw409.
advisor(ugrad42_d0,lect2_d0) :- sw409.
0.20::sw410.
undergraduateStudent(ugrad43_d0) :- sw410.
0.52::sw411.
memberOf(ugrad43_d0,dept0) :- sw411.
0.42::sw412.
takesCourse(ugrad43_d0,course3_d0) :- sw412.
0.50::sw413.
takesCourse(ugrad43_d0,course5_d0) :- sw413.
0.31::sw414.
undergraduateStudent(ugrad44_d0) :- sw414.
0.25::sw415.
memberOf(ugrad44_d0,dept0) :- sw415.
0.54::sw416.
takesCourse(ugrad44_d0,course7_d0) :- sw416.
0.67::sw417.
takesCourse(ugrad44_d0,course0_d0) :- sw417.
0.58::sw418.
undergraduateStudent(ugrad45_d0) :- sw418.
0.96::sw419.
memberOf(ugrad45_d0,dept0) :- sw419.
0.58::sw420.
takesCourse(ugrad45_d0,course13_d0) :- sw420.
0.19::sw421.
takesCourse(ugrad45_d0,course1_d0) :- sw421.
0.66::sw422.
undergraduateStudent(ugrad46_d0) :- sw422.
0.35::sw423.
memberOf(ugrad46_d0,dept0) :- sw423.
0.94::sw424.
takesCourse(ugrad46_d0,course19_d0) :- sw424.
0.17::sw425.
takesCourse(ugrad46_d0,course3_d0) :- sw425.
0.48::sw426.
undergraduateStudent(ugrad47_d0) :- sw426.
0.69::sw427.
memberOf(ugrad47_d0,dept0) :- sw427.
0.97::sw428.
takesCourse(ugrad47_d0,course8_d0) :- sw428.
0.55::sw429.
takesCourse(ugrad47_d0,course17_d0) :- sw429.
0.41::sw430.
undergraduateStudent(ugrad48_d0) :- sw430.
0.79::sw431.
memberOf(ugrad48_d0,dept0) :- sw431.
0.80::sw432.
takesCourse(ugrad48_d0,course1_d0) :- sw432.
0.92::sw433.
takesCourse(ugrad48_d0,course11_d0) :- sw433.
0.74::sw434.
undergraduateStudent(ugrad49_d0) :- sw434.
0.17::sw435.
memberOf(ugrad49_d0,dept0) :- sw435.
0.99::sw436.
takesCourse(ugrad49_d0,course3_d0) :- sw436.
0.93::sw437.
takesCourse(ugrad49_d0,course17_d0) :- sw437.
0.46::sw438.
undergraduateStudent(ugrad50_d0) :- sw438.
0.68::sw439.
memberOf(ugrad50_d0,dept0) :- sw439.
0.84::sw440.
takesCourse(ugrad50_d0,course3_d0) :- sw440.
0.92::sw441.
takesCourse(ugrad50_d0,course5_d0) :- sw441.
0.74::sw442.
undergraduateStudent(ugrad51_d0) :- sw442.
0.14::sw443.
memberOf(ugrad51_d0,dept0) :- sw443.
0.11::sw444.
takesCourse(ugrad51_d0,course8_d0) :- sw444.
0.40::sw445.
takesCourse(ugrad51_d0,course4_d0) :- sw445.
0.48::sw446.
undergraduateStudent(ugrad52_d0) :- sw446.
0.35::sw447.
memberOf(ugrad52_d0,dept0) :- sw447.
0.76::sw448.
takesCourse(ugrad52_d0,course0_d0) :- sw448.
0.78::sw449.
takesCourse(ugrad52_d0,course15_d0) :- sw449.
0.43::sw450.
undergraduateStudent(ugrad53_d0) :- sw450.
0.71::sw451.
memberOf(ugrad53_d0,dept0) :- sw451.
0.23::sw452.
takesCourse(ugrad53_d0,course12_d0) :- sw452.
0.95::sw453.
takesCourse(ugrad53_d0,course1_d0) :- sw453.
0.28::sw454.
undergraduateStudent(ugrad54_d0) :- sw454.
0.20::sw455.
memberOf(ugrad54_d0,dept0) :- sw455.
0.41::sw456.
takesCourse(ugrad54_d0,course7_d0) :- sw456.
0.87::sw457.
takesCourse(ugrad54_d0,course8_d0) :- sw457.
0.62::sw458.
undergraduateStudent(ugrad55_d0) :- sw458.
0.70::sw459.
memberOf(ugrad55_d0,dept0) :- sw459.
0.83::sw460.
takesCourse(ugrad55_d0,course16_d0) :- sw460.
0.42::sw461.
takesCourse(ugrad55_d0,course13_d0) :- sw461.
0.96::sw462.
advisor(ugrad55_d0,assi2_d0) :- sw462.
0.99::sw463.
undergraduateStudent(ugrad56_d0) :- sw463.
0.56::sw464.
memberOf(ugrad56_d0,dept0) :- sw464.
0.76::sw465.
takesCourse(ugrad56_d0,course0_d0) :- sw465.
0.86::sw466.
takesCourse(ugrad56_d0,course1_d0) :- sw466.
0.61::sw467.
undergraduateStudent(ugrad57_d0) :- sw467.
0.17::sw468.
memberOf(ugrad57_d0,dept0) :- sw468.
0.67::sw469.
takesCourse(ugrad57_d0,course1_d0) :- sw469.
0.48::sw470.
takesCourse(ugrad57_d0,course3_d0) :- sw470.
0.86::sw471.
advisor(ugrad57_d0,lect2_d0) :- sw471.
0.25::sw472.
undergraduateStudent(ugrad58_d0) :- sw472.
0.06::sw473.
memberOf(ugrad58_d0,dept0) :- sw473.
0.22::sw474.
takesCourse(ugrad58_d0,course1_d0) :- sw474.
0.21::sw475.
takesCourse(ugrad58_d0,course2_d0) :- sw475.
0.42::sw476.
undergraduateStudent(ugrad59_d0) :- sw476.
0.25::sw477.
memberOf(ugrad59_d0,dept0) :- sw477.
0.37::sw478.
takesCourse(ugrad59_d0,course15_d0) :- sw478.
0.61::sw479.
takesCourse(ugrad59_d0,course10_d0) :- sw479.
0.20::sw480.
advisor(ugrad59_d0,full4_d0) :- sw480.
0.51::sw481.
undergraduateStudent(ugrad60_d0) :- sw481.
0.39::sw482.
memberOf(ugrad60_d0,dept0) :- sw482.
0.05::sw483.
takesCourse(ugrad60_d0,course11_d0) :- sw483.
0.69::sw484.
takesCourse(ugrad60_d0,course12_d0) :- sw484.
0.53::sw485.
undergraduateStudent(ugrad61_d0) :- sw485.
0.79::sw486.
memberOf(ugrad61_d0,dept0) :- sw486.
0.88::sw487.
takesCourse(ugrad61_d0,course18_d0) :- sw487.
0.10::sw488.
takesCourse(ugrad61_d0,course9_d0) :- sw488.
0.73::sw489.
undergraduateStudent(ugrad62_d0) :- sw489.
0.49::sw490.
memberOf(ugrad62_d0,dept0) :- sw490.
0.88::sw491.
takesCourse(ugrad62_d0,course6_d0) :- sw491.
0.16::sw492.
takesCourse(ugrad62_d0,course10_d0) :- sw492.
0.85::sw493.
undergraduateStudent(ugrad63_d0) :- sw493.
0.46::sw494.
memberOf(ugrad63_d0,dept0) :- sw494.
0.14::sw495.
takesCourse(ugrad63_d0,course4_d0) :- sw495.
0.49::sw496.
takesCourse(ugrad63_d0,course17_d0) :- sw496.
0.88::sw497.
advisor(ugrad63_d0,assi6_d0) :- sw497.
0.12::sw498.
undergraduateStudent(ugrad64_d0) :- sw498.
0.41::sw499.
memberOf(ugrad64_d0,dept0) :- sw499.
0.13::sw500.
takesCourse(ugrad64_d0,course2_d0) :- sw500.
0.06::sw501.
takesCourse(ugrad64_d0,course18_d0) :- sw501.
0.84::sw502.
advisor(ugrad64_d0,assi5_d0) :- sw502.
0.57::sw503.
undergraduateStudent(ugrad65_d0) :- sw503.
0.59::sw504.
memberOf(ugrad65_d0,dept0) :- sw504.
0.90::sw505.
takesCourse(ugrad65_d0,course14_d0) :- sw505.
0.13::sw506.
takesCourse(ugrad65_d0,course17_d0) :- sw506.
0.95::sw507.
undergraduateStudent(ugrad66_d0) :- sw507.
0.77::sw508.
memberOf(ugrad66_d0,dept0) :- sw508.
0.86::sw509.
takesCourse(ugrad66_d0,course1_d0) :- sw509.
0.82::sw510.
takesCourse(ugrad66_d0,course13_d0) :- sw510.
0.42::sw511.
advisor(ugrad66_d0,lect3_d0) :- sw511.
0.07::sw512.
undergraduateStudent(ugrad67_d0) :- sw512.
memberOf(ugrad67_d0,dept0).
0.65::sw513.
takesCourse(ugrad67_d0,course10_d0) :- sw513.
0.73::sw514.
takesCourse(ugrad67_d0,course13_d0) :- sw514.
0.71::sw515.
undergraduateStudent(ugrad68_d0) :- sw515.
0.33::sw516.
memberOf(ugrad68_d0,dept0) :- sw516.
0.67::sw517.
takesCourse(ugrad68_d0,course13_d0) :- sw517.
0.48::sw518.
takesCourse(ugrad68_d0,course14_d0) :- sw518.
0.27::sw519.
advisor(ugrad68_d0,asso5_d0) :- sw519.
0.52::sw520.
undergraduateStudent(ugrad69_d0) :- sw520.
0.49::sw521.
memberOf(ugrad69_d0,dept0) :- sw521.
0.34::sw522.
takesCourse(ugrad69_d0,course17_d0) :- sw522.
0.76::sw523.
takesCourse(ugrad69_d0,course8_d0) :- sw523.
0.91::sw524.
undergraduateStudent(ugrad70_d0) :- sw524.
0.62::sw525.
memberOf(ugrad70_d0,dept0) :- sw525.
0.07::sw526.
takesCourse(ugrad70_d0,course2_d0) :- sw526.
0.57::sw527.
takesCourse(ugrad70_d0,course13_d0) :- sw527.
0.65::sw528.
undergraduateStudent(ugrad71_d0) :- sw528.
0.82::sw529.
memberOf(ugrad71_d0,dept0) :- sw529.
0.34::sw530.
takesCourse(ugrad71_d0,course4_d0) :- sw530.
0.27::sw531.
takesCourse(ugrad71_d0,course0_d0) :- sw531.
0.41::sw532.
undergraduateStudent(ugrad72_d0) :- sw532.
0.20::sw533.
memberOf(ugrad72_d0,dept0) :- sw533.
0.79::sw534.
takesCourse(ugrad72_d0,course11_d0) :- sw534.
0.08::sw535.
takesCourse(ugrad72_d0,course17_d0) :- sw535.
0.59::sw536.
undergraduateStudent(ugrad73_d0) :- sw536.
0.84::sw537.
memberOf(ugrad73_d0,dept0) :- sw537.
0.08::sw538.
takesCourse(ugrad73_d0,course8_d0) :- sw538.
0.21::sw539.
takesCourse(ugrad73_d0,course3_d0) :- sw539.
0.99::sw540.
undergraduateStudent(ugrad74_d0) :- sw540.
0.34::sw541.
memberOf(ugrad74_d0,dept0) :- sw541.
0.78::sw542.
takesCourse(ugrad74_d0,course3_d0) :- sw542.
0.08::sw543.
takesCourse(ugrad74_d0,course16_d0) :- sw543.
0.49::sw544.
undergraduateStudent(ugrad75_d0) :- sw544.
0.09::sw545.
memberOf(ugrad75_d0,dept0) :- sw545.
0.28::sw546.
takesCourse(ugrad75_d0,course3_d0) :- sw546.
0.07::sw547.
takesCourse(ugrad75_d0,course10_d0) :- sw547.
0.70::sw548.
undergraduateStudent(ugrad76_d0) :- sw548.
0.48::sw549.
memberOf(ugrad76_d0,dept0) :- sw549.
0.38::sw550.
takesCourse(ugrad76_d0,course3_d0) :- sw550.
0.45::sw551.
takesCourse(ugrad76_d0,course18_d0) :- sw551.
0.70::sw552.
undergraduateStudent(ugrad77_d0) :- sw552.
0.30::sw553.
memberOf(ugrad77_d0,dept0) :- sw553.
0.20::sw554.
takesCourse(ugrad77_d0,course15_d0) :- sw554.
0.09::sw555.
takesCourse(ugrad77_d0,course4_d0) :- sw555.
0.67::sw556.
undergraduateStudent(ugrad78_d0) :- sw556.
0.68::sw557.
memberOf(ugrad78_d0,dept0) :- sw557.
0.28::sw558.
takesCourse(ugrad78_d0,course12_d0) :- sw558.
0.54::sw559.
takesCourse(ugrad78_d0,course1_d0) :- sw559.
0.97::sw560.
undergraduateStudent(ugrad79_d0) :- sw560.
0.50::sw561.
memberOf(ugrad79_d0,dept0) :- sw561.
0.78::sw562.
takesCourse(ugrad79_d0,course18_d0) :- sw562.
0.38::sw563.
takesCourse(ugrad79_d0,course3_d0) :- sw563.
0.57::sw564.
undergraduateStudent(ugrad80_d0) :- sw564.
0.79::sw565.
memberOf(ugrad80_d0,dept0) :- sw565.
0.71::sw566.
takesCourse(ugrad80_d0,course12_d0) :- sw566.
0.62::sw567.
takesCourse(ugrad80_d0,course5_d0) :- sw567.
0.33::sw568.
undergraduateStudent(ugrad81_d0) :- sw568.
0.10::sw569.
memberOf(ugrad81_d0,dept0) :- sw569.
0.51::sw570.
takesCourse(ugrad81_d0,course10_d0) :- sw570.
0.74::sw571.
takesCourse(ugrad81_d0,course3_d0) :- sw571.
0.39::sw572.
advisor(ugrad81_d0,full7_d0) :- sw572.
0.74::sw573.
undergraduateStudent(ugrad82_d0) :- sw573.
0.50::sw574.
memberOf(ugrad82_d0,dept0) :- sw574.
0.12::sw575.
takesCourse(ugrad82_d0,course15_d0) :- sw575.
0.60::sw576.
takesCourse(ugrad82_d0,course9_d0) :- sw576.
0.57::sw577.
undergraduateStudent(ugrad83_d0) :- sw577.
0.36::sw578.
memberOf(ugrad83_d0,dept0) :- sw578.
0.24::sw579.
takesCourse(ugrad83_d0,course2_d0) :- sw579.
0.99::sw580.
takesCourse(ugrad83_d0,course1_d0) :- sw580.
0.61::sw581.
undergraduateStudent(ugrad84_d0) :- sw581.
0.74::sw582.
memberOf(ugrad84_d0,dept0) :- sw582.
0.09::sw583.
takesCourse(ugrad84_d0,course18_d0) :- sw583.
0.75::sw584.
takesCourse(ugrad84_d0,course16_d0) :- sw584.
0.20::sw585.
undergraduateStudent(ugrad85_d0) :- sw585.
0.51::sw586.
memberOf(ugrad85_d0,dept0) :- sw586.
0.42::sw587.
takesCourse(ugrad85_d0,course7_d0) :- sw587.
0.42::sw588.
takesCourse(ugrad85_d0,course3_d0) :- sw588.
0.80::sw589.
undergraduateStudent(ugrad86_d0) :- sw589.
0.24::sw590.
memberOf(ugrad86_d0,dept0) :- sw590.
0.95::sw591.
takesCourse(ugrad86_d0,course3_d0) :- sw591.
0.86::sw592.
takesCourse(ugrad86_d0,course17_d0) :- sw592.
0.52::sw593.
advisor(ugrad86_d0,assi2_d0) :- sw593.
0.88::sw594.
undergraduateStudent(ugrad87_d0) :- sw594.
0.57::sw595.
memberOf(ugrad87_d0,dept0) :- sw595.
0.92::sw596.
takesCourse(ugrad87_d0,course18_d0) :- sw596.
0.51::sw597.
takesCourse(ugrad87_d0,course5_d0) :- sw597.
0.98::sw598.
undergraduateStudent(ugrad88_d0) :- sw598.
0.76::sw599.
memberOf(ugrad88_d0,dept0) :- sw599.
0.68::sw600.
takesCourse(ugrad88_d0,course7_d0) :- sw600.
0.99::sw601.
takesCourse(ugrad88_d0,course5_d0) :- sw601.
0.71::sw602.
undergraduateStudent(ugrad89_d0) :- sw602.
0.28::sw603.
memberOf(ugrad89_d0,dept0) :- sw603.
0.66::sw604.
takesCourse(ugrad89_d0,course14_d0) :- sw604.
0.21::sw605.
takesCourse(ugrad89_d0,course12_d0) :- sw605.
0.43::sw606.
undergraduateStudent(ugrad90_d0) :- sw606.
0.72::sw607.
memberOf(ugrad90_d0,dept0) :- sw607.
0.23::sw608.
takesCourse(ugrad90_d0,course19_d0) :- sw608.
0.45::sw609.
takesCourse(ugrad90_d0,course12_d0) :- sw609.
0.27::sw610.
undergraduateStudent(ugrad91_d0) :- sw610.
0.44::sw611.
memberOf(ugrad91_d0,dept0) :- sw611.
0.27::sw612.
takesCourse(ugrad91_d0,course17_d0) :- sw612.
0.72::sw613.
takesCourse(ugrad91_d0,course13_d0) :- sw613.
0.84::sw614.
undergraduateStudent(ugrad92_d0) :- sw614.
0.51::sw615.
memberOf(ugrad92_d0,dept0) :- sw615.
0.73::sw616.
takesCourse(ugrad92_d0,course12_d0) :- sw616.
0.77::sw617.
takesCourse(ugrad92_d0,course16_d0) :- sw617.
0.82::sw618.
undergraduateStudent(ugrad93_d0) :- sw618.
0.81::sw619.
memberOf(ugrad93_d0,dept0) :- sw619.
0.67::sw620.
takesCourse(ugrad93_d0,course13_d0) :- sw620.
0.75::sw621.
takesCourse(ugrad93_d0,course5_d0) :- sw621.
0.74::sw622.
undergraduateStudent(ugrad94_d0) :- sw622.
0.55::sw623.
memberOf(ugrad94_d0,dept0) :- sw623.
0.81::sw624.
takesCourse(ugrad94_d0,course18_d0) :- sw624.
0.23::sw625.
takesCourse(ugrad94_d0,course19_d0) :- sw625.
0.73::sw626.
undergraduateStudent(ugrad95_d0) :- sw626.
0.66::sw627.
memberOf(ugrad95_d0,dept0) :- sw627.
0.56::sw628.
takesCourse(ugrad95_d0,course16_d0) :- sw628.
0.62::sw629.
takesCourse(ugrad95_d0,course15_d0) :- sw629.
0.92::sw630.
advisor(ugrad95_d0,assi7_d0) :- sw630.
0.80::sw631.
undergraduateStudent(ugrad96_d0) :- sw631.
0.71::sw632.
memberOf(ugrad96_d0,dept0) :- sw632.
0.91::sw633.
takesCourse(ugrad96_d0,course4_d0) :- sw633.
0.88::sw634.
takesCourse(ugrad96_d0,course5_d0) :- sw634.
0.36::sw635.
advisor(ugrad96_d0,lect2_d0) :- sw635.
0.87::sw636.
undergraduateStudent(ugrad97_d0) :- sw636.
0.89::sw637.
memberOf(ugrad97_d0,dept0) :- sw637.
0.60::sw638.
takesCourse(ugrad97_d0,course16_d0) :- sw638.
0.93::sw639.
takesCourse(ugrad97_d0,course14_d0) :- sw639.
0.22::sw640.
undergraduateStudent(ugrad98_d0) :- sw640.
0.81::sw641.
memberOf(ugrad98_d0,dept0) :- sw641.
0.28::sw642.
takesCourse(ugrad98_d0,course5_d0) :- sw642.
0.43::sw643.
takesCourse(ugrad98_d0,course4_d0) :- sw643.
0.53::sw644.
undergraduateStudent(ugrad99_d0) :- sw644.
0.45::sw645.
memberOf(ugrad99_d0,dept0) :- sw645.
0.54::sw646.
takesCourse(ugrad99_d0,course6_d0) :- sw646.
0.14::sw647.
takesCourse(ugrad99_d0,course4_d0) :- sw647.
0.11::sw648.
undergraduateStudent(ugrad100_d0) :- sw648.
0.74::sw649.
memberOf(ugrad100_d0,dept0) :- sw649.
0.31::sw650.
takesCourse(ugrad100_d0,course10_d0) :- sw650.
0.31::sw651.
takesCourse(ugrad100_d0,course7_d0) :- sw651.
0.72::sw652.
undergraduateStudent(ugrad101_d0) :- sw652.
0.77::sw653.
memberOf(ugrad101_d0,dept0) :- sw653.
0.56::sw654.
takesCourse(ugrad101_d0,course17_d0) :- sw654.
0.83::sw655.
takesCourse(ugrad101_d0,course9_d0) :- sw655.
0.38::sw656.
undergraduateStudent(ugrad102_d0) :- sw656.
0.90::sw657.
memberOf(ugrad102_d0,dept0) :- sw657.
0.66::sw658.
takesCourse(ugrad102_d0,course13_d0) :- sw658.
0.85::sw659.
takesCourse(ugrad102_d0,course18_d0) :- sw659.
0.82::sw660.
undergraduateStudent(ugrad103_d0) :- sw660.
0.72::sw661.
memberOf(ugrad103_d0,dept0) :- sw661.
0.93::sw662.
takesCourse(ugrad103_d0,course8_d0) :- sw662.
0.77::sw663.
takesCourse(ugrad103_d0,course6_d0) :- sw663.
0.48::sw664.
undergraduateStudent(ugrad104_d0) :- sw664.
0.16::sw665.
memberOf(ugrad104_d0,dept0) :- sw665.
0.43::sw666.
takesCourse(ugrad104_d0,course8_d0) :- sw666.
0.63::sw667.
takesCourse(ugrad104_d0,course15_d0) :- sw667.
0.07::sw668.
undergraduateStudent(ugrad105_d0) :- sw668.
0.62::sw669.
memberOf(ugrad105_d0,dept0) :- sw669.
0.44::sw670.
takesCourse(ugrad105_d0,course6_d0) :- sw670.
0.50::sw671.
takesCourse(ugrad105_d0,course5_d0) :- sw671.
0.11::sw672.
undergraduateStudent(ugrad106_d0) :- sw672.
0.12::sw673.
memberOf(ugrad106_d0,dept0) :- sw673.
0.67::sw674.
takesCourse(ugrad106_d0,course7_d0) :- sw674.
0.31::sw675.
takesCourse(ugrad106_d0,course10_d0) :- sw675.
0.20::sw676.
undergraduateStudent(ugrad107_d0) :- sw676.
0.87::sw677.
memberOf(ugrad107_d0,dept0) :- sw677.
0.10::sw678.
takesCourse(ugrad107_d0,course4_d0) :- sw678.
0.72::sw679.
takesCourse(ugrad107_d0,course13_d0) :- sw679.
0.83::sw680.
undergraduateStudent(ugrad108_d0) :- sw680.
0.90::sw681.
memberOf(ugrad108_d0,dept0) :- sw681.
0.68::sw682.
takesCourse(ugrad108_d0,course15_d0) :- sw682.
0.10::sw683.
takesCourse(ugrad108_d0,course6_d0) :- sw683.
0.47::sw684.
undergraduateStudent(ugrad109_d0) :- sw684.
0.88::sw685.
memberOf(ugrad109_d0,dept0) :- sw685.
0.44::sw686.
takesCourse(ugrad109_d0,course17_d0) :- sw686.
0.56::sw687.
takesCourse(ugrad109_d0,course0_d0) :- sw687.
0.76::sw688.
undergraduateStudent(ugrad110_d0) :- sw688.
0.60::sw689.
memberOf(ugrad110_d0,dept0) :- sw689.
0.39::sw690.
takesCourse(ugrad110_d0,course2_d0) :- sw690.
0.61::sw691.
takesCourse(ugrad110_d0,course12_d0) :- sw691.
0.49::sw692.
undergraduateStudent(ugrad111_d0) :- sw692.
0.37::sw693.
memberOf(ugrad111_d0,dept0) :- sw693.
0.12::sw694.
takesCourse(ugrad111_d0,course1_d0) :- sw694.
0.30::sw695.
takesCourse(ugrad111_d0,course14_d0) :- sw695.
undergraduateStudent(ugrad112_d0).
0.33::sw696.
memberOf(ugrad112_d0,dept0) :- sw696.
0.38::sw697.
takesCourse(ugrad112_d0,course7_d0) :- sw697.
0.98::sw698.
takesCourse(ugrad112_d0,course2_d0) :- sw698.
0.15::sw699.
undergraduateStudent(ugrad113_d0) :- sw699.
0.29::sw700.
memberOf(ugrad113_d0,dept0) :- sw700.
0.41::sw701.
takesCourse(ugrad113_d0,course8_d0) :- sw701.
0.49::sw702.
takesCourse(ugrad113_d0,course7_d0) :- sw702.
0.43::sw703.
undergraduateStudent(ugrad114_d0) :- sw703.
0.31::sw704.
memberOf(ugrad114_d0,dept0) :- sw704.
0.19::sw705.
takesCourse(ugrad114_d0,course8_d0) :- sw705.
0.58::sw706.
takesCourse(ugrad114_d0,course4_d0) :- sw706.
0.21::sw707.
advisor(ugrad114_d0,full2_d0) :- sw707.
0.05::sw708.
undergraduateStudent(ugrad115_d0) :- sw708.
0.77::sw709.
memberOf(ugrad115_d0,dept0) :- sw709.
0.78::sw710.
takesCourse(ugrad115_d0,course8_d0) :- sw710.
0.39::sw711.
takesCourse(ugrad115_d0,course5_d0) :- sw711.
0.89::sw712.
undergraduateStudent(ugrad116_d0) :- sw712.
0.20::sw713.
memberOf(ugrad116_d0,dept0) :- sw713.
0.91::sw714.
takesCourse(ugrad116_d0,course10_d0) :- sw714.
0.70::sw715.
takesCourse(ugrad116_d0,course5_d0) :- sw715.
0.69::sw716.
undergraduateStudent(ugrad117_d0) :- sw716.
0.10::sw717.
memberOf(ugrad117_d0,dept0) :- sw717.
0.77::sw718.
takesCourse(ugrad117_d0,course2_d0) :- sw718.
0.21::sw719.
takesCourse(ugrad117_d0,course3_d0) :- sw719.
0.56::sw720.
advisor(ugrad117_d0,assi0_d0) :- sw720.
0.57::sw721.
undergraduateStudent(ugrad118_d0) :- sw721.
0.11::sw722.
memberOf(ugrad118_d0,dept0) :- sw722.
0.33::sw723.
takesCourse(ugrad118_d0,course1_d0) :- sw723.
0.92::sw724.
takesCourse(ugrad118_d0,course11_d0) :- sw724.
0.77::sw725.
undergraduateStudent(ugrad119_d0) :- sw725.
0.34::sw726.
memberOf(ugrad119_d0,dept0) :- sw726.
0.98::sw727.
takesCourse(ugrad119_d0,course10_d0) :- sw727.
0.12::sw728.
takesCourse(ugrad119_d0,course0_d0) :- sw728.
0.67::sw729.
advisor(ugrad119_d0,assi3_d0) :- sw729.
0.81::sw730.
undergraduateStudent(ugrad120_d0) :- sw730.
0.86::sw731.
memberOf(ugrad120_d0,dept0) :- sw731.
0.66::sw732.
takesCourse(ugrad120_d0,course13_d0) :- sw732.
0.75::sw733.
takesCourse(ugrad120_d0,course12_d0) :- sw733.
0.28::sw734.
undergraduateStudent(ugrad121_d0) :- sw734.
0.79::sw735.
memberOf(ugrad121_d0,dept0) :- sw735.
0.70::sw736.
takesCourse(ugrad121_d0,course6_d0) :- sw736.
0.60::sw737.
takesCourse(ugrad121_d0,course18_d0) :- sw737.
0.30::sw738.
undergraduateStudent(ugrad122_d0) :- sw738.
0.69::sw739.
memberOf(ugrad122_d0,dept0) :- sw739.
0.10::sw740.
takesCourse(ugrad122_d0,course15_d0) :- sw740.
0.53::sw741.
takesCourse(ugrad122_d0,course12_d0) :- sw741.
0.67::sw742.
advisor(ugrad122_d0,assi2_d0) :- sw742.
0.37::sw743.
undergraduateStudent(ugrad123_d0) :- sw743.
0.62::sw744.
memberOf(ugrad123_d0,dept0) :- sw744.
0.10::sw745.
takesCourse(ugrad123_d0,course3_d0) :- sw745.
0.37::sw746.
takesCourse(ugrad123_d0,course8_d0) :- sw746.
0.52::sw747.
advisor(ugrad123_d0,assi9_d0) :- sw747.
0.84::sw748.
undergraduateStudent(ugrad124_d0) :- sw748.
0.56::sw749.
memberOf(ugrad124_d0,dept0) :- sw749.
0.93::sw750.
takesCourse(ugrad124_d0,course3_d0) :- sw750.
0.40::sw751.
takesCourse(ugrad124_d0,course14_d0) :- sw751.
0.90::sw752.
undergraduateStudent(ugrad125_d0) :- sw752.
0.60::sw753.
memberOf(ugrad125_d0,dept0) :- sw753.
0.50::sw754.
takesCourse(ugrad125_d0,course8_d0) :- sw754.
0.22::sw755.
takesCourse(ugrad125_d0,course3_d0) :- sw755.
0.84::sw756.
undergraduateStudent(ugrad126_d0) :- sw756.
0.81::sw757.
memberOf(ugrad126_d0,dept0) :- sw757.
0.42::sw758.
takesCourse(ugrad126_d0,course11_d0) :- sw758.
0.36::sw759.
takesCourse(ugrad126_d0,course19_d0) :- sw759.
0.31::sw760.
undergraduateStudent(ugrad127_d0) :- sw760.
0.37::sw761.
memberOf(ugrad127_d0,dept0) :- sw761.
0.14::sw762.
takesCourse(ugrad127_d0,course9_d0) :- sw762.
0.86::sw763.
takesCourse(ugrad127_d0,course8_d0) :- sw763.
0.46::sw764.
advisor(ugrad127_d0,assi3_d0) :- sw764.
0.22::sw765.
undergraduateStudent(ugrad128_d0) :- sw765.
0.70::sw766.
memberOf(ugrad128_d0,dept0) :- sw766.
0.22::sw767.
takesCourse(ugrad128_d0,course18_d0) :- sw767.
0.89::sw768.
takesCourse(ugrad128_d0,course17_d0) :- sw768.
0.05::sw769.
undergraduateStudent(ugrad129_d0) :- sw769.
0.58::sw770.
memberOf(ugrad129_d0,dept0) :- sw770.
0.66::sw771.
takesCourse(ugrad129_d0,course15_d0) :- sw771.
0.38::sw772.
takesCourse(ugrad129_d0,course16_d0) :- sw772.
0.23::sw773.
undergraduateStudent(ugrad130_d0) :- sw773.
0.90::sw774.
memberOf(ugrad130_d0,dept0) :- sw774.
0.61::sw775.
takesCourse(ugrad130_d0,course9_d0) :- sw775.
0.71::sw776.
takesCourse(ugrad130_d0,course18_d0) :- sw776.
0.21::sw777.
undergraduateStudent(ugrad131_d0) :- sw777.
0.06::sw778.
memberOf(ugrad131_d0,dept0) :- sw778.
0.91::sw779.
takesCourse(ugrad131_d0,course4_d0) :- sw779.
0.23::sw780.
takesCourse(ugrad131_d0,course5_d0) :- sw780.
0.10::sw781.
undergraduateStudent(ugrad132_d0) :- sw781.
0.79::sw782.
memberOf(ugrad132_d0,dept0) :- sw782.
0.59::sw783.
takesCourse(ugrad132_d0,course14_d0) :- sw783.
0.07::sw784.
takesCourse(ugrad132_d0,course3_d0) :- sw784.
0.58::sw785.
advisor(ugrad132_d0,asso1_d0) :- sw785.
0.53::sw786.
undergraduateStudent(ugrad133_d0) :- sw786.
0.93::sw787.
memberOf(ugrad133_d0,dept0) :- sw787.
0.61::sw788.
takesCourse(ugrad133_d0,course10_d0) :- sw788.
0.19::sw789.
takesCourse(ugrad133_d0,course13_d0) :- sw789.
0.64::sw790.
undergraduateStudent(ugrad134_d0) :- sw790.
0.81::sw791.
memberOf(ugrad134_d0,dept0) :- sw791.
0.97::sw792.
takesCourse(ugrad134_d0,course5_d0) :- sw792.
0.35::sw793.
takesCourse(ugrad134_d0,course14_d0) :- sw793.
0.60::sw794.
undergraduateStudent(ugrad135_d0) :- sw794.
0.10::sw795.
memberOf(ugrad135_d0,dept0) :- sw795.
0.96::sw796.
takesCourse(ugrad135_d0,course5_d0) :- sw796.
0.19::sw797.
takesCourse(ugrad135_d0,course2_d0) :- sw797.
0.67::sw798.
advisor(ugrad135_d0,asso3_d0) :- sw798.
0.86::sw799.
undergraduateStudent(ugrad136_d0) :- sw799.
0.51::sw800.
memberOf(ugrad136_d0,dept0) :- sw800.
0.98::sw801.
takesCourse(ugrad136_d0,course17_d0) :- sw801.
0.44::sw802.
takesCourse(ugrad136_d0,course19_d0) :- sw802.
0.59::sw803.
undergraduateStudent(ugrad137_d0) :- sw803.
0.86::sw804.
memberOf(ugrad137_d0,dept0) :- sw804.
0.07::sw805.
takesCourse(ugrad137_d0,course12_d0) :- sw805.
0.87::sw806.
takesCourse(ugrad137_d0,course11_d0) :- sw806.
0.85::sw807.
advisor(ugrad137_d0,asso9_d0) :- sw807.
0.21::sw808.
undergraduateStudent(ugrad138_d0) :- sw808.
0.71::sw809.
memberOf(ugrad138_d0,dept0) :- sw809.
0.31::sw810.
takesCourse(ugrad138_d0,course12_d0) :- sw810.
0.23::sw811.
takesCourse(ugrad138_d0,course1_d0) :- sw811.
0.54::sw812.
undergraduateStudent(ugrad139_d0) :- sw812.
0.73::sw813.
memberOf(ugrad139_d0,dept0) :- sw813.
0.41::sw814.
takesCourse(ugrad139_d0,course1_d0) :- sw814.
0.37::sw815.
takesCourse(ugrad139_d0,course15_d0) :- sw815.
0.26::sw816.
undergraduateStudent(ugrad140_d0) :- sw816.
0.60::sw817.
memberOf(ugrad140_d0,dept0) :- sw817.
0.60::sw818.
takesCourse(ugrad140_d0,course7_d0) :- sw818.
0.87::sw819.
takesCourse(ugrad140_d0,course16_d0) :- sw819.
0.84::sw820.
undergraduateStudent(ugrad141_d0) :- sw820.
0.06::sw821.
memberOf(ugrad141_d0,dept0) :- sw821.
0.19::sw822.
takesCourse(ugrad141_d0,course10_d0) :- sw822.
0.18::sw823.
takesCourse(ugrad141_d0,course12_d0) :- sw823.
0.31::sw824.
undergraduateStudent(ugrad142_d0) :- sw824.
0.76::sw825.
memberOf(ugrad142_d0,dept0) :- sw825.
0.51::sw826.
takesCourse(ugrad142_d0,course2_d0) :- sw826.
0.74::sw827.
takesCourse(ugrad142_d0,course11_d0) :- sw827.
0.85::sw828.
undergraduateStudent(ugrad143_d0) :- sw828.
0.40::sw829.
memberOf(ugrad143_d0,dept0) :- sw829.
0.05::sw830.
takesCourse(ugrad143_d0,course3_d0) :- sw830.
0.25::sw831.
takesCourse(ugrad143_d0,course4_d0) :- sw831.
0.64::sw832.
undergraduateStudent(ugrad144_d0) :- sw832.
0.59::sw833.
memberOf(ugrad144_d0,dept0) :- sw833.
0.24::sw834.
takesCourse(ugrad144_d0,course3_d0) :- sw834.
0.77::sw835.
takesCourse(ugrad144_d0,course19_d0) :- sw835.
0.08::sw836.
undergraduateStudent(ugrad145_d0) :- sw836.
0.20::sw837.
memberOf(ugrad145_d0,dept0) :- sw837.
0.54::sw838.
takesCourse(ugrad145_d0,course3_d0) :- sw838.
0.62::sw839.
takesCourse(ugrad145_d0,course5_d0) :- sw839.
0.92::sw840.
undergraduateStudent(ugrad146_d0) :- sw840.
0.41::sw841.
memberOf(ugrad146_d0,dept0) :- sw841.
0.82::sw842.
takesCourse(ugrad146_d0,course18_d0) :- sw842.
0.50::sw843.
takesCourse(ugrad146_d0,course13_d0) :- sw843.
0.34::sw844.
undergraduateStudent(ugrad147_d0) :- sw844.
0.96::sw845.
memberOf(ugrad147_d0,dept0) :- sw845.
0.52::sw846.
takesCourse(ugrad147_d0,course12_d0) :- sw846.
0.72::sw847.
takesCourse(ugrad147_d0,course4_d0) :- sw847.
0.33::sw848.
undergraduateStudent(ugrad148_d0) :- sw848.
0.89::sw849.
memberOf(ugrad148_d0,dept0) :- sw849.
0.50::sw850.
takesCourse(ugrad148_d0,course4_d0) :- sw850.
0.09::sw851.
takesCourse(ugrad148_d0,course12_d0) :- sw851.
0.11::sw852.
undergraduateStudent(ugrad149_d0) :- sw852.
0.39::sw853.
memberOf(ugrad149_d0,dept0) :- sw853.
0.46::sw854.
takesCourse(ugrad149_d0,course17_d0) :- sw854.
0.16::sw855.
takesCourse(ugrad149_d0,course16_d0) :- sw855.
0.86::sw856.
advisor(ugrad149_d0,asso3_d0) :- sw856.
0.58::sw857.
graduateStudent(grad0_d0) :- sw857.
0.95::sw858.
memberOf(grad0_d0,dept0) :- sw858.
0.67::sw859.
undergraduateDegreeFrom(grad0_d0,univ3) :- sw859.
0.81::sw860.
advisor(grad0_d0,asso8_d0) :- sw860.
0.21::sw861.
takesCourse(grad0_d0,gradCourse5_d0) :- sw861.
0.09::sw862.
takesCourse(grad0_d0,gradCourse4_d0) :- sw862.
0.27::sw863.
teachingAssistantOf(grad0_d0,course14_d0) :- sw863.
0.45::sw864.
graduateStudent(grad1_d0) :- sw864.
0.10::sw865.
memberOf(grad1_d0,dept0) :- sw865.
0.93::sw866.
undergraduateDegreeFrom(grad1_d0,univ6) :- sw866.
0.33::sw867.
advisor(grad1_d0,assi6_d0) :- sw867.
0.80::sw868.
takesCourse(grad1_d0,gradCourse5_d0) :- sw868.
0.09::sw869.
takesCourse(grad1_d0,gradCourse8_d0) :- sw869.
0.86::sw870.
graduateStudent(grad2_d0) :- sw870.
0.37::sw871.
memberOf(grad2_d0,dept0) :- sw871.
0.54::sw872.
undergraduateDegreeFrom(grad2_d0,univ4) :- sw872.
0.63::sw873.
advisor(grad2_d0,lect3_d0) :- sw873.
0.63::sw874.
takesCourse(grad2_d0,gradCourse8_d0) :- sw874.
0.33::sw875.
takesCourse(grad2_d0,gradCourse4_d0) :- sw875.
0.29::sw876.
graduateStudent(grad3_d0) :- sw876.
0.42::sw877.
memberOf(grad3_d0,dept0) :- sw877.
0.58::sw878.
undergraduateDegreeFrom(grad3_d0,univ7) :- sw878.
0.05::sw879.
advisor(grad3_d0,full1_d0) :- sw879.
0.27::sw880.
takesCourse(grad3_d0,gradCourse9_d0) :- sw880.
0.12::sw881.
takesCourse(grad3_d0,gradCourse3_d0) :- sw881.
0.84::sw882.
graduateStudent(grad4_d0) :- sw882.
0.72::sw883.
memberOf(grad4_d0,dept0) :- sw883.
0.84::sw884.
undergraduateDegreeFrom(grad4_d0,univ0) :- sw884.
0.69::sw885.
advisor(grad4_d0,full6_d0) :- sw885.
0.08::sw886.
takesCourse(grad4_d0,gradCourse3_d0) :- sw886.
0.36::sw887.
takesCourse(grad4_d0,gradCourse7_d0) :- sw887.
0.89::sw888.
teachingAssistantOf(grad4_d0,course14_d0) :- sw888.
0.49::sw889.
graduateStudent(grad5_d0) :- sw889.
0.36::sw890.
memberOf(grad5_d0,dept0) :- sw890.
0.20::sw891.
undergraduateDegreeFrom(grad5_d0,univ3) :- sw891.
0.92::sw892.
advisor(grad5_d0,asso4_d0) :- sw892.
0.14::sw893.
takesCourse(grad5_d0,gradCourse8_d0) :- sw893.
0.39::sw894.
takesCourse(grad5_d0,gradCourse3_d0) :- sw894.
0.35::sw895.
teachingAssistantOf(grad5_d0,course16_d0) :- sw895.
0.66::sw896.
graduateStudent(grad6_d0) :- sw896.
0.92::sw897.
memberOf(grad6_d0,dept0) :- sw897.
0.75::sw898.
undergraduateDegreeFrom(grad6_d0,univ7) :- sw898.
0.97::sw899.
advisor(grad6_d0,full7_d0) :- sw899.
0.32::sw900.
takesCourse(grad6_d0,gradCourse9_d0) :- sw900.
0.76::sw901.
takesCourse(grad6_d0,gradCourse4_d0) :- sw901.
0.73::sw902.
graduateStudent(grad7_d0) :- sw902.
0.10::sw903.
memberOf(grad7_d0,dept0) :- sw903.
0.60::sw904.
undergraduateDegreeFrom(grad7_d0,univ2) :- sw904.
0.88::sw905.
advisor(grad7_d0,asso0_d0) :- sw905.
0.08::sw906.
takesCourse(grad7_d0,gradCourse7_d0) :- sw906.
0.27::sw907.
takesCourse(grad7_d0,gradCourse1_d0) :- sw907.
0.56::sw908.
graduateStudent(grad8_d0) :- sw908.
0.63::sw909.
memberOf(grad8_d0,dept0) :- sw909.
0.57::sw910.
undergraduateDegreeFrom(grad8_d0,univ0) :- sw910.
0.89::sw911.
advisor(grad8_d0,full1_d0) :- sw911.
0.41::sw912.
takesCourse(grad8_d0,gradCourse5_d0) :- sw912.
0.68::sw913.
takesCourse(grad8_d0,gradCourse3_d0) :- sw913.
0.57::sw914.
graduateStudent(grad9_d0) :- sw914.
0.83::sw915.
memberOf(grad9_d0,dept0) :- sw915.
0.42::sw916.
undergraduateDegreeFrom(grad9_d0,univ7) :- sw916.
0.92::sw917.
advisor(grad9_d0,full1_d0) :- sw917.
0.86::sw918.
takesCourse(grad9_d0,gradCourse5_d0) :- sw918.
0.74::sw919.
takesCourse(grad9_d0,gradCourse9_d0) :- sw919.
0.92::sw920.
graduateStudent(grad10_d0) :- sw920.
0.68::sw921.
memberOf(grad10_d0,dept0) :- sw921.
0.33::sw922.
undergraduateDegreeFrom(grad10_d0,univ5) :- sw922.
0.96::sw923.
advisor(grad10_d0,asso0_d0) :- sw923.
0.38::sw924.
takesCourse(grad10_d0,gradCourse1_d0) :- sw924.
0.38::sw925.
takesCourse(grad10_d0,gradCourse0_d0) :- sw925.
0.65::sw926.
graduateStudent(grad11_d0) :- sw926.
0.53::sw927.
memberOf(grad11_d0,dept0) :- sw927.
undergraduateDegreeFrom(grad11_d0,univ5).
0.44::sw928.
advisor(grad11_d0,asso5_d0) :- sw928.
0.94::sw929.
takesCourse(grad11_d0,gradCourse1_d0) :- sw929.
0.48::sw930.
takesCourse(grad11_d0,gradCourse3_d0) :- sw930.
0.26::sw931.
graduateStudent(grad12_d0) :- sw931.
0.56::sw932.
memberOf(grad12_d0,dept0) :- sw932.
0.69::sw933.
undergraduateDegreeFrom(grad12_d0,univ3) :- sw933.
0.34::sw934.
advisor(grad12_d0,lect3_d0) :- sw934.
0.61::sw935.
takesCourse(grad12_d0,gradCourse5_d0) :- sw935.
0.47::sw936.
takesCourse(grad12_d0,gradCourse1_d0) :- sw936.
0.07::sw937.
graduateStudent(grad13_d0) :- sw937.
0.11::sw938.
memberOf(grad13_d0,dept0) :- sw938.
0.41::sw939.
undergraduateDegreeFrom(grad13_d0,univ6) :- sw939.
0.72::sw940.
advisor(grad13_d0,full4_d0) :- sw940.
0.20::sw941.
takesCourse(grad13_d0,gradCourse3_d0) :- sw941.
0.96::sw942.
takesCourse(grad13_d0,gradCourse2_d0) :- sw942.
0.39::sw943.
graduateStudent(grad14_d0) :- sw943.
0.15::sw944.
memberOf(grad14_d0,dept0) :- sw944.
0.23::sw945.
undergraduateDegreeFrom(grad14_d0,univ7) :- sw945.
0.92::sw946.
advisor(grad14_d0,full4_d0) :- sw946.
0.85::sw947.
takesCourse(grad14_d0,gradCourse8_d0) :- sw947.
0.68::sw948.
takesCourse(grad14_d0,gradCourse6_d0) :- sw948.
0.11::sw949.
teachingAssistantOf(grad14_d0,course15_d0) :- sw949.
0.66::sw950.
graduateStudent(grad15_d0) :- sw950.
0.07::sw951.
memberOf(grad15_d0,dept0) :- sw951.
0.27::sw952.
undergraduateDegreeFrom(grad15_d0,univ4) :- sw952.
0.11::sw953.
advisor(grad15_d0,full1_d0) :- sw953.
0.69::sw954.
takesCourse(grad15_d0,gradCourse7_d0) :- sw954.
0.83::sw955.
takesCourse(grad15_d0,gradCourse9_d0) :- sw955.
0.30::sw956.
graduateStudent(grad16_d0) :- sw956.
memberOf(grad16_d0,dept0).
0.57::sw957.
undergraduateDegreeFrom(grad16_d0,univ6) :- sw957.
0.86::sw958.
advisor(grad16_d0,lect0_d0) :- sw958.
0.24::sw959.
takesCourse(grad16_d0,gradCourse2_d0) :- sw959.
0.81::sw960.
takesCourse(grad16_d0,gradCourse7_d0) :- sw960.
0.65::sw961.
graduateStudent(grad17_d0) :- sw961.
0.12::sw962.
memberOf(grad17_d0,dept0) :- sw962.
0.78::sw963.
undergraduateDegreeFrom(grad17_d0,univ4) :- sw963.
0.78::sw964.
advisor(grad17_d0,assi5_d0) :- sw964.
0.41::sw965.
takesCourse(grad17_d0,gradCourse5_d0) :- sw965.
0.30::sw966.
takesCourse(grad17_d0,gradCourse7_d0) :- sw966.
0.12::sw967.
graduateStudent(grad18_d0) :- sw967.
0.62::sw968.
memberOf(grad18_d0,dept0) :- sw968.
0.33::sw969.
undergraduateDegreeFrom(grad18_d0,univ9) :- sw969.
0.27::sw970.
advisor(grad18_d0,assi7_d0) :- sw970.
0.48::sw971.
takesCourse(grad18_d0,gradCourse3_d0) :- sw971.
0.17::sw972.
takesCourse(grad18_d0,gradCourse0_d0) :- sw972.
0.68::sw973.
graduateStudent(grad19_d0) :- sw973.
0.36::sw974.
memberOf(grad19_d0,dept0) :- sw974.
0.33::sw975.
undergraduateDegreeFrom(grad19_d0,univ4) :- sw975.
0.46::sw976.
advisor(grad19_d0,assi5_d0) :- sw976.
0.46::sw977.
takesCourse(grad19_d0,gradCourse2_d0) :- sw977.
0.46::sw978.
takesCourse(grad19_d0,gradCourse7_d0) :- sw978.
0.29::sw979.
graduateStudent(grad20_d0) :- sw979.
0.77::sw980.
memberOf(grad20_d0,dept0) :- sw980.
0.90::sw981.
undergraduateDegreeFrom(grad20_d0,univ2) :- sw981.
0.59::sw982.
advisor(grad20_d0,asso5_d0) :- sw982.
0.74::sw983.
takesCourse(grad20_d0,gradCourse0_d0) :- sw983.
0.82::sw984.
takesCourse(grad20_d0,gradCourse2_d0) :- sw984.
0.32::sw985.
graduateStudent(grad21_d0) :- sw985.
0.88::sw986.
memberOf(grad21_d0,dept0) :- sw986.
0.59::sw987.
undergraduateDegreeFrom(grad21_d0,univ8) :- sw987.
0.65::sw988.
advisor(grad21_d0,asso2_d0) :- sw988.
0.58::sw989.
takesCourse(grad21_d0,gradCourse0_d0) :- sw989.
0.89::sw990.
takesCourse(grad21_d0,gradCourse2_d0) :- sw990.
0.52::sw991.
teachingAssistantOf(grad21_d0,course5_d0) :- sw991.
0.72::sw992.
graduateStudent(grad22_d0) :- sw992.
0.30::sw993.
memberOf(grad22_d0,dept0) :- sw993.
0.20::sw994.
undergraduateDegreeFrom(grad22_d0,univ7) :- sw994.
0.56::sw995.
advisor(grad22_d0,lect3_d0) :- sw995.
0.83::sw996.
takesCourse(grad22_d0,gradCourse2_d0) :- sw996.
0.19::sw997.
takesCourse(grad22_d0,gradCourse0_d0) :- sw997.
0.74::sw998.
graduateStudent(grad23_d0) :- sw998.
0.31::sw999.
memberOf(grad23_d0,dept0) :- sw999.
0.16::sw1000.
undergraduateDegreeFrom(grad23_d0,univ6) :- sw1000.
0.82::sw1001.
advisor(grad23_d0,lect0_d0) :- sw1001.
0.11::sw1002.
takesCourse(grad23_d0,gradCourse5_d0) :- sw1002.
0.45::sw1003.
takesCourse(grad23_d0,gradCourse6_d0) :- sw1003.
0.67::sw1004.
teachingAssistantOf(grad23_d0,course1_d0) :- sw1004.
0.72::sw1005.
graduateStudent(grad24_d0) :- sw1005.
0.78::sw1006.
memberOf(grad24_d0,dept0) :- sw1006.
0.14::sw1007.
undergraduateDegreeFrom(grad24_d0,univ3) :- sw1007.
0.17::sw1008.
advisor(grad24_d0,assi7_d0) :- sw1008.
0.34::sw1009.
takesCourse(grad24_d0,gradCourse0_d0) :- sw1009.
0.85::sw1010.
takesCourse(grad24_d0,gradCourse6_d0) :- sw1010.
0.90::sw1011.
graduateStudent(grad25_d0) :- sw1011.
0.45::sw1012.
memberOf(grad25_d0,dept0) :- sw1012.
0.32::sw1013.
undergraduateDegreeFrom(grad25_d0,univ3) :- sw1013.
0.63::sw1014.
advisor(grad25_d0,asso7_d0) :- sw1014.
0.46::sw1015.
takesCourse(grad25_d0,gradCourse1_d0) :- sw1015.
0.07::sw1016.
takesCourse(grad25_d0,gradCourse6_d0) :- sw1016.
0.63::sw1017.
graduateStudent(grad26_d0) :- sw1017.
0.93::sw1018.
memberOf(grad26_d0,dept0) :- sw1018.
0.68::sw1019.
undergraduateDegreeFrom(grad26_d0,univ2) :- sw1019.
0.74::sw1020.
advisor(grad26_d0,assi3_d0) :- sw1020.
0.12::sw1021.
takesCourse(grad26_d0,gradCourse9_d0) :- sw1021.
0.63::sw1022.
takesCourse(grad26_d0,gradCourse1_d0) :- sw1022.
0.94::sw1023.
graduateStudent(grad27_d0) :- sw1023.
0.31::sw1024.
memberOf(grad27_d0,dept0) :- sw1024.
0.35::sw1025.
undergraduateDegreeFrom(grad27_d0,univ1) :- sw1025.
0.29::sw1026.
advisor(grad27_d0,full3_d0) :- sw1026.
0.62::sw1027.
takesCourse(grad27_d0,gradCourse4_d0) :- sw1027.
0.38::sw1028.
takesCourse(grad27_d0,gradCourse9_d0) :- sw1028.
0.86::sw1029.
graduateStudent(grad28_d0) :- sw1029.
0.69::sw1030.
memberOf(grad28_d0,dept0) :- sw1030.
0.57::sw1031.
undergraduateDegreeFrom(grad28_d0,univ7) :- sw1031.
0.77::sw1032.
advisor(grad28_d0,assi1_d0) :- sw1032.
0.25::sw1033.
takesCourse(grad28_d0,gradCourse7_d0) :- sw1033.
0.29::sw1034.
takesCourse(grad28_d0,gradCourse3_d0) :- sw1034.
0.45::sw1035.
graduateStudent(grad29_d0) :- sw1035.
0.42::sw1036.
memberOf(grad29_d0,dept0) :- sw1036.
0.47::sw1037.
undergraduateDegreeFrom(grad29_d0,univ0) :- sw1037.
0.99::sw1038.
advisor(grad29_d0,assi3_d0) :- sw1038.
0.36::sw1039.
takesCourse(grad29_d0,gradCourse5_d0) :- sw1039.
0.86::sw1040.
takesCourse(grad29_d0,gradCourse9_d0) :- sw1040.
0.84::sw1041.
teachingAssistantOf(grad29_d0,course13_d0) :- sw1041.
0.35::sw1042.
graduateStudent(grad30_d0) :- sw1042.
0.42::sw1043.
memberOf(grad30_d0,dept0) :- sw1043.
0.07::sw1044.
undergraduateDegreeFrom(grad30_d0,univ1) :- sw1044.
0.71::sw1045.
advisor(grad30_d0,full0_d0) :- sw1045.
0.51::sw1046.
takesCourse(grad30_d0,gradCourse1_d0) :- sw1046.
0.21::sw1047.
takesCourse(grad30_d0,gradCourse0_d0) :- sw1047.
0.91::sw1048.
graduateStudent(grad31_d0) :- sw1048.
0.48::sw1049.
memberOf(grad31_d0,dept0) :- sw1049.
0.28::sw1050.
undergraduateDegreeFrom(grad31_d0,univ0) :- sw1050.
0.50::sw1051.
advisor(grad31_d0,asso2_d0) :- sw1051.
0.21::sw1052.
takesCourse(grad31_d0,gradCourse8_d0) :- sw1052.
0.28::sw1053.
takesCourse(grad31_d0,gradCourse0_d0) :- sw1053.
0.66::sw1054.
graduateStudent(grad32_d0) :- sw1054.
0.67::sw1055.
memberOf(grad32_d0,dept0) :- sw1055.
0.15::sw1056.
undergraduateDegreeFrom(grad32_d0,univ3) :- sw1056.
0.75::sw1057.
advisor(grad32_d0,lect4_d0) :- sw1057.
0.78::sw1058.
takesCourse(grad32_d0,gradCourse5_d0) :- sw1058.
0.56::sw1059.
takesCourse(grad32_d0,gradCourse3_d0) :- sw1059.
0.63::sw1060.
graduateStudent(grad33_d0) :- sw1060.
0.63::sw1061.
memberOf(grad33_d0,dept0) :- sw1061.
0.79::sw1062.
undergraduateDegreeFrom(grad33_d0,univ7) :- sw1062.
0.73::sw1063.
advisor(grad33_d0,assi3_d0) :- sw1063.
0.80::sw1064.
takesCourse(grad33_d0,gradCourse7_d0) :- sw1064.
0.54::sw1065.
takesCourse(grad33_d0,gradCourse5_d0) :- sw1065.
0.50::sw1066.
graduateStudent(grad34_d0) :- sw1066.
0.18::sw1067.
memberOf(grad34_d0,dept0) :- sw1067.
0.69::sw1068.
undergraduateDegreeFrom(grad34_d0,univ0) :- sw1068.
0.66::sw1069.
advisor(grad34_d0,assi6_d0) :- sw1069.
0.78::sw1070.
takesCourse(grad34_d0,gradCourse4_d0) :- sw1070.
0.66::sw1071.
takesCourse(grad34_d0,gradCourse6_d0) :- sw1071.
0.52::sw1072.
teachingAssistantOf(grad34_d0,course9_d0) :- sw1072.
0.10::sw1073.
graduateStudent(grad35_d0) :- sw1073.
0.67::sw1074.
memberOf(grad35_d0,dept0) :- sw1074.
0.69::sw1075.
undergraduateDegreeFrom(grad35_d0,univ2) :- sw1075.
0.18::sw1076.
advisor(grad35_d0,assi8_d0) :- sw1076.
0.27::sw1077.
takesCourse(grad35_d0,gradCourse1_d0) :- sw1077.
0.49::sw1078.
takesCourse(grad35_d0,gradCourse8_d0) :- sw1078.
0.16::sw1079.
graduateStudent(grad36_d0) :- sw1079.
0.99::sw1080.
memberOf(grad36_d0,dept0) :- sw1080.
0.12::sw1081.
undergraduateDegreeFrom(grad36_d0,univ5) :- sw1081.
0.71::sw1082.
advisor(grad36_d0,assi7_d0) :- sw1082.
0.88::sw1083.
takesCourse(grad36_d0,gradCourse2_d0) :- sw1083.
0.11::sw1084.
takesCourse(grad36_d0,gradCourse6_d0) :- sw1084.
0.51::sw1085.
graduateStudent(grad37_d0) :- sw1085.
0.47::sw1086.
memberOf(grad37_d0,dept0) :- sw1086.
0.98::sw1087.
undergraduateDegreeFrom(grad37_d0,univ8) :- sw1087.
0.96::sw1088.
advisor(grad37_d0,assi4_d0) :- sw1088.
0.60::sw1089.
takesCourse(grad37_d0,gradCourse2_d0) :- sw1089.
0.76::sw1090.
takesCourse(grad37_d0,gradCourse5_d0) :- sw1090.
0.87::sw1091.
graduateStudent(grad38_d0) :- sw1091.
0.15::sw1092.
memberOf(grad38_d0,dept0) :- sw1092.
0.16::sw1093.
undergraduateDegreeFrom(grad38_d0,univ7) :- sw1093.
0.66::sw1094.
advisor(grad38_d0,asso6_d0) :- sw1094.
0.91::sw1095.
takesCourse(grad38_d0,gradCourse7_d0) :- sw1095.
0.72::sw1096.
takesCourse(grad38_d0,gradCourse9_d0) :- sw1096.
0.92::sw1097.
graduateStudent(grad39_d0) :- sw1097.
0.21::sw1098.
memberOf(grad39_d0,dept0) :- sw1098.
0.31::sw1099.
undergraduateDegreeFrom(grad39_d0,univ2) :- sw1099.
0.23::sw1100.
advisor(grad39_d0,lect4_d0) :- sw1100.
0.56::sw1101.
takesCourse(grad39_d0,gradCourse9_d0) :- sw1101.
0.96::sw1102.
takesCourse(grad39_d0,gradCourse6_d0) :- sw1102.
0.24::sw1103.
publication(pub0_d0) :- sw1103.
0.47::sw1104.
publicationAuthor(pub0_d0,full2_d0) :- sw1104.
0.49::sw1105.
publicationAuthor(pub0_d0,grad31_d0) :- sw1105.
0.57::sw1106.
publication(pub1_d0) :- sw1106.
0.33::sw1107.
publicationAuthor(pub1_d0,full1_d0) :- sw1107.
0.47::sw1108.
publication(pub2_d0) :- sw1108.
0.05::sw1109.
publicationAuthor(pub2_d0,full5_d0) :- sw1109.
0.05::sw1110.
publication(pub3_d0) :- sw1110.
0.55::sw1111.
publicationAuthor(pub3_d0,full6_d0) :- sw1111.
0.15::sw1112.
publicationAuthor(pub3_d0,grad3_d0) :- sw1112.
0.63::sw1113.
publication(pub4_d0) :- sw1113.
0.44::sw1114.
publicationAuthor(pub4_d0,full3_d0) :- sw1114.
0.46::sw1115.
publication(pub5_d0) :- sw1115.
0.33::sw1116.
publicationAuthor(pub5_d0,full3_d0) :- sw1116.
0.87::sw1117.
publicationAuthor(pub5_d0,grad37_d0) :- sw1117.
0.38::sw1118.
publication(pub6_d0) :- sw1118.
0.87::sw1119.
publicationAuthor(pub6_d0,assi3_d0) :- sw1119.
0.11::sw1120.
publication(pub7_d0) :- sw1120.
0.65::sw1121.
publicationAuthor(pub7_d0,full0_d0) :- sw1121.
0.23::sw1122.
publicationAuthor(pub7_d0,ugrad102_d0) :- sw1122.
0.93::sw1123.
publication(pub8_d0) :- sw1123.
0.09::sw1124.
publicationAuthor(pub8_d0,full6_d0) :- sw1124.
0.84::sw1125.
publicationAuthor(pub8_d0,ugrad79_d0) :- sw1125.
0.78::sw1126.
publication(pub9_d0) :- sw1126.
0.43::sw1127.
publicationAuthor(pub9_d0,full7_d0) :- sw1127.
0.11::sw1128.
publicationAuthor(pub9_d0,grad16_d0) :- sw1128.
0.72::sw1129.
publication(pub10_d0) :- sw1129.
0.74::sw1130.
publicationAuthor(pub10_d0,asso5_d0) :- sw1130.
0.80::sw1131.
publicationAuthor(pub10_d0,ugrad12_d0) :- sw1131.
0.69::sw1132.
publication(pub11_d0) :- sw1132.
0.83::sw1133.
publicationAuthor(pub11_d0,asso1_d0) :- sw1133.
0.43::sw1134.
publication(pub12_d0) :- sw1134.
0.67::sw1135.
publicationAuthor(pub12_d0,asso1_d0) :- sw1135.
0.91::sw1136.
publication(pub13_d0) :- sw1136.
0.33::sw1137.
publicationAuthor(pub13_d0,full0_d0) :- sw1137.
0.27::sw1138.
publicationAuthor(pub13_d0,ugrad73_d0) :- sw1138.
0.34::sw1139.
publication(pub14_d0) :- sw1139.
0.07::sw1140.
publicationAuthor(pub14_d0,asso5_d0) :- sw1140.
0.85::sw1141.
publicationAuthor(pub14_d0,ugrad143_d0) :- sw1141.
0.22::sw1142.
publication(pub15_d0) :- sw1142.
0.06::sw1143.
publicationAuthor(pub15_d0,lect4_d0) :- sw1143.
0.30::sw1144.
publicationAuthor(pub15_d0,grad4_d0) :- sw1144.
0.50::sw1145.
publication(pub16_d0) :- sw1145.
0.91::sw1146.
publicationAuthor(pub16_d0,assi2_d0) :- sw1146.
0.38::sw1147.
publication(pub17_d0) :- sw1147.
0.87::sw1148.
publicationAuthor(pub17_d0,asso4_d0) :- sw1148.
0.93::sw1149.
publicationAuthor(pub17_d0,grad9_d0) :- sw1149.
0.99::sw1150.
publication(pub18_d0) :- sw1150.
0.61::sw1151.
publicationAuthor(pub18_d0,full5_d0) :- sw1151.
0.67::sw1152.
publicationAuthor(pub18_d0,ugrad28_d0) :- sw1152.
0.57::sw1153.
publication(pub19_d0) :- sw1153.
0.80::sw1154.
publicationAuthor(pub19_d0,full1_d0) :- sw1154.
0.70::sw1155.
publication(pub20_d0) :- sw1155.
0.15::sw1156.
publicationAuthor(pub20_d0,full6_d0) :- sw1156.
0.44::sw1157.
publicationAuthor(pub20_d0,ugrad65_d0) :- sw1157.
0.86::sw1158.
publication(pub21_d0) :- sw1158.
0.45::sw1159.
publicationAuthor(pub21_d0,full5_d0) :- sw1159.
0.80::sw1160.
publicationAuthor(pub21_d0,ugrad102_d0) :- sw1160.
0.85::sw1161.
publication(pub22_d0) :- sw1161.
0.78::sw1162.
publicationAuthor(pub22_d0,asso6_d0) :- sw1162.
0.74::sw1163.
publication(pub23_d0) :- sw1163.
0.37::sw1164.
publicationAuthor(pub23_d0,full6_d0) :- sw1164.
0.53::sw1165.
publication(pub24_d0) :- sw1165.
0.85::sw1166.
publicationAuthor(pub24_d0,assi4_d0) :- sw1166.
0.46::sw1167.
publicationAuthor(pub24_d0,grad19_d0) :- sw1167.
0.60::sw1168.
publication(pub25_d0) :- sw1168.
0.10::sw1169.
publicationAuthor(pub25_d0,lect0_d0) :- sw1169.
0.47::sw1170.
publication(pub26_d0) :- sw1170.
0.52::sw1171.
publicationAuthor(pub26_d0,assi0_d0) :- sw1171.
0.20::sw1172.
publication(pub27_d0) :- sw1172.
0.42::sw1173.
publicationAuthor(pub27_d0,lect0_d0) :- sw1173.
0.12::sw1174.
publication(pub28_d0) :- sw1174.
0.97::sw1175.
publicationAuthor(pub28_d0,asso5_d0) :- sw1175.
0.18::sw1176.
publicationAuthor(pub28_d0,ugrad1_d0) :- sw1176.
0.73::sw1177.
publication(pub29_d0) :- sw1177.
0.30::sw1178.
publicationAuthor(pub29_d0,lect1_d0) :- sw1178.
0.98::sw1179.
publicationAuthor(pub29_d0,grad14_d0) :- sw1179.
0.87::sw1180.
publication(pub30_d0) :- sw1180.
0.56::sw1181.
publicationAuthor(pub30_d0,full4_d0) :- sw1181.
0.28::sw1182.
publicationAuthor(pub30_d0,ugrad49_d0) :- sw1182.
0.14::sw1183.
publication(pub31_d0) :- sw1183.
0.46::sw1184.
publicationAuthor(pub31_d0,lect3_d0) :- sw1184.
0.37::sw1185.
publication(pub32_d0) :- sw1185.
0.25::sw1186.
publicationAuthor(pub32_d0,assi5_d0) :- sw1186.
0.93::sw1187.
publicationAuthor(pub32_d0,grad15_d0) :- sw1187.
0.64::sw1188.
publication(pub33_d0) :- sw1188.
0.16::sw1189.
publicationAuthor(pub33_d0,full4_d0) :- sw1189.
0.49::sw1190.
publication(pub34_d0) :- sw1190.
0.36::sw1191.
publicationAuthor(pub34_d0,asso5_d0) :- sw1191.
0.80::sw1192.
publicationAuthor(pub34_d0,ugrad15_d0) :- sw1192.
0.60::sw1193.
publication(pub35_d0) :- sw1193.
0.07::sw1194.
publicationAuthor(pub35_d0,assi3_d0) :- sw1194.
0.55::sw1195.
publicationAuthor(pub35_d0,ugrad112_d0) :- sw1195.
0.51::sw1196.
publication(pub36_d0) :- sw1196.
0.30::sw1197.
publicationAuthor(pub36_d0,full5_d0) :- sw1197.
0.46::sw1198.
publicationAuthor(pub36_d0,ugrad82_d0) :- sw1198.
0.30::sw1199.
publication(pub37_d0) :- sw1199.
0.18::sw1200.
publicationAuthor(pub37_d0,asso2_d0) :- sw1200.
0.33::sw1201.
publication(pub38_d0) :- sw1201.
0.99::sw1202.
publicationAuthor(pub38_d0,asso5_d0) :- sw1202.
0.11::sw1203.
publication(pub39_d0) :- sw1203.
0.59::sw1204.
publicationAuthor(pub39_d0,lect1_d0) :- sw1204.
0.83::sw1205.
publication(pub40_d0) :- sw1205.
0.87::sw1206.
publicationAuthor(pub40_d0,assi8_d0) :- sw1206.
0.49::sw1207.
publicationAuthor(pub40_d0,ugrad48_d0) :- sw1207.
0.73::sw1208.
publication(pub41_d0) :- sw1208.
0.50::sw1209.
publicationAuthor(pub41_d0,assi8_d0) :- sw1209.
0.59::sw1210.
publicationAuthor(pub41_d0,ugrad104_d0) :- sw1210.
0.20::sw1211.
publication(pub42_d0) :- sw1211.
0.83::sw1212.
publicationAuthor(pub42_d0,lect2_d0) :- sw1212.
0.81::sw1213.
publication(pub43_d0) :- sw1213.
0.30::sw1214.
publicationAuthor(pub43_d0,full2_d0) :- sw1214.
0.63::sw1215.
publicationAuthor(pub43_d0,ugrad4_d0) :- sw1215.
0.24::sw1216.
publication(pub44_d0) :- sw1216.
0.80::sw1217.
publicationAuthor(pub44_d0,asso3_d0) :- sw1217.
0.18::sw1218.
publication(pub45_d0) :- sw1218.
0.24::sw1219.
publicationAuthor(pub45_d0,full1_d0) :- sw1219.
0.50::sw1220.
publication(pub46_d0) :- sw1220.
0.36::sw1221.
publicationAuthor(pub46_d0,assi0_d0) :- sw1221.
0.47::sw1222.
publication(pub47_d0) :- sw1222.
0.17::sw1223.
publicationAuthor(pub47_d0,full3_d0) :- sw1223.
0.72::sw1224.
publication(pub48_d0) :- sw1224.
0.20::sw1225.
publicationAuthor(pub48_d0,full2_d0) :- sw1225.
0.14::sw1226.
publicationAuthor(pub48_d0,ugrad53_d0) :- sw1226.
0.56::sw1227.
publication(pub49_d0) :- sw1227.
0.84::sw1228.
publicationAuthor(pub49_d0,asso9_d0) :- sw1228.
0.68::sw1229.
publicationAuthor(pub49_d0,ugrad9_d0) :- sw1229.
0.74::sw1230.
publication(pub50_d0) :- sw1230.
0.30::sw1231.
publicationAuthor(pub50_d0,assi4_d0) :- sw1231.
0.40::sw1232.
publicationAuthor(pub50_d0,ugrad50_d0) :- sw1232.
0.62::sw1233.
publication(pub51_d0) :- sw1233.
0.34::sw1234.
publicationAuthor(pub51_d0,assi0_d0) :- sw1234.
0.40::sw1235.
publicationAuthor(pub51_d0,ugrad113_d0) :- sw1235.
0.78::sw1236.
publication(pub52_d0) :- sw1236.
0.13::sw1237.
publicationAuthor(pub52_d0,assi1_d0) :- sw1237.
0.66::sw1238.
publication(pub53_d0) :- sw1238.
0.33::sw1239.
publicationAuthor(pub53_d0,lect0_d0) :- sw1239.
0.30::sw1240.
publicationAuthor(pub53_d0,ugrad39_d0) :- sw1240.
0.82::sw1241.
publication(pub54_d0) :- sw1241.
0.83::sw1242.
publicationAuthor(pub54_d0,lect3_d0) :- sw1242.
0.11::sw1243.
publication(pub55_d0) :- sw1243.
0.14::sw1244.
publicationAuthor(pub55_d0,assi0_d0) :- sw1244.
0.39::sw1245.
publication(pub56_d0) :- sw1245.
0.47::sw1246.
publicationAuthor(pub56_d0,assi5_d0) :- sw1246.
0.44::sw1247.
publication(pub57_d0) :- sw1247.
0.66::sw1248.
publicationAuthor(pub57_d0,assi9_d0) :- sw1248.
0.40::sw1249.
publicationAuthor(pub57_d0,ugrad118_d0) :- sw1249.
0.27::sw1250.
publication(pub58_d0) :- sw1250.
0.98::sw1251.
publicationAuthor(pub58_d0,lect2_d0) :- sw1251.
publication(pub59_d0).
0.82::sw1252.
publicationAuthor(pub59_d0,asso6_d0) :- sw1252.
0.85::sw1253.
publicationAuthor(pub59_d0,ugrad73_d0) :- sw1253.
0.98::sw1254.
department(dept1) :- sw1254.
0.80::sw1255.
subOrganizationOf(dept1,univ0) :- sw1255.
0.59::sw1256.
fullProfessor(full0_d1) :- sw1256.
0.10::sw1257.
worksFor(full0_d1,dept1) :- sw1257.
0.25::sw1258.
doctoralDegreeFrom(full0_d1,univ4) :- sw1258.
0.61::sw1259.
emailAddress(full0_d1,mail_full0_d1) :- sw1259.
0.52::sw1260.
researchInterest(full0_d1,res0) :- sw1260.
0.85::sw1261.
fullProfessor(full1_d1) :- sw1261.
0.06::sw1262.
worksFor(full1_d1,dept1) :- sw1262.
0.45::sw1263.
doctoralDegreeFrom(full1_d1,univ7) :- sw1263.
0.12::sw1264.
emailAddress(full1_d1,mail_full1_d1) :- sw1264.
0.32::sw1265.
researchInterest(full1_d1,res11) :- sw1265.
0.41::sw1266.
fullProfessor(full2_d1) :- sw1266.
0.75::sw1267.
worksFor(full2_d1,dept1) :- sw1267.
0.77::sw1268.
doctoralDegreeFrom(full2_d1,univ5) :- sw1268.
0.71::sw1269.
emailAddress(full2_d1,mail_full2_d1) :- sw1269.
0.46::sw1270.
researchInterest(full2_d1,res9) :- sw1270.
0.55::sw1271.
fullProfessor(full3_d1) :- sw1271.
0.76::sw1272.
worksFor(full3_d1,dept1) :- sw1272.
0.71::sw1273.
doctoralDegreeFrom(full3_d1,univ3) :- sw1273.
0.23::sw1274.
emailAddress(full3_d1,mail_full3_d1) :- sw1274.
0.87::sw1275.
researchInterest(full3_d1,res16) :- sw1275.
0.82::sw1276.
fullProfessor(full4_d1) :- sw1276.
0.74::sw1277.
worksFor(full4_d1,dept1) :- sw1277.
0.67::sw1278.
doctoralDegreeFrom(full4_d1,univ0) :- sw1278.
0.57::sw1279.
emailAddress(full4_d1,mail_full4_d1) :- sw1279.
0.22::sw1280.
researchInterest(full4_d1,res0) :- sw1280.
0.12::sw1281.
fullProfessor(full5_d1) :- sw1281.
0.13::sw1282.
worksFor(full5_d1,dept1) :- sw1282.
0.09::sw1283.
doctoralDegreeFrom(full5_d1,univ2) :- sw1283.
0.26::sw1284.
emailAddress(full5_d1,mail_full5_d1) :- sw1284.
0.99::sw1285.
researchInterest(full5_d1,res16) :- sw1285.
0.60::sw1286.
fullProfessor(full6_d1) :- sw1286.
0.05::sw1287.
worksFor(full6_d1,dept1) :- sw1287.
0.85::sw1288.
doctoralDegreeFrom(full6_d1,univ2) :- sw1288.
0.10::sw1289.
emailAddress(full6_d1,mail_full6_d1) :- sw1289.
0.44::sw1290.
researchInterest(full6_d1,res17) :- sw1290.
0.59::sw1291.
fullProfessor(full7_d1) :- sw1291.
0.31::sw1292.
worksFor(full7_d1,dept1) :- sw1292.
0.87::sw1293.
doctoralDegreeFrom(full7_d1,univ0) :- sw1293.
0.49::sw1294.
emailAddress(full7_d1,mail_full7_d1) :- sw1294.
0.63::sw1295.
researchInterest(full7_d1,res5) :- sw1295.
0.90::sw1296.
associateProfessor(asso0_d1) :- sw1296.
0.37::sw1297.
worksFor(asso0_d1,dept1) :- sw1297.
0.79::sw1298.
doctoralDegreeFrom(asso0_d1,univ0) :- sw1298.
0.77::sw1299.
emailAddress(asso0_d1,mail_asso0_d1) :- sw1299.
0.56::sw1300.
researchInterest(asso0_d1,res0) :- sw1300.
0.35::sw1301.
associateProfessor(asso1_d1) :- sw1301.
0.99::sw1302.
worksFor(asso1_d1,dept1) :- sw1302.
0.48::sw1303.
doctoralDegreeFrom(asso1_d1,univ3) :- sw1303.
0.45::sw1304.
emailAddress(asso1_d1,mail_asso1_d1) :- sw1304.
0.64::sw1305.
researchInterest(asso1_d1,res14) :- sw1305.
0.27::sw1306.
associateProfessor(asso2_d1) :- sw1306.
0.49::sw1307.
worksFor(asso2_d1,dept1) :- sw1307.
0.31::sw1308.
doctoralDegreeFrom(asso2_d1,univ5) :- sw1308.
0.58::sw1309.
emailAddress(asso2_d1,mail_asso2_d1) :- sw1309.
0.18::sw1310.
researchInterest(asso2_d1,res11) :- sw1310.
0.08::sw1311.
associateProfessor(asso3_d1) :- sw1311.
0.71::sw1312.
worksFor(asso3_d1,dept1) :- sw1312.
0.28::sw1313.
doctoralDegreeFrom(asso3_d1,univ8) :- sw1313.
0.06::sw1314.
emailAddress(asso3_d1,mail_asso3_d1) :- sw1314.
0.19::sw1315.
researchInterest(asso3_d1,res1) :- sw1315.
0.80::sw1316.
associateProfessor(asso4_d1) :- sw1316.
0.93::sw1317.
worksFor(asso4_d1,dept1) :- sw1317.
0.96::sw1318.
doctoralDegreeFrom(asso4_d1,univ7) :- sw1318.
0.43::sw1319.
emailAddress(asso4_d1,mail_asso4_d1) :- sw1319.
0.48::sw1320.
researchInterest(asso4_d1,res5) :- sw1320.
0.62::sw1321.
associateProfessor(asso5_d1) :- sw1321.
0.93::sw1322.
worksFor(asso5_d1,dept1) :- sw1322.
0.76::sw1323.
doctoralDegreeFrom(asso5_d1,univ3) :- sw1323.
0.84::sw1324.
emailAddress(asso5_d1,mail_asso5_d1) :- sw1324.
0.14::sw1325.
researchInterest(asso5_d1,res0) :- sw1325.
0.57::sw1326.
associateProfessor(asso6_d1) :- sw1326.
0.69::sw1327.
worksFor(asso6_d1,dept1) :- sw1327.
0.28::sw1328.
doctoralDegreeFrom(asso6_d1,univ4) :- sw1328.
0.41::sw1329.
emailAddress(asso6_d1,mail_asso6_d1) :- sw1329.
0.12::sw1330.
researchInterest(asso6_d1,res13) :- sw1330.
0.77::sw1331.
associateProfessor(asso7_d1) :- sw1331.
0.57::sw1332.
worksFor(asso7_d1,dept1) :- sw1332.
0.16::sw1333.
doctoralDegreeFrom(asso7_d1,univ5) :- sw1333.
0.77::sw1334.
emailAddress(asso7_d1,mail_asso7_d1) :- sw1334.
0.95::sw1335.
researchInterest(asso7_d1,res1) :- sw1335.
0.50::sw1336.
associateProfessor(asso8_d1) :- sw1336.
0.91::sw1337.
worksFor(asso8_d1,dept1) :- sw1337.
0.62::sw1338.
doctoralDegreeFrom(asso8_d1,univ9) :- sw1338.
0.39::sw1339.
emailAddress(asso8_d1,mail_asso8_d1) :- sw1339.
0.49::sw1340.
researchInterest(asso8_d1,res17) :- sw1340.
0.97::sw1341.
associateProfessor(asso9_d1) :- sw1341.
0.88::sw1342.
worksFor(asso9_d1,dept1) :- sw1342.
0.46::sw1343.
doctoralDegreeFrom(asso9_d1,univ1) :- sw1343.
0.61::sw1344.
emailAddress(asso9_d1,mail_asso9_d1) :- sw1344.
0.37::sw1345.
researchInterest(asso9_d1,res14) :- sw1345.
0.86::sw1346.
assistantProfessor(assi0_d1) :- sw1346.
0.84::sw1347.
worksFor(assi0_d1,dept1) :- sw1347.
0.37::sw1348.
doctoralDegreeFrom(assi0_d1,univ4) :- sw1348.
0.38::sw1349.
emailAddress(assi0_d1,mail_assi0_d1) :- sw1349.
0.95::sw1350.
researchInterest(assi0_d1,res8) :- sw1350.
0.57::sw1351.
assistantProfessor(assi1_d1) :- sw1351.
0.11::sw1352.
worksFor(assi1_d1,dept1) :- sw1352.
0.18::sw1353.
doctoralDegreeFrom(assi1_d1,univ3) :- sw1353.
0.87::sw1354.
emailAddress(assi1_d1,mail_assi1_d1) :- sw1354.
0.93::sw1355.
researchInterest(assi1_d1,res15) :- sw1355.
0.18::sw1356.
assistantProfessor(assi2_d1) :- sw1356.
0.85::sw1357.
worksFor(assi2_d1,dept1) :- sw1357.
0.12::sw1358.
doctoralDegreeFrom(assi2_d1,univ6) :- sw1358.
0.36::sw1359.
emailAddress(assi2_d1,mail_assi2_d1) :- sw1359.
0.47::sw1360.
researchInterest(assi2_d1,res8) :- sw1360.
0.90::sw1361.
assistantProfessor(assi3_d1) :- sw1361.
0.48::sw1362.
worksFor(assi3_d1,dept1) :- sw1362.
0.41::sw1363.
doctoralDegreeFrom(assi3_d1,univ5) :- sw1363.
0.54::sw1364.
emailAddress(assi3_d1,mail_assi3_d1) :- sw1364.
0.11::sw1365.
researchInterest(assi3_d1,res1) :- sw1365.
0.51::sw1366.
assistantProfessor(assi4_d1) :- sw1366.
0.27::sw1367.
worksFor(assi4_d1,dept1) :- sw1367.
0.20::sw1368.
doctoralDegreeFrom(assi4_d1,univ0) :- sw1368.
0.10::sw1369.
emailAddress(assi4_d1,mail_assi4_d1) :- sw1369.
0.90::sw1370.
researchInterest(assi4_d1,res13) :- sw1370.
0.27::sw1371.
assistantProfessor(assi5_d1) :- sw1371.
0.69::sw1372.
worksFor(assi5_d1,dept1) :- sw1372.
0.43::sw1373.
doctoralDegreeFrom(assi5_d1,univ0) :- sw1373.
0.43::sw1374.
emailAddress(assi5_d1,mail_assi5_d1) :- sw1374.
0.84::sw1375.
researchInterest(assi5_d1,res5) :- sw1375.
0.29::sw1376.
assistantProfessor(assi6_d1) :- sw1376.
0.48::sw1377.
worksFor(assi6_d1,dept1) :- sw1377.
0.47::sw1378.
doctoralDegreeFrom(assi6_d1,univ9) :- sw1378.
0.78::sw1379.
emailAddress(assi6_d1,mail_assi6_d1) :- sw1379.
0.92::sw1380.
researchInterest(assi6_d1,res7) :- sw1380.
0.42::sw1381.
assistantProfessor(assi7_d1) :- sw1381.
0.09::sw1382.
worksFor(assi7_d1,dept1) :- sw1382.
0.12::sw1383.
doctoralDegreeFrom(assi7_d1,univ2) :- sw1383.
0.67::sw1384.
emailAddress(assi7_d1,mail_assi7_d1) :- sw1384.
0.73::sw1385.
researchInterest(assi7_d1,res13) :- sw1385.
0.07::sw1386.
assistantProfessor(assi8_d1) :- sw1386.
0.98::sw1387.
worksFor(assi8_d1,dept1) :- sw1387.
0.57::sw1388.
doctoralDegreeFrom(assi8_d1,univ8) :- sw1388.
0.23::sw1389.
emailAddress(assi8_d1,mail_assi8_d1) :- sw1389.
0.07::sw1390.
researchInterest(assi8_d1,res10) :- sw1390.
0.41::sw1391.
assistantProfessor(assi9_d1) :- sw1391.
0.21::sw1392.
worksFor(assi9_d1,dept1) :- sw1392.
0.92::sw1393.
doctoralDegreeFrom(assi9_d1,univ8) :- sw1393.
0.19::sw1394.
emailAddress(assi9_d1,mail_assi9_d1) :- sw1394.
0.71::sw1395.
researchInterest(assi9_d1,res4) :- sw1395.
0.47::sw1396.
lecturer(lect0_d1) :- sw1396.
0.93::sw1397.
worksFor(lect0_d1,dept1) :- sw1397.
0.51::sw1398.
doctoralDegreeFrom(lect0_d1,univ4) :- sw1398.
0.67::sw1399.
emailAddress(lect0_d1,mail_lect0_d1) :- sw1399.
0.99::sw1400.
researchInterest(lect0_d1,res0) :- sw1400.
0.40::sw1401.
lecturer(lect1_d1) :- sw1401.
0.55::sw1402.
worksFor(lect1_d1,dept1) :- sw1402.
0.49::sw1403.
doctoralDegreeFrom(lect1_d1,univ2) :- sw1403.
0.75::sw1404.
emailAddress(lect1_d1,mail_lect1_d1) :- sw1404.
0.28::sw1405.
researchInterest(lect1_d1,res1) :- sw1405.
0.14::sw1406.
lecturer(lect2_d1) :- sw1406.
0.78::sw1407.
worksFor(lect2_d1,dept1) :- sw1407.
0.63::sw1408.
doctoralDegreeFrom(lect2_d1,univ0) :- sw1408.
0.50::sw1409.
emailAddress(lect2_d1,mail_lect2_d1) :- sw1409.
0.47::sw1410.
researchInterest(lect2_d1,res15) :- sw1410.
0.87::sw1411.
lecturer(lect3_d1) :- sw1411.
0.34::sw1412.
worksFor(lect3_d1,dept1) :- sw1412.
0.31::sw1413.
doctoralDegreeFrom(lect3_d1,univ0) :- sw1413.
0.85::sw1414.
emailAddress(lect3_d1,mail_lect3_d1) :- sw1414.
0.34::sw1415.
researchInterest(lect3_d1,res14) :- sw1415.
0.84::sw1416.
lecturer(lect4_d1) :- sw1416.
0.10::sw1417.
worksFor(lect4_d1,dept1) :- sw1417.
0.36::sw1418.
doctoralDegreeFrom(lect4_d1,univ7) :- sw1418.
0.34::sw1419.
emailAddress(lect4_d1,mail_lect4_d1) :- sw1419.
0.85::sw1420.
researchInterest(lect4_d1,res16) :- sw1420.
0.47::sw1421.
headOf(full0_d1,dept1) :- sw1421.
0.99::sw1422.
course(course0_d1) :- sw1422.
0.78::sw1423.
teacherOf(lect4_d1,course0_d1) :- sw1423.
0.71::sw1424.
course(course1_d1) :- sw1424.
0.38::sw1425.
teacherOf(assi8_d1,course1_d1) :- sw1425.
0.56::sw1426.
course(course2_d1) :- sw1426.
0.58::sw1427.
teacherOf(assi5_d1,course2_d1) :- sw1427.
0.48::sw1428.
course(course3_d1) :- sw1428.
0.15::sw1429.
teacherOf(asso2_d1,course3_d1) :- sw1429.
0.35::sw1430.
course(course4_d1) :- sw1430.
0.53::sw1431.
teacherOf(assi0_d1,course4_d1) :- sw1431.
0.33::sw1432.
course(course5_d1) :- sw1432.
0.58::sw1433.
teacherOf(asso3_d1,course5_d1) :- sw1433.
0.32::sw1434.
course(course6_d1) :- sw1434.
0.84::sw1435.
teacherOf(full4_d1,course6_d1) :- sw1435.
0.23::sw1436.
course(course7_d1) :- sw1436.
0.72::sw1437.
teacherOf(asso0_d1,course7_d1) :- sw1437.
0.76::sw1438.
course(course8_d1) :- sw1438.
0.96::sw1439.
teacherOf(full6_d1,course8_d1) :- sw1439.
0.80::sw1440.
course(course9_d1) :- sw1440.
0.54::sw1441.
teacherOf(assi8_d1,course9_d1) :- sw1441.
0.25::sw1442.
course(course10_d1) :- sw1442.
0.09::sw1443.
teacherOf(assi4_d1,course10_d1) :- sw1443.
0.59::sw1444.
course(course11_d1) :- sw1444.
0.85::sw1445.
teacherOf(lect0_d1,course11_d1) :- sw1445.
0.66::sw1446.
course(course12_d1) :- sw1446.
0.60::sw1447.
teacherOf(lect1_d1,course12_d1) :- sw1447.
0.92::sw1448.
course(course13_d1) :- sw1448.
0.74::sw1449.
teacherOf(asso9_d1,course13_d1) :- sw1449.
0.67::sw1450.
course(course14_d1) :- sw1450.
0.89::sw1451.
teacherOf(asso8_d1,course14_d1) :- sw1451.
0.64::sw1452.
course(course15_d1) :- sw1452.
0.94::sw1453.
teacherOf(lect0_d1,course15_d1) :- sw1453.
0.06::sw1454.
course(course16_d1) :- sw1454.
0.77::sw1455.
teacherOf(assi0_d1,course16_d1) :- sw1455.
0.31::sw1456.
course(course17_d1) :- sw1456.
0.98::sw1457.
teacherOf(asso1_d1,course17_d1) :- sw1457.
0.90::sw1458.
course(course18_d1) :- sw1458.
0.82::sw1459.
teacherOf(assi2_d1,course18_d1) :- sw1459.
0.84::sw1460.
course(course19_d1) :- sw1460.
0.14::sw1461.
teacherOf(asso0_d1,course19_d1) :- sw1461.
0.05::sw1462.
graduateCourse(gradCourse0_d1) :- sw1462.
0.43::sw1463.
teacherOf(full2_d1,gradCourse0_d1) :- sw1463.
0.07::sw1464.
graduateCourse(gradCourse1_d1) :- sw1464.
0.97::sw1465.
teacherOf(assi8_d1,gradCourse1_d1) :- sw1465.
0.13::sw1466.
graduateCourse(gradCourse2_d1) :- sw1466.
0.37::sw1467.
teacherOf(lect3_d1,gradCourse2_d1) :- sw1467.
0.31::sw1468.
graduateCourse(gradCourse3_d1) :- sw1468.
0.56::sw1469.
teacherOf(asso6_d1,gradCourse3_d1) :- sw1469.
0.83::sw1470.
graduateCourse(gradCourse4_d1) :- sw1470.
0.11::sw1471.
teacherOf(lect1_d1,gradCourse4_d1) :- sw1471.
0.45::sw1472.
graduateCourse(gradCourse5_d1) :- sw1472.
0.17::sw1473.
teacherOf(asso9_d1,gradCourse5_d1) :- sw1473.
0.62::sw1474.
graduateCourse(gradCourse6_d1) :- sw1474.
0.56::sw1475.
teacherOf(full1_d1,gradCourse6_d1) :- sw1475.
0.17::sw1476.
graduateCourse(gradCourse7_d1) :- sw1476.
0.71::sw1477.
teacherOf(assi2_d1,gradCourse7_d1) :- sw1477.
0.21::sw1478.
graduateCourse(gradCourse8_d1) :- sw1478.
0.20::sw1479.
teacherOf(full7_d1,gradCourse8_d1) :- sw1479.
0.79::sw1480.
graduateCourse(gradCourse9_d1) :- sw1480.
0.17::sw1481.
teacherOf(lect3_d1,gradCourse9_d1) :- sw1481.
0.63::sw1482.
undergraduateStudent(ugrad0_d1) :- sw1482.
0.74::sw1483.
memberOf(ugrad0_d1,dept1) :- sw1483.
0.15::sw1484.
takesCourse(ugrad0_d1,course4_d1) :- sw1484.
0.87::sw1485.
takesCourse(ugrad0_d1,course8_d1) :- sw1485.
0.34::sw1486.
undergraduateStudent(ugrad1_d1) :- sw1486.
0.60::sw1487.
memberOf(ugrad1_d1,dept1) :- sw1487.
0.41::sw1488.
takesCourse(ugrad1_d1,course8_d1) :- sw1488.
0.99::sw1489.
takesCourse(ugrad1_d1,course3_d1) :- sw1489.
0.90::sw1490.
undergraduateStudent(ugrad2_d1) :- sw1490.
0.40::sw1491.
memberOf(ugrad2_d1,dept1) :- sw1491.
0.36::sw1492.
takesCourse(ugrad2_d1,course2_d1) :- sw1492.
0.92::sw1493.
takesCourse(ugrad2_d1,course11_d1) :- sw1493.
0.88::sw1494.
advisor(ugrad2_d1,lect3_d1) :- sw1494.
0.83::sw1495.
undergraduateStudent(ugrad3_d1) :- sw1495.
0.92::sw1496.
memberOf(ugrad3_d1,dept1) :- sw1496.
0.99::sw1497.
takesCourse(ugrad3_d1,course14_d1) :- sw1497.
0.28::sw1498.
takesCourse(ugrad3_d1,course6_d1) :- sw1498.
0.94::sw1499.
undergraduateStudent(ugrad4_d1) :- sw1499.
0.59::sw1500.
memberOf(ugrad4_d1,dept1) :- sw1500.
0.54::sw1501.
takesCourse(ugrad4_d1,course11_d1) :- sw1501.
0.39::sw1502.
takesCourse(ugrad4_d1,course5_d1) :- sw1502.
0.81::sw1503.
undergraduateStudent(ugrad5_d1) :- sw1503.
0.71::sw1504.
memberOf(ugrad5_d1,dept1) :- sw1504.
0.06::sw1505.
takesCourse(ugrad5_d1,course12_d1) :- sw1505.
0.91::sw1506.
takesCourse(ugrad5_d1,course10_d1) :- sw1506.
0.52::sw1507.
advisor(ugrad5_d1,asso5_d1) :- sw1507.
0.28::sw1508.
undergraduateStudent(ugrad6_d1) :- sw1508.
0.63::sw1509.
memberOf(ugrad6_d1,dept1) :- sw1509.
0.46::sw1510.
takesCourse(ugrad6_d1,course1_d1) :- sw1510.
0.38::sw1511.
takesCourse(ugrad6_d1,course10_d1) :- sw1511.
0.41::sw1512.
undergraduateStudent(ugrad7_d1) :- sw1512.
0.96::sw1513.
memberOf(ugrad7_d1,dept1) :- sw1513.
0.23::sw1514.
takesCourse(ugrad7_d1,course12_d1) :- sw1514.
0.55::sw1515.
takesCourse(ugrad7_d1,course17_d1) :- sw1515.
0.48::sw1516.
undergraduateStudent(ugrad8_d1) :- sw1516.
0.11::sw1517.
memberOf(ugrad8_d1,dept1) :- sw1517.
0.57::sw1518.
takesCourse(ugrad8_d1,course4_d1) :- sw1518.
0.59::sw1519.
takesCourse(ugrad8_d1,course13_d1) :- sw1519.
0.71::sw1520.
undergraduateStudent(ugrad9_d1) :- sw1520.
0.60::sw1521.
memberOf(ugrad9_d1,dept1) :- sw1521.
0.29::sw1522.
takesCourse(ugrad9_d1,course2_d1) :- sw1522.
0.15::sw1523.
takesCourse(ugrad9_d1,course15_d1) :- sw1523.
0.80::sw1524.
undergraduateStudent(ugrad10_d1) :- sw1524.
0.86::sw1525.
memberOf(ugrad10_d1,dept1) :- sw1525.
0.33::sw1526.
takesCourse(ugrad10_d1,course6_d1) :- sw1526.
0.41::sw1527.
takesCourse(ugrad10_d1,course2_d1) :- sw1527.
0.79::sw1528.
undergraduateStudent(ugrad11_d1) :- sw1528.
0.51::sw1529.
memberOf(ugrad11_d1,dept1) :- sw1529.
0.78::sw1530.
takesCourse(ugrad11_d1,course3_d1) :- sw1530.
0.91::sw1531.
takesCourse(ugrad11_d1,course19_d1) :- sw1531.
0.46::sw1532.
undergraduateStudent(ugrad12_d1) :- sw1532.
0.96::sw1533.
memberOf(ugrad12_d1,dept1) :- sw1533.
0.31::sw1534.
takesCourse(ugrad12_d1,course0_d1) :- sw1534.
0.21::sw1535.
takesCourse(ugrad12_d1,course9_d1) :- sw1535.
0.28::sw1536.
undergraduateStudent(ugrad13_d1) :- sw1536.
0.17::sw1537.
memberOf(ugrad13_d1,dept1) :- sw1537.
0.62::sw1538.
takesCourse(ugrad13_d1,course2_d1) :- sw1538.
0.81::sw1539.
takesCourse(ugrad13_d1,course13_d1) :- sw1539.
0.99::sw1540.
undergraduateStudent(ugrad14_d1) :- sw1540.
0.47::sw1541.
memberOf(ugrad14_d1,dept1) :- sw1541.
0.83::sw1542.
takesCourse(ugrad14_d1,course15_d1) :- sw1542.
0.70::sw1543.
takesCourse(ugrad14_d1,course14_d1) :- sw1543.
0.47::sw1544.
undergraduateStudent(ugrad15_d1) :- sw1544.
0.34::sw1545.
memberOf(ugrad15_d1,dept1) :- sw1545.
0.43::sw1546.
takesCourse(ugrad15_d1,course17_d1) :- sw1546.
0.82::sw1547.
takesCourse(ugrad15_d1,course19_d1) :- sw1547.
0.33::sw1548.
advisor(ugrad15_d1,asso7_d1) :- sw1548.
0.27::sw1549.
undergraduateStudent(ugrad16_d1) :- sw1549.
0.24::sw1550.
memberOf(ugrad16_d1,dept1) :- sw1550.
0.38::sw1551.
takesCourse(ugrad16_d1,course15_d1) :- sw1551.
0.20::sw1552.
takesCourse(ugrad16_d1,course5_d1) :- sw1552.
0.30::sw1553.
advisor(ugrad16_d1,asso3_d1) :- sw1553.
0.06::sw1554.
undergraduateStudent(ugrad17_d1) :- sw1554.
0.80::sw1555.
memberOf(ugrad17_d1,dept1) :- sw1555.
0.35::sw1556.
takesCourse(ugrad17_d1,course14_d1) :- sw1556.
0.36::sw1557.
takesCourse(ugrad17_d1,course12_d1) :- sw1557.
0.31::sw1558.
undergraduateStudent(ugrad18_d1) :- sw1558.
0.15::sw1559.
memberOf(ugrad18_d1,dept1) :- sw1559.
0.36::sw1560.
takesCourse(ugrad18_d1,course4_d1) :- sw1560.
0.49::sw1561.
takesCourse(ugrad18_d1,course12_d1) :- sw1561.
0.96::sw1562.
advisor(ugrad18_d1,asso3_d1) :- sw1562.
0.36::sw1563.
undergraduateStudent(ugrad19_d1) :- sw1563.
0.44::sw1564.
memberOf(ugrad19_d1,dept1) :- sw1564.
0.43::sw1565.
takesCourse(ugrad19_d1,course9_d1) :- sw1565.
0.49::sw1566.
takesCourse(ugrad19_d1,course6_d1) :- sw1566.
0.64::sw1567.
undergraduateStudent(ugrad20_d1) :- sw1567.
0.68::sw1568.
memberOf(ugrad20_d1,dept1) :- sw1568.
0.34::sw1569.
takesCourse(ugrad20_d1,course4_d1) :- sw1569.
0.43::sw1570.
takesCourse(ugrad20_d1,course19_d1) :- sw1570.
0.67::sw1571.
advisor(ugrad20_d1,asso1_d1) :- sw1571.
0.78::sw1572.
undergraduateStudent(ugrad21_d1) :- sw1572.
0.32::sw1573.
memberOf(ugrad21_d1,dept1) :- sw1573.
0.08::sw1574.
takesCourse(ugrad21_d1,course17_d1) :- sw1574.
0.98::sw1575.
takesCourse(ugrad21_d1,course6_d1) :- sw1575.
0.61::sw1576.
undergraduateStudent(ugrad22_d1) :- sw1576.
0.55::sw1577.
memberOf(ugrad22_d1,dept1) :- sw1577.
0.41::sw1578.
takesCourse(ugrad22_d1,course3_d1) :- sw1578.
0.77::sw1579.
takesCourse(ugrad22_d1,course13_d1) :- sw1579.
0.41::sw1580.
undergraduateStudent(ugrad23_d1) :- sw1580.
0.98::sw1581.
memberOf(ugrad23_d1,dept1) :- sw1581.
0.39::sw1582.
takesCourse(ugrad23_d1,course0_d1) :- sw1582.
0.94::sw1583.
takesCourse(ugrad23_d1,course8_d1) :- sw1583.
0.08::sw1584.
advisor(ugrad23_d1,full7_d1) :- sw1584.
0.41::sw1585.
undergraduateStudent(ugrad24_d1) :- sw1585.
0.48::sw1586.
memberOf(ugrad24_d1,dept1) :- sw1586.
0.52::sw1587.
takesCourse(ugrad24_d1,course4_d1) :- sw1587.
0.20::sw1588.
takesCourse(ugrad24_d1,course9_d1) :- sw1588.
0.74::sw1589.
advisor(ugrad24_d1,assi4_d1) :- sw1589.
0.19::sw1590.
undergraduateStudent(ugrad25_d1) :- sw1590.
0.19::sw1591.
memberOf(ugrad25_d1,dept1) :- sw1591.
0.91::sw1592.
takesCourse(ugrad25_d1,course19_d1) :- sw1592.
0.47::sw1593.
takesCourse(ugrad25_d1,course2_d1) :- sw1593.
0.88::sw1594.
undergraduateStudent(ugrad26_d1) :- sw1594.
0.39::sw1595.
memberOf(ugrad26_d1,dept1) :- sw1595.
0.90::sw1596.
takesCourse(ugrad26_d1,course0_d1) :- sw1596.
0.13::sw1597.
takesCourse(ugrad26_d1,course11_d1) :- sw1597.
0.92::sw1598.
undergraduateStudent(ugrad27_d1) :- sw1598.
0.97::sw1599.
memberOf(ugrad27_d1,dept1) :- sw1599.
0.67::sw1600.
takesCourse(ugrad27_d1,course15_d1) :- sw1600.
0.24::sw1601.
takesCourse(ugrad27_d1,course7_d1) :- sw1601.
0.96::sw1602.
advisor(ugrad27_d1,lect3_d1) :- sw1602.
0.31::sw1603.
undergraduateStudent(ugrad28_d1) :- sw1603.
0.59::sw1604.
memberOf(ugrad28_d1,dept1) :- sw1604.
0.50::sw1605.
takesCourse(ugrad28_d1,course3_d1) :- sw1605.
0.96::sw1606.
takesCourse(ugrad28_d1,course10_d1) :- sw1606.
0.65::sw1607.
undergraduateStudent(ugrad29_d1) :- sw1607.
0.82::sw1608.
memberOf(ugrad29_d1,dept1) :- sw1608.
0.44::sw1609.
takesCourse(ugrad29_d1,course11_d1) :- sw1609.
0.30::sw1610.
takesCourse(ugrad29_d1,course16_d1) :- sw1610.
0.37::sw1611.
undergraduateStudent(ugrad30_d1) :- sw1611.
0.60::sw1612.
memberOf(ugrad30_d1,dept1) :- sw1612.
0.78::sw1613.
takesCourse(ugrad30_d1,course14_d1) :- sw1613.
0.77::sw1614.
takesCourse(ugrad30_d1,course18_d1) :- sw1614.
0.88::sw1615.
undergraduateStudent(ugrad31_d1) :- sw1615.
0.60::sw1616.
memberOf(ugrad31_d1,dept1) :- sw1616.
0.58::sw1617.
takesCourse(ugrad31_d1,course17_d1) :- sw1617.
0.46::sw1618.
takesCourse(ugrad31_d1,course19_d1) :- sw1618.
0.33::sw1619.
undergraduateStudent(ugrad32_d1) :- sw1619.
0.76::sw1620.
memberOf(ugrad32_d1,dept1) :- sw1620.
0.13::sw1621.
takesCourse(ugrad32_d1,course4_d1) :- sw1621.
0.66::sw1622.
takesCourse(ugrad32_d1,course17_d1) :- sw1622.
0.21::sw1623.
undergraduateStudent(ugrad33_d1) :- sw1623.
0.10::sw1624.
memberOf(ugrad33_d1,dept1) :- sw1624.
0.53::sw1625.
takesCourse(ugrad33_d1,course12_d1) :- sw1625.
0.74::sw1626.
takesCourse(ugrad33_d1,course6_d1) :- sw1626.
0.53::sw1627.
undergraduateStudent(ugrad34_d1) :- sw1627.
0.91::sw1628.
memberOf(ugrad34_d1,dept1) :- sw1628.
0.83::sw1629.
takesCourse(ugrad34_d1,course9_d1) :- sw1629.
0.73::sw1630.
takesCourse(ugrad34_d1,course5_d1) :- sw1630.
0.73::sw1631.
undergraduateStudent(ugrad35_d1) :- sw1631.
0.84::sw1632.
memberOf(ugrad35_d1,dept1) :- sw1632.
0.39::sw1633.
takesCourse(ugrad35_d1,course5_d1) :- sw1633.
0.80::sw1634.
takesCourse(ugrad35_d1,course10_d1) :- sw1634.
0.08::sw1635.
undergraduateStudent(ugrad36_d1) :- sw1635.
memberOf(ugrad36_d1,dept1).
0.22::sw1636.
takesCourse(ugrad36_d1,course6_d1) :- sw1636.
0.44::sw1637.
takesCourse(ugrad36_d1,course4_d1) :- sw1637.
0.40::sw1638.
advisor(ugrad36_d1,full3_d1) :- sw1638.
0.33::sw1639.
undergraduateStudent(ugrad37_d1) :- sw1639.
0.14::sw1640.
memberOf(ugrad37_d1,dept1) :- sw1640.
0.94::sw1641.
takesCourse(ugrad37_d1,course13_d1) :- sw1641.
0.94::sw1642.
takesCourse(ugrad37_d1,course5_d1) :- sw1642.
0.93::sw1643.
advisor(ugrad37_d1,full0_d1) :- sw1643.
0.63::sw1644.
undergraduateStudent(ugrad38_d1) :- sw1644.
0.21::sw1645.
memberOf(ugrad38_d1,dept1) :- sw1645.
0.65::sw1646.
takesCourse(ugrad38_d1,course5_d1) :- sw1646.
0.91::sw1647.
takesCourse(ugrad38_d1,course3_d1) :- sw1647.
0.37::sw1648.
undergraduateStudent(ugrad39_d1) :- sw1648.
0.13::sw1649.
memberOf(ugrad39_d1,dept1) :- sw1649.
0.71::sw1650.
takesCourse(ugrad39_d1,course18_d1) :- sw1650.
0.79::sw1651.
takesCourse(ugrad39_d1,course11_d1) :- sw1651.
0.45::sw1652.
undergraduateStudent(ugrad40_d1) :- sw1652.
0.59::sw1653.
memberOf(ugrad40_d1,dept1) :- sw1653.
0.71::sw1654.
takesCourse(ugrad40_d1,course8_d1) :- sw1654.
0.55::sw1655.
takesCourse(ugrad40_d1,course2_d1) :- sw1655.
0.89::sw1656.
undergraduateStudent(ugrad41_d1) :- sw1656.
0.30::sw1657.
memberOf(ugrad41_d1,dept1) :- sw1657.
0.23::sw1658.
takesCourse(ugrad41_d1,course18_d1) :- sw1658.
0.74::sw1659.
takesCourse(ugrad41_d1,course14_d1) :- sw1659.
0.90::sw1660.
undergraduateStudent(ugrad42_d1) :- sw1660.
0.96::sw1661.
memberOf(ugrad42_d1,dept1) :- sw1661.
0.18::sw1662.
takesCourse(ugrad42_d1,course18_d1) :- sw1662.
0.40::sw1663.
takesCourse(ugrad42_d1,course6_d1) :- sw1663.
0.27::sw1664.
undergraduateStudent(ugrad43_d1) :- sw1664.
0.57::sw1665.
memberOf(ugrad43_d1,dept1) :- sw1665.
0.31::sw1666.
takesCourse(ugrad43_d1,course16_d1) :- sw1666.
0.71::sw1667.
takesCourse(ugrad43_d1,course18_d1) :- sw1667.
0.50::sw1668.
undergraduateStudent(ugrad44_d1) :- sw1668.
0.77::sw1669.
memberOf(ugrad44_d1,dept1) :- sw1669.
0.65::sw1670.
takesCourse(ugrad44_d1,course10_d1) :- sw1670.
0.93::sw1671.
takesCourse(ugrad44_d1,course18_d1) :- sw1671.
0.38::sw1672.
undergraduateStudent(ugrad45_d1) :- sw1672.
0.73::sw1673.
memberOf(ugrad45_d1,dept1) :- sw1673.
0.59::sw1674.
takesCourse(ugrad45_d1,course19_d1) :- sw1674.
0.52::sw1675.
takesCourse(ugrad45_d1,course11_d1) :- sw1675.
0.31::sw1676.
undergraduateStudent(ugrad46_d1) :- sw1676.
0.42::sw1677.
memberOf(ugrad46_d1,dept1) :- sw1677.
0.82::sw1678.
takesCourse(ugrad46_d1,course10_d1) :- sw1678.
0.69::sw1679.
takesCourse(ugrad46_d1,course9_d1) :- sw1679.
0.68::sw1680.
undergraduateStudent(ugrad47_d1) :- sw1680.
0.67::sw1681.
memberOf(ugrad47_d1,dept1) :- sw1681.
0.43::sw1682.
takesCourse(ugrad47_d1,course9_d1) :- sw1682.
0.80::sw1683.
takesCourse(ugrad47_d1,course8_d1) :- sw1683.
0.75::sw1684.
advisor(ugrad47_d1,lect4_d1) :- sw1684.
0.88::sw1685.
undergraduateStudent(ugrad48_d1) :- sw1685.
0.79::sw1686.
memberOf(ugrad48_d1,dept1) :- sw1686.
0.61::sw1687.
takesCourse(ugrad48_d1,course7_d1) :- sw1687.
0.76::sw1688.
takesCourse(ugrad48_d1,course10_d1) :- sw1688.
0.12::sw1689.
undergraduateStudent(ugrad49_d1) :- sw1689.
0.95::sw1690.
memberOf(ugrad49_d1,dept1) :- sw1690.
0.41::sw1691.
takesCourse(ugrad49_d1,course7_d1) :- sw1691.
0.21::sw1692.
takesCourse(ugrad49_d1,course9_d1) :- sw1692.
0.10::sw1693.
undergraduateStudent(ugrad50_d1) :- sw1693.
0.69::sw1694.
memberOf(ugrad50_d1,dept1) :- sw1694.
0.24::sw1695.
takesCourse(ugrad50_d1,course8_d1) :- sw1695.
0.75::sw1696.
takesCourse(ugrad50_d1,course14_d1) :- sw1696.
0.36::sw1697.
advisor(ugrad50_d1,assi3_d1) :- sw1697.
0.43::sw1698.
undergraduateStudent(ugrad51_d1) :- sw1698.
0.39::sw1699.
memberOf(ugrad51_d1,dept1) :- sw1699.
0.78::sw1700.
takesCourse(ugrad51_d1,course17_d1) :- sw1700.
takesCourse(ugrad51_d1,course5_d1).
0.92::sw1701.
undergraduateStudent(ugrad52_d1) :- sw1701.
0.12::sw1702.
memberOf(ugrad52_d1,dept1) :- sw1702.
0.16::sw1703.
takesCourse(ugrad52_d1,course16_d1) :- sw1703.
0.60::sw1704.
takesCourse(ugrad52_d1,course19_d1) :- sw1704.
0.84::sw1705.
undergraduateStudent(ugrad53_d1) :- sw1705.
0.83::sw1706.
memberOf(ugrad53_d1,dept1) :- sw1706.
0.67::sw1707.
takesCourse(ugrad53_d1,course19_d1) :- sw1707.
0.86::sw1708.
takesCourse(ugrad53_d1,course1_d1) :- sw1708.
0.61::sw1709.
advisor(ugrad53_d1,assi9_d1) :- sw1709.
0.53::sw1710.
undergraduateStudent(ugrad54_d1) :- sw1710.
0.07::sw1711.
memberOf(ugrad54_d1,dept1) :- sw1711.
0.83::sw1712.
takesCourse(ugrad54_d1,course17_d1) :- sw1712.
0.23::sw1713.
takesCourse(ugrad54_d1,course9_d1) :- sw1713.
0.37::sw1714.
advisor(ugrad54_d1,assi6_d1) :- sw1714.
0.60::sw1715.
undergraduateStudent(ugrad55_d1) :- sw1715.
0.33::sw1716.
memberOf(ugrad55_d1,dept1) :- sw1716.
0.95::sw1717.
takesCourse(ugrad55_d1,course12_d1) :- sw1717.
0.99::sw1718.
takesCourse(ugrad55_d1,course6_d1) :- sw1718.
0.15::sw1719.
undergraduateStudent(ugrad56_d1) :- sw1719.
0.83::sw1720.
memberOf(ugrad56_d1,dept1) :- sw1720.
0.39::sw1721.
takesCourse(ugrad56_d1,course11_d1) :- sw1721.
0.39::sw1722.
takesCourse(ugrad56_d1,course16_d1) :- sw1722.
0.40::sw1723.
undergraduateStudent(ugrad57_d1) :- sw1723.
0.89::sw1724.
memberOf(ugrad57_d1,dept1) :- sw1724.
0.30::sw1725.
takesCourse(ugrad57_d1,course17_d1) :- sw1725.
0.91::sw1726.
takesCourse(ugrad57_d1,course15_d1) :- sw1726.
0.73::sw1727.
undergraduateStudent(ugrad58_d1) :- sw1727.
0.26::sw1728.
memberOf(ugrad58_d1,dept1) :- sw1728.
0.06::sw1729.
takesCourse(ugrad58_d1,course13_d1) :- sw1729.
0.66::sw1730.
takesCourse(ugrad58_d1,course12_d1) :- sw1730.
0.61::sw1731.
undergraduateStudent(ugrad59_d1) :- sw1731.
0.21::sw1732.
memberOf(ugrad59_d1,dept1) :- sw1732.
0.15::sw1733.
takesCourse(ugrad59_d1,course11_d1) :- sw1733.
0.96::sw1734.
takesCourse(ugrad59_d1,course0_d1) :- sw1734.
0.48::sw1735.
undergraduateStudent(ugrad60_d1) :- sw1735.
0.78::sw1736.
memberOf(ugrad60_d1,dept1) :- sw1736.
0.07::sw1737.
takesCourse(ugrad60_d1,course16_d1) :- sw1737.
0.31::sw1738.
takesCourse(ugrad60_d1,course11_d1) :- sw1738.
0.46::sw1739.
undergraduateStudent(ugrad61_d1) :- sw1739.
0.39::sw1740.
memberOf(ugrad61_d1,dept1) :- sw1740.
0.63::sw1741.
takesCourse(ugrad61_d1,course11_d1) :- sw1741.
0.94::sw1742.
takesCourse(ugrad61_d1,course3_d1) :- sw1742.
0.54::sw1743.
undergraduateStudent(ugrad62_d1) :- sw1743.
0.93::sw1744.
memberOf(ugrad62_d1,dept1) :- sw1744.
0.57::sw1745.
takesCourse(ugrad62_d1,course4_d1) :- sw1745.
0.80::sw1746.
takesCourse(ugrad62_d1,course10_d1) :- sw1746.
0.25::sw1747.
undergraduateStudent(ugrad63_d1) :- sw1747.
0.45::sw1748.
memberOf(ugrad63_d1,dept1) :- sw1748.
0.58::sw1749.
takesCourse(ugrad63_d1,course11_d1) :- sw1749.
0.12::sw1750.
takesCourse(ugrad63_d1,course2_d1) :- sw1750.
0.80::sw1751.
undergraduateStudent(ugrad64_d1) :- sw1751.
0.25::sw1752.
memberOf(ugrad64_d1,dept1) :- sw1752.
0.96::sw1753.
takesCourse(ugrad64_d1,course4_d1) :- sw1753.
0.19::sw1754.
takesCourse(ugrad64_d1,course2_d1) :- sw1754.
0.58::sw1755.
undergraduateStudent(ugrad65_d1) :- sw1755.
0.94::sw1756.
memberOf(ugrad65_d1,dept1) :- sw1756.
0.60::sw1757.
takesCourse(ugrad65_d1,course13_d1) :- sw1757.
0.49::sw1758.
takesCourse(ugrad65_d1,course9_d1) :- sw1758.
0.82::sw1759.
advisor(ugrad65_d1,full1_d1) :- sw1759.
0.49::sw1760.
undergraduateStudent(ugrad66_d1) :- sw1760.
0.57::sw1761.
memberOf(ugrad66_d1,dept1) :- sw1761.
0.83::sw1762.
takesCourse(ugrad66_d1,course17_d1) :- sw1762.
0.18::sw1763.
takesCourse(ugrad66_d1,course10_d1) :- sw1763.
0.26::sw1764.
undergraduateStudent(ugrad67_d1) :- sw1764.
0.07::sw1765.
memberOf(ugrad67_d1,dept1) :- sw1765.
0.65::sw1766.
takesCourse(ugrad67_d1,course11_d1) :- sw1766.
0.84::sw1767.
takesCourse(ugrad67_d1,course6_d1) :- sw1767.
0.63::sw1768.
undergraduateStudent(ugrad68_d1) :- sw1768.
0.55::sw1769.
memberOf(ugrad68_d1,dept1) :- sw1769.
0.73::sw1770.
takesCourse(ugrad68_d1,course18_d1) :- sw1770.
0.05::sw1771.
takesCourse(ugrad68_d1,course3_d1) :- sw1771.
0.12::sw1772.
undergraduateStudent(ugrad69_d1) :- sw1772.
0.29::sw1773.
memberOf(ugrad69_d1,dept1) :- sw1773.
0.28::sw1774.
takesCourse(ugrad69_d1,course12_d1) :- sw1774.
0.16::sw1775.
takesCourse(ugrad69_d1,course7_d1) :- sw1775.
undergraduateStudent(ugrad70_d1).
0.68::sw1776.
memberOf(ugrad70_d1,dept1) :- sw1776.
0.72::sw1777.
takesCourse(ugrad70_d1,course9_d1) :- sw1777.
0.78::sw1778.
takesCourse(ugrad70_d1,course19_d1) :- sw1778.
0.07::sw1779.
undergraduateStudent(ugrad71_d1) :- sw1779.
0.15::sw1780.
memberOf(ugrad71_d1,dept1) :- sw1780.
0.10::sw1781.
takesCourse(ugrad71_d1,course3_d1) :- sw1781.
0.94::sw1782.
takesCourse(ugrad71_d1,course5_d1) :- sw1782.
0.85::sw1783.
undergraduateStudent(ugrad72_d1) :- sw1783.
0.77::sw1784.
memberOf(ugrad72_d1,dept1) :- sw1784.
0.55::sw1785.
takesCourse(ugrad72_d1,course2_d1) :- sw1785.
0.96::sw1786.
takesCourse(ugrad72_d1,course13_d1) :- sw1786.
0.70::sw1787.
advisor(ugrad72_d1,assi4_d1) :- sw1787.
0.10::sw1788.
undergraduateStudent(ugrad73_d1) :- sw1788.
0.53::sw1789.
memberOf(ugrad73_d1,dept1) :- sw1789.
0.42::sw1790.
takesCourse(ugrad73_d1,course12_d1) :- sw1790.
0.26::sw1791.
takesCourse(ugrad73_d1,course0_d1) :- sw1791.
0.98::sw1792.
undergraduateStudent(ugrad74_d1) :- sw1792.
0.49::sw1793.
memberOf(ugrad74_d1,dept1) :- sw1793.
0.78::sw1794.
takesCourse(ugrad74_d1,course5_d1) :- sw1794.
0.14::sw1795.
takesCourse(ugrad74_d1,course15_d1) :- sw1795.
0.30::sw1796.
undergraduateStudent(ugrad75_d1) :- sw1796.
0.08::sw1797.
memberOf(ugrad75_d1,dept1) :- sw1797.
0.72::sw1798.
takesCourse(ugrad75_d1,course12_d1) :- sw1798.
0.79::sw1799.
takesCourse(ugrad75_d1,course6_d1) :- sw1799.
0.40::sw1800.
undergraduateStudent(ugrad76_d1) :- sw1800.
0.89::sw1801.
memberOf(ugrad76_d1,dept1) :- sw1801.
0.51::sw1802.
takesCourse(ugrad76_d1,course13_d1) :- sw1802.
0.63::sw1803.
takesCourse(ugrad76_d1,course18_d1) :- sw1803.
0.24::sw1804.
undergraduateStudent(ugrad77_d1) :- sw1804.
0.12::sw1805.
memberOf(ugrad77_d1,dept1) :- sw1805.
0.88::sw1806.
takesCourse(ugrad77_d1,course9_d1) :- sw1806.
0.95::sw1807.
takesCourse(ugrad77_d1,course13_d1) :- sw1807.
0.19::sw1808.
undergraduateStudent(ugrad78_d1) :- sw1808.
0.20::sw1809.
memberOf(ugrad78_d1,dept1) :- sw1809.
0.44::sw1810.
takesCourse(ugrad78_d1,course2_d1) :- sw1810.
0.77::sw1811.
takesCourse(ugrad78_d1,course19_d1) :- sw1811.
0.52::sw1812.
undergraduateStudent(ugrad79_d1) :- sw1812.
0.95::sw1813.
memberOf(ugrad79_d1,dept1) :- sw1813.
0.67::sw1814.
takesCourse(ugrad79_d1,course10_d1) :- sw1814.
0.49::sw1815.
takesCourse(ugrad79_d1,course2_d1) :- sw1815.
0.07::sw1816.
undergraduateStudent(ugrad80_d1) :- sw1816.
0.77::sw1817.
memberOf(ugrad80_d1,dept1) :- sw1817.
0.56::sw1818.
takesCourse(ugrad80_d1,course10_d1) :- sw1818.
0.93::sw1819.
takesCourse(ugrad80_d1,course15_d1) :- sw1819.
0.22::sw1820.
undergraduateStudent(ugrad81_d1) :- sw1820.
0.27::sw1821.
memberOf(ugrad81_d1,dept1) :- sw1821.
0.63::sw1822.
takesCourse(ugrad81_d1,course3_d1) :- sw1822.
0.49::sw1823.
takesCourse(ugrad81_d1,course10_d1) :- sw1823.
0.77::sw1824.
undergraduateStudent(ugrad82_d1) :- sw1824.
0.24::sw1825.
memberOf(ugrad82_d1,dept1) :- sw1825.
0.39::sw1826.
takesCourse(ugrad82_d1,course18_d1) :- sw1826.
0.74::sw1827.
takesCourse(ugrad82_d1,course7_d1) :- sw1827.
0.87::sw1828.
undergraduateStudent(ugrad83_d1) :- sw1828.
0.56::sw1829.
memberOf(ugrad83_d1,dept1) :- sw1829.
0.70::sw1830.
takesCourse(ugrad83_d1,course6_d1) :- sw1830.
0.17::sw1831.
takesCourse(ugrad83_d1,course12_d1) :- sw1831.
0.52::sw1832.
undergraduateStudent(ugrad84_d1) :- sw1832.
0.07::sw1833.
memberOf(ugrad84_d1,dept1) :- sw1833.
0.25::sw1834.
takesCourse(ugrad84_d1,course1_d1) :- sw1834.
0.82::sw1835.
takesCourse(ugrad84_d1,course16_d1) :- sw1835.
0.45::sw1836.
advisor(ugrad84_d1,lect4_d1) :- sw1836.
0.21::sw1837.
undergraduateStudent(ugrad85_d1) :- sw1837.
0.45::sw1838.
memberOf(ugrad85_d1,dept1) :- sw1838.
0.43::sw1839.
takesCourse(ugrad85_d1,course16_d1) :- sw1839.
0.84::sw1840.
takesCourse(ugrad85_d1,course7_d1) :- sw1840.
0.24::sw1841.
undergraduateStudent(ugrad86_d1) :- sw1841.
0.49::sw1842.
memberOf(ugrad86_d1,dept1) :- sw1842.
0.92::sw1843.
takesCourse(ugrad86_d1,course2_d1) :- sw1843.
0.53::sw1844.
takesCourse(ugrad86_d1,course5_d1) :- sw1844.
0.53::sw1845.
undergraduateStudent(ugrad87_d1) :- sw1845.
0.49::sw1846.
memberOf(ugrad87_d1,dept1) :- sw1846.
0.22::sw1847.
takesCourse(ugrad87_d1,course15_d1) :- sw1847.
0.15::sw1848.
takesCourse(ugrad87_d1,course17_d1) :- sw1848.
0.74::sw1849.
undergraduateStudent(ugrad88_d1) :- sw1849.
0.24::sw1850.
memberOf(ugrad88_d1,dept1) :- sw1850.
0.94::sw1851.
takesCourse(ugrad88_d1,course11_d1) :- sw1851.
0.91::sw1852.
takesCourse(ugrad88_d1,course14_d1) :- sw1852.
0.56::sw1853.
undergraduateStudent(ugrad89_d1) :- sw1853.
0.30::sw1854.
memberOf(ugrad89_d1,dept1) :- sw1854.
0.82::sw1855.
takesCourse(ugrad89_d1,course16_d1) :- sw1855.
0.94::sw1856.
takesCourse(ugrad89_d1,course7_d1) :- sw1856.
0.93::sw1857.
undergraduateStudent(ugrad90_d1) :- sw1857.
0.55::sw1858.
memberOf(ugrad90_d1,dept1) :- sw1858.
0.64::sw1859.
takesCourse(ugrad90_d1,course9_d1) :- sw1859.
0.39::sw1860.
takesCourse(ugrad90_d1,course10_d1) :- sw1860.
0.16::sw1861.
undergraduateStudent(ugrad91_d1) :- sw1861.
0.20::sw1862.
memberOf(ugrad91_d1,dept1) :- sw1862.
0.10::sw1863.
takesCourse(ugrad91_d1,course4_d1) :- sw1863.
0.62::sw1864.
takesCourse(ugrad91_d1,course18_d1) :- sw1864.
0.18::sw1865.
undergraduateStudent(ugrad92_d1) :- sw1865.
0.84::sw1866.
memberOf(ugrad92_d1,dept1) :- sw1866.
0.53::sw1867.
takesCourse(ugrad92_d1,course19_d1) :- sw1867.
0.26::sw1868.
takesCourse(ugrad92_d1,course16_d1) :- sw1868.
0.42::sw1869.
undergraduateStudent(ugrad93_d1) :- sw1869.
0.45::sw1870.
memberOf(ugrad93_d1,dept1) :- sw1870.
0.63::sw1871.
takesCourse(ugrad93_d1,course18_d1) :- sw1871.
0.71::sw1872.
takesCourse(ugrad93_d1,course16_d1) :- sw1872.
0.18::sw1873.
undergraduateStudent(ugrad94_d1) :- sw1873.
0.52::sw1874.
memberOf(ugrad94_d1,dept1) :- sw1874.
0.69::sw1875.
takesCourse(ugrad94_d1,course1_d1) :- sw1875.
0.92::sw1876.
takesCourse(ugrad94_d1,course13_d1) :- sw1876.
0.82::sw1877.
undergraduateStudent(ugrad95_d1) :- sw1877.
0.05::sw1878.
memberOf(ugrad95_d1,dept1) :- sw1878.
0.62::sw1879.
takesCourse(ugrad95_d1,course6_d1) :- sw1879.
0.16::sw1880.
takesCourse(ugrad95_d1,course15_d1) :- sw1880.
0.58::sw1881.
undergraduateStudent(ugrad96_d1) :- sw1881.
0.97::sw1882.
memberOf(ugrad96_d1,dept1) :- sw1882.
0.26::sw1883.
takesCourse(ugrad96_d1,course6_d1) :- sw1883.
0.41::sw1884.
takesCourse(ugrad96_d1,course5_d1) :- sw1884.
0.33::sw1885.
undergraduateStudent(ugrad97_d1) :- sw1885.
0.45::sw1886.
memberOf(ugrad97_d1,dept1) :- sw1886.
0.16::sw1887.
takesCourse(ugrad97_d1,course14_d1) :- sw1887.
0.35::sw1888.
takesCourse(ugrad97_d1,course3_d1) :- sw1888.
0.27::sw1889.
undergraduateStudent(ugrad98_d1) :- sw1889.
0.13::sw1890.
memberOf(ugrad98_d1,dept1) :- sw1890.
0.11::sw1891.
takesCourse(ugrad98_d1,course16_d1) :- sw1891.
0.31::sw1892.
takesCourse(ugrad98_d1,course12_d1) :- sw1892.
0.73::sw1893.
undergraduateStudent(ugrad99_d1) :- sw1893.
0.06::sw1894.
memberOf(ugrad99_d1,dept1) :- sw1894.
0.84::sw1895.
takesCourse(ugrad99_d1,course10_d1) :- sw1895.
0.47::sw1896.
takesCourse(ugrad99_d1,course5_d1) :- sw1896.
0.80::sw1897.
undergraduateStudent(ugrad100_d1) :- sw1897.
0.24::sw1898.
memberOf(ugrad100_d1,dept1) :- sw1898.
0.74::sw1899.
takesCourse(ugrad100_d1,course10_d1) :- sw1899.
0.06::sw1900.
takesCourse(ugrad100_d1,course15_d1) :- sw1900.
0.23::sw1901.
undergraduateStudent(ugrad101_d1) :- sw1901.
0.94::sw1902.
memberOf(ugrad101_d1,dept1) :- sw1902.
0.53::sw1903.
takesCourse(ugrad101_d1,course1_d1) :- sw1903.
0.56::sw1904.
takesCourse(ugrad101_d1,course7_d1) :- sw1904.
0.31::sw1905.
undergraduateStudent(ugrad102_d1) :- sw1905.
0.11::sw1906.
memberOf(ugrad102_d1,dept1) :- sw1906.
0.10::sw1907.
takesCourse(ugrad102_d1,course12_d1) :- sw1907.
0.06::sw1908.
takesCourse(ugrad102_d1,course7_d1) :- sw1908.
0.74::sw1909.
advisor(ugrad102_d1,asso8_d1) :- sw1909.
0.52::sw1910.
undergraduateStudent(ugrad103_d1) :- sw1910.
0.41::sw1911.
memberOf(ugrad103_d1,dept1) :- sw1911.
0.31::sw1912.
takesCourse(ugrad103_d1,course11_d1) :- sw1912.
0.99::sw1913.
takesCourse(ugrad103_d1,course8_d1) :- sw1913.
0.11::sw1914.
advisor(ugrad103_d1,assi3_d1) :- sw1914.
0.25::sw1915.
undergraduateStudent(ugrad104_d1) :- sw1915.
0.42::sw1916.
memberOf(ugrad104_d1,dept1) :- sw1916.
0.69::sw1917.
takesCourse(ugrad104_d1,course3_d1) :- sw1917.
0.73::sw1918.
takesCourse(ugrad104_d1,course6_d1) :- sw1918.
0.97::sw1919.
undergraduateStudent(ugrad105_d1) :- sw1919.
0.59::sw1920.
memberOf(ugrad105_d1,dept1) :- sw1920.
0.39::sw1921.
takesCourse(ugrad105_d1,course14_d1) :- sw1921.
0.71::sw1922.
takesCourse(ugrad105_d1,course5_d1) :- sw1922.
0.41::sw1923.
undergraduateStudent(ugrad106_d1) :- sw1923.
0.47::sw1924.
memberOf(ugrad106_d1,dept1) :- sw1924.
0.80::sw1925.
takesCourse(ugrad106_d1,course7_d1) :- sw1925.
0.86::sw1926.
takesCourse(ugrad106_d1,course15_d1) :- sw1926.
0.63::sw1927.
undergraduateStudent(ugrad107_d1) :- sw1927.
0.17::sw1928.
memberOf(ugrad107_d1,dept1) :- sw1928.
0.66::sw1929.
takesCourse(ugrad107_d1,course6_d1) :- sw1929.
0.81::sw1930.
takesCourse(ugrad107_d1,course11_d1) :- sw1930.
0.82::sw1931.
undergraduateStudent(ugrad108_d1) :- sw1931.
0.47::sw1932.
memberOf(ugrad108_d1,dept1) :- sw1932.
0.54::sw1933.
takesCourse(ugrad108_d1,course5_d1) :- sw1933.
0.40::sw1934.
takesCourse(ugrad108_d1,course16_d1) :- sw1934.
0.05::sw1935.
undergraduateStudent(ugrad109_d1) :- sw1935.
0.51::sw1936.
memberOf(ugrad109_d1,dept1) :- sw1936.
0.44::sw1937.
takesCourse(ugrad109_d1,course17_d1) :- sw1937.
0.29::sw1938.
takesCourse(ugrad109_d1,course13_d1) :- sw1938.
0.72::sw1939.
undergraduateStudent(ugrad110_d1) :- sw1939.
0.25::sw1940.
memberOf(ugrad110_d1,dept1) :- sw1940.
0.67::sw1941.
takesCourse(ugrad110_d1,course9_d1) :- sw1941.
0.10::sw1942.
takesCourse(ugrad110_d1,course14_d1) :- sw1942.
0.55::sw1943.
undergraduateStudent(ugrad111_d1) :- sw1943.
0.34::sw1944.
memberOf(ugrad111_d1,dept1) :- sw1944.
0.96::sw1945.
takesCourse(ugrad111_d1,course2_d1) :- sw1945.
0.38::sw1946.
takesCourse(ugrad111_d1,course17_d1) :- sw1946.
0.49::sw1947.
undergraduateStudent(ugrad112_d1) :- sw1947.
0.17::sw1948.
memberOf(ugrad112_d1,dept1) :- sw1948.
0.88::sw1949.
takesCourse(ugrad112_d1,course15_d1) :- sw1949.
0.42::sw1950.
takesCourse(ugrad112_d1,course0_d1) :- sw1950.
0.62::sw1951.
undergraduateStudent(ugrad113_d1) :- sw1951.
0.79::sw1952.
memberOf(ugrad113_d1,dept1) :- sw1952.
0.43::sw1953.
takesCourse(ugrad113_d1,course8_d1) :- sw1953.
0.06::sw1954.
takesCourse(ugrad113_d1,course16_d1) :- sw1954.
0.85::sw1955.
undergraduateStudent(ugrad114_d1) :- sw1955.
0.25::sw1956.
memberOf(ugrad114_d1,dept1) :- sw1956.
0.99::sw1957.
takesCourse(ugrad114_d1,course15_d1) :- sw1957.
0.21::sw1958.
takesCourse(ugrad114_d1,course7_d1) :- sw1958.
0.15::sw1959.
undergraduateStudent(ugrad115_d1) :- sw1959.
0.65::sw1960.
memberOf(ugrad115_d1,dept1) :- sw1960.
0.12::sw1961.
takesCourse(ugrad115_d1,course16_d1) :- sw1961.
0.52::sw1962.
takesCourse(ugrad115_d1,course15_d1) :- sw1962.
0.88::sw1963.
undergraduateStudent(ugrad116_d1) :- sw1963.
0.99::sw1964.
memberOf(ugrad116_d1,dept1) :- sw1964.
0.24::sw1965.
takesCourse(ugrad116_d1,course19_d1) :- sw1965.
0.88::sw1966.
takesCourse(ugrad116_d1,course15_d1) :- sw1966.
0.96::sw1967.
undergraduateStudent(ugrad117_d1) :- sw1967.
0.48::sw1968.
memberOf(ugrad117_d1,dept1) :- sw1968.
0.47::sw1969.
takesCourse(ugrad117_d1,course3_d1) :- sw1969.
0.22::sw1970.
takesCourse(ugrad117_d1,course13_d1) :- sw1970.
0.31::sw1971.
undergraduateStudent(ugrad118_d1) :- sw1971.
0.63::sw1972.
memberOf(ugrad118_d1,dept1) :- sw1972.
0.43::sw1973.
takesCourse(ugrad118_d1,course4_d1) :- sw1973.
0.96::sw1974.
takesCourse(ugrad118_d1,course18_d1) :- sw1974.
0.42::sw1975.
undergraduateStudent(ugrad119_d1) :- sw1975.
0.21::sw1976.
memberOf(ugrad119_d1,dept1) :- sw1976.
0.32::sw1977.
takesCourse(ugrad119_d1,course11_d1) :- sw1977.
0.97::sw1978.
takesCourse(ugrad119_d1,course16_d1) :- sw1978.
0.15::sw1979.
advisor(ugrad119_d1,assi1_d1) :- sw1979.
0.28::sw1980.
undergraduateStudent(ugrad120_d1) :- sw1980.
0.68::sw1981.
memberOf(ugrad120_d1,dept1) :- sw1981.
0.83::sw1982.
takesCourse(ugrad120_d1,course15_d1) :- sw1982.
0.27::sw1983.
takesCourse(ugrad120_d1,course17_d1) :- sw1983.
0.20::sw1984.
advisor(ugrad120_d1,lect0_d1) :- sw1984.
0.47::sw1985.
undergraduateStudent(ugrad121_d1) :- sw1985.
0.36::sw1986.
memberOf(ugrad121_d1,dept1) :- sw1986.
0.44::sw1987.
takesCourse(ugrad121_d1,course11_d1) :- sw1987.
0.34::sw1988.
takesCourse(ugrad121_d1,course15_d1) :- sw1988.
0.60::sw1989.
advisor(ugrad121_d1,assi4_d1) :- sw1989.
0.48::sw1990.
undergraduateStudent(ugrad122_d1) :- sw1990.
0.18::sw1991.
memberOf(ugrad122_d1,dept1) :- sw1991.
0.39::sw1992.
takesCourse(ugrad122_d1,course6_d1) :- sw1992.
0.59::sw1993.
takesCourse(ugrad122_d1,course2_d1) :- sw1993.
0.47::sw1994.
undergraduateStudent(ugrad123_d1) :- sw1994.
0.51::sw1995.
memberOf(ugrad123_d1,dept1) :- sw1995.
0.68::sw1996.
takesCourse(ugrad123_d1,course17_d1) :- sw1996.
0.94::sw1997.
takesCourse(ugrad123_d1,course18_d1) :- sw1997.
0.75::sw1998.
undergraduateStudent(ugrad124_d1) :- sw1998.
0.33::sw1999.
memberOf(ugrad124_d1,dept1) :- sw1999.
0.63::sw2000.
takesCourse(ugrad124_d1,course9_d1) :- sw2000.
0.64::sw2001.
takesCourse(ugrad124_d1,course17_d1) :- sw2001.
0.19::sw2002.
undergraduateStudent(ugrad125_d1) :- sw2002.
0.75::sw2003.
memberOf(ugrad125_d1,dept1) :- sw2003.
0.90::sw2004.
takesCourse(ugrad125_d1,course13_d1) :- sw2004.
0.88::sw2005.
takesCourse(ugrad125_d1,course9_d1) :- sw2005.
0.76::sw2006.
undergraduateStudent(ugrad126_d1) :- sw2006.
0.71::sw2007.
memberOf(ugrad126_d1,dept1) :- sw2007.
0.62::sw2008.
takesCourse(ugrad126_d1,course13_d1) :- sw2008.
0.21::sw2009.
takesCourse(ugrad126_d1,course17_d1) :- sw2009.
0.68::sw2010.
undergraduateStudent(ugrad127_d1) :- sw2010.
0.09::sw2011.
memberOf(ugrad127_d1,dept1) :- sw2011.
0.18::sw2012.
takesCourse(ugrad127_d1,course11_d1) :- sw2012.
0.12::sw2013.
takesCourse(ugrad127_d1,course13_d1) :- sw2013.
0.34::sw2014.
undergraduateStudent(ugrad128_d1) :- sw2014.
0.24::sw2015.
memberOf(ugrad128_d1,dept1) :- sw2015.
0.84::sw2016.
takesCourse(ugrad128_d1,course18_d1) :- sw2016.
0.58::sw2017.
takesCourse(ugrad128_d1,course5_d1) :- sw2017.
0.28::sw2018.
undergraduateStudent(ugrad129_d1) :- sw2018.
0.43::sw2019.
memberOf(ugrad129_d1,dept1) :- sw2019.
0.84::sw2020.
takesCourse(ugrad129_d1,course6_d1) :- sw2020.
0.88::sw2021.
takesCourse(ugrad129_d1,course18_d1) :- sw2021.
0.77::sw2022.
undergraduateStudent(ugrad130_d1) :- sw2022.
0.47::sw2023.
memberOf(ugrad130_d1,dept1) :- sw2023.
0.36::sw2024.
takesCourse(ugrad130_d1,course3_d1) :- sw2024.
0.91::sw2025.
takesCourse(ugrad130_d1,course10_d1) :- sw2025.
0.95::sw2026.
undergraduateStudent(ugrad131_d1) :- sw2026.
0.76::sw2027.
memberOf(ugrad131_d1,dept1) :- sw2027.
0.48::sw2028.
takesCourse(ugrad131_d1,course10_d1) :- sw2028.
0.73::sw2029.
takesCourse(ugrad131_d1,course15_d1) :- sw2029.
0.37::sw2030.
advisor(ugrad131_d1,assi7_d1) :- sw2030.
0.22::sw2031.
undergraduateStudent(ugrad132_d1) :- sw2031.
0.22::sw2032.
memberOf(ugrad132_d1,dept1) :- sw2032.
0.48::sw2033.
takesCourse(ugrad132_d1,course14_d1) :- sw2033.
0.99::sw2034.
takesCourse(ugrad132_d1,course6_d1) :- sw2034.
0.59::sw2035.
undergraduateStudent(ugrad133_d1) :- sw2035.
0.81::sw2036.
memberOf(ugrad133_d1,dept1) :- sw2036.
0.85::sw2037.
takesCourse(ugrad133_d1,course17_d1) :- sw2037.
0.98::sw2038.
takesCourse(ugrad133_d1,course18_d1) :- sw2038.
0.94::sw2039.
undergraduateStudent(ugrad134_d1) :- sw2039.
0.19::sw2040.
memberOf(ugrad134_d1,dept1) :- sw2040.
0.34::sw2041.
takesCourse(ugrad134_d1,course1_d1) :- sw2041.
0.18::sw2042.
takesCourse(ugrad134_d1,course15_d1) :- sw2042.
0.64::sw2043.
undergraduateStudent(ugrad135_d1) :- sw2043.
0.93::sw2044.
memberOf(ugrad135_d1,dept1) :- sw2044.
0.46::sw2045.
takesCourse(ugrad135_d1,course5_d1) :- sw2045.
0.99::sw2046.
takesCourse(ugrad135_d1,course16_d1) :- sw2046.
0.31::sw2047.
undergraduateStudent(ugrad136_d1) :- sw2047.
0.69::sw2048.
memberOf(ugrad136_d1,dept1) :- sw2048.
0.42::sw2049.
takesCourse(ugrad136_d1,course3_d1) :- sw2049.
0.55::sw2050.
takesCourse(ugrad136_d1,course19_d1) :- sw2050.
0.90::sw2051.
undergraduateStudent(ugrad137_d1) :- sw2051.
0.78::sw2052.
memberOf(ugrad137_d1,dept1) :- sw2052.
0.12::sw2053.
takesCourse(ugrad137_d1,course3_d1) :- sw2053.
0.79::sw2054.
takesCourse(ugrad137_d1,course12_d1) :- sw2054.
0.91::sw2055.
undergraduateStudent(ugrad138_d1) :- sw2055.
0.75::sw2056.
memberOf(ugrad138_d1,dept1) :- sw2056.
0.74::sw2057.
takesCourse(ugrad138_d1,course16_d1) :- sw2057.
0.93::sw2058.
takesCourse(ugrad138_d1,course10_d1) :- sw2058.
0.62::sw2059.
undergraduateStudent(ugrad139_d1) :- sw2059.
0.87::sw2060.
memberOf(ugrad139_d1,dept1) :- sw2060.
0.15::sw2061.
takesCourse(ugrad139_d1,course2_d1) :- sw2061.
0.14::sw2062.
takesCourse(ugrad139_d1,course15_d1) :- sw2062.
0.23::sw2063.
undergraduateStudent(ugrad140_d1) :- sw2063.
0.22::sw2064.
memberOf(ugrad140_d1,dept1) :- sw2064.
0.87::sw2065.
takesCourse(ugrad140_d1,course10_d1) :- sw2065.
0.82::sw2066.
takesCourse(ugrad140_d1,course7_d1) :- sw2066.
0.11::sw2067.
undergraduateStudent(ugrad141_d1) :- sw2067.
0.94::sw2068.
memberOf(ugrad141_d1,dept1) :- sw2068.
0.73::sw2069.
takesCourse(ugrad141_d1,course3_d1) :- sw2069.
0.36::sw2070.
takesCourse(ugrad141_d1,course6_d1) :- sw2070.
0.85::sw2071.
undergraduateStudent(ugrad142_d1) :- sw2071.
0.58::sw2072.
memberOf(ugrad142_d1,dept1) :- sw2072.
0.26::sw2073.
takesCourse(ugrad142_d1,course15_d1) :- sw2073.
0.37::sw2074.
takesCourse(ugrad142_d1,course11_d1) :- sw2074.
0.53::sw2075.
undergraduateStudent(ugrad143_d1) :- sw2075.
0.37::sw2076.
memberOf(ugrad143_d1,dept1) :- sw2076.
0.78::sw2077.
takesCourse(ugrad143_d1,course8_d1) :- sw2077.
0.65::sw2078.
takesCourse(ugrad143_d1,course11_d1) :- sw2078.
0.31::sw2079.
undergraduateStudent(ugrad144_d1) :- sw2079.
memberOf(ugrad144_d1,dept1).
0.31::sw2080.
takesCourse(ugrad144_d1,course5_d1) :- sw2080.
0.40::sw2081.
takesCourse(ugrad144_d1,course8_d1) :- sw2081.
0.53::sw2082.
undergraduateStudent(ugrad145_d1) :- sw2082.
0.85::sw2083.
memberOf(ugrad145_d1,dept1) :- sw2083.
0.79::sw2084.
takesCourse(ugrad145_d1,course16_d1) :- sw2084.
0.72::sw2085.
takesCourse(ugrad145_d1,course6_d1) :- sw2085.
0.56::sw2086.
undergraduateStudent(ugrad146_d1) :- sw2086.
0.39::sw2087.
memberOf(ugrad146_d1,dept1) :- sw2087.
0.27::sw2088.
takesCourse(ugrad146_d1,course7_d1) :- sw2088.
0.34::sw2089.
takesCourse(ugrad146_d1,course8_d1) :- sw2089.
0.57::sw2090.
undergraduateStudent(ugrad147_d1) :- sw2090.
0.09::sw2091.
memberOf(ugrad147_d1,dept1) :- sw2091.
0.78::sw2092.
takesCourse(ugrad147_d1,course10_d1) :- sw2092.
0.82::sw2093.
takesCourse(ugrad147_d1,course3_d1) :- sw2093.
0.30::sw2094.
advisor(ugrad147_d1,asso0_d1) :- sw2094.
0.48::sw2095.
undergraduateStudent(ugrad148_d1) :- sw2095.
0.97::sw2096.
memberOf(ugrad148_d1,dept1) :- sw2096.
0.22::sw2097.
takesCourse(ugrad148_d1,course2_d1) :- sw2097.
0.43::sw2098.
takesCourse(ugrad148_d1,course7_d1) :- sw2098.
0.39::sw2099.
undergraduateStudent(ugrad149_d1) :- sw2099.
0.60::sw2100.
memberOf(ugrad149_d1,dept1) :- sw2100.
0.96::sw2101.
takesCourse(ugrad149_d1,course10_d1) :- sw2101.
0.27::sw2102.
takesCourse(ugrad149_d1,course3_d1) :- sw2102.
0.53::sw2103.
graduateStudent(grad0_d1) :- sw2103.
0.93::sw2104.
memberOf(grad0_d1,dept1) :- sw2104.
0.64::sw2105.
undergraduateDegreeFrom(grad0_d1,univ2) :- sw2105.
0.41::sw2106.
advisor(grad0_d1,asso2_d1) :- sw2106.
0.20::sw2107.
takesCourse(grad0_d1,gradCourse0_d1) :- sw2107.
0.27::sw2108.
takesCourse(grad0_d1,gradCourse7_d1) :- sw2108.
0.66::sw2109.
teachingAssistantOf(grad0_d1,course16_d1) :- sw2109.
0.71::sw2110.
graduateStudent(grad1_d1) :- sw2110.
0.59::sw2111.
memberOf(grad1_d1,dept1) :- sw2111.
0.77::sw2112.
undergraduateDegreeFrom(grad1_d1,univ2) :- sw2112.
0.07::sw2113.
advisor(grad1_d1,assi5_d1) :- sw2113.
0.73::sw2114.
takesCourse(grad1_d1,gradCourse7_d1) :- sw2114.
0.92::sw2115.
takesCourse(grad1_d1,gradCourse6_d1) :- sw2115.
0.60::sw2116.
graduateStudent(grad2_d1) :- sw2116.
0.45::sw2117.
memberOf(grad2_d1,dept1) :- sw2117.
0.06::sw2118.
undergraduateDegreeFrom(grad2_d1,univ9) :- sw2118.
0.26::sw2119.
advisor(grad2_d1,assi9_d1) :- sw2119.
0.36::sw2120.
takesCourse(grad2_d1,gradCourse6_d1) :- sw2120.
0.20::sw2121.
takesCourse(grad2_d1,gradCourse4_d1) :- sw2121.
0.89::sw2122.
teachingAssistantOf(grad2_d1,course8_d1) :- sw2122.
0.94::sw2123.
graduateStudent(grad3_d1) :- sw2123.
0.23::sw2124.
memberOf(grad3_d1,dept1) :- sw2124.
0.88::sw2125.
undergraduateDegreeFrom(grad3_d1,univ9) :- sw2125.
0.10::sw2126.
advisor(grad3_d1,assi6_d1) :- sw2126.
0.78::sw2127.
takesCourse(grad3_d1,gradCourse2_d1) :- sw2127.
0.84::sw2128.
takesCourse(grad3_d1,gradCourse0_d1) :- sw2128.
0.44::sw2129.
teachingAssistantOf(grad3_d1,course13_d1) :- sw2129.
0.78::sw2130.
graduateStudent(grad4_d1) :- sw2130.
0.36::sw2131.
memberOf(grad4_d1,dept1) :- sw2131.
0.49::sw2132.
undergraduateDegreeFrom(grad4_d1,univ0) :- sw2132.
0.40::sw2133.
advisor(grad4_d1,asso5_d1) :- sw2133.
0.88::sw2134.
takesCourse(grad4_d1,gradCourse2_d1) :- sw2134.
0.67::sw2135.
takesCourse(grad4_d1,gradCourse8_d1) :- sw2135.
0.83::sw2136.
graduateStudent(grad5_d1) :- sw2136.
memberOf(grad5_d1,dept1).
0.42::sw2137.
undergraduateDegreeFrom(grad5_d1,univ3) :- sw2137.
0.62::sw2138.
advisor(grad5_d1,assi5_d1) :- sw2138.
0.71::sw2139.
takesCourse(grad5_d1,gradCourse4_d1) :- sw2139.
0.76::sw2140.
takesCourse(grad5_d1,gradCourse0_d1) :- sw2140.
0.23::sw2141.
graduateStudent(grad6_d1) :- sw2141.
0.16::sw2142.
memberOf(grad6_d1,dept1) :- sw2142.
0.54::sw2143.
undergraduateDegreeFrom(grad6_d1,univ9) :- sw2143.
0.51::sw2144.
advisor(grad6_d1,assi4_d1) :- sw2144.
0.70::sw2145.
takesCourse(grad6_d1,gradCourse3_d1) :- sw2145.
0.27::sw2146.
takesCourse(grad6_d1,gradCourse1_d1) :- sw2146.
0.77::sw2147.
teachingAssistantOf(grad6_d1,course2_d1) :- sw2147.
0.43::sw2148.
graduateStudent(grad7_d1) :- sw2148.
0.07::sw2149.
memberOf(grad7_d1,dept1) :- sw2149.
0.55::sw2150.
undergraduateDegreeFrom(grad7_d1,univ7) :- sw2150.
0.34::sw2151.
advisor(grad7_d1,assi9_d1) :- sw2151.
0.13::sw2152.
takesCourse(grad7_d1,gradCourse4_d1) :- sw2152.
0.72::sw2153.
takesCourse(grad7_d1,gradCourse2_d1) :- sw2153.
0.93::sw2154.
teachingAssistantOf(grad7_d1,course10_d1) :- sw2154.
0.20::sw2155.
graduateStudent(grad8_d1) :- sw2155.
0.50::sw2156.
memberOf(grad8_d1,dept1) :- sw2156.
0.11::sw2157.
undergraduateDegreeFrom(grad8_d1,univ9) :- sw2157.
0.50::sw2158.
advisor(grad8_d1,asso2_d1) :- sw2158.
0.09::sw2159.
takesCourse(grad8_d1,gradCourse4_d1) :- sw2159.
0.51::sw2160.
takesCourse(grad8_d1,gradCourse2_d1) :- sw2160.
0.24::sw2161.
teachingAssistantOf(grad8_d1,course2_d1) :- sw2161.
0.32::sw2162.
graduateStudent(grad9_d1) :- sw2162.
0.23::sw2163.
memberOf(grad9_d1,dept1) :- sw2163.
0.90::sw2164.
undergraduateDegreeFrom(grad9_d1,univ2) :- sw2164.
0.53::sw2165.
advisor(grad9_d1,full6_d1) :- sw2165.
0.51::sw2166.
takesCourse(grad9_d1,gradCourse0_d1) :- sw2166.
0.52::sw2167.
takesCourse(grad9_d1,gradCourse1_d1) :- sw2167.
0.90::sw2168.
graduateStudent(grad10_d1) :- sw2168.
0.26::sw2169.
memberOf(grad10_d1,dept1) :- sw2169.
0.24::sw2170.
undergraduateDegreeFrom(grad10_d1,univ8) :- sw2170.
0.23::sw2171.
advisor(grad10_d1,assi7_d1) :- sw2171.
0.84::sw2172.
takesCourse(grad10_d1,gradCourse7_d1) :- sw2172.
0.59::sw2173.
takesCourse(grad10_d1,gradCourse8_d1) :- sw2173.
0.21::sw2174.
graduateStudent(grad11_d1) :- sw2174.
0.09::sw2175.
memberOf(grad11_d1,dept1) :- sw2175.
0.12::sw2176.
undergraduateDegreeFrom(grad11_d1,univ9) :- sw2176.
0.69::sw2177.
advisor(grad11_d1,lect0_d1) :- sw2177.
0.85::sw2178.
takesCourse(grad11_d1,gradCourse4_d1) :- sw2178.
0.31::sw2179.
takesCourse(grad11_d1,gradCourse2_d1) :- sw2179.
0.30::sw2180.
graduateStudent(grad12_d1) :- sw2180.
0.75::sw2181.
memberOf(grad12_d1,dept1) :- sw2181.
0.57::sw2182.
undergraduateDegreeFrom(grad12_d1,univ0) :- sw2182.
0.80::sw2183.
advisor(grad12_d1,full4_d1) :- sw2183.
0.37::sw2184.
takesCourse(grad12_d1,gradCourse4_d1) :- sw2184.
0.81::sw2185.
takesCourse(grad12_d1,gradCourse6_d1) :- sw2185.
0.24::sw2186.
teachingAssistantOf(grad12_d1,course1_d1) :- sw2186.
0.54::sw2187.
graduateStudent(grad13_d1) :- sw2187.
0.92::sw2188.
memberOf(grad13_d1,dept1) :- sw2188.
0.60::sw2189.
undergraduateDegreeFrom(grad13_d1,univ5) :- sw2189.
0.43::sw2190.
advisor(grad13_d1,assi2_d1) :- sw2190.
0.52::sw2191.
takesCourse(grad13_d1,gradCourse5_d1) :- sw2191.
0.94::sw2192.
takesCourse(grad13_d1,gradCourse1_d1) :- sw2192.
0.28::sw2193.
teachingAssistantOf(grad13_d1,course6_d1) :- sw2193.
0.99::sw2194.
graduateStudent(grad14_d1) :- sw2194.
0.67::sw2195.
memberOf(grad14_d1,dept1) :- sw2195.
0.18::sw2196.
undergraduateDegreeFrom(grad14_d1,univ6) :- sw2196.
0.28::sw2197.
advisor(grad14_d1,full0_d1) :- sw2197.
0.31::sw2198.
takesCourse(grad14_d1,gradCourse8_d1) :- sw2198.
0.19::sw2199.
takesCourse(grad14_d1,gradCourse7_d1) :- sw2199.
0.12::sw2200.
graduateStudent(grad15_d1) :- sw2200.
0.15::sw2201.
memberOf(grad15_d1,dept1) :- sw2201.
0.43::sw2202.
undergraduateDegreeFrom(grad15_d1,univ5) :- sw2202.
0.38::sw2203.
advisor(grad15_d1,asso6_d1) :- sw2203.
0.44::sw2204.
takesCourse(grad15_d1,gradCourse7_d1) :- sw2204.
0.11::sw2205.
takesCourse(grad15_d1,gradCourse9_d1) :- sw2205.
0.75::sw2206.
teachingAssistantOf(grad15_d1,course0_d1) :- sw2206.
0.49::sw2207.
graduateStudent(grad16_d1) :- sw2207.
0.06::sw2208.
memberOf(grad16_d1,dept1) :- sw2208.
0.45::sw2209.
undergraduateDegreeFrom(grad16_d1,univ5) :- sw2209.
0.60::sw2210.
advisor(grad16_d1,asso5_d1) :- sw2210.
0.21::sw2211.
takesCourse(grad16_d1,gradCourse3_d1) :- sw2211.
0.94::sw2212.
takesCourse(grad16_d1,gradCourse2_d1) :- sw2212.
0.09::sw2213.
graduateStudent(grad17_d1) :- sw2213.
0.28::sw2214.
memberOf(grad17_d1,dept1) :- sw2214.
0.27::sw2215.
undergraduateDegreeFrom(grad17_d1,univ1) :- sw2215.
0.53::sw2216.
advisor(grad17_d1,assi7_d1) :- sw2216.
0.07::sw2217.
takesCourse(grad17_d1,gradCourse5_d1) :- sw2217.
0.16::sw2218.
takesCourse(grad17_d1,gradCourse1_d1) :- sw2218.
0.25::sw2219.
graduateStudent(grad18_d1) :- sw2219.
0.25::sw2220.
memberOf(grad18_d1,dept1) :- sw2220.
0.59::sw2221.
undergraduateDegreeFrom(grad18_d1,univ9) :- sw2221.
0.91::sw2222.
advisor(grad18_d1,asso7_d1) :- sw2222.
0.26::sw2223.
takesCourse(grad18_d1,gradCourse4_d1) :- sw2223.
0.54::sw2224.
takesCourse(grad18_d1,gradCourse1_d1) :- sw2224.
0.79::sw2225.
teachingAssistantOf(grad18_d1,course0_d1) :- sw2225.
0.70::sw2226.
graduateStudent(grad19_d1) :- sw2226.
0.47::sw2227.
memberOf(grad19_d1,dept1) :- sw2227.
0.30::sw2228.
undergraduateDegreeFrom(grad19_d1,univ9) :- sw2228.
0.30::sw2229.
advisor(grad19_d1,assi3_d1) :- sw2229.
0.92::sw2230.
takesCourse(grad19_d1,gradCourse3_d1) :- sw2230.
0.57::sw2231.
takesCourse(grad19_d1,gradCourse9_d1) :- sw2231.
0.25::sw2232.
graduateStudent(grad20_d1) :- sw2232.
0.74::sw2233.
memberOf(grad20_d1,dept1) :- sw2233.
0.37::sw2234.
undergraduateDegreeFrom(grad20_d1,univ8) :- sw2234.
0.13::sw2235.
advisor(grad20_d1,asso8_d1) :- sw2235.
0.19::sw2236.
takesCourse(grad20_d1,gradCourse9_d1) :- sw2236.
0.56::sw2237.
takesCourse(grad20_d1,gradCourse6_d1) :- sw2237.
0.22::sw2238.
graduateStudent(grad21_d1) :- sw2238.
0.84::sw2239.
memberOf(grad21_d1,dept1) :- sw2239.
0.39::sw2240.
undergraduateDegreeFrom(grad21_d1,univ3) :- sw2240.
0.44::sw2241.
advisor(grad21_d1,assi9_d1) :- sw2241.
0.24::sw2242.
takesCourse(grad21_d1,gradCourse4_d1) :- sw2242.
takesCourse(grad21_d1,gradCourse1_d1).
0.34::sw2243.
teachingAssistantOf(grad21_d1,course14_d1) :- sw2243.
0.69::sw2244.
graduateStudent(grad22_d1) :- sw2244.
0.87::sw2245.
memberOf(grad22_d1,dept1) :- sw2245.
0.51::sw2246.
undergraduateDegreeFrom(grad22_d1,univ8) :- sw2246.
0.47::sw2247.
advisor(grad22_d1,full6_d1) :- sw2247.
0.13::sw2248.
takesCourse(grad22_d1,gradCourse4_d1) :- sw2248.
0.50::sw2249.
takesCourse(grad22_d1,gradCourse2_d1) :- sw2249.
0.78::sw2250.
graduateStudent(grad23_d1) :- sw2250.
0.18::sw2251.
memberOf(grad23_d1,dept1) :- sw2251.
0.24::sw2252.
undergraduateDegreeFrom(grad23_d1,univ2) :- sw2252.
0.92::sw2253.
advisor(grad23_d1,assi1_d1) :- sw2253.
0.76::sw2254.
takesCourse(grad23_d1,gradCourse8_d1) :- sw2254.
0.27::sw2255.
takesCourse(grad23_d1,gradCourse2_d1) :- sw2255.
0.57::sw2256.
teachingAssistantOf(grad23_d1,course16_d1) :- sw2256.
0.81::sw2257.
graduateStudent(grad24_d1) :- sw2257.
0.99::sw2258.
memberOf(grad24_d1,dept1) :- sw2258.
0.64::sw2259.
undergraduateDegreeFrom(grad24_d1,univ4) :- sw2259.
0.89::sw2260.
advisor(grad24_d1,full7_d1) :- sw2260.
0.77::sw2261.
takesCourse(grad24_d1,gradCourse1_d1) :- sw2261.
0.68::sw2262.
takesCourse(grad24_d1,gradCourse7_d1) :- sw2262.
0.65::sw2263.
teachingAssistantOf(grad24_d1,course7_d1) :- sw2263.
0.65::sw2264.
graduateStudent(grad25_d1) :- sw2264.
0.30::sw2265.
memberOf(grad25_d1,dept1) :- sw2265.
0.39::sw2266.
undergraduateDegreeFrom(grad25_d1,univ6) :- sw2266.
0.17::sw2267.
advisor(grad25_d1,full1_d1) :- sw2267.
0.49::sw2268.
takesCourse(grad25_d1,gradCourse0_d1) :- sw2268.
0.97::sw2269.
takesCourse(grad25_d1,gradCourse9_d1) :- sw2269.
0.37::sw2270.
graduateStudent(grad26_d1) :- sw2270.
0.70::sw2271.
memberOf(grad26_d1,dept1) :- sw2271.
0.15::sw2272.
undergraduateDegreeFrom(grad26_d1,univ0) :- sw2272.
0.66::sw2273.
advisor(grad26_d1,full3_d1) :- sw2273.
0.30::sw2274.
takesCourse(grad26_d1,gradCourse8_d1) :- sw2274.
0.45::sw2275.
takesCourse(grad26_d1,gradCourse7_d1) :- sw2275.
0.71::sw2276.
graduateStudent(grad27_d1) :- sw2276.
0.56::sw2277.
memberOf(grad27_d1,dept1) :- sw2277.
0.28::sw2278.
undergraduateDegreeFrom(grad27_d1,univ0) :- sw2278.
0.21::sw2279.
advisor(grad27_d1,assi4_d1) :- sw2279.
0.38::sw2280.
takesCourse(grad27_d1,gradCourse4_d1) :- sw2280.
0.17::sw2281.
takesCourse(grad27_d1,gradCourse9_d1) :- sw2281.
0.61::sw2282.
graduateStudent(grad28_d1) :- sw2282.
0.17::sw2283.
memberOf(grad28_d1,dept1) :- sw2283.
0.87::sw2284.
undergraduateDegreeFrom(grad28_d1,univ7) :- sw2284.
0.12::sw2285.
advisor(grad28_d1,assi1_d1) :- sw2285.
0.09::sw2286.
takesCourse(grad28_d1,gradCourse4_d1) :- sw2286.
0.95::sw2287.
takesCourse(grad28_d1,gradCourse2_d1) :- sw2287.
0.61::sw2288.
graduateStudent(grad29_d1) :- sw2288.
0.90::sw2289.
memberOf(grad29_d1,dept1) :- sw2289.
0.93::sw2290.
undergraduateDegreeFrom(grad29_d1,univ9) :- sw2290.
0.40::sw2291.
advisor(grad29_d1,full5_d1) :- sw2291.
0.36::sw2292.
takesCourse(grad29_d1,gradCourse6_d1) :- sw2292.
0.35::sw2293.
takesCourse(grad29_d1,gradCourse0_d1) :- sw2293.
0.73::sw2294.
teachingAssistantOf(grad29_d1,course6_d1) :- sw2294.
0.07::sw2295.
graduateStudent(grad30_d1) :- sw2295.
0.29::sw2296.
memberOf(grad30_d1,dept1) :- sw2296.
0.46::sw2297.
undergraduateDegreeFrom(grad30_d1,univ3) :- sw2297.
0.85::sw2298.
advisor(grad30_d1,full5_d1) :- sw2298.
0.51::sw2299.
takesCourse(grad30_d1,gradCourse2_d1) :- sw2299.
0.23::sw2300.
takesCourse(grad30_d1,gradCourse6_d1) :- sw2300.
0.62::sw2301.
graduateStudent(grad31_d1) :- sw2301.
0.70::sw2302.
memberOf(grad31_d1,dept1) :- sw2302.
0.08::sw2303.
undergraduateDegreeFrom(grad31_d1,univ8) :- sw2303.
0.96::sw2304.
advisor(grad31_d1,asso0_d1) :- sw2304.
0.79::sw2305.
takesCourse(grad31_d1,gradCourse2_d1) :- sw2305.
0.91::sw2306.
takesCourse(grad31_d1,gradCourse1_d1) :- sw2306.
0.15::sw2307.
graduateStudent(grad32_d1) :- sw2307.
0.58::sw2308.
memberOf(grad32_d1,dept1) :- sw2308.
0.44::sw2309.
undergraduateDegreeFrom(grad32_d1,univ4) :- sw2309.
0.59::sw2310.
advisor(grad32_d1,lect4_d1) :- sw2310.
0.37::sw2311.
takesCourse(grad32_d1,gradCourse8_d1) :- sw2311.
0.65::sw2312.
takesCourse(grad32_d1,gradCourse0_d1) :- sw2312.
0.66::sw2313.
graduateStudent(grad33_d1) :- sw2313.
0.05::sw2314.
memberOf(grad33_d1,dept1) :- sw2314.
0.66::sw2315.
undergraduateDegreeFrom(grad33_d1,univ5) :- sw2315.
0.92::sw2316.
advisor(grad33_d1,lect3_d1) :- sw2316.
0.94::sw2317.
takesCourse(grad33_d1,gradCourse1_d1) :- sw2317.
0.46::sw2318.
takesCourse(grad33_d1,gradCourse6_d1) :- sw2318.
0.86::sw2319.
graduateStudent(grad34_d1) :- sw2319.
0.40::sw2320.
memberOf(grad34_d1,dept1) :- sw2320.
0.68::sw2321.
undergraduateDegreeFrom(grad34_d1,univ5) :- sw2321.
0.68::sw2322.
advisor(grad34_d1,assi7_d1) :- sw2322.
0.82::sw2323.
takesCourse(grad34_d1,gradCourse6_d1) :- sw2323.
0.90::sw2324.
takesCourse(grad34_d1,gradCourse7_d1) :- sw2324.
0.99::sw2325.
graduateStudent(grad35_d1) :- sw2325.
0.16::sw2326.
memberOf(grad35_d1,dept1) :- sw2326.
0.80::sw2327.
undergraduateDegreeFrom(grad35_d1,univ0) :- sw2327.
0.85::sw2328.
advisor(grad35_d1,assi2_d1) :- sw2328.
0.78::sw2329.
takesCourse(grad35_d1,gradCourse4_d1) :- sw2329.
0.50::sw2330.
takesCourse(grad35_d1,gradCourse7_d1) :- sw2330.
0.08::sw2331.
graduateStudent(grad36_d1) :- sw2331.
0.49::sw2332.
memberOf(grad36_d1,dept1) :- sw2332.
0.50::sw2333.
undergraduateDegreeFrom(grad36_d1,univ4) :- sw2333.
0.52::sw2334.
advisor(grad36_d1,lect2_d1) :- sw2334.
0.61::sw2335.
takesCourse(grad36_d1,gradCourse4_d1) :- sw2335.
0.32::sw2336.
takesCourse(grad36_d1,gradCourse3_d1) :- sw2336.
0.09::sw2337.
graduateStudent(grad37_d1) :- sw2337.
0.20::sw2338.
memberOf(grad37_d1,dept1) :- sw2338.
0.99::sw2339.
undergraduateDegreeFrom(grad37_d1,univ4) :- sw2339.
0.56::sw2340.
advisor(grad37_d1,lect2_d1) :- sw2340.
0.91::sw2341.
takesCourse(grad37_d1,gradCourse6_d1) :- sw2341.
0.69::sw2342.
takesCourse(grad37_d1,gradCourse7_d1) :- sw2342.
0.33::sw2343.
graduateStudent(grad38_d1) :- sw2343.
0.06::sw2344.
memberOf(grad38_d1,dept1) :- sw2344.
0.97::sw2345.
undergraduateDegreeFrom(grad38_d1,univ5) :- sw2345.
0.96::sw2346.
advisor(grad38_d1,full3_d1) :- sw2346.
0.45::sw2347.
takesCourse(grad38_d1,gradCourse3_d1) :- sw2347.
0.62::sw2348.
takesCourse(grad38_d1,gradCourse0_d1) :- sw2348.
0.69::sw2349.
graduateStudent(grad39_d1) :- sw2349.
0.72::sw2350.
memberOf(grad39_d1,dept1) :- sw2350.
0.57::sw2351.
undergraduateDegreeFrom(grad39_d1,univ3) :- sw2351.
0.86::sw2352.
advisor(grad39_d1,assi6_d1) :- sw2352.
0.08::sw2353.
takesCourse(grad39_d1,gradCourse2_d1) :- sw2353.
0.25::sw2354.
takesCourse(grad39_d1,gradCourse5_d1) :- sw2354.
0.51::sw2355.
teachingAssistantOf(grad39_d1,course5_d1) :- sw2355.
0.19::sw2356.
publication(pub0_d1) :- sw2356.
0.47::sw2357.
publicationAuthor(pub0_d1,lect4_d1) :- sw2357.
0.34::sw2358.
publicationAuthor(pub0_d1,ugrad110_d1) :- sw2358.
0.33::sw2359.
publication(pub1_d1) :- sw2359.
0.55::sw2360.
publicationAuthor(pub1_d1,assi8_d1) :- sw2360.
0.86::sw2361.
publication(pub2_d1) :- sw2361.
0.33::sw2362.
publicationAuthor(pub2_d1,assi3_d1) :- sw2362.
0.45::sw2363.
publicationAuthor(pub2_d1,ugrad10_d1) :- sw2363.
0.31::sw2364.
publication(pub3_d1) :- sw2364.
0.23::sw2365.
publicationAuthor(pub3_d1,assi5_d1) :- sw2365.
0.78::sw2366.
publication(pub4_d1) :- sw2366.
0.91::sw2367.
publicationAuthor(pub4_d1,assi7_d1) :- sw2367.
0.30::sw2368.
publicationAuthor(pub4_d1,grad35_d1) :- sw2368.
0.34::sw2369.
publication(pub5_d1) :- sw2369.
0.15::sw2370.
publicationAuthor(pub5_d1,assi7_d1) :- sw2370.
0.58::sw2371.
publicationAuthor(pub5_d1,ugrad56_d1) :- sw2371.
0.74::sw2372.
publication(pub6_d1) :- sw2372.
0.27::sw2373.
publicationAuthor(pub6_d1,asso0_d1) :- sw2373.
0.56::sw2374.
publicationAuthor(pub6_d1,ugrad50_d1) :- sw2374.
0.10::sw2375.
publication(pub7_d1) :- sw2375.
0.35::sw2376.
publicationAuthor(pub7_d1,full1_d1) :- sw2376.
0.09::sw2377.
publication(pub8_d1) :- sw2377.
0.97::sw2378.
publicationAuthor(pub8_d1,full6_d1) :- sw2378.
0.86::sw2379.
publication(pub9_d1) :- sw2379.
0.76::sw2380.
publicationAuthor(pub9_d1,assi7_d1) :- sw2380.
0.69::sw2381.
publicationAuthor(pub9_d1,ugrad96_d1) :- sw2381.
0.30::sw2382.
publication(pub10_d1) :- sw2382.
0.21::sw2383.
publicationAuthor(pub10_d1,lect4_d1) :- sw2383.
0.66::sw2384.
publication(pub11_d1) :- sw2384.
0.39::sw2385.
publicationAuthor(pub11_d1,assi9_d1) :- sw2385.
0.78::sw2386.
publication(pub12_d1) :- sw2386.
0.63::sw2387.
publicationAuthor(pub12_d1,lect2_d1) :- sw2387.
0.33::sw2388.
publicationAuthor(pub12_d1,grad15_d1) :- sw2388.
0.32::sw2389.
publication(pub13_d1) :- sw2389.
0.18::sw2390.
publicationAuthor(pub13_d1,asso2_d1) :- sw2390.
0.93::sw2391.
publication(pub14_d1) :- sw2391.
0.74::sw2392.
publicationAuthor(pub14_d1,asso4_d1) :- sw2392.
0.18::sw2393.
publication(pub15_d1) :- sw2393.
0.39::sw2394.
publicationAuthor(pub15_d1,full6_d1) :- sw2394.
0.53::sw2395.
publication(pub16_d1) :- sw2395.
0.93::sw2396.
publicationAuthor(pub16_d1,asso0_d1) :- sw2396.
0.09::sw2397.
publicationAuthor(pub16_d1,ugrad131_d1) :- sw2397.
0.84::sw2398.
publication(pub17_d1) :- sw2398.
0.76::sw2399.
publicationAuthor(pub17_d1,full7_d1) :- sw2399.
0.84::sw2400.
publicationAuthor(pub17_d1,grad2_d1) :- sw2400.
0.70::sw2401.
publication(pub18_d1) :- sw2401.
0.57::sw2402.
publicationAuthor(pub18_d1,asso5_d1) :- sw2402.
0.18::sw2403.
publication(pub19_d1) :- sw2403.
0.10::sw2404.
publicationAuthor(pub19_d1,assi0_d1) :- sw2404.
0.63::sw2405.
publication(pub20_d1) :- sw2405.
0.34::sw2406.
publicationAuthor(pub20_d1,asso0_d1) :- sw2406.
0.68::sw2407.
publication(pub21_d1) :- sw2407.
0.25::sw2408.
publicationAuthor(pub21_d1,assi9_d1) :- sw2408.
0.46::sw2409.
publication(pub22_d1) :- sw2409.
0.46::sw2410.
publicationAuthor(pub22_d1,asso2_d1) :- sw2410.
0.13::sw2411.
publicationAuthor(pub22_d1,grad10_d1) :- sw2411.
0.30::sw2412.
publication(pub23_d1) :- sw2412.
0.29::sw2413.
publicationAuthor(pub23_d1,assi9_d1) :- sw2413.
0.77::sw2414.
publicationAuthor(pub23_d1,grad10_d1) :- sw2414.
0.77::sw2415.
publication(pub24_d1) :- sw2415.
0.57::sw2416.
publicationAuthor(pub24_d1,lect0_d1) :- sw2416.
publication(pub25_d1).
0.85::sw2417.
publicationAuthor(pub25_d1,full1_d1) :- sw2417.
0.45::sw2418.
publicationAuthor(pub25_d1,ugrad4_d1) :- sw2418.
0.31::sw2419.
publication(pub26_d1) :- sw2419.
0.23::sw2420.
publicationAuthor(pub26_d1,assi3_d1) :- sw2420.
0.65::sw2421.
publicationAuthor(pub26_d1,ugrad98_d1) :- sw2421.
0.18::sw2422.
publication(pub27_d1) :- sw2422.
0.44::sw2423.
publicationAuthor(pub27_d1,asso5_d1) :- sw2423.
0.27::sw2424.
publication(pub28_d1) :- sw2424.
0.41::sw2425.
publicationAuthor(pub28_d1,assi0_d1) :- sw2425.
0.65::sw2426.
publicationAuthor(pub28_d1,ugrad52_d1) :- sw2426.
0.44::sw2427.
publication(pub29_d1) :- sw2427.
0.69::sw2428.
publicationAuthor(pub29_d1,assi6_d1) :- sw2428.
0.25::sw2429.
publicationAuthor(pub29_d1,ugrad56_d1) :- sw2429.
0.40::sw2430.
publication(pub30_d1) :- sw2430.
0.49::sw2431.
publicationAuthor(pub30_d1,assi3_d1) :- sw2431.
0.76::sw2432.
publicationAuthor(pub30_d1,ugrad23_d1) :- sw2432.
0.52::sw2433.
publication(pub31_d1) :- sw2433.
0.51::sw2434.
publicationAuthor(pub31_d1,assi3_d1) :- sw2434.
0.58::sw2435.
publication(pub32_d1) :- sw2435.
0.75::sw2436.
publicationAuthor(pub32_d1,asso5_d1) :- sw2436.
0.26::sw2437.
publication(pub33_d1) :- sw2437.
0.23::sw2438.
publicationAuthor(pub33_d1,asso5_d1) :- sw2438.
0.46::sw2439.
publication(pub34_d1) :- sw2439.
0.67::sw2440.
publicationAuthor(pub34_d1,assi7_d1) :- sw2440.
0.29::sw2441.
publicationAuthor(pub34_d1,grad14_d1) :- sw2441.
0.32::sw2442.
publication(pub35_d1) :- sw2442.
0.99::sw2443.
publicationAuthor(pub35_d1,assi1_d1) :- sw2443.
0.81::sw2444.
publication(pub36_d1) :- sw2444.
0.61::sw2445.
publicationAuthor(pub36_d1,asso7_d1) :- sw2445.
0.21::sw2446.
publication(pub37_d1) :- sw2446.
0.72::sw2447.
publicationAuthor(pub37_d1,asso9_d1) :- sw2447.
0.25::sw2448.
publication(pub38_d1) :- sw2448.
0.38::sw2449.
publicationAuthor(pub38_d1,full4_d1) :- sw2449.
0.84::sw2450.
publication(pub39_d1) :- sw2450.
0.17::sw2451.
publicationAuthor(pub39_d1,assi4_d1) :- sw2451.
0.85::sw2452.
publicationAuthor(pub39_d1,ugrad39_d1) :- sw2452.
0.81::sw2453.
publication(pub40_d1) :- sw2453.
0.65::sw2454.
publicationAuthor(pub40_d1,assi4_d1) :- sw2454.
0.90::sw2455.
publication(pub41_d1) :- sw2455.
0.46::sw2456.
publicationAuthor(pub41_d1,asso4_d1) :- sw2456.
0.90::sw2457.
publication(pub42_d1) :- sw2457.
0.69::sw2458.
publicationAuthor(pub42_d1,full7_d1) :- sw2458.
0.86::sw2459.
publicationAuthor(pub42_d1,ugrad64_d1) :- sw2459.
0.55::sw2460.
publication(pub43_d1) :- sw2460.
0.38::sw2461.
publicationAuthor(pub43_d1,full3_d1) :- sw2461.
0.95::sw2462.
publication(pub44_d1) :- sw2462.
0.21::sw2463.
publicationAuthor(pub44_d1,assi7_d1) :- sw2463.
0.24::sw2464.
publicationAuthor(pub44_d1,ugrad73_d1) :- sw2464.
0.18::sw2465.
publication(pub45_d1) :- sw2465.
0.66::sw2466.
publicationAuthor(pub45_d1,asso4_d1) :- sw2466.
0.59::sw2467.
publicationAuthor(pub45_d1,ugrad52_d1) :- sw2467.
0.87::sw2468.
publication(pub46_d1) :- sw2468.
0.98::sw2469.
publicationAuthor(pub46_d1,assi1_d1) :- sw2469.
0.17::sw2470.
publicationAuthor(pub46_d1,ugrad22_d1) :- sw2470.
0.71::sw2471.
publication(pub47_d1) :- sw2471.
0.58::sw2472.
publicationAuthor(pub47_d1,full6_d1) :- sw2472.
0.33::sw2473.
publicationAuthor(pub47_d1,ugrad102_d1) :- sw2473.
0.49::sw2474.
publication(pub48_d1) :- sw2474.
0.59::sw2475.
publicationAuthor(pub48_d1,assi4_d1) :- sw2475.
0.53::sw2476.
publication(pub49_d1) :- sw2476.
0.53::sw2477.
publicationAuthor(pub49_d1,asso7_d1) :- sw2477.
0.29::sw2478.
publicationAuthor(pub49_d1,ugrad31_d1) :- sw2478.
0.62::sw2479.
publication(pub50_d1) :- sw2479.
0.35::sw2480.
publicationAuthor(pub50_d1,full7_d1) :- sw2480.
0.14::sw2481.
publicationAuthor(pub50_d1,ugrad81_d1) :- sw2481.
0.29::sw2482.
publication(pub51_d1) :- sw2482.
0.42::sw2483.
publicationAuthor(pub51_d1,assi4_d1) :- sw2483.
0.10::sw2484.
publication(pub52_d1) :- sw2484.
0.60::sw2485.
publicationAuthor(pub52_d1,asso6_d1) :- sw2485.
0.64::sw2486.
publicationAuthor(pub52_d1,ugrad29_d1) :- sw2486.
0.11::sw2487.
publication(pub53_d1) :- sw2487.
0.19::sw2488.
publicationAuthor(pub53_d1,assi2_d1) :- sw2488.
0.76::sw2489.
publication(pub54_d1) :- sw2489.
0.38::sw2490.
publicationAuthor(pub54_d1,full4_d1) :- sw2490.
0.67::sw2491.
publicationAuthor(pub54_d1,ugrad85_d1) :- sw2491.
0.88::sw2492.
publication(pub55_d1) :- sw2492.
0.38::sw2493.
publicationAuthor(pub55_d1,assi0_d1) :- sw2493.
0.22::sw2494.
publicationAuthor(pub55_d1,ugrad113_d1) :- sw2494.
0.99::sw2495.
publication(pub56_d1) :- sw2495.
0.37::sw2496.
publicationAuthor(pub56_d1,lect0_d1) :- sw2496.
0.10::sw2497.
publication(pub57_d1) :- sw2497.
0.19::sw2498.
publicationAuthor(pub57_d1,asso2_d1) :- sw2498.
0.88::sw2499.
publicationAuthor(pub57_d1,ugrad30_d1) :- sw2499.
0.30::sw2500.
publication(pub58_d1) :- sw2500.
0.33::sw2501.
publicationAuthor(pub58_d1,asso2_d1) :- sw2501.
0.61::sw2502.
publicationAuthor(pub58_d1,ugrad122_d1) :- sw2502.
0.27::sw2503.
publication(pub59_d1) :- sw2503.
0.36::sw2504.
publicationAuthor(pub59_d1,asso9_d1) :- sw2504.
0.65::sw2505.
publicationAuthor(pub59_d1,ugrad132_d1) :- sw2505.
0.12::sw2506.
department(dept2) :- sw2506.
0.24::sw2507.
subOrganizationOf(dept2,univ0) :- sw2507.
0.62::sw2508.
fullProfessor(full0_d2) :- sw2508.
0.08::sw2509.
worksFor(full0_d2,dept2) :- sw2509.
0.38::sw2510.
doctoralDegreeFrom(full0_d2,univ3) :- sw2510.
0.50::sw2511.
emailAddress(full0_d2,mail_full0_d2) :- sw2511.
0.48::sw2512.
researchInterest(full0_d2,res14) :- sw2512.
0.47::sw2513.
fullProfessor(full1_d2) :- sw2513.
0.63::sw2514.
worksFor(full1_d2,dept2) :- sw2514.
0.69::sw2515.
doctoralDegreeFrom(full1_d2,univ6) :- sw2515.
0.71::sw2516.
emailAddress(full1_d2,mail_full1_d2) :- sw2516.
0.90::sw2517.
researchInterest(full1_d2,res15) :- sw2517.
0.23::sw2518.
fullProfessor(full2_d2) :- sw2518.
0.98::sw2519.
worksFor(full2_d2,dept2) :- sw2519.
0.73::sw2520.
doctoralDegreeFrom(full2_d2,univ5) :- sw2520.
0.85::sw2521.
emailAddress(full2_d2,mail_full2_d2) :- sw2521.
0.19::sw2522.
researchInterest(full2_d2,res11) :- sw2522.
0.27::sw2523.
fullProfessor(full3_d2) :- sw2523.
0.23::sw2524.
worksFor(full3_d2,dept2) :- sw2524.
0.45::sw2525.
doctoralDegreeFrom(full3_d2,univ0) :- sw2525.
0.83::sw2526.
emailAddress(full3_d2,mail_full3_d2) :- sw2526.
0.70::sw2527.
researchInterest(full3_d2,res17) :- sw2527.
0.50::sw2528.
fullProfessor(full4_d2) :- sw2528.
0.22::sw2529.
worksFor(full4_d2,dept2) :- sw2529.
0.68::sw2530.
doctoralDegreeFrom(full4_d2,univ5) :- sw2530.
0.13::sw2531.
emailAddress(full4_d2,mail_full4_d2) :- sw2531.
0.39::sw2532.
researchInterest(full4_d2,res15) :- sw2532.
0.14::sw2533.
fullProfessor(full5_d2) :- sw2533.
worksFor(full5_d2,dept2).
0.17::sw2534.
doctoralDegreeFrom(full5_d2,univ9) :- sw2534.
0.59::sw2535.
emailAddress(full5_d2,mail_full5_d2) :- sw2535.
0.52::sw2536.
researchInterest(full5_d2,res15) :- sw2536.
0.88::sw2537.
fullProfessor(full6_d2) :- sw2537.
0.79::sw2538.
worksFor(full6_d2,dept2) :- sw2538.
0.64::sw2539.
doctoralDegreeFrom(full6_d2,univ8) :- sw2539.
0.10::sw2540.
emailAddress(full6_d2,mail_full6_d2) :- sw2540.
0.21::sw2541.
researchInterest(full6_d2,res14) :- sw2541.
0.80::sw2542.
fullProfessor(full7_d2) :- sw2542.
0.14::sw2543.
worksFor(full7_d2,dept2) :- sw2543.
0.37::sw2544.
doctoralDegreeFrom(full7_d2,univ0) :- sw2544.
0.39::sw2545.
emailAddress(full7_d2,mail_full7_d2) :- sw2545.
0.42::sw2546.
researchInterest(full7_d2,res15) :- sw2546.
0.48::sw2547.
associateProfessor(asso0_d2) :- sw2547.
0.65::sw2548.
worksFor(asso0_d2,dept2) :- sw2548.
0.07::sw2549.
doctoralDegreeFrom(asso0_d2,univ1) :- sw2549.
0.09::sw2550.
emailAddress(asso0_d2,mail_asso0_d2) :- sw2550.
0.58::sw2551.
researchInterest(asso0_d2,res9) :- sw2551.
0.81::sw2552.
associateProfessor(asso1_d2) :- sw2552.
0.59::sw2553.
worksFor(asso1_d2,dept2) :- sw2553.
0.36::sw2554.
doctoralDegreeFrom(asso1_d2,univ2) :- sw2554.
0.44::sw2555.
emailAddress(asso1_d2,mail_asso1_d2) :- sw2555.
0.51::sw2556.
researchInterest(asso1_d2,res7) :- sw2556.
0.06::sw2557.
associateProfessor(asso2_d2) :- sw2557.
0.16::sw2558.
worksFor(asso2_d2,dept2) :- sw2558.
0.38::sw2559.
doctoralDegreeFrom(asso2_d2,univ8) :- sw2559.
0.19::sw2560.
emailAddress(asso2_d2,mail_asso2_d2) :- sw2560.
0.55::sw2561.
researchInterest(asso2_d2,res3) :- sw2561.
0.43::sw2562.
associateProfessor(asso3_d2) :- sw2562.
0.93::sw2563.
worksFor(asso3_d2,dept2) :- sw2563.
0.77::sw2564.
doctoralDegreeFrom(asso3_d2,univ2) :- sw2564.
0.64::sw2565.
emailAddress(asso3_d2,mail_asso3_d2) :- sw2565.
researchInterest(asso3_d2,res5).
0.53::sw2566.
associateProfessor(asso4_d2) :- sw2566.
0.51::sw2567.
worksFor(asso4_d2,dept2) :- sw2567.
0.83::sw2568.
doctoralDegreeFrom(asso4_d2,univ4) :- sw2568.
0.10::sw2569.
emailAddress(asso4_d2,mail_asso4_d2) :- sw2569.
0.34::sw2570.
researchInterest(asso4_d2,res10) :- sw2570.
0.30::sw2571.
associateProfessor(asso5_d2) :- sw2571.
0.36::sw2572.
worksFor(asso5_d2,dept2) :- sw2572.
0.17::sw2573.
doctoralDegreeFrom(asso5_d2,univ1) :- sw2573.
0.83::sw2574.
emailAddress(asso5_d2,mail_asso5_d2) :- sw2574.
0.45::sw2575.
researchInterest(asso5_d2,res11) :- sw2575.
0.33::sw2576.
associateProfessor(asso6_d2) :- sw2576.
0.60::sw2577.
worksFor(asso6_d2,dept2) :- sw2577.
0.80::sw2578.
doctoralDegreeFrom(asso6_d2,univ8) :- sw2578.
0.76::sw2579.
emailAddress(asso6_d2,mail_asso6_d2) :- sw2579.
0.54::sw2580.
researchInterest(asso6_d2,res0) :- sw2580.
0.87::sw2581.
associateProfessor(asso7_d2) :- sw2581.
0.98::sw2582.
worksFor(asso7_d2,dept2) :- sw2582.
0.70::sw2583.
doctoralDegreeFrom(asso7_d2,univ3) :- sw2583.
0.43::sw2584.
emailAddress(asso7_d2,mail_asso7_d2) :- sw2584.
0.10::sw2585.
researchInterest(asso7_d2,res10) :- sw2585.
0.75::sw2586.
associateProfessor(asso8_d2) :- sw2586.
0.77::sw2587.
worksFor(asso8_d2,dept2) :- sw2587.
0.78::sw2588.
doctoralDegreeFrom(asso8_d2,univ0) :- sw2588.
0.83::sw2589.
emailAddress(asso8_d2,mail_asso8_d2) :- sw2589.
0.49::sw2590.
researchInterest(asso8_d2,res19) :- sw2590.
0.67::sw2591.
associateProfessor(asso9_d2) :- sw2591.
0.69::sw2592.
worksFor(asso9_d2,dept2) :- sw2592.
0.24::sw2593.
doctoralDegreeFrom(asso9_d2,univ0) :- sw2593.
0.74::sw2594.
emailAddress(asso9_d2,mail_asso9_d2) :- sw2594.
0.14::sw2595.
researchInterest(asso9_d2,res12) :- sw2595.
0.95::sw2596.
assistantProfessor(assi0_d2) :- sw2596.
0.66::sw2597.
worksFor(assi0_d2,dept2) :- sw2597.
0.99::sw2598.
doctoralDegreeFrom(assi0_d2,univ2) :- sw2598.
0.17::sw2599.
emailAddress(assi0_d2,mail_assi0_d2) :- sw2599.
0.87::sw2600.
researchInterest(assi0_d2,res3) :- sw2600.
0.14::sw2601.
assistantProfessor(assi1_d2) :- sw2601.
0.63::sw2602.
worksFor(assi1_d2,dept2) :- sw2602.
0.76::sw2603.
doctoralDegreeFrom(assi1_d2,univ8) :- sw2603.
0.49::sw2604.
emailAddress(assi1_d2,mail_assi1_d2) :- sw2604.
0.89::sw2605.
researchInterest(assi1_d2,res14) :- sw2605.
0.21::sw2606.
assistantProfessor(assi2_d2) :- sw2606.
0.56::sw2607.
worksFor(assi2_d2,dept2) :- sw2607.
0.50::sw2608.
doctoralDegreeFrom(assi2_d2,univ5) :- sw2608.
0.30::sw2609.
emailAddress(assi2_d2,mail_assi2_d2) :- sw2609.
0.22::sw2610.
researchInterest(assi2_d2,res15) :- sw2610.
0.82::sw2611.
assistantProfessor(assi3_d2) :- sw2611.
0.76::sw2612.
worksFor(assi3_d2,dept2) :- sw2612.
0.61::sw2613.
doctoralDegreeFrom(assi3_d2,univ0) :- sw2613.
0.42::sw2614.
emailAddress(assi3_d2,mail_assi3_d2) :- sw2614.
0.19::sw2615.
researchInterest(assi3_d2,res14) :- sw2615.
0.64::sw2616.
assistantProfessor(assi4_d2) :- sw2616.
0.11::sw2617.
worksFor(assi4_d2,dept2) :- sw2617.
0.73::sw2618.
doctoralDegreeFrom(assi4_d2,univ6) :- sw2618.
0.46::sw2619.
emailAddress(assi4_d2,mail_assi4_d2) :- sw2619.
0.56::sw2620.
researchInterest(assi4_d2,res17) :- sw2620.
0.16::sw2621.
assistantProfessor(assi5_d2) :- sw2621.
0.44::sw2622.
worksFor(assi5_d2,dept2) :- sw2622.
0.13::sw2623.
doctoralDegreeFrom(assi5_d2,univ1) :- sw2623.
0.36::sw2624.
emailAddress(assi5_d2,mail_assi5_d2) :- sw2624.
0.18::sw2625.
researchInterest(assi5_d2,res3) :- sw2625.
0.68::sw2626.
assistantProfessor(assi6_d2) :- sw2626.
0.28::sw2627.
worksFor(assi6_d2,dept2) :- sw2627.
0.90::sw2628.
doctoralDegreeFrom(assi6_d2,univ1) :- sw2628.
0.21::sw2629.
emailAddress(assi6_d2,mail_assi6_d2) :- sw2629.
0.08::sw2630.
researchInterest(assi6_d2,res2) :- sw2630.
0.46::sw2631.
assistantProfessor(assi7_d2) :- sw2631.
0.79::sw2632.
worksFor(assi7_d2,dept2) :- sw2632.
0.72::sw2633.
doctoralDegreeFrom(assi7_d2,univ3) :- sw2633.
0.56::sw2634.
emailAddress(assi7_d2,mail_assi7_d2) :- sw2634.
0.06::sw2635.
researchInterest(assi7_d2,res3) :- sw2635.
0.22::sw2636.
assistantProfessor(assi8_d2) :- sw2636.
0.41::sw2637.
worksFor(assi8_d2,dept2) :- sw2637.
0.14::sw2638.
doctoralDegreeFrom(assi8_d2,univ4) :- sw2638.
0.54::sw2639.
emailAddress(assi8_d2,mail_assi8_d2) :- sw2639.
0.65::sw2640.
researchInterest(assi8_d2,res2) :- sw2640.
0.56::sw2641.
assistantProfessor(assi9_d2) :- sw2641.
0.94::sw2642.
worksFor(assi9_d2,dept2) :- sw2642.
0.15::sw2643.
doctoralDegreeFrom(assi9_d2,univ5) :- sw2643.
0.10::sw2644.
emailAddress(assi9_d2,mail_assi9_d2) :- sw2644.
0.59::sw2645.
researchInterest(assi9_d2,res0) :- sw2645.
0.35::sw2646.
lecturer(lect0_d2) :- sw2646.
0.18::sw2647.
worksFor(lect0_d2,dept2) :- sw2647.
0.61::sw2648.
doctoralDegreeFrom(lect0_d2,univ3) :- sw2648.
0.36::sw2649.
emailAddress(lect0_d2,mail_lect0_d2) :- sw2649.
0.76::sw2650.
researchInterest(lect0_d2,res1) :- sw2650.
0.53::sw2651.
lecturer(lect1_d2) :- sw2651.
0.61::sw2652.
worksFor(lect1_d2,dept2) :- sw2652.
0.55::sw2653.
doctoralDegreeFrom(lect1_d2,univ7) :- sw2653.
0.62::sw2654.
emailAddress(lect1_d2,mail_lect1_d2) :- sw2654.
0.07::sw2655.
researchInterest(lect1_d2,res1) :- sw2655.
0.79::sw2656.
lecturer(lect2_d2) :- sw2656.
0.52::sw2657.
worksFor(lect2_d2,dept2) :- sw2657.
0.41::sw2658.
doctoralDegreeFrom(lect2_d2,univ1) :- sw2658.
0.34::sw2659.
emailAddress(lect2_d2,mail_lect2_d2) :- sw2659.
0.21::sw2660.
researchInterest(lect2_d2,res16) :- sw2660.
0.84::sw2661.
lecturer(lect3_d2) :- sw2661.
0.58::sw2662.
worksFor(lect3_d2,dept2) :- sw2662.
0.22::sw2663.
doctoralDegreeFrom(lect3_d2,univ3) :- sw2663.
0.95::sw2664.
emailAddress(lect3_d2,mail_lect3_d2) :- sw2664.
0.06::sw2665.
researchInterest(lect3_d2,res10) :- sw2665.
0.70::sw2666.
lecturer(lect4_d2) :- sw2666.
0.37::sw2667.
worksFor(lect4_d2,dept2) :- sw2667.
0.37::sw2668.
doctoralDegreeFrom(lect4_d2,univ7) :- sw2668.
0.32::sw2669.
emailAddress(lect4_d2,mail_lect4_d2) :- sw2669.
0.86::sw2670.
researchInterest(lect4_d2,res19) :- sw2670.
0.53::sw2671.
headOf(full0_d2,dept2) :- sw2671.
0.23::sw2672.
course(course0_d2) :- sw2672.
0.67::sw2673.
teacherOf(assi1_d2,course0_d2) :- sw2673.
0.10::sw2674.
course(course1_d2) :- sw2674.
0.17::sw2675.
teacherOf(assi2_d2,course1_d2) :- sw2675.
0.90::sw2676.
course(course2_d2) :- sw2676.
0.79::sw2677.
teacherOf(full0_d2,course2_d2) :- sw2677.
0.92::sw2678.
course(course3_d2) :- sw2678.
0.89::sw2679.
teacherOf(asso4_d2,course3_d2) :- sw2679.
0.17::sw2680.
course(course4_d2) :- sw2680.
0.98::sw2681.
teacherOf(full0_d2,course4_d2) :- sw2681.
0.18::sw2682.
course(course5_d2) :- sw2682.
0.23::sw2683.
teacherOf(asso5_d2,course5_d2) :- sw2683.
0.19::sw2684.
course(course6_d2) :- sw2684.
0.86::sw2685.
teacherOf(assi9_d2,course6_d2) :- sw2685.
0.38::sw2686.
course(course7_d2) :- sw2686.
0.13::sw2687.
teacherOf(asso0_d2,course7_d2) :- sw2687.
0.75::sw2688.
course(course8_d2) :- sw2688.
0.90::sw2689.
teacherOf(assi4_d2,course8_d2) :- sw2689.
0.48::sw2690.
course(course9_d2) :- sw2690.
0.90::sw2691.
teacherOf(lect0_d2,course9_d2) :- sw2691.
0.21::sw2692.
course(course10_d2) :- sw2692.
0.15::sw2693.
teacherOf(assi8_d2,course10_d2) :- sw2693.
0.31::sw2694.
course(course11_d2) :- sw2694.
0.77::sw2695.
teacherOf(lect2_d2,course11_d2) :- sw2695.
0.61::sw2696.
course(course12_d2) :- sw2696.
0.60::sw2697.
teacherOf(asso0_d2,course12_d2) :- sw2697.
0.57::sw2698.
course(course13_d2) :- sw2698.
0.76::sw2699.
teacherOf(assi1_d2,course13_d2) :- sw2699.
0.21::sw2700.
course(course14_d2) :- sw2700.
0.89::sw2701.
teacherOf(assi0_d2,course14_d2) :- sw2701.
0.97::sw2702.
course(course15_d2) :- sw2702.
0.34::sw2703.
teacherOf(full4_d2,course15_d2) :- sw2703.
course(course16_d2).
0.43::sw2704.
teacherOf(asso6_d2,course16_d2) :- sw2704.
0.73::sw2705.
course(course17_d2) :- sw2705.
0.17::sw2706.
teacherOf(asso2_d2,course17_d2) :- sw2706.
0.41::sw2707.
course(course18_d2) :- sw2707.
0.53::sw2708.
teacherOf(assi3_d2,course18_d2) :- sw2708.
0.85::sw2709.
course(course19_d2) :- sw2709.
0.83::sw2710.
teacherOf(lect0_d2,course19_d2) :- sw2710.
0.79::sw2711.
graduateCourse(gradCourse0_d2) :- sw2711.
0.71::sw2712.
teacherOf(assi6_d2,gradCourse0_d2) :- sw2712.
0.08::sw2713.
graduateCourse(gradCourse1_d2) :- sw2713.
0.76::sw2714.
teacherOf(asso7_d2,gradCourse1_d2) :- sw2714.
0.26::sw2715.
graduateCourse(gradCourse2_d2) :- sw2715.
0.97::sw2716.
teacherOf(assi2_d2,gradCourse2_d2) :- sw2716.
0.90::sw2717.
graduateCourse(gradCourse3_d2) :- sw2717.
0.48::sw2718.
teacherOf(assi0_d2,gradCourse3_d2) :- sw2718.
0.65::sw2719.
graduateCourse(gradCourse4_d2) :- sw2719.
0.86::sw2720.
teacherOf(assi3_d2,gradCourse4_d2) :- sw2720.
0.31::sw2721.
graduateCourse(gradCourse5_d2) :- sw2721.
0.63::sw2722.
teacherOf(assi4_d2,gradCourse5_d2) :- sw2722.
0.49::sw2723.
graduateCourse(gradCourse6_d2) :- sw2723.
0.61::sw2724.
teacherOf(asso2_d2,gradCourse6_d2) :- sw2724.
0.98::sw2725.
graduateCourse(gradCourse7_d2) :- sw2725.
0.30::sw2726.
teacherOf(assi0_d2,gradCourse7_d2) :- sw2726.
0.37::sw2727.
graduateCourse(gradCourse8_d2) :- sw2727.
0.40::sw2728.
teacherOf(assi5_d2,gradCourse8_d2) :- sw2728.
0.71::sw2729.
graduateCourse(gradCourse9_d2) :- sw2729.
0.71::sw2730.
teacherOf(full4_d2,gradCourse9_d2) :- sw2730.
0.14::sw2731.
undergraduateStudent(ugrad0_d2) :- sw2731.
0.18::sw2732.
memberOf(ugrad0_d2,dept2) :- sw2732.
0.23::sw2733.
takesCourse(ugrad0_d2,course5_d2) :- sw2733.
0.24::sw2734.
takesCourse(ugrad0_d2,course12_d2) :- sw2734.
0.67::sw2735.
undergraduateStudent(ugrad1_d2) :- sw2735.
0.86::sw2736.
memberOf(ugrad1_d2,dept2) :- sw2736.
0.99::sw2737.
takesCourse(ugrad1_d2,course19_d2) :- sw2737.
0.35::sw2738.
takesCourse(ugrad1_d2,course14_d2) :- sw2738.
0.78::sw2739.
undergraduateStudent(ugrad2_d2) :- sw2739.
0.06::sw2740.
memberOf(ugrad2_d2,dept2) :- sw2740.
0.34::sw2741.
takesCourse(ugrad2_d2,course16_d2) :- sw2741.
0.76::sw2742.
takesCourse(ugrad2_d2,course13_d2) :- sw2742.
0.74::sw2743.
undergraduateStudent(ugrad3_d2) :- sw2743.
0.97::sw2744.
memberOf(ugrad3_d2,dept2) :- sw2744.
0.97::sw2745.
takesCourse(ugrad3_d2,course3_d2) :- sw2745.
0.80::sw2746.
takesCourse(ugrad3_d2,course11_d2) :- sw2746.
0.86::sw2747.
advisor(ugrad3_d2,assi5_d2) :- sw2747.
0.28::sw2748.
undergraduateStudent(ugrad4_d2) :- sw2748.
0.64::sw2749.
memberOf(ugrad4_d2,dept2) :- sw2749.
0.96::sw2750.
takesCourse(ugrad4_d2,course14_d2) :- sw2750.
0.75::sw2751.
takesCourse(ugrad4_d2,course1_d2) :- sw2751.
0.97::sw2752.
undergraduateStudent(ugrad5_d2) :- sw2752.
0.26::sw2753.
memberOf(ugrad5_d2,dept2) :- sw2753.
0.52::sw2754.
takesCourse(ugrad5_d2,course14_d2) :- sw2754.
0.46::sw2755.
takesCourse(ugrad5_d2,course16_d2) :- sw2755.
0.43::sw2756.
undergraduateStudent(ugrad6_d2) :- sw2756.
0.74::sw2757.
memberOf(ugrad6_d2,dept2) :- sw2757.
0.35::sw2758.
takesCourse(ugrad6_d2,course19_d2) :- sw2758.
0.25::sw2759.
takesCourse(ugrad6_d2,course8_d2) :- sw2759.
0.94::sw2760.
undergraduateStudent(ugrad7_d2) :- sw2760.
0.20::sw2761.
memberOf(ugrad7_d2,dept2) :- sw2761.
0.29::sw2762.
takesCourse(ugrad7_d2,course15_d2) :- sw2762.
0.15::sw2763.
takesCourse(ugrad7_d2,course17_d2) :- sw2763.
0.49::sw2764.
undergraduateStudent(ugrad8_d2) :- sw2764.
0.78::sw2765.
memberOf(ugrad8_d2,dept2) :- sw2765.
0.29::sw2766.
takesCourse(ugrad8_d2,course15_d2) :- sw2766.
0.27::sw2767.
takesCourse(ugrad8_d2,course6_d2) :- sw2767.
0.67::sw2768.
undergraduateStudent(ugrad9_d2) :- sw2768.
0.93::sw2769.
memberOf(ugrad9_d2,dept2) :- sw2769.
0.48::sw2770.
takesCourse(ugrad9_d2,course9_d2) :- sw2770.
0.23::sw2771.
takesCourse(ugrad9_d2,course2_d2) :- sw2771.
0.77::sw2772.
undergraduateStudent(ugrad10_d2) :- sw2772.
0.56::sw2773.
memberOf(ugrad10_d2,dept2) :- sw2773.
0.34::sw2774.
takesCourse(ugrad10_d2,course2_d2) :- sw2774.
0.87::sw2775.
takesCourse(ugrad10_d2,course15_d2) :- sw2775.
0.24::sw2776.
undergraduateStudent(ugrad11_d2) :- sw2776.
0.49::sw2777.
memberOf(ugrad11_d2,dept2) :- sw2777.
0.69::sw2778.
takesCourse(ugrad11_d2,course12_d2) :- sw2778.
0.65::sw2779.
takesCourse(ugrad11_d2,course5_d2) :- sw2779.
0.39::sw2780.
undergraduateStudent(ugrad12_d2) :- sw2780.
0.45::sw2781.
memberOf(ugrad12_d2,dept2) :- sw2781.
0.78::sw2782.
takesCourse(ugrad12_d2,course8_d2) :- sw2782.
0.85::sw2783.
takesCourse(ugrad12_d2,course4_d2) :- sw2783.
0.72::sw2784.
undergraduateStudent(ugrad13_d2) :- sw2784.
0.70::sw2785.
memberOf(ugrad13_d2,dept2) :- sw2785.
0.05::sw2786.
takesCourse(ugrad13_d2,course18_d2) :- sw2786.
0.33::sw2787.
takesCourse(ugrad13_d2,course8_d2) :- sw2787.
0.66::sw2788.
advisor(ugrad13_d2,asso3_d2) :- sw2788.
0.66::sw2789.
undergraduateStudent(ugrad14_d2) :- sw2789.
0.79::sw2790.
memberOf(ugrad14_d2,dept2) :- sw2790.
0.34::sw2791.
takesCourse(ugrad14_d2,course6_d2) :- sw2791.
0.21::sw2792.
takesCourse(ugrad14_d2,course7_d2) :- sw2792.
0.73::sw2793.
undergraduateStudent(ugrad15_d2) :- sw2793.
0.68::sw2794.
memberOf(ugrad15_d2,dept2) :- sw2794.
0.70::sw2795.
takesCourse(ugrad15_d2,course18_d2) :- sw2795.
0.89::sw2796.
takesCourse(ugrad15_d2,course3_d2) :- sw2796.
0.74::sw2797.
undergraduateStudent(ugrad16_d2) :- sw2797.
0.44::sw2798.
memberOf(ugrad16_d2,dept2) :- sw2798.
0.96::sw2799.
takesCourse(ugrad16_d2,course6_d2) :- sw2799.
0.95::sw2800.
takesCourse(ugrad16_d2,course16_d2) :- sw2800.
0.48::sw2801.
undergraduateStudent(ugrad17_d2) :- sw2801.
0.96::sw2802.
memberOf(ugrad17_d2,dept2) :- sw2802.
0.95::sw2803.
takesCourse(ugrad17_d2,course0_d2) :- sw2803.
0.38::sw2804.
takesCourse(ugrad17_d2,course10_d2) :- sw2804.
0.84::sw2805.
undergraduateStudent(ugrad18_d2) :- sw2805.
0.71::sw2806.
memberOf(ugrad18_d2,dept2) :- sw2806.
0.30::sw2807.
takesCourse(ugrad18_d2,course15_d2) :- sw2807.
0.70::sw2808.
takesCourse(ugrad18_d2,course1_d2) :- sw2808.
0.11::sw2809.
undergraduateStudent(ugrad19_d2) :- sw2809.
0.73::sw2810.
memberOf(ugrad19_d2,dept2) :- sw2810.
0.50::sw2811.
takesCourse(ugrad19_d2,course10_d2) :- sw2811.
0.21::sw2812.
takesCourse(ugrad19_d2,course9_d2) :- sw2812.
0.18::sw2813.
advisor(ugrad19_d2,lect1_d2) :- sw2813.
0.78::sw2814.
undergraduateStudent(ugrad20_d2) :- sw2814.
0.90::sw2815.
memberOf(ugrad20_d2,dept2) :- sw2815.
0.14::sw2816.
takesCourse(ugrad20_d2,course18_d2) :- sw2816.
0.39::sw2817.
takesCourse(ugrad20_d2,course19_d2) :- sw2817.
0.53::sw2818.
undergraduateStudent(ugrad21_d2) :- sw2818.
0.34::sw2819.
memberOf(ugrad21_d2,dept2) :- sw2819.
0.56::sw2820.
takesCourse(ugrad21_d2,course16_d2) :- sw2820.
0.40::sw2821.
takesCourse(ugrad21_d2,course15_d2) :- sw2821.
0.92::sw2822.
undergraduateStudent(ugrad22_d2) :- sw2822.
0.62::sw2823.
memberOf(ugrad22_d2,dept2) :- sw2823.
0.62::sw2824.
takesCourse(ugrad22_d2,course2_d2) :- sw2824.
0.97::sw2825.
takesCourse(ugrad22_d2,course6_d2) :- sw2825.
0.61::sw2826.
undergraduateStudent(ugrad23_d2) :- sw2826.
0.40::sw2827.
memberOf(ugrad23_d2,dept2) :- sw2827.
0.69::sw2828.
takesCourse(ugrad23_d2,course11_d2) :- sw2828.
0.35::sw2829.
takesCourse(ugrad23_d2,course17_d2) :- sw2829.
0.40::sw2830.
advisor(ugrad23_d2,full0_d2) :- sw2830.
0.51::sw2831.
undergraduateStudent(ugrad24_d2) :- sw2831.
0.66::sw2832.
memberOf(ugrad24_d2,dept2) :- sw2832.
0.74::sw2833.
takesCourse(ugrad24_d2,course5_d2) :- sw2833.
0.54::sw2834.
takesCourse(ugrad24_d2,course1_d2) :- sw2834.
0.50::sw2835.
undergraduateStudent(ugrad25_d2) :- sw2835.
0.32::sw2836.
memberOf(ugrad25_d2,dept2) :- sw2836.
0.50::sw2837.
takesCourse(ugrad25_d2,course10_d2) :- sw2837.
0.29::sw2838.
takesCourse(ugrad25_d2,course3_d2) :- sw2838.
0.33::sw2839.
advisor(ugrad25_d2,assi5_d2) :- sw2839.
0.99::sw2840.
undergraduateStudent(ugrad26_d2) :- sw2840.
0.78::sw2841.
memberOf(ugrad26_d2,dept2) :- sw2841.
0.17::sw2842.
takesCourse(ugrad26_d2,course18_d2) :- sw2842.
0.67::sw2843.
takesCourse(ugrad26_d2,course7_d2) :- sw2843.
0.32::sw2844.
undergraduateStudent(ugrad27_d2) :- sw2844.
0.51::sw2845.
memberOf(ugrad27_d2,dept2) :- sw2845.
0.06::sw2846.
takesCourse(ugrad27_d2,course16_d2) :- sw2846.
0.59::sw2847.
takesCourse(ugrad27_d2,course17_d2) :- sw2847.
0.37::sw2848.
advisor(ugrad27_d2,asso6_d2) :- sw2848.
0.32::sw2849.
undergraduateStudent(ugrad28_d2) :- sw2849.
0.86::sw2850.
memberOf(ugrad28_d2,dept2) :- sw2850.
0.80::sw2851.
takesCourse(ugrad28_d2,course10_d2) :- sw2851.
0.67::sw2852.
takesCourse(ugrad28_d2,course4_d2) :- sw2852.
0.73::sw2853.
undergraduateStudent(ugrad29_d2) :- sw2853.
0.34::sw2854.
memberOf(ugrad29_d2,dept2) :- sw2854.
0.30::sw2855.
takesCourse(ugrad29_d2,course17_d2) :- sw2855.
0.20::sw2856.
takesCourse(ugrad29_d2,course7_d2) :- sw2856.
0.57::sw2857.
undergraduateStudent(ugrad30_d2) :- sw2857.
0.61::sw2858.
memberOf(ugrad30_d2,dept2) :- sw2858.
0.40::sw2859.
takesCourse(ugrad30_d2,course11_d2) :- sw2859.
0.56::sw2860.
takesCourse(ugrad30_d2,course18_d2) :- sw2860.
0.89::sw2861.
undergraduateStudent(ugrad31_d2) :- sw2861.
0.49::sw2862.
memberOf(ugrad31_d2,dept2) :- sw2862.
0.62::sw2863.
takesCourse(ugrad31_d2,course14_d2) :- sw2863.
0.29::sw2864.
takesCourse(ugrad31_d2,course13_d2) :- sw2864.
0.97::sw2865.
undergraduateStudent(ugrad32_d2) :- sw2865.
0.87::sw2866.
memberOf(ugrad32_d2,dept2) :- sw2866.
0.98::sw2867.
takesCourse(ugrad32_d2,course12_d2) :- sw2867.
0.87::sw2868.
takesCourse(ugrad32_d2,course1_d2) :- sw2868.
0.78::sw2869.
undergraduateStudent(ugrad33_d2) :- sw2869.
0.45::sw2870.
memberOf(ugrad33_d2,dept2) :- sw2870.
0.35::sw2871.
takesCourse(ugrad33_d2,course12_d2) :- sw2871.
0.72::sw2872.
takesCourse(ugrad33_d2,course0_d2) :- sw2872.
0.35::sw2873.
undergraduateStudent(ugrad34_d2) :- sw2873.
0.13::sw2874.
memberOf(ugrad34_d2,dept2) :- sw2874.
0.24::sw2875.
takesCourse(ugrad34_d2,course19_d2) :- sw2875.
0.73::sw2876.
takesCourse(ugrad34_d2,course2_d2) :- sw2876.
0.73::sw2877.
undergraduateStudent(ugrad35_d2) :- sw2877.
0.73::sw2878.
memberOf(ugrad35_d2,dept2) :- sw2878.
0.44::sw2879.
takesCourse(ugrad35_d2,course8_d2) :- sw2879.
0.14::sw2880.
takesCourse(ugrad35_d2,course13_d2) :- sw2880.
0.32::sw2881.
undergraduateStudent(ugrad36_d2) :- sw2881.
0.08::sw2882.
memberOf(ugrad36_d2,dept2) :- sw2882.
0.46::sw2883.
takesCourse(ugrad36_d2,course3_d2) :- sw2883.
0.61::sw2884.
takesCourse(ugrad36_d2,course0_d2) :- sw2884.
0.77::sw2885.
advisor(ugrad36_d2,full6_d2) :- sw2885.
0.26::sw2886.
undergraduateStudent(ugrad37_d2) :- sw2886.
0.87::sw2887.
memberOf(ugrad37_d2,dept2) :- sw2887.
0.78::sw2888.
takesCourse(ugrad37_d2,course13_d2) :- sw2888.
0.60::sw2889.
takesCourse(ugrad37_d2,course1_d2) :- sw2889.
0.49::sw2890.
undergraduateStudent(ugrad38_d2) :- sw2890.
0.76::sw2891.
memberOf(ugrad38_d2,dept2) :- sw2891.
0.35::sw2892.
takesCourse(ugrad38_d2,course13_d2) :- sw2892.
0.62::sw2893.
takesCourse(ugrad38_d2,course7_d2) :- sw2893.
0.61::sw2894.
undergraduateStudent(ugrad39_d2) :- sw2894.
0.60::sw2895.
memberOf(ugrad39_d2,dept2) :- sw2895.
0.49::sw2896.
takesCourse(ugrad39_d2,course13_d2) :- sw2896.
0.50::sw2897.
takesCourse(ugrad39_d2,course1_d2) :- sw2897.
0.30::sw2898.
undergraduateStudent(ugrad40_d2) :- sw2898.
0.26::sw2899.
memberOf(ugrad40_d2,dept2) :- sw2899.
0.58::sw2900.
takesCourse(ugrad40_d2,course11_d2) :- sw2900.
0.29::sw2901.
takesCourse(ugrad40_d2,course5_d2) :- sw2901.
0.85::sw2902.
undergraduateStudent(ugrad41_d2) :- sw2902.
0.59::sw2903.
memberOf(ugrad41_d2,dept2) :- sw2903.
0.48::sw2904.
takesCourse(ugrad41_d2,course11_d2) :- sw2904.
0.29::sw2905.
takesCourse(ugrad41_d2,course13_d2) :- sw2905.
0.07::sw2906.
undergraduateStudent(ugrad42_d2) :- sw2906.
0.32::sw2907.
memberOf(ugrad42_d2,dept2) :- sw2907.
0.85::sw2908.
takesCourse(ugrad42_d2,course7_d2) :- sw2908.
0.57::sw2909.
takesCourse(ugrad42_d2,course11_d2) :- sw2909.
0.92::sw2910.
undergraduateStudent(ugrad43_d2) :- sw2910.
0.82::sw2911.
memberOf(ugrad43_d2,dept2) :- sw2911.
0.50::sw2912.
takesCourse(ugrad43_d2,course7_d2) :- sw2912.
0.95::sw2913.
takesCourse(ugrad43_d2,course12_d2) :- sw2913.
0.97::sw2914.
undergraduateStudent(ugrad44_d2) :- sw2914.
0.15::sw2915.
memberOf(ugrad44_d2,dept2) :- sw2915.
0.35::sw2916.
takesCourse(ugrad44_d2,course11_d2) :- sw2916.
0.18::sw2917.
takesCourse(ugrad44_d2,course9_d2) :- sw2917.
0.37::sw2918.
undergraduateStudent(ugrad45_d2) :- sw2918.
0.71::sw2919.
memberOf(ugrad45_d2,dept2) :- sw2919.
0.41::sw2920.
takesCourse(ugrad45_d2,course7_d2) :- sw2920.
0.22::sw2921.
takesCourse(ugrad45_d2,course11_d2) :- sw2921.
0.09::sw2922.
undergraduateStudent(ugrad46_d2) :- sw2922.
0.75::sw2923.
memberOf(ugrad46_d2,dept2) :- sw2923.
0.87::sw2924.
takesCourse(ugrad46_d2,course0_d2) :- sw2924.
0.39::sw2925.
takesCourse(ugrad46_d2,course7_d2) :- sw2925.
0.62::sw2926.
undergraduateStudent(ugrad47_d2) :- sw2926.
0.35::sw2927.
memberOf(ugrad47_d2,dept2) :- sw2927.
0.10::sw2928.
takesCourse(ugrad47_d2,course15_d2) :- sw2928.
0.73::sw2929.
takesCourse(ugrad47_d2,course8_d2) :- sw2929.
0.86::sw2930.
advisor(ugrad47_d2,lect2_d2) :- sw2930.
0.65::sw2931.
undergraduateStudent(ugrad48_d2) :- sw2931.
0.89::sw2932.
memberOf(ugrad48_d2,dept2) :- sw2932.
0.50::sw2933.
takesCourse(ugrad48_d2,course16_d2) :- sw2933.
0.92::sw2934.
takesCourse(ugrad48_d2,course18_d2) :- sw2934.
0.71::sw2935.
undergraduateStudent(ugrad49_d2) :- sw2935.
0.90::sw2936.
memberOf(ugrad49_d2,dept2) :- sw2936.
0.79::sw2937.
takesCourse(ugrad49_d2,course14_d2) :- sw2937.
0.96::sw2938.
takesCourse(ugrad49_d2,course5_d2) :- sw2938.
0.08::sw2939.
undergraduateStudent(ugrad50_d2) :- sw2939.
0.89::sw2940.
memberOf(ugrad50_d2,dept2) :- sw2940.
0.34::sw2941.
takesCourse(ugrad50_d2,course12_d2) :- sw2941.
0.37::sw2942.
takesCourse(ugrad50_d2,course8_d2) :- sw2942.
0.84::sw2943.
undergraduateStudent(ugrad51_d2) :- sw2943.
0.11::sw2944.
memberOf(ugrad51_d2,dept2) :- sw2944.
0.48::sw2945.
takesCourse(ugrad51_d2,course18_d2) :- sw2945.
0.42::sw2946.
takesCourse(ugrad51_d2,course12_d2) :- sw2946.
0.61::sw2947.
advisor(ugrad51_d2,assi6_d2) :- sw2947.
0.55::sw2948.
undergraduateStudent(ugrad52_d2) :- sw2948.
0.90::sw2949.
memberOf(ugrad52_d2,dept2) :- sw2949.
0.62::sw2950.
takesCourse(ugrad52_d2,course3_d2) :- sw2950.
0.97::sw2951.
takesCourse(ugrad52_d2,course6_d2) :- sw2951.
0.57::sw2952.
undergraduateStudent(ugrad53_d2) :- sw2952.
0.57::sw2953.
memberOf(ugrad53_d2,dept2) :- sw2953.
0.30::sw2954.
takesCourse(ugrad53_d2,course18_d2) :- sw2954.
0.61::sw2955.
takesCourse(ugrad53_d2,course11_d2) :- sw2955.
0.23::sw2956.
undergraduateStudent(ugrad54_d2) :- sw2956.
0.29::sw2957.
memberOf(ugrad54_d2,dept2) :- sw2957.
0.06::sw2958.
takesCourse(ugrad54_d2,course11_d2) :- sw2958.
0.20::sw2959.
takesCourse(ugrad54_d2,course8_d2) :- sw2959.
0.87::sw2960.
undergraduateStudent(ugrad55_d2) :- sw2960.
0.77::sw2961.
memberOf(ugrad55_d2,dept2) :- sw2961.
0.92::sw2962.
takesCourse(ugrad55_d2,course12_d2) :- sw2962.
0.75::sw2963.
takesCourse(ugrad55_d2,course17_d2) :- sw2963.
0.63::sw2964.
undergraduateStudent(ugrad56_d2) :- sw2964.
0.44::sw2965.
memberOf(ugrad56_d2,dept2) :- sw2965.
0.92::sw2966.
takesCourse(ugrad56_d2,course4_d2) :- sw2966.
0.50::sw2967.
takesCourse(ugrad56_d2,course11_d2) :- sw2967.
0.40::sw2968.
undergraduateStudent(ugrad57_d2) :- sw2968.
0.38::sw2969.
memberOf(ugrad57_d2,dept2) :- sw2969.
0.26::sw2970.
takesCourse(ugrad57_d2,course9_d2) :- sw2970.
0.57::sw2971.
takesCourse(ugrad57_d2,course10_d2) :- sw2971.
0.65::sw2972.
undergraduateStudent(ugrad58_d2) :- sw2972.
0.93::sw2973.
memberOf(ugrad58_d2,dept2) :- sw2973.
0.75::sw2974.
takesCourse(ugrad58_d2,course8_d2) :- sw2974.
0.17::sw2975.
takesCourse(ugrad58_d2,course6_d2) :- sw2975.
0.14::sw2976.
advisor(ugrad58_d2,assi7_d2) :- sw2976.
0.15::sw2977.
undergraduateStudent(ugrad59_d2) :- sw2977.
0.58::sw2978.
memberOf(ugrad59_d2,dept2) :- sw2978.
0.55::sw2979.
takesCourse(ugrad59_d2,course6_d2) :- sw2979.
0.35::sw2980.
takesCourse(ugrad59_d2,course19_d2) :- sw2980.
0.18::sw2981.
undergraduateStudent(ugrad60_d2) :- sw2981.
0.81::sw2982.
memberOf(ugrad60_d2,dept2) :- sw2982.
0.58::sw2983.
takesCourse(ugrad60_d2,course11_d2) :- sw2983.
0.23::sw2984.
takesCourse(ugrad60_d2,course18_d2) :- sw2984.
0.19::sw2985.
undergraduateStudent(ugrad61_d2) :- sw2985.
0.54::sw2986.
memberOf(ugrad61_d2,dept2) :- sw2986.
0.39::sw2987.
takesCourse(ugrad61_d2,course7_d2) :- sw2987.
0.87::sw2988.
takesCourse(ugrad61_d2,course3_d2) :- sw2988.
0.18::sw2989.
undergraduateStudent(ugrad62_d2) :- sw2989.
0.16::sw2990.
memberOf(ugrad62_d2,dept2) :- sw2990.
0.55::sw2991.
takesCourse(ugrad62_d2,course3_d2) :- sw2991.
0.96::sw2992.
takesCourse(ugrad62_d2,course16_d2) :- sw2992.
0.16::sw2993.
undergraduateStudent(ugrad63_d2) :- sw2993.
0.55::sw2994.
memberOf(ugrad63_d2,dept2) :- sw2994.
0.55::sw2995.
takesCourse(ugrad63_d2,course0_d2) :- sw2995.
0.44::sw2996.
takesCourse(ugrad63_d2,course18_d2) :- sw2996.
0.56::sw2997.
undergraduateStudent(ugrad64_d2) :- sw2997.
0.97::sw2998.
memberOf(ugrad64_d2,dept2) :- sw2998.
0.27::sw2999.
takesCourse(ugrad64_d2,course1_d2) :- sw2999.
0.79::sw3000.
takesCourse(ugrad64_d2,course17_d2) :- sw3000.
0.63::sw3001.
undergraduateStudent(ugrad65_d2) :- sw3001.
0.81::sw3002.
memberOf(ugrad65_d2,dept2) :- sw3002.
0.09::sw3003.
takesCourse(ugrad65_d2,course9_d2) :- sw3003.
0.08::sw3004.
takesCourse(ugrad65_d2,course19_d2) :- sw3004.
0.88::sw3005.
undergraduateStudent(ugrad66_d2) :- sw3005.
0.83::sw3006.
memberOf(ugrad66_d2,dept2) :- sw3006.
0.25::sw3007.
takesCourse(ugrad66_d2,course4_d2) :- sw3007.
0.48::sw3008.
takesCourse(ugrad66_d2,course16_d2) :- sw3008.
0.79::sw3009.
advisor(ugrad66_d2,asso3_d2) :- sw3009.
0.69::sw3010.
undergraduateStudent(ugrad67_d2) :- sw3010.
0.45::sw3011.
memberOf(ugrad67_d2,dept2) :- sw3011.
0.59::sw3012.
takesCourse(ugrad67_d2,course15_d2) :- sw3012.
0.36::sw3013.
takesCourse(ugrad67_d2,course12_d2) :- sw3013.
0.73::sw3014.
undergraduateStudent(ugrad68_d2) :- sw3014.
0.90::sw3015.
memberOf(ugrad68_d2,dept2) :- sw3015.
0.47::sw3016.
takesCourse(ugrad68_d2,course7_d2) :- sw3016.
0.61::sw3017.
takesCourse(ugrad68_d2,course5_d2) :- sw3017.
0.08::sw3018.
undergraduateStudent(ugrad69_d2) :- sw3018.
0.54::sw3019.
memberOf(ugrad69_d2,dept2) :- sw3019.
0.32::sw3020.
takesCourse(ugrad69_d2,course18_d2) :- sw3020.
0.60::sw3021.
takesCourse(ugrad69_d2,course15_d2) :- sw3021.
0.67::sw3022.
advisor(ugrad69_d2,assi4_d2) :- sw3022.
0.95::sw3023.
undergraduateStudent(ugrad70_d2) :- sw3023.
0.99::sw3024.
memberOf(ugrad70_d2,dept2) :- sw3024.
0.55::sw3025.
takesCourse(ugrad70_d2,course0_d2) :- sw3025.
0.46::sw3026.
takesCourse(ugrad70_d2,course18_d2) :- sw3026.
0.95::sw3027.
undergraduateStudent(ugrad71_d2) :- sw3027.
0.92::sw3028.
memberOf(ugrad71_d2,dept2) :- sw3028.
0.51::sw3029.
takesCourse(ugrad71_d2,course1_d2) :- sw3029.
0.21::sw3030.
takesCourse(ugrad71_d2,course17_d2) :- sw3030.
0.26::sw3031.
undergraduateStudent(ugrad72_d2) :- sw3031.
0.79::sw3032.
memberOf(ugrad72_d2,dept2) :- sw3032.
0.13::sw3033.
takesCourse(ugrad72_d2,course3_d2) :- sw3033.
0.73::sw3034.
takesCourse(ugrad72_d2,course12_d2) :- sw3034.
0.75::sw3035.
undergraduateStudent(ugrad73_d2) :- sw3035.
0.25::sw3036.
memberOf(ugrad73_d2,dept2) :- sw3036.
0.10::sw3037.
takesCourse(ugrad73_d2,course9_d2) :- sw3037.
0.41::sw3038.
takesCourse(ugrad73_d2,course11_d2) :- sw3038.
0.81::sw3039.
undergraduateStudent(ugrad74_d2) :- sw3039.
0.06::sw3040.
memberOf(ugrad74_d2,dept2) :- sw3040.
0.90::sw3041.
takesCourse(ugrad74_d2,course18_d2) :- sw3041.
0.41::sw3042.
takesCourse(ugrad74_d2,course12_d2) :- sw3042.
0.68::sw3043.
undergraduateStudent(ugrad75_d2) :- sw3043.
0.72::sw3044.
memberOf(ugrad75_d2,dept2) :- sw3044.
0.85::sw3045.
takesCourse(ugrad75_d2,course14_d2) :- sw3045.
0.07::sw3046.
takesCourse(ugrad75_d2,course6_d2) :- sw3046.
0.13::sw3047.
advisor(ugrad75_d2,asso8_d2) :- sw3047.
0.53::sw3048.
undergraduateStudent(ugrad76_d2) :- sw3048.
0.48::sw3049.
memberOf(ugrad76_d2,dept2) :- sw3049.
0.42::sw3050.
takesCourse(ugrad76_d2,course14_d2) :- sw3050.
0.28::sw3051.
takesCourse(ugrad76_d2,course3_d2) :- sw3051.
0.24::sw3052.
undergraduateStudent(ugrad77_d2) :- sw3052.
0.94::sw3053.
memberOf(ugrad77_d2,dept2) :- sw3053.
0.32::sw3054.
takesCourse(ugrad77_d2,course2_d2) :- sw3054.
0.21::sw3055.
takesCourse(ugrad77_d2,course7_d2) :- sw3055.
0.15::sw3056.
undergraduateStudent(ugrad78_d2) :- sw3056.
0.45::sw3057.
memberOf(ugrad78_d2,dept2) :- sw3057.
0.36::sw3058.
takesCourse(ugrad78_d2,course11_d2) :- sw3058.
0.73::sw3059.
takesCourse(ugrad78_d2,course8_d2) :- sw3059.
0.54::sw3060.
undergraduateStudent(ugrad79_d2) :- sw3060.
0.75::sw3061.
memberOf(ugrad79_d2,dept2) :- sw3061.
0.37::sw3062.
takesCourse(ugrad79_d2,course7_d2) :- sw3062.
0.30::sw3063.
takesCourse(ugrad79_d2,course18_d2) :- sw3063.
0.98::sw3064.
undergraduateStudent(ugrad80_d2) :- sw3064.
0.18::sw3065.
memberOf(ugrad80_d2,dept2) :- sw3065.
0.94::sw3066.
takesCourse(ugrad80_d2,course10_d2) :- sw3066.
0.86::sw3067.
takesCourse(ugrad80_d2,course13_d2) :- sw3067.
0.36::sw3068.
advisor(ugrad80_d2,full4_d2) :- sw3068.
0.69::sw3069.
undergraduateStudent(ugrad81_d2) :- sw3069.
0.17::sw3070.
memberOf(ugrad81_d2,dept2) :- sw3070.
0.51::sw3071.
takesCourse(ugrad81_d2,course18_d2) :- sw3071.
0.86::sw3072.
takesCourse(ugrad81_d2,course0_d2) :- sw3072.
0.51::sw3073.
advisor(ugrad81_d2,asso6_d2) :- sw3073.
0.43::sw3074.
undergraduateStudent(ugrad82_d2) :- sw3074.
0.62::sw3075.
memberOf(ugrad82_d2,dept2) :- sw3075.
0.46::sw3076.
takesCourse(ugrad82_d2,course3_d2) :- sw3076.
0.08::sw3077.
takesCourse(ugrad82_d2,course6_d2) :- sw3077.
0.62::sw3078.
undergraduateStudent(ugrad83_d2) :- sw3078.
0.41::sw3079.
memberOf(ugrad83_d2,dept2) :- sw3079.
0.36::sw3080.
takesCourse(ugrad83_d2,course17_d2) :- sw3080.
0.34::sw3081.
takesCourse(ugrad83_d2,course2_d2) :- sw3081.
0.76::sw3082.
advisor(ugrad83_d2,lect4_d2) :- sw3082.
0.38::sw3083.
undergraduateStudent(ugrad84_d2) :- sw3083.
0.46::sw3084.
memberOf(ugrad84_d2,dept2) :- sw3084.
0.79::sw3085.
takesCourse(ugrad84_d2,course14_d2) :- sw3085.
0.74::sw3086.
takesCourse(ugrad84_d2,course0_d2) :- sw3086.
0.12::sw3087.
undergraduateStudent(ugrad85_d2) :- sw3087.
0.24::sw3088.
memberOf(ugrad85_d2,dept2) :- sw3088.
0.38::sw3089.
takesCourse(ugrad85_d2,course10_d2) :- sw3089.
0.56::sw3090.
takesCourse(ugrad85_d2,course6_d2) :- sw3090.
0.21::sw3091.
undergraduateStudent(ugrad86_d2) :- sw3091.
0.80::sw3092.
memberOf(ugrad86_d2,dept2) :- sw3092.
0.90::sw3093.
takesCourse(ugrad86_d2,course13_d2) :- sw3093.
0.70::sw3094.
takesCourse(ugrad86_d2,course7_d2) :- sw3094.
0.85::sw3095.
advisor(ugrad86_d2,full5_d2) :- sw3095.
0.96::sw3096.
undergraduateStudent(ugrad87_d2) :- sw3096.
0.47::sw3097.
memberOf(ugrad87_d2,dept2) :- sw3097.
0.49::sw3098.
takesCourse(ugrad87_d2,course2_d2) :- sw3098.
0.22::sw3099.
takesCourse(ugrad87_d2,course17_d2) :- sw3099.
0.33::sw3100.
undergraduateStudent(ugrad88_d2) :- sw3100.
0.16::sw3101.
memberOf(ugrad88_d2,dept2) :- sw3101.
0.05::sw3102.
takesCourse(ugrad88_d2,course6_d2) :- sw3102.
0.38::sw3103.
takesCourse(ugrad88_d2,course5_d2) :- sw3103.
0.34::sw3104.
undergraduateStudent(ugrad89_d2) :- sw3104.
0.99::sw3105.
memberOf(ugrad89_d2,dept2) :- sw3105.
0.15::sw3106.
takesCourse(ugrad89_d2,course2_d2) :- sw3106.
0.46::sw3107.
takesCourse(ugrad89_d2,course11_d2) :- sw3107.
0.77::sw3108.
advisor(ugrad89_d2,lect3_d2) :- sw3108.
0.65::sw3109.
undergraduateStudent(ugrad90_d2) :- sw3109.
0.71::sw3110.
memberOf(ugrad90_d2,dept2) :- sw3110.
0.20::sw3111.
takesCourse(ugrad90_d2,course16_d2) :- sw3111.
0.84::sw3112.
takesCourse(ugrad90_d2,course4_d2) :- sw3112.
0.62::sw3113.
advisor(ugrad90_d2,asso6_d2) :- sw3113.
0.50::sw3114.
undergraduateStudent(ugrad91_d2) :- sw3114.
0.15::sw3115.
memberOf(ugrad91_d2,dept2) :- sw3115.
0.31::sw3116.
takesCourse(ugrad91_d2,course15_d2) :- sw3116.
0.75::sw3117.
takesCourse(ugrad91_d2,course8_d2) :- sw3117.
0.21::sw3118.
undergraduateStudent(ugrad92_d2) :- sw3118.
0.94::sw3119.
memberOf(ugrad92_d2,dept2) :- sw3119.
0.46::sw3120.
takesCourse(ugrad92_d2,course1_d2) :- sw3120.
0.27::sw3121.
takesCourse(ugrad92_d2,course7_d2) :- sw3121.
0.79::sw3122.
undergraduateStudent(ugrad93_d2) :- sw3122.
0.52::sw3123.
memberOf(ugrad93_d2,dept2) :- sw3123.
0.28::sw3124.
takesCourse(ugrad93_d2,course11_d2) :- sw3124.
0.82::sw3125.
takesCourse(ugrad93_d2,course2_d2) :- sw3125.
0.71::sw3126.
undergraduateStudent(ugrad94_d2) :- sw3126.
0.79::sw3127.
memberOf(ugrad94_d2,dept2) :- sw3127.
0.75::sw3128.
takesCourse(ugrad94_d2,course5_d2) :- sw3128.
0.68::sw3129.
takesCourse(ugrad94_d2,course0_d2) :- sw3129.
0.21::sw3130.
undergraduateStudent(ugrad95_d2) :- sw3130.
0.26::sw3131.
memberOf(ugrad95_d2,dept2) :- sw3131.
0.98::sw3132.
takesCourse(ugrad95_d2,course7_d2) :- sw3132.
0.97::sw3133.
takesCourse(ugrad95_d2,course3_d2) :- sw3133.
0.38::sw3134.
undergraduateStudent(ugrad96_d2) :- sw3134.
0.94::sw3135.
memberOf(ugrad96_d2,dept2) :- sw3135.
0.09::sw3136.
takesCourse(ugrad96_d2,course4_d2) :- sw3136.
0.11::sw3137.
takesCourse(ugrad96_d2,course17_d2) :- sw3137.
0.93::sw3138.
undergraduateStudent(ugrad97_d2) :- sw3138.
0.44::sw3139.
memberOf(ugrad97_d2,dept2) :- sw3139.
0.53::sw3140.
takesCourse(ugrad97_d2,course10_d2) :- sw3140.
0.49::sw3141.
takesCourse(ugrad97_d2,course6_d2) :- sw3141.
0.74::sw3142.
undergraduateStudent(ugrad98_d2) :- sw3142.
0.49::sw3143.
memberOf(ugrad98_d2,dept2) :- sw3143.
0.54::sw3144.
takesCourse(ugrad98_d2,course13_d2) :- sw3144.
0.57::sw3145.
takesCourse(ugrad98_d2,course0_d2) :- sw3145.
0.89::sw3146.
undergraduateStudent(ugrad99_d2) :- sw3146.
0.97::sw3147.
memberOf(ugrad99_d2,dept2) :- sw3147.
0.87::sw3148.
takesCourse(ugrad99_d2,course14_d2) :- sw3148.
0.33::sw3149.
takesCourse(ugrad99_d2,course7_d2) :- sw3149.
0.70::sw3150.
undergraduateStudent(ugrad100_d2) :- sw3150.
0.89::sw3151.
memberOf(ugrad100_d2,dept2) :- sw3151.
0.68::sw3152.
takesCourse(ugrad100_d2,course7_d2) :- sw3152.
0.23::sw3153.
takesCourse(ugrad100_d2,course3_d2) :- sw3153.
0.44::sw3154.
undergraduateStudent(ugrad101_d2) :- sw3154.
0.17::sw3155.
memberOf(ugrad101_d2,dept2) :- sw3155.
0.21::sw3156.
takesCourse(ugrad101_d2,course18_d2) :- sw3156.
0.26::sw3157.
takesCourse(ugrad101_d2,course5_d2) :- sw3157.
0.16::sw3158.
undergraduateStudent(ugrad102_d2) :- sw3158.
0.99::sw3159.
memberOf(ugrad102_d2,dept2) :- sw3159.
0.59::sw3160.
takesCourse(ugrad102_d2,course16_d2) :- sw3160.
0.15::sw3161.
takesCourse(ugrad102_d2,course8_d2) :- sw3161.
0.40::sw3162.
advisor(ugrad102_d2,lect1_d2) :- sw3162.
0.89::sw3163.
undergraduateStudent(ugrad103_d2) :- sw3163.
0.26::sw3164.
memberOf(ugrad103_d2,dept2) :- sw3164.
0.19::sw3165.
takesCourse(ugrad103_d2,course13_d2) :- sw3165.
0.89::sw3166.
takesCourse(ugrad103_d2,course0_d2) :- sw3166.
0.16::sw3167.
undergraduateStudent(ugrad104_d2) :- sw3167.
0.69::sw3168.
memberOf(ugrad104_d2,dept2) :- sw3168.
0.51::sw3169.
takesCourse(ugrad104_d2,course3_d2) :- sw3169.
0.27::sw3170.
takesCourse(ugrad104_d2,course7_d2) :- sw3170.
0.96::sw3171.
undergraduateStudent(ugrad105_d2) :- sw3171.
0.86::sw3172.
memberOf(ugrad105_d2,dept2) :- sw3172.
0.31::sw3173.
takesCourse(ugrad105_d2,course5_d2) :- sw3173.
0.42::sw3174.
takesCourse(ugrad105_d2,course2_d2) :- sw3174.
0.51::sw3175.
advisor(ugrad105_d2,lect2_d2) :- sw3175.
0.79::sw3176.
undergraduateStudent(ugrad106_d2) :- sw3176.
0.94::sw3177.
memberOf(ugrad106_d2,dept2) :- sw3177.
0.95::sw3178.
takesCourse(ugrad106_d2,course0_d2) :- sw3178.
0.38::sw3179.
takesCourse(ugrad106_d2,course5_d2) :- sw3179.
0.97::sw3180.
undergraduateStudent(ugrad107_d2) :- sw3180.
0.66::sw3181.
memberOf(ugrad107_d2,dept2) :- sw3181.
0.50::sw3182.
takesCourse(ugrad107_d2,course19_d2) :- sw3182.
0.53::sw3183.
takesCourse(ugrad107_d2,course10_d2) :- sw3183.
0.67::sw3184.
undergraduateStudent(ugrad108_d2) :- sw3184.
0.64::sw3185.
memberOf(ugrad108_d2,dept2) :- sw3185.
0.36::sw3186.
takesCourse(ugrad108_d2,course14_d2) :- sw3186.
0.31::sw3187.
takesCourse(ugrad108_d2,course9_d2) :- sw3187.
0.10::sw3188.
advisor(ugrad108_d2,full6_d2) :- sw3188.
0.70::sw3189.
undergraduateStudent(ugrad109_d2) :- sw3189.
0.32::sw3190.
memberOf(ugrad109_d2,dept2) :- sw3190.
0.80::sw3191.
takesCourse(ugrad109_d2,course11_d2) :- sw3191.
0.68::sw3192.
takesCourse(ugrad109_d2,course18_d2) :- sw3192.
0.62::sw3193.
undergraduateStudent(ugrad110_d2) :- sw3193.
0.92::sw3194.
memberOf(ugrad110_d2,dept2) :- sw3194.
0.09::sw3195.
takesCourse(ugrad110_d2,course0_d2) :- sw3195.
0.93::sw3196.
takesCourse(ugrad110_d2,course11_d2) :- sw3196.
0.36::sw3197.
undergraduateStudent(ugrad111_d2) :- sw3197.
0.95::sw3198.
memberOf(ugrad111_d2,dept2) :- sw3198.
0.09::sw3199.
takesCourse(ugrad111_d2,course2_d2) :- sw3199.
0.37::sw3200.
takesCourse(ugrad111_d2,course5_d2) :- sw3200.
0.45::sw3201.
undergraduateStudent(ugrad112_d2) :- sw3201.
0.71::sw3202.
memberOf(ugrad112_d2,dept2) :- sw3202.
0.63::sw3203.
takesCourse(ugrad112_d2,course0_d2) :- sw3203.
0.30::sw3204.
takesCourse(ugrad112_d2,course9_d2) :- sw3204.
0.42::sw3205.
undergraduateStudent(ugrad113_d2) :- sw3205.
0.23::sw3206.
memberOf(ugrad113_d2,dept2) :- sw3206.
0.06::sw3207.
takesCourse(ugrad113_d2,course19_d2) :- sw3207.
0.26::sw3208.
takesCourse(ugrad113_d2,course15_d2) :- sw3208.
0.33::sw3209.
undergraduateStudent(ugrad114_d2) :- sw3209.
0.86::sw3210.
memberOf(ugrad114_d2,dept2) :- sw3210.
0.32::sw3211.
takesCourse(ugrad114_d2,course13_d2) :- sw3211.
0.42::sw3212.
takesCourse(ugrad114_d2,course12_d2) :- sw3212.
0.84::sw3213.
advisor(ugrad114_d2,assi3_d2) :- sw3213.
0.80::sw3214.
undergraduateStudent(ugrad115_d2) :- sw3214.
0.99::sw3215.
memberOf(ugrad115_d2,dept2) :- sw3215.
0.06::sw3216.
takesCourse(ugrad115_d2,course4_d2) :- sw3216.
0.89::sw3217.
takesCourse(ugrad115_d2,course17_d2) :- sw3217.
0.70::sw3218.
undergraduateStudent(ugrad116_d2) :- sw3218.
0.77::sw3219.
memberOf(ugrad116_d2,dept2) :- sw3219.
0.88::sw3220.
takesCourse(ugrad116_d2,course2_d2) :- sw3220.
0.14::sw3221.
takesCourse(ugrad116_d2,course10_d2) :- sw3221.
0.66::sw3222.
undergraduateStudent(ugrad117_d2) :- sw3222.
0.92::sw3223.
memberOf(ugrad117_d2,dept2) :- sw3223.
0.39::sw3224.
takesCourse(ugrad117_d2,course9_d2) :- sw3224.
0.38::sw3225.
takesCourse(ugrad117_d2,course17_d2) :- sw3225.
0.92::sw3226.
undergraduateStudent(ugrad118_d2) :- sw3226.
0.42::sw3227.
memberOf(ugrad118_d2,dept2) :- sw3227.
0.64::sw3228.
takesCourse(ugrad118_d2,course12_d2) :- sw3228.
0.78::sw3229.
takesCourse(ugrad118_d2,course4_d2) :- sw3229.
0.25::sw3230.
undergraduateStudent(ugrad119_d2) :- sw3230.
0.50::sw3231.
memberOf(ugrad119_d2,dept2) :- sw3231.
0.76::sw3232.
takesCourse(ugrad119_d2,course2_d2) :- sw3232.
0.82::sw3233.
takesCourse(ugrad119_d2,course18_d2) :- sw3233.
0.26::sw3234.
undergraduateStudent(ugrad120_d2) :- sw3234.
0.25::sw3235.
memberOf(ugrad120_d2,dept2) :- sw3235.
0.68::sw3236.
takesCourse(ugrad120_d2,course16_d2) :- sw3236.
0.81::sw3237.
takesCourse(ugrad120_d2,course2_d2) :- sw3237.
0.51::sw3238.
undergraduateStudent(ugrad121_d2) :- sw3238.
0.73::sw3239.
memberOf(ugrad121_d2,dept2) :- sw3239.
0.49::sw3240.
takesCourse(ugrad121_d2,course2_d2) :- sw3240.
0.68::sw3241.
takesCourse(ugrad121_d2,course16_d2) :- sw3241.
0.27::sw3242.
undergraduateStudent(ugrad122_d2) :- sw3242.
0.29::sw3243.
memberOf(ugrad122_d2,dept2) :- sw3243.
0.64::sw3244.
takesCourse(ugrad122_d2,course10_d2) :- sw3244.
0.12::sw3245.
takesCourse(ugrad122_d2,course7_d2) :- sw3245.
0.63::sw3246.
advisor(ugrad122_d2,assi7_d2) :- sw3246.
0.32::sw3247.
undergraduateStudent(ugrad123_d2) :- sw3247.
0.29::sw3248.
memberOf(ugrad123_d2,dept2) :- sw3248.
0.52::sw3249.
takesCourse(ugrad123_d2,course14_d2) :- sw3249.
0.12::sw3250.
takesCourse(ugrad123_d2,course9_d2) :- sw3250.
0.56::sw3251.
undergraduateStudent(ugrad124_d2) :- sw3251.
0.55::sw3252.
memberOf(ugrad124_d2,dept2) :- sw3252.
0.47::sw3253.
takesCourse(ugrad124_d2,course4_d2) :- sw3253.
0.53::sw3254.
takesCourse(ugrad124_d2,course19_d2) :- sw3254.
0.65::sw3255.
undergraduateStudent(ugrad125_d2) :- sw3255.
0.32::sw3256.
memberOf(ugrad125_d2,dept2) :- sw3256.
0.71::sw3257.
takesCourse(ugrad125_d2,course18_d2) :- sw3257.
0.30::sw3258.
takesCourse(ugrad125_d2,course0_d2) :- sw3258.
0.47::sw3259.
undergraduateStudent(ugrad126_d2) :- sw3259.
0.63::sw3260.
memberOf(ugrad126_d2,dept2) :- sw3260.
0.99::sw3261.
takesCourse(ugrad126_d2,course16_d2) :- sw3261.
0.83::sw3262.
takesCourse(ugrad126_d2,course14_d2) :- sw3262.
0.31::sw3263.
undergraduateStudent(ugrad127_d2) :- sw3263.
0.13::sw3264.
memberOf(ugrad127_d2,dept2) :- sw3264.
0.73::sw3265.
takesCourse(ugrad127_d2,course13_d2) :- sw3265.
0.49::sw3266.
takesCourse(ugrad127_d2,course18_d2) :- sw3266.
0.63::sw3267.
undergraduateStudent(ugrad128_d2) :- sw3267.
0.30::sw3268.
memberOf(ugrad128_d2,dept2) :- sw3268.
0.71::sw3269.
takesCourse(ugrad128_d2,course14_d2) :- sw3269.
0.79::sw3270.
takesCourse(ugrad128_d2,course16_d2) :- sw3270.
0.86::sw3271.
undergraduateStudent(ugrad129_d2) :- sw3271.
0.51::sw3272.
memberOf(ugrad129_d2,dept2) :- sw3272.
0.97::sw3273.
takesCourse(ugrad129_d2,course12_d2) :- sw3273.
0.09::sw3274.
takesCourse(ugrad129_d2,course17_d2) :- sw3274.
0.64::sw3275.
undergraduateStudent(ugrad130_d2) :- sw3275.
0.55::sw3276.
memberOf(ugrad130_d2,dept2) :- sw3276.
0.91::sw3277.
takesCourse(ugrad130_d2,course9_d2) :- sw3277.
0.27::sw3278.
takesCourse(ugrad130_d2,course2_d2) :- sw3278.
0.33::sw3279.
undergraduateStudent(ugrad131_d2) :- sw3279.
0.53::sw3280.
memberOf(ugrad131_d2,dept2) :- sw3280.
0.96::sw3281.
takesCourse(ugrad131_d2,course19_d2) :- sw3281.
0.70::sw3282.
takesCourse(ugrad131_d2,course10_d2) :- sw3282.
0.39::sw3283.
undergraduateStudent(ugrad132_d2) :- sw3283.
0.71::sw3284.
memberOf(ugrad132_d2,dept2) :- sw3284.
0.70::sw3285.
takesCourse(ugrad132_d2,course2_d2) :- sw3285.
0.72::sw3286.
takesCourse(ugrad132_d2,course12_d2) :- sw3286.
0.17::sw3287.
undergraduateStudent(ugrad133_d2) :- sw3287.
0.39::sw3288.
memberOf(ugrad133_d2,dept2) :- sw3288.
0.96::sw3289.
takesCourse(ugrad133_d2,course8_d2) :- sw3289.
0.92::sw3290.
takesCourse(ugrad133_d2,course14_d2) :- sw3290.
0.20::sw3291.
undergraduateStudent(ugrad134_d2) :- sw3291.
0.33::sw3292.
memberOf(ugrad134_d2,dept2) :- sw3292.
0.24::sw3293.
takesCourse(ugrad134_d2,course7_d2) :- sw3293.
0.71::sw3294.
takesCourse(ugrad134_d2,course14_d2) :- sw3294.
0.69::sw3295.
undergraduateStudent(ugrad135_d2) :- sw3295.
0.69::sw3296.
memberOf(ugrad135_d2,dept2) :- sw3296.
0.29::sw3297.
takesCourse(ugrad135_d2,course19_d2) :- sw3297.
0.33::sw3298.
takesCourse(ugrad135_d2,course15_d2) :- sw3298.
0.98::sw3299.
advisor(ugrad135_d2,full6_d2) :- sw3299.
0.44::sw3300.
undergraduateStudent(ugrad136_d2) :- sw3300.
0.43::sw3301.
memberOf(ugrad136_d2,dept2) :- sw3301.
0.90::sw3302.
takesCourse(ugrad136_d2,course18_d2) :- sw3302.
0.34::sw3303.
takesCourse(ugrad136_d2,course12_d2) :- sw3303.
0.25::sw3304.
undergraduateStudent(ugrad137_d2) :- sw3304.
0.69::sw3305.
memberOf(ugrad137_d2,dept2) :- sw3305.
0.15::sw3306.
takesCourse(ugrad137_d2,course6_d2) :- sw3306.
0.99::sw3307.
takesCourse(ugrad137_d2,course14_d2) :- sw3307.
0.38::sw3308.
undergraduateStudent(ugrad138_d2) :- sw3308.
0.53::sw3309.
memberOf(ugrad138_d2,dept2) :- sw3309.
0.78::sw3310.
takesCourse(ugrad138_d2,course18_d2) :- sw3310.
0.57::sw3311.
takesCourse(ugrad138_d2,course9_d2) :- sw3311.
0.28::sw3312.
undergraduateStudent(ugrad139_d2) :- sw3312.
0.94::sw3313.
memberOf(ugrad139_d2,dept2) :- sw3313.
0.52::sw3314.
takesCourse(ugrad139_d2,course9_d2) :- sw3314.
0.77::sw3315.
takesCourse(ugrad139_d2,course2_d2) :- sw3315.
0.06::sw3316.
advisor(ugrad139_d2,asso4_d2) :- sw3316.
0.64::sw3317.
undergraduateStudent(ugrad140_d2) :- sw3317.
0.22::sw3318.
memberOf(ugrad140_d2,dept2) :- sw3318.
0.05::sw3319.
takesCourse(ugrad140_d2,course1_d2) :- sw3319.
0.50::sw3320.
takesCourse(ugrad140_d2,course19_d2) :- sw3320.
0.46::sw3321.
undergraduateStudent(ugrad141_d2) :- sw3321.
0.50::sw3322.
memberOf(ugrad141_d2,dept2) :- sw3322.
0.08::sw3323.
takesCourse(ugrad141_d2,course16_d2) :- sw3323.
0.30::sw3324.
takesCourse(ugrad141_d2,course12_d2) :- sw3324.
0.26::sw3325.
undergraduateStudent(ugrad142_d2) :- sw3325.
0.77::sw3326.
memberOf(ugrad142_d2,dept2) :- sw3326.
0.42::sw3327.
takesCourse(ugrad142_d2,course12_d2) :- sw3327.
0.74::sw3328.
takesCourse(ugrad142_d2,course13_d2) :- sw3328.
0.87::sw3329.
undergraduateStudent(ugrad143_d2) :- sw3329.
0.23::sw3330.
memberOf(ugrad143_d2,dept2) :- sw3330.
0.15::sw3331.
takesCourse(ugrad143_d2,course4_d2) :- sw3331.
0.85::sw3332.
takesCourse(ugrad143_d2,course0_d2) :- sw3332.
0.65::sw3333.
undergraduateStudent(ugrad144_d2) :- sw3333.
0.85::sw3334.
memberOf(ugrad144_d2,dept2) :- sw3334.
0.82::sw3335.
takesCourse(ugrad144_d2,course13_d2) :- sw3335.
0.57::sw3336.
takesCourse(ugrad144_d2,course14_d2) :- sw3336.
0.61::sw3337.
advisor(ugrad144_d2,asso3_d2) :- sw3337.
undergraduateStudent(ugrad145_d2).
0.53::sw3338.
memberOf(ugrad145_d2,dept2) :- sw3338.
0.22::sw3339.
takesCourse(ugrad145_d2,course5_d2) :- sw3339.
0.85::sw3340.
takesCourse(ugrad145_d2,course11_d2) :- sw3340.
0.40::sw3341.
advisor(ugrad145_d2,assi4_d2) :- sw3341.
0.70::sw3342.
undergraduateStudent(ugrad146_d2) :- sw3342.
0.19::sw3343.
memberOf(ugrad146_d2,dept2) :- sw3343.
0.90::sw3344.
takesCourse(ugrad146_d2,course11_d2) :- sw3344.
0.34::sw3345.
takesCourse(ugrad146_d2,course0_d2) :- sw3345.
0.65::sw3346.
undergraduateStudent(ugrad147_d2) :- sw3346.
0.07::sw3347.
memberOf(ugrad147_d2,dept2) :- sw3347.
0.90::sw3348.
takesCourse(ugrad147_d2,course1_d2) :- sw3348.
0.06::sw3349.
takesCourse(ugrad147_d2,course18_d2) :- sw3349.
0.30::sw3350.
undergraduateStudent(ugrad148_d2) :- sw3350.
memberOf(ugrad148_d2,dept2).
0.74::sw3351.
takesCourse(ugrad148_d2,course10_d2) :- sw3351.
0.44::sw3352.
takesCourse(ugrad148_d2,course0_d2) :- sw3352.
0.56::sw3353.
undergraduateStudent(ugrad149_d2) :- sw3353.
memberOf(ugrad149_d2,dept2).
0.44::sw3354.
takesCourse(ugrad149_d2,course1_d2) :- sw3354.
0.37::sw3355.
takesCourse(ugrad149_d2,course8_d2) :- sw3355.
0.59::sw3356.
graduateStudent(grad0_d2) :- sw3356.
0.38::sw3357.
memberOf(grad0_d2,dept2) :- sw3357.
0.70::sw3358.
undergraduateDegreeFrom(grad0_d2,univ0) :- sw3358.
0.26::sw3359.
advisor(grad0_d2,full5_d2) :- sw3359.
0.41::sw3360.
takesCourse(grad0_d2,gradCourse3_d2) :- sw3360.
0.44::sw3361.
takesCourse(grad0_d2,gradCourse5_d2) :- sw3361.
0.78::sw3362.
graduateStudent(grad1_d2) :- sw3362.
0.70::sw3363.
memberOf(grad1_d2,dept2) :- sw3363.
0.92::sw3364.
undergraduateDegreeFrom(grad1_d2,univ1) :- sw3364.
0.18::sw3365.
advisor(grad1_d2,lect2_d2) :- sw3365.
0.67::sw3366.
takesCourse(grad1_d2,gradCourse6_d2) :- sw3366.
0.38::sw3367.
takesCourse(grad1_d2,gradCourse0_d2) :- sw3367.
0.94::sw3368.
graduateStudent(grad2_d2) :- sw3368.
0.95::sw3369.
memberOf(grad2_d2,dept2) :- sw3369.
0.78::sw3370.
undergraduateDegreeFrom(grad2_d2,univ0) :- sw3370.
0.53::sw3371.
advisor(grad2_d2,assi1_d2) :- sw3371.
0.29::sw3372.
takesCourse(grad2_d2,gradCourse7_d2) :- sw3372.
0.60::sw3373.
takesCourse(grad2_d2,gradCourse8_d2) :- sw3373.
0.45::sw3374.
teachingAssistantOf(grad2_d2,course12_d2) :- sw3374.
0.11::sw3375.
graduateStudent(grad3_d2) :- sw3375.
0.22::sw3376.
memberOf(grad3_d2,dept2) :- sw3376.
0.39::sw3377.
undergraduateDegreeFrom(grad3_d2,univ3) :- sw3377.
0.57::sw3378.
advisor(grad3_d2,asso1_d2) :- sw3378.
0.39::sw3379.
takesCourse(grad3_d2,gradCourse6_d2) :- sw3379.
0.06::sw3380.
takesCourse(grad3_d2,gradCourse8_d2) :- sw3380.
0.71::sw3381.
teachingAssistantOf(grad3_d2,course2_d2) :- sw3381.
0.51::sw3382.
graduateStudent(grad4_d2) :- sw3382.
0.62::sw3383.
memberOf(grad4_d2,dept2) :- sw3383.
0.07::sw3384.
undergraduateDegreeFrom(grad4_d2,univ1) :- sw3384.
0.66::sw3385.
advisor(grad4_d2,asso7_d2) :- sw3385.
0.61::sw3386.
takesCourse(grad4_d2,gradCourse0_d2) :- sw3386.
0.13::sw3387.
takesCourse(grad4_d2,gradCourse3_d2) :- sw3387.
0.79::sw3388.
graduateStudent(grad5_d2) :- sw3388.
0.87::sw3389.
memberOf(grad5_d2,dept2) :- sw3389.
0.82::sw3390.
undergraduateDegreeFrom(grad5_d2,univ5) :- sw3390.
0.38::sw3391.
advisor(grad5_d2,lect0_d2) :- sw3391.
0.74::sw3392.
takesCourse(grad5_d2,gradCourse8_d2) :- sw3392.
0.61::sw3393.
takesCourse(grad5_d2,gradCourse0_d2) :- sw3393.
0.25::sw3394.
graduateStudent(grad6_d2) :- sw3394.
0.19::sw3395.
memberOf(grad6_d2,dept2) :- sw3395.
0.24::sw3396.
undergraduateDegreeFrom(grad6_d2,univ1) :- sw3396.
0.79::sw3397.
advisor(grad6_d2,assi3_d2) :- sw3397.
0.45::sw3398.
takesCourse(grad6_d2,gradCourse1_d2) :- sw3398.
0.85::sw3399.
takesCourse(grad6_d2,gradCourse7_d2) :- sw3399.
0.45::sw3400.
graduateStudent(grad7_d2) :- sw3400.
0.82::sw3401.
memberOf(grad7_d2,dept2) :- sw3401.
0.05::sw3402.
undergraduateDegreeFrom(grad7_d2,univ3) :- sw3402.
0.70::sw3403.
advisor(grad7_d2,assi6_d2) :- sw3403.
0.89::sw3404.
takesCourse(grad7_d2,gradCourse2_d2) :- sw3404.
0.74::sw3405.
takesCourse(grad7_d2,gradCourse5_d2) :- sw3405.
0.18::sw3406.
teachingAssistantOf(grad7_d2,course11_d2) :- sw3406.
0.97::sw3407.
graduateStudent(grad8_d2) :- sw3407.
0.05::sw3408.
memberOf(grad8_d2,dept2) :- sw3408.
0.35::sw3409.
undergraduateDegreeFrom(grad8_d2,univ5) :- sw3409.
0.89::sw3410.
advisor(grad8_d2,assi3_d2) :- sw3410.
0.25::sw3411.
takesCourse(grad8_d2,gradCourse1_d2) :- sw3411.
takesCourse(grad8_d2,gradCourse2_d2).
0.06::sw3412.
graduateStudent(grad9_d2) :- sw3412.
0.31::sw3413.
memberOf(grad9_d2,dept2) :- sw3413.
0.43::sw3414.
undergraduateDegreeFrom(grad9_d2,univ5) :- sw3414.
0.94::sw3415.
advisor(grad9_d2,asso3_d2) :- sw3415.
0.09::sw3416.
takesCourse(grad9_d2,gradCourse5_d2) :- sw3416.
0.57::sw3417.
takesCourse(grad9_d2,gradCourse3_d2) :- sw3417.
0.35::sw3418.
teachingAssistantOf(grad9_d2,course4_d2) :- sw3418.
0.45::sw3419.
graduateStudent(grad10_d2) :- sw3419.
0.51::sw3420.
memberOf(grad10_d2,dept2) :- sw3420.
0.33::sw3421.
undergraduateDegreeFrom(grad10_d2,univ7) :- sw3421.
0.21::sw3422.
advisor(grad10_d2,assi1_d2) :- sw3422.
0.54::sw3423.
takesCourse(grad10_d2,gradCourse9_d2) :- sw3423.
0.53::sw3424.
takesCourse(grad10_d2,gradCourse7_d2) :- sw3424.
0.19::sw3425.
graduateStudent(grad11_d2) :- sw3425.
0.81::sw3426.
memberOf(grad11_d2,dept2) :- sw3426.
0.19::sw3427.
undergraduateDegreeFrom(grad11_d2,univ8) :- sw3427.
0.48::sw3428.
advisor(grad11_d2,full6_d2) :- sw3428.
0.17::sw3429.
takesCourse(grad11_d2,gradCourse6_d2) :- sw3429.
0.13::sw3430.
takesCourse(grad11_d2,gradCourse1_d2) :- sw3430.
0.19::sw3431.
teachingAssistantOf(grad11_d2,course2_d2) :- sw3431.
0.29::sw3432.
graduateStudent(grad12_d2) :- sw3432.
0.48::sw3433.
memberOf(grad12_d2,dept2) :- sw3433.
0.73::sw3434.
undergraduateDegreeFrom(grad12_d2,univ9) :- sw3434.
0.70::sw3435.
advisor(grad12_d2,asso7_d2) :- sw3435.
0.76::sw3436.
takesCourse(grad12_d2,gradCourse4_d2) :- sw3436.
0.87::sw3437.
takesCourse(grad12_d2,gradCourse5_d2) :- sw3437.
0.91::sw3438.
graduateStudent(grad13_d2) :- sw3438.
0.11::sw3439.
memberOf(grad13_d2,dept2) :- sw3439.
0.83::sw3440.
undergraduateDegreeFrom(grad13_d2,univ3) :- sw3440.
0.32::sw3441.
advisor(grad13_d2,asso3_d2) :- sw3441.
0.13::sw3442.
takesCourse(grad13_d2,gradCourse2_d2) :- sw3442.
0.74::sw3443.
takesCourse(grad13_d2,gradCourse8_d2) :- sw3443.
0.25::sw3444.
teachingAssistantOf(grad13_d2,course4_d2) :- sw3444.
0.66::sw3445.
graduateStudent(grad14_d2) :- sw3445.
0.50::sw3446.
memberOf(grad14_d2,dept2) :- sw3446.
0.29::sw3447.
undergraduateDegreeFrom(grad14_d2,univ3) :- sw3447.
0.39::sw3448.
advisor(grad14_d2,assi3_d2) :- sw3448.
0.79::sw3449.
takesCourse(grad14_d2,gradCourse5_d2) :- sw3449.
0.13::sw3450.
takesCourse(grad14_d2,gradCourse3_d2) :- sw3450.
0.11::sw3451.
teachingAssistantOf(grad14_d2,course5_d2) :- sw3451.
0.22::sw3452.
graduateStudent(grad15_d2) :- sw3452.
0.15::sw3453.
memberOf(grad15_d2,dept2) :- sw3453.
0.29::sw3454.
undergraduateDegreeFrom(grad15_d2,univ6) :- sw3454.
0.90::sw3455.
advisor(grad15_d2,full0_d2) :- sw3455.
0.27::sw3456.
takesCourse(grad15_d2,gradCourse3_d2) :- sw3456.
0.29::sw3457.
takesCourse(grad15_d2,gradCourse4_d2) :- sw3457.
0.67::sw3458.
graduateStudent(grad16_d2) :- sw3458.
0.18::sw3459.
memberOf(grad16_d2,dept2) :- sw3459.
0.78::sw3460.
undergraduateDegreeFrom(grad16_d2,univ0) :- sw3460.
0.82::sw3461.
advisor(grad16_d2,assi5_d2) :- sw3461.
0.81::sw3462.
takesCourse(grad16_d2,gradCourse7_d2) :- sw3462.
0.17::sw3463.
takesCourse(grad16_d2,gradCourse5_d2) :- sw3463.
0.78::sw3464.
graduateStudent(grad17_d2) :- sw3464.
0.92::sw3465.
memberOf(grad17_d2,dept2) :- sw3465.
0.22::sw3466.
undergraduateDegreeFrom(grad17_d2,univ4) :- sw3466.
0.76::sw3467.
advisor(grad17_d2,assi3_d2) :- sw3467.
0.93::sw3468.
takesCourse(grad17_d2,gradCourse9_d2) :- sw3468.
0.84::sw3469.
takesCourse(grad17_d2,gradCourse7_d2) :- sw3469.
0.65::sw3470.
graduateStudent(grad18_d2) :- sw3470.
0.89::sw3471.
memberOf(grad18_d2,dept2) :- sw3471.
0.39::sw3472.
undergraduateDegreeFrom(grad18_d2,univ1) :- sw3472.
0.18::sw3473.
advisor(grad18_d2,assi3_d2) :- sw3473.
0.71::sw3474.
takesCourse(grad18_d2,gradCourse3_d2) :- sw3474.
0.52::sw3475.
takesCourse(grad18_d2,gradCourse4_d2) :- sw3475.
0.90::sw3476.
graduateStudent(grad19_d2) :- sw3476.
0.92::sw3477.
memberOf(grad19_d2,dept2) :- sw3477.
0.65::sw3478.
undergraduateDegreeFrom(grad19_d2,univ7) :- sw3478.
0.60::sw3479.
advisor(grad19_d2,asso6_d2) :- sw3479.
0.75::sw3480.
takesCourse(grad19_d2,gradCourse9_d2) :- sw3480.
0.72::sw3481.
takesCourse(grad19_d2,gradCourse7_d2) :- sw3481.
0.38::sw3482.
graduateStudent(grad20_d2) :- sw3482.
0.59::sw3483.
memberOf(grad20_d2,dept2) :- sw3483.
0.38::sw3484.
undergraduateDegreeFrom(grad20_d2,univ3) :- sw3484.
0.34::sw3485.
advisor(grad20_d2,assi5_d2) :- sw3485.
0.85::sw3486.
takesCourse(grad20_d2,gradCourse1_d2) :- sw3486.
0.40::sw3487.
takesCourse(grad20_d2,gradCourse7_d2) :- sw3487.
0.33::sw3488.
graduateStudent(grad21_d2) :- sw3488.
0.17::sw3489.
memberOf(grad21_d2,dept2) :- sw3489.
0.90::sw3490.
undergraduateDegreeFrom(grad21_d2,univ8) :- sw3490.
0.47::sw3491.
advisor(grad21_d2,lect3_d2) :- sw3491.
0.73::sw3492.
takesCourse(grad21_d2,gradCourse2_d2) :- sw3492.
0.16::sw3493.
takesCourse(grad21_d2,gradCourse5_d2) :- sw3493.
0.10::sw3494.
graduateStudent(grad22_d2) :- sw3494.
0.17::sw3495.
memberOf(grad22_d2,dept2) :- sw3495.
0.19::sw3496.
undergraduateDegreeFrom(grad22_d2,univ0) :- sw3496.
0.81::sw3497.
advisor(grad22_d2,assi3_d2) :- sw3497.
0.10::sw3498.
takesCourse(grad22_d2,gradCourse0_d2) :- sw3498.
0.40::sw3499.
takesCourse(grad22_d2,gradCourse4_d2) :- sw3499.
0.07::sw3500.
teachingAssistantOf(grad22_d2,course7_d2) :- sw3500.
0.91::sw3501.
graduateStudent(grad23_d2) :- sw3501.
0.82::sw3502.
memberOf(grad23_d2,dept2) :- sw3502.
0.70::sw3503.
undergraduateDegreeFrom(grad23_d2,univ4) :- sw3503.
0.97::sw3504.
advisor(grad23_d2,assi5_d2) :- sw3504.
0.91::sw3505.
takesCourse(grad23_d2,gradCourse4_d2) :- sw3505.
0.52::sw3506.
takesCourse(grad23_d2,gradCourse2_d2) :- sw3506.
0.43::sw3507.
graduateStudent(grad24_d2) :- sw3507.
0.59::sw3508.
memberOf(grad24_d2,dept2) :- sw3508.
0.66::sw3509.
undergraduateDegreeFrom(grad24_d2,univ2) :- sw3509.
0.61::sw3510.
advisor(grad24_d2,asso1_d2) :- sw3510.
0.12::sw3511.
takesCourse(grad24_d2,gradCourse5_d2) :- sw3511.
0.59::sw3512.
takesCourse(grad24_d2,gradCourse8_d2) :- sw3512.
0.47::sw3513.
graduateStudent(grad25_d2) :- sw3513.
0.37::sw3514.
memberOf(grad25_d2,dept2) :- sw3514.
0.07::sw3515.
undergraduateDegreeFrom(grad25_d2,univ9) :- sw3515.
0.38::sw3516.
advisor(grad25_d2,asso5_d2) :- sw3516.
0.32::sw3517.
takesCourse(grad25_d2,gradCourse4_d2) :- sw3517.
0.43::sw3518.
takesCourse(grad25_d2,gradCourse5_d2) :- sw3518.
0.68::sw3519.
graduateStudent(grad26_d2) :- sw3519.
0.28::sw3520.
memberOf(grad26_d2,dept2) :- sw3520.
0.21::sw3521.
undergraduateDegreeFrom(grad26_d2,univ1) :- sw3521.
0.15::sw3522.
advisor(grad26_d2,assi8_d2) :- sw3522.
0.75::sw3523.
takesCourse(grad26_d2,gradCourse3_d2) :- sw3523.
0.12::sw3524.
takesCourse(grad26_d2,gradCourse1_d2) :- sw3524.
0.77::sw3525.
teachingAssistantOf(grad26_d2,course3_d2) :- sw3525.
0.30::sw3526.
graduateStudent(grad27_d2) :- sw3526.
0.64::sw3527.
memberOf(grad27_d2,dept2) :- sw3527.
0.44::sw3528.
undergraduateDegreeFrom(grad27_d2,univ2) :- sw3528.
0.51::sw3529.
advisor(grad27_d2,lect4_d2) :- sw3529.
0.36::sw3530.
takesCourse(grad27_d2,gradCourse0_d2) :- sw3530.
0.66::sw3531.
takesCourse(grad27_d2,gradCourse7_d2) :- sw3531.
0.27::sw3532.
graduateStudent(grad28_d2) :- sw3532.
0.67::sw3533.
memberOf(grad28_d2,dept2) :- sw3533.
0.24::sw3534.
undergraduateDegreeFrom(grad28_d2,univ5) :- sw3534.
0.59::sw3535.
advisor(grad28_d2,assi0_d2) :- sw3535.
0.81::sw3536.
takesCourse(grad28_d2,gradCourse3_d2) :- sw3536.
0.57::sw3537.
takesCourse(grad28_d2,gradCourse4_d2) :- sw3537.
0.28::sw3538.
graduateStudent(grad29_d2) :- sw3538.
0.76::sw3539.
memberOf(grad29_d2,dept2) :- sw3539.
0.42::sw3540.
undergraduateDegreeFrom(grad29_d2,univ1) :- sw3540.
0.73::sw3541.
advisor(grad29_d2,full1_d2) :- sw3541.
0.83::sw3542.
takesCourse(grad29_d2,gradCourse1_d2) :- sw3542.
0.94::sw3543.
takesCourse(grad29_d2,gradCourse6_d2) :- sw3543.
0.85::sw3544.
teachingAssistantOf(grad29_d2,course16_d2) :- sw3544.
0.81::sw3545.
graduateStudent(grad30_d2) :- sw3545.
0.10::sw3546.
memberOf(grad30_d2,dept2) :- sw3546.
0.11::sw3547.
undergraduateDegreeFrom(grad30_d2,univ2) :- sw3547.
0.25::sw3548.
advisor(grad30_d2,asso2_d2) :- sw3548.
0.39::sw3549.
takesCourse(grad30_d2,gradCourse8_d2) :- sw3549.
0.92::sw3550.
takesCourse(grad30_d2,gradCourse7_d2) :- sw3550.
0.05::sw3551.
teachingAssistantOf(grad30_d2,course10_d2) :- sw3551.
0.89::sw3552.
graduateStudent(grad31_d2) :- sw3552.
0.09::sw3553.
memberOf(grad31_d2,dept2) :- sw3553.
0.22::sw3554.
undergraduateDegreeFrom(grad31_d2,univ9) :- sw3554.
0.96::sw3555.
advisor(grad31_d2,assi9_d2) :- sw3555.
0.75::sw3556.
takesCourse(grad31_d2,gradCourse0_d2) :- sw3556.
0.59::sw3557.
takesCourse(grad31_d2,gradCourse6_d2) :- sw3557.
0.99::sw3558.
teachingAssistantOf(grad31_d2,course12_d2) :- sw3558.
0.91::sw3559.
graduateStudent(grad32_d2) :- sw3559.
0.69::sw3560.
memberOf(grad32_d2,dept2) :- sw3560.
0.44::sw3561.
undergraduateDegreeFrom(grad32_d2,univ8) :- sw3561.
0.35::sw3562.
advisor(grad32_d2,asso9_d2) :- sw3562.
0.11::sw3563.
takesCourse(grad32_d2,gradCourse4_d2) :- sw3563.
0.43::sw3564.
takesCourse(grad32_d2,gradCourse9_d2) :- sw3564.
0.15::sw3565.
teachingAssistantOf(grad32_d2,course11_d2) :- sw3565.
0.96::sw3566.
graduateStudent(grad33_d2) :- sw3566.
0.50::sw3567.
memberOf(grad33_d2,dept2) :- sw3567.
0.26::sw3568.
undergraduateDegreeFrom(grad33_d2,univ0) :- sw3568.
0.39::sw3569.
advisor(grad33_d2,asso6_d2) :- sw3569.
0.47::sw3570.
takesCourse(grad33_d2,gradCourse1_d2) :- sw3570.
0.13::sw3571.
takesCourse(grad33_d2,gradCourse2_d2) :- sw3571.
0.15::sw3572.
teachingAssistantOf(grad33_d2,course6_d2) :- sw3572.
0.73::sw3573.
graduateStudent(grad34_d2) :- sw3573.
0.23::sw3574.
memberOf(grad34_d2,dept2) :- sw3574.
0.36::sw3575.
undergraduateDegreeFrom(grad34_d2,univ9) :- sw3575.
0.48::sw3576.
advisor(grad34_d2,full4_d2) :- sw3576.
0.23::sw3577.
takesCourse(grad34_d2,gradCourse6_d2) :- sw3577.
0.36::sw3578.
takesCourse(grad34_d2,gradCourse0_d2) :- sw3578.
0.69::sw3579.
graduateStudent(grad35_d2) :- sw3579.
0.98::sw3580.
memberOf(grad35_d2,dept2) :- sw3580.
0.75::sw3581.
undergraduateDegreeFrom(grad35_d2,univ8) :- sw3581.
0.73::sw3582.
advisor(grad35_d2,lect2_d2) :- sw3582.
0.73::sw3583.
takesCourse(grad35_d2,gradCourse3_d2) :- sw3583.
0.95::sw3584.
takesCourse(grad35_d2,gradCourse1_d2) :- sw3584.
0.08::sw3585.
graduateStudent(grad36_d2) :- sw3585.
0.85::sw3586.
memberOf(grad36_d2,dept2) :- sw3586.
0.47::sw3587.
undergraduateDegreeFrom(grad36_d2,univ8) :- sw3587.
0.48::sw3588.
advisor(grad36_d2,asso8_d2) :- sw3588.
0.71::sw3589.
takesCourse(grad36_d2,gradCourse8_d2) :- sw3589.
0.99::sw3590.
takesCourse(grad36_d2,gradCourse5_d2) :- sw3590.
0.95::sw3591.
teachingAssistantOf(grad36_d2,course18_d2) :- sw3591.
0.61::sw3592.
graduateStudent(grad37_d2) :- sw3592.
0.32::sw3593.
memberOf(grad37_d2,dept2) :- sw3593.
0.81::sw3594.
undergraduateDegreeFrom(grad37_d2,univ3) :- sw3594.
0.97::sw3595.
advisor(grad37_d2,lect0_d2) :- sw3595.
0.31::sw3596.
takesCourse(grad37_d2,gradCourse9_d2) :- sw3596.
0.48::sw3597.
takesCourse(grad37_d2,gradCourse7_d2) :- sw3597.
0.82::sw3598.
graduateStudent(grad38_d2) :- sw3598.
0.83::sw3599.
memberOf(grad38_d2,dept2) :- sw3599.
0.71::sw3600.
undergraduateDegreeFrom(grad38_d2,univ0) :- sw3600.
0.52::sw3601.
advisor(grad38_d2,lect3_d2) :- sw3601.
0.49::sw3602.
takesCourse(grad38_d2,gradCourse7_d2) :- sw3602.
0.81::sw3603.
takesCourse(grad38_d2,gradCourse5_d2) :- sw3603.
0.92::sw3604.
teachingAssistantOf(grad38_d2,course10_d2) :- sw3604.
0.38::sw3605.
graduateStudent(grad39_d2) :- sw3605.
0.39::sw3606.
memberOf(grad39_d2,dept2) :- sw3606.
0.75::sw3607.
undergraduateDegreeFrom(grad39_d2,univ1) :- sw3607.
0.19::sw3608.
advisor(grad39_d2,assi4_d2) :- sw3608.
0.92::sw3609.
takesCourse(grad39_d2,gradCourse0_d2) :- sw3609.
0.39::sw3610.
takesCourse(grad39_d2,gradCourse4_d2) :- sw3610.
0.70::sw3611.
publication(pub0_d2) :- sw3611.
0.14::sw3612.
publicationAuthor(pub0_d2,lect0_d2) :- sw3612.
0.08::sw3613.
publicationAuthor(pub0_d2,grad2_d2) :- sw3613.
0.97::sw3614.
publication(pub1_d2) :- sw3614.
0.30::sw3615.
publicationAuthor(pub1_d2,full6_d2) :- sw3615.
0.46::sw3616.
publicationAuthor(pub1_d2,ugrad140_d2) :- sw3616.
0.95::sw3617.
publication(pub2_d2) :- sw3617.
0.42::sw3618.
publicationAuthor(pub2_d2,asso8_d2) :- sw3618.
0.18::sw3619.
publicationAuthor(pub2_d2,ugrad135_d2) :- sw3619.
0.33::sw3620.
publication(pub3_d2) :- sw3620.
0.52::sw3621.
publicationAuthor(pub3_d2,full6_d2) :- sw3621.
0.33::sw3622.
publicationAuthor(pub3_d2,ugrad75_d2) :- sw3622.
0.67::sw3623.
publication(pub4_d2) :- sw3623.
publicationAuthor(pub4_d2,lect0_d2).
0.32::sw3624.
publicationAuthor(pub4_d2,ugrad131_d2) :- sw3624.
0.17::sw3625.
publication(pub5_d2) :- sw3625.
0.92::sw3626.
publicationAuthor(pub5_d2,asso9_d2) :- sw3626.
0.28::sw3627.
publicationAuthor(pub5_d2,ugrad91_d2) :- sw3627.
0.91::sw3628.
publication(pub6_d2) :- sw3628.
0.11::sw3629.
publicationAuthor(pub6_d2,assi9_d2) :- sw3629.
0.33::sw3630.
publicationAuthor(pub6_d2,ugrad57_d2) :- sw3630.
0.25::sw3631.
publication(pub7_d2) :- sw3631.
0.57::sw3632.
publicationAuthor(pub7_d2,assi3_d2) :- sw3632.
0.72::sw3633.
publicationAuthor(pub7_d2,ugrad61_d2) :- sw3633.
0.22::sw3634.
publication(pub8_d2) :- sw3634.
0.36::sw3635.
publicationAuthor(pub8_d2,lect2_d2) :- sw3635.
0.82::sw3636.
publicationAuthor(pub8_d2,ugrad95_d2) :- sw3636.
0.88::sw3637.
publication(pub9_d2) :- sw3637.
0.74::sw3638.
publicationAuthor(pub9_d2,full4_d2) :- sw3638.
0.71::sw3639.
publication(pub10_d2) :- sw3639.
0.97::sw3640.
publicationAuthor(pub10_d2,full1_d2) :- sw3640.
0.35::sw3641.
publication(pub11_d2) :- sw3641.
0.19::sw3642.
publicationAuthor(pub11_d2,assi9_d2) :- sw3642.
0.32::sw3643.
publicationAuthor(pub11_d2,ugrad149_d2) :- sw3643.
0.65::sw3644.
publication(pub12_d2) :- sw3644.
0.80::sw3645.
publicationAuthor(pub12_d2,assi7_d2) :- sw3645.
0.48::sw3646.
publication(pub13_d2) :- sw3646.
0.41::sw3647.
publicationAuthor(pub13_d2,assi6_d2) :- sw3647.
0.58::sw3648.
publicationAuthor(pub13_d2,ugrad116_d2) :- sw3648.
0.57::sw3649.
publication(pub14_d2) :- sw3649.
0.58::sw3650.
publicationAuthor(pub14_d2,full3_d2) :- sw3650.
0.54::sw3651.
publication(pub15_d2) :- sw3651.
0.46::sw3652.
publicationAuthor(pub15_d2,assi9_d2) :- sw3652.
0.63::sw3653.
publication(pub16_d2) :- sw3653.
0.32::sw3654.
publicationAuthor(pub16_d2,asso3_d2) :- sw3654.
0.39::sw3655.
publication(pub17_d2) :- sw3655.
0.80::sw3656.
publicationAuthor(pub17_d2,asso1_d2) :- sw3656.
0.84::sw3657.
publication(pub18_d2) :- sw3657.
0.36::sw3658.
publicationAuthor(pub18_d2,assi4_d2) :- sw3658.
0.25::sw3659.
publicationAuthor(pub18_d2,ugrad72_d2) :- sw3659.
0.54::sw3660.
publication(pub19_d2) :- sw3660.
0.38::sw3661.
publicationAuthor(pub19_d2,lect4_d2) :- sw3661.
0.33::sw3662.
publication(pub20_d2) :- sw3662.
0.16::sw3663.
publicationAuthor(pub20_d2,assi7_d2) :- sw3663.
0.49::sw3664.
publicationAuthor(pub20_d2,ugrad82_d2) :- sw3664.
0.42::sw3665.
publication(pub21_d2) :- sw3665.
0.37::sw3666.
publicationAuthor(pub21_d2,asso5_d2) :- sw3666.
0.72::sw3667.
publicationAuthor(pub21_d2,ugrad4_d2) :- sw3667.
0.31::sw3668.
publication(pub22_d2) :- sw3668.
0.37::sw3669.
publicationAuthor(pub22_d2,lect0_d2) :- sw3669.
0.72::sw3670.
publicationAuthor(pub22_d2,grad1_d2) :- sw3670.
0.16::sw3671.
publication(pub23_d2) :- sw3671.
0.40::sw3672.
publicationAuthor(pub23_d2,assi1_d2) :- sw3672.
0.11::sw3673.
publication(pub24_d2) :- sw3673.
0.48::sw3674.
publicationAuthor(pub24_d2,assi9_d2) :- sw3674.
0.56::sw3675.
publication(pub25_d2) :- sw3675.
0.91::sw3676.
publicationAuthor(pub25_d2,asso0_d2) :- sw3676.
0.36::sw3677.
publication(pub26_d2) :- sw3677.
0.29::sw3678.
publicationAuthor(pub26_d2,full7_d2) :- sw3678.
0.51::sw3679.
publicationAuthor(pub26_d2,ugrad28_d2) :- sw3679.
0.33::sw3680.
publication(pub27_d2) :- sw3680.
0.44::sw3681.
publicationAuthor(pub27_d2,asso3_d2) :- sw3681.
0.35::sw3682.
publication(pub28_d2) :- sw3682.
0.97::sw3683.
publicationAuthor(pub28_d2,asso4_d2) :- sw3683.
0.29::sw3684.
publication(pub29_d2) :- sw3684.
0.08::sw3685.
publicationAuthor(pub29_d2,lect1_d2) :- sw3685.
0.49::sw3686.
publication(pub30_d2) :- sw3686.
0.10::sw3687.
publicationAuthor(pub30_d2,lect3_d2) :- sw3687.
0.74::sw3688.
publicationAuthor(pub30_d2,ugrad53_d2) :- sw3688.
0.19::sw3689.
publication(pub31_d2) :- sw3689.
0.92::sw3690.
publicationAuthor(pub31_d2,assi2_d2) :- sw3690.
0.69::sw3691.
publication(pub32_d2) :- sw3691.
0.65::sw3692.
publicationAuthor(pub32_d2,assi4_d2) :- sw3692.
0.63::sw3693.
publication(pub33_d2) :- sw3693.
0.67::sw3694.
publicationAuthor(pub33_d2,assi4_d2) :- sw3694.
0.19::sw3695.
publication(pub34_d2) :- sw3695.
0.41::sw3696.
publicationAuthor(pub34_d2,asso4_d2) :- sw3696.
0.28::sw3697.
publicationAuthor(pub34_d2,ugrad92_d2) :- sw3697.
publication(pub35_d2).
0.52::sw3698.
publicationAuthor(pub35_d2,asso0_d2) :- sw3698.
0.59::sw3699.
publicationAuthor(pub35_d2,grad10_d2) :- sw3699.
0.26::sw3700.
publication(pub36_d2) :- sw3700.
0.08::sw3701.
publicationAuthor(pub36_d2,asso9_d2) :- sw3701.
0.63::sw3702.
publication(pub37_d2) :- sw3702.
0.14::sw3703.
publicationAuthor(pub37_d2,assi8_d2) :- sw3703.
0.09::sw3704.
publication(pub38_d2) :- sw3704.
0.39::sw3705.
publicationAuthor(pub38_d2,lect1_d2) :- sw3705.
0.46::sw3706.
publication(pub39_d2) :- sw3706.
0.50::sw3707.
publicationAuthor(pub39_d2,lect1_d2) :- sw3707.
0.93::sw3708.
publicationAuthor(pub39_d2,ugrad3_d2) :- sw3708.
0.63::sw3709.
publication(pub40_d2) :- sw3709.
0.91::sw3710.
publicationAuthor(pub40_d2,assi9_d2) :- sw3710.
0.47::sw3711.
publication(pub41_d2) :- sw3711.
0.06::sw3712.
publicationAuthor(pub41_d2,lect0_d2) :- sw3712.
0.21::sw3713.
publication(pub42_d2) :- sw3713.
0.91::sw3714.
publicationAuthor(pub42_d2,lect0_d2) :- sw3714.
0.71::sw3715.
publicationAuthor(pub42_d2,ugrad119_d2) :- sw3715.
0.61::sw3716.
publication(pub43_d2) :- sw3716.
0.06::sw3717.
publicationAuthor(pub43_d2,assi4_d2) :- sw3717.
0.19::sw3718.
publicationAuthor(pub43_d2,ugrad65_d2) :- sw3718.
0.81::sw3719.
publication(pub44_d2) :- sw3719.
0.85::sw3720.
publicationAuthor(pub44_d2,asso2_d2) :- sw3720.
0.40::sw3721.
publication(pub45_d2) :- sw3721.
0.69::sw3722.
publicationAuthor(pub45_d2,full7_d2) :- sw3722.
0.80::sw3723.
publicationAuthor(pub45_d2,ugrad12_d2) :- sw3723.
0.09::sw3724.
publication(pub46_d2) :- sw3724.
0.40::sw3725.
publicationAuthor(pub46_d2,assi0_d2) :- sw3725.
0.24::sw3726.
publicationAuthor(pub46_d2,ugrad135_d2) :- sw3726.
0.13::sw3727.
publication(pub47_d2) :- sw3727.
0.24::sw3728.
publicationAuthor(pub47_d2,lect1_d2) :- sw3728.
0.47::sw3729.
publication(pub48_d2) :- sw3729.
0.74::sw3730.
publicationAuthor(pub48_d2,assi2_d2) :- sw3730.
0.53::sw3731.
publicationAuthor(pub48_d2,ugrad0_d2) :- sw3731.
0.86::sw3732.
publication(pub49_d2) :- sw3732.
0.34::sw3733.
publicationAuthor(pub49_d2,asso5_d2) :- sw3733.
0.07::sw3734.
publicationAuthor(pub49_d2,grad10_d2) :- sw3734.
0.67::sw3735.
publication(pub50_d2) :- sw3735.
0.81::sw3736.
publicationAuthor(pub50_d2,lect1_d2) :- sw3736.
0.79::sw3737.
publicationAuthor(pub50_d2,ugrad144_d2) :- sw3737.
0.06::sw3738.
publication(pub51_d2) :- sw3738.
0.94::sw3739.
publicationAuthor(pub51_d2,assi6_d2) :- sw3739.
0.17::sw3740.
publicationAuthor(pub51_d2,ugrad82_d2) :- sw3740.
0.84::sw3741.
publication(pub52_d2) :- sw3741.
0.41::sw3742.
publicationAuthor(pub52_d2,assi7_d2) :- sw3742.
0.42::sw3743.
publication(pub53_d2) :- sw3743.
0.39::sw3744.
publicationAuthor(pub53_d2,asso4_d2) :- sw3744.
0.15::sw3745.
publication(pub54_d2) :- sw3745.
0.79::sw3746.
publicationAuthor(pub54_d2,lect3_d2) :- sw3746.
0.54::sw3747.
publication(pub55_d2) :- sw3747.
0.65::sw3748.
publicationAuthor(pub55_d2,asso7_d2) :- sw3748.
0.80::sw3749.
publication(pub56_d2) :- sw3749.
0.20::sw3750.
publicationAuthor(pub56_d2,lect4_d2) :- sw3750.
0.63::sw3751.
publication(pub57_d2) :- sw3751.
0.44::sw3752.
publicationAuthor(pub57_d2,asso5_d2) :- sw3752.
0.10::sw3753.
publicationAuthor(pub57_d2,ugrad17_d2) :- sw3753.
0.27::sw3754.
publication(pub58_d2) :- sw3754.
0.12::sw3755.
publicationAuthor(pub58_d2,asso8_d2) :- sw3755.
0.93::sw3756.
publication(pub59_d2) :- sw3756.
0.32::sw3757.
publicationAuthor(pub59_d2,lect1_d2) :- sw3757.
0.11::sw3758.
publicationAuthor(pub59_d2,ugrad34_d2) :- sw3758.
course(X) :- graduateCourse(X).
course(Y) :- teacherOf(X,Y).
course(Y) :- teachingAssistantOf(X,Y).
degreeFrom(X,Y) :- doctoralDegreeFrom(X,Y).
degreeFrom(X,Y) :- undergraduateDegreeFrom(X,Y).
faculty(X) :- lecturer(X).
faculty(X) :- teacherOf(X,Y).
hasAlumnus(Y,X) :- degreeFrom(X,Y).
member(Y,X) :- memberOf(X,Y).
memberOf(X,Y) :- worksFor(X,Y).
memberOf(Y,X) :- member(X,Y).
organization(X) :- department(X).
organization(X) :- member(X,Y).
organization(X) :- subOrganizationOf(X,Y).
organization(X) :- university(X).
organization(Y) :- subOrganizationOf(X,Y).
person(X) :- advisor(X,Y).
person(X) :- degreeFrom(X,Y).
person(X) :- doctoralDegreeFrom(X,Y).
person(X) :- emailAddress(X,Y).
person(X) :- graduateStudent(X).
person(X) :- undergraduateDegreeFrom(X,Y).
person(Y) :- hasAlumnus(X,Y).
person(Y) :- member(X,Y).
person(Y) :- publicationAuthor(X,Y).
professor(X) :- assistantProfessor(X).
professor(X) :- associateProfessor(X).
professor(X) :- fullProfessor(X).
professor(Y) :- advisor(X,Y).
publication(X) :- publicationAuthor(X,Y).
student(X) :- undergraduateStudent(X).
subOrganizationOf(X,Z) :- subOrganizationOf(X,Y), subOrganizationOf(Y,Z).
teachingAssistant(X) :- teachingAssistantOf(X,Y).
university(X) :- hasAlumnus(X,Y).
university(Y) :- degreeFrom(X,Y).
university(Y) :- doctoralDegreeFrom(X,Y).
university(Y) :- undergraduateDegreeFrom(X,Y).
work(X) :- course(X).
worksFor(X,Y) :- headOf(X,Y).
degreeFrom(Y,X) :- hasAlumnus(X,Y).
employee(X) :- faculty(X).
faculty(X) :- professor(X).
-researchInterest(full0_d0,res18).
