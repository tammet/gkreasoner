[
 {
  "@logic": [
   "a"
  ],
  "@confidence": 0.5
 },
 {
  "@logic": [
   [
    "a"
   ],
   "|",
   [
    "$block",
    1,
    [
     "b"
    ]
   ]
  ],
  "@confidence": 0.6
 },
 {
  "@logic": [
   [
    "b"
   ],
   "|",
   [
    "$block",
    2,
    [
     "a"
    ]
   ]
  ],
  "@confidence": 0.8
 },
 {
  "@question": [
   "a"
  ]
 }
]
