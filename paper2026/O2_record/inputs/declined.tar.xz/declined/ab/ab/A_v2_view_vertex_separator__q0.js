[
 {
  "@logic": [
   "c"
  ],
  "@confidence": 0.5
 },
 {
  "@logic": [
   [
    "c"
   ],
   "=>",
   [
    "v"
   ]
  ],
  "@confidence": 0.5
 },
 {
  "@logic": [
   [
    "c"
   ],
   "=>",
   [
    [
     "v"
    ],
    "|",
    [
     "$block",
     1,
     [
      "nv"
     ]
    ]
   ]
  ],
  "@confidence": 0.6
 },
 {
  "@logic": [
   [
    "v"
   ],
   "=>",
   [
    "l"
   ]
  ],
  "@confidence": 0.6
 },
 {
  "@logic": [
   [
    "r"
   ],
   "|",
   [
    "$block",
    2,
    [
     "w"
    ]
   ]
  ],
  "@confidence": 0.7
 },
 {
  "@logic": [
   [
    "w"
   ],
   "|",
   [
    "$block",
    2,
    [
     "v"
    ]
   ]
  ]
 },
 {
  "@logic": [
   [
    [
     "l"
    ],
    "&",
    [
     "r"
    ]
   ],
   "=>",
   [
    "h"
   ]
  ]
 },
 {
  "@question": [
   "h"
  ]
 }
]
