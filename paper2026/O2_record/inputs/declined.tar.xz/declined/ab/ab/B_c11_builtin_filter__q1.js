[
 {
  "@logic": [
   "age",
   "tom",
   30
  ]
 },
 {
  "@logic": [
   "age",
   "ann",
   12
  ]
 },
 {
  "@logic": [
   [
    [
     "age",
     "?:X",
     "?:N"
    ],
    "&",
    [
     "$greatereq",
     "?:N",
     18
    ]
   ],
   "=>",
   [
    "adult",
    "?:X"
   ]
  ],
  "@confidence": 0.9
 },
 {
  "@question": [
   "adult",
   "ann"
  ]
 }
]
