[
 {
  "@logic": [
   "c"
  ],
  "@confidence": 0.6
 },
 {
  "@logic": [
   [
    "c"
   ],
   "=>",
   [
    "p"
   ]
  ],
  "@confidence": 0.5
 },
 {
  "@logic": [
   "q"
  ],
  "@confidence": 0.4
 },
 {
  "@logic": [
   [
    "q"
   ],
   "=>",
   [
    "p"
   ]
  ],
  "@confidence": 0.5
 },
 {
  "@logic": [
   [
    "p"
   ],
   "=>",
   [
    "q"
   ]
  ],
  "@confidence": 0.5
 },
 {
  "@logic": [
   [
    "v"
   ],
   "|",
   [
    "$block",
    3,
    [
     "$not",
     [
      "v"
     ]
    ]
   ]
  ],
  "@confidence": 0.5
 },
 {
  "@logic": [
   [
    "v"
   ],
   "|",
   [
    "$block",
    1,
    [
     "$not",
     [
      "v"
     ]
    ]
   ]
  ],
  "@confidence": 0.6
 },
 {
  "@logic": [
   [
    [
     "p"
    ],
    "&",
    [
     "v"
    ]
   ],
   "=>",
   [
    "l"
   ]
  ],
  "@confidence": 0.7
 },
 {
  "@logic": [
   [
    "q"
   ],
   "=>",
   [
    [
     "r"
    ],
    "|",
    [
     "$block",
     2,
     [
      "w"
     ]
    ]
   ]
  ],
  "@confidence": 0.8
 },
 {
  "@logic": [
   [
    "w"
   ],
   "|",
   [
    "$block",
    2,
    [
     "v"
    ]
   ]
  ]
 },
 {
  "@logic": [
   [
    [
     "l"
    ],
    "&",
    [
     "r"
    ]
   ],
   "=>",
   [
    "h"
   ]
  ]
 },
 {
  "@question": [
   "h"
  ]
 }
]
