[
  [
    [
      "probe"
    ],
    [
      "p",
      "a"
    ],
    [
      "$lesseq",
      "?:X",
      7
    ]
  ],
  [
    [
      "-p",
      "a"
    ]
  ],
  {
    "@role": "question",
    "@logic": [
      "probe"
    ]
  }
]
