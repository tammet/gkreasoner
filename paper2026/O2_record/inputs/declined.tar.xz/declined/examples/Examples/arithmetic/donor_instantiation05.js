[
  [
    [
      "probe"
    ],
    [
      "p",
      "a"
    ],
    [
      "$less",
      "?:X",
      4
    ]
  ],
  [
    [
      "-p",
      "a"
    ]
  ],
  {
    "@role": "question",
    "@logic": [
      "probe"
    ]
  }
]
