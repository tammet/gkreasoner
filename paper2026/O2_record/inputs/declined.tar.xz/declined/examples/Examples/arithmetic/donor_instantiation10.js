[
  [
    [
      "probe"
    ],
    [
      "-$less",
      0,
      "?:X"
    ],
    [
      "-$less",
      "?:X",
      10
    ]
  ],
  {
    "@role": "question",
    "@logic": [
      "probe"
    ]
  }
]
