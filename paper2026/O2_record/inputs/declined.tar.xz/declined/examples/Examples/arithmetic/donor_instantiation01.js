[
  [
    [
      "probe"
    ],
    [
      "-=",
      [
        "$sum",
        "?:X",
        0
      ],
      "?:X"
    ]
  ],
  {
    "@role": "question",
    "@logic": [
      "probe"
    ]
  }
]
