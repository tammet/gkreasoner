[
  [
    [
      "probe"
    ],
    [
      "p",
      [
        "$sum",
        "?:X",
        1
      ]
    ]
  ],
  [
    [
      "-p",
      3
    ]
  ],
  {
    "@role": "question",
    "@logic": [
      "probe"
    ]
  }
]
