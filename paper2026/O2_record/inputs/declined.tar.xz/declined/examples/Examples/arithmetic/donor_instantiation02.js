[
  [
    [
      "probe"
    ],
    [
      "-=",
      [
        "$sum",
        "?:X",
        "?:X"
      ],
      2
    ]
  ],
  {
    "@role": "question",
    "@logic": [
      "probe"
    ]
  }
]
