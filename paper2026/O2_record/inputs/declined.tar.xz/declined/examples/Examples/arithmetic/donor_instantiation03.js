[
  [
    [
      "probe"
    ],
    [
      "-=",
      [
        "$product",
        2,
        "?:X"
      ],
      [
        "$sum",
        "?:X",
        2
      ]
    ]
  ],
  {
    "@role": "question",
    "@logic": [
      "probe"
    ]
  }
]
