[
  {"@role": "question", "@logic": ["flies", "?:X"]}
]
