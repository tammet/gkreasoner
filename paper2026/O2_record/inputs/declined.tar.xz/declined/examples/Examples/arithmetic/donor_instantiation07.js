[
  [
    [
      "probe"
    ],
    [
      "p",
      "a"
    ],
    [
      "$greater",
      "?:X",
      7
    ]
  ],
  [
    [
      "-p",
      "a"
    ]
  ],
  {
    "@role": "question",
    "@logic": [
      "probe"
    ]
  }
]
