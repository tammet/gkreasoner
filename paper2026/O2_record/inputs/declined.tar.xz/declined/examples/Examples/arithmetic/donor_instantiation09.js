[
  [
    [
      "probe"
    ],
    [
      "p",
      "a"
    ],
    [
      "$greatereq",
      "?:X",
      7
    ]
  ],
  [
    [
      "-p",
      "a"
    ]
  ],
  {
    "@role": "question",
    "@logic": [
      "probe"
    ]
  }
]
