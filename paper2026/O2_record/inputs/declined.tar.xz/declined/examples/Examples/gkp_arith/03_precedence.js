[
[["!=",["$sum",1,["$product",2,3]],"?:Z"],["val","?:Z"]],
{"@question": ["val","?:Z"]}
]
