[
[["-basket","?:X"],["!=",["$sum","?:X",2],10],["haveapples","?:X"]],
["basket",8],
{"@question": ["haveapples","?:X"]}
]
