[
[["-john","?:J"],["!=",["$product",2,"?:J"],"?:P"],["-$greater","?:J",0],["price","?:P"]],
["john",5],
{"@question": ["price","?:P"]}
]
