[
[["-src","?:X"],["!=",["$uminus","?:X"],"?:Z"],["neg","?:Z"]],
["src",7],
{"@question": ["neg","?:Z"]}
]
