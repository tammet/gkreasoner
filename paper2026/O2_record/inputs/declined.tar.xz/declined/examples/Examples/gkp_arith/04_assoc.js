[
[["!=",["$difference",["$difference",10,3],2],"?:Z"],["val","?:Z"]],
{"@question": ["val","?:Z"]}
]
