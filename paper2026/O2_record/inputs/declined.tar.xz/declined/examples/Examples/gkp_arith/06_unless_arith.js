[
{"@confidence": 0.9,
 "@logic": [["-price","?:X","?:P"],["-$less","?:P",100],["cheap","?:X"],
            ["$block",2,["$not",["cheap","?:X"]]]]},
["price","book",20],
{"@question": ["cheap","?:X"]}
]
