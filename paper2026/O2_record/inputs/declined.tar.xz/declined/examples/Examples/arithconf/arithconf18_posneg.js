// positive arithinst proof 0.8 against a plain negative fact 0.3:
// exercises the scrutiny/netting report over an arithinst history.
[
{"@name":"pos", "@confidence": 0.8,
 "@logic": [["probe"], ["-=",["$sum","?:X",2],10]]},
{"@name":"neg", "@confidence": 0.3, "@logic": ["-probe"]},
{"@question": ["probe"]}
]
