// default with confidence 0.8 and an unrefutable blocker, arithinst proof.
// Expected: answer found with confidence 0.8 and the blocker listed.
[
{"@name":"default", "@confidence": 0.8,
 "@logic": [["probe"], ["-=",["$sum","?:X",2],10],
            ["$block", 2, ["$not", ["probe"]]]]},
{"@question": ["probe"]}
]
