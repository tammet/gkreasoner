// very low confidence through an arithinst step: must not crash,
// must not report nonsense (native behaviour is the reference).
[
{"@name":"ax1", "@confidence": 0.01,
 "@logic": [["probe"], ["-=",["$sum","?:X",0],"?:X"]]},
{"@question": ["probe"]}
]
