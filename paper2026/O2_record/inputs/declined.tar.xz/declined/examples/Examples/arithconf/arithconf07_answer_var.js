// answer selected by arithmetic (the cars donor pattern): the answer term
// is a constant, the arithmetic decides whether it qualifies.
// Expected: answer johnhad(eight), confidence 0.75, arithinst step.
// (Direct arithmetic binding of an answer variable, as in
// arithmetic_instantiation11_apples_answer, is a known open gap: gk and
// gkc agree on "no answers found" there.)
[
{"@name":"apples_rule", "@confidence": 0.75,
 "@logic": [["johnhad", "eight"], ["-=",["$sum","?:X",2],10], ["-$less","?:X",10]]},
{"@role": "question", "@logic": ["johnhad", "?:X"]}
]
