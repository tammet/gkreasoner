// the arithinst step cuts a fact carrying confidence 0.7:
// clause needs q to be cut away during instantiation.
// Expected: answer found, confidence 0.7, arithinst step with q-cut in deps.
[
{"@name":"ax1",
 "@logic": [["probe"], ["-=",["$sum","?:X",2],10], ["-$less","?:X",10], ["-q"]]},
{"@name":"qf", "@confidence": 0.7, "@logic": ["q"]},
{"@question": ["probe"]}
]
