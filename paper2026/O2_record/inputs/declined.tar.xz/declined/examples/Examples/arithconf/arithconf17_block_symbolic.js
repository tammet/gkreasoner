// symbolic (taxonomy-form) blocker strengths on arithmetic defaults:
// without -defaults the words are incomparable and both blockers stay.
[
{"@name":"d1",
 "@logic": [["nice"], ["-=",["$sum","?:X",2],10],
            ["$block", ["$","bird"], ["$not", ["nice"]]]]},
{"@name":"d2",
 "@logic": [["-nice"], ["-=",["$sum","?:Y",2],10], ["-$less",5,"?:Y"],
            ["$block", ["$","object"], ["nice"]]]},
{"@question": ["nice"]}
]
