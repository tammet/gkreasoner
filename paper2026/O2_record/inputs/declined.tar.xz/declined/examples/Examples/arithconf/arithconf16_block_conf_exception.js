// default 0.9 with blocker; exception 0.8 refutes the blocker via arithmetic.
// Native behaviour is the reference; the interesting property is that the
// confidences and the blocker bookkeeping pass through arithinst histories.
[
{"@name":"default", "@confidence": 0.9,
 "@logic": [["probe"], ["-=",["$sum","?:X",2],10],
            ["$block", 2, ["$not", ["probe"]]]]},
{"@name":"exception", "@confidence": 0.8,
 "@logic": [["-probe"], ["-=",["$sum","?:Y",1],3], ["$block", 3, ["probe"]]]},
{"@question": ["probe"]}
]
