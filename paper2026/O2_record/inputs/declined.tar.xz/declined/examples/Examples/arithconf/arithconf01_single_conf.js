// single axiom with confidence, proof needs an arithinst step:
// X+0=X instantiated. Expected: answer found, confidence 0.8,
// proof contains an "arithinst" step.
[
{"@name":"ax1", "@confidence": 0.8,
 "@logic": [["probe"], ["-=",["$sum","?:X",0],"?:X"]]},
{"@question": ["probe"]}
]
