// one clause with TWO arithmetic constraints and two cut facts:
// f1 (0.9) and f2 (0.8) both get cut in the instantiation step.
// Expected: answer found, confidence 0.72, arithinst with two variables.
[
{"@name":"f1", "@confidence": 0.9, "@logic": ["f1"]},
{"@name":"f2", "@confidence": 0.8, "@logic": ["f2"]},
{"@name":"use",
 "@logic": [["probe"], ["-f1"], ["-f2"],
            ["-=",["$sum","?:X",3],7], ["-=",["$sum","?:Y",1],5]]},
{"@question": ["probe"]}
]
