// refuting the blocker requires an arithinst step inside the NESTED run:
// the exception clause only fires after instantiating X+1=3.
// Expected: no crash; nested blocker check performs arithmetic.
[
{"@name":"default",
 "@logic": [["win"], ["$block", 2, ["$not", ["win"]]]]},
{"@name":"exception",
 "@logic": [["-win"], ["-=",["$sum","?:X",1],3], ["$block", 3, ["win"]]]},
{"@question": ["win"]}
]
