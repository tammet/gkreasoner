// two independent arithinst proofs of probe, confidences 0.6 and 0.5.
// Expected: cumulated confidence 0.8 (noisy-or), both proofs arithmetic.
[
{"@name":"a1", "@confidence": 0.6,
 "@logic": [["probe"], ["-=",["$sum","?:X",2],10]]},
{"@name":"a2", "@confidence": 0.5,
 "@logic": [["probe"], ["-=",["$sum","?:Y",5],8]]},
{"@question": ["probe"]}
]
