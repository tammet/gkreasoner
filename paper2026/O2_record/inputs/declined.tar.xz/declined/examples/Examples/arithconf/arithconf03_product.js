// product of confidences through one arithinst step: the instantiation
// cuts both the goal and the fact f (0.8); the clause itself carries 0.5.
// Expected: answer found, confidence 0.4, arithinst step.
[
{"@name":"f", "@confidence": 0.8, "@logic": ["f"]},
{"@name":"use", "@confidence": 0.5,
 "@logic": [["probe"], ["-f"], ["-=",["$sum","?:X",2],10], ["-$less","?:X",10]]},
{"@question": ["probe"]}
]
