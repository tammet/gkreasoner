// two competing defaults with priorities 2 and 3, both with inline
// arithmetic antecedents. The stronger (3) side should prevail.
[
{"@name":"weak",
 "@logic": [["good"], ["-=",["$sum","?:X",2],10], ["-$less","?:X",100],
            ["$block", 2, ["$not", ["good"]]]]},
{"@name":"strong",
 "@logic": [["-good"], ["-=",["$sum","?:Y",2],10], ["-$less",5,"?:Y"],
            ["$block", 3, ["good"]]]},
{"@question": ["good"]}
]
