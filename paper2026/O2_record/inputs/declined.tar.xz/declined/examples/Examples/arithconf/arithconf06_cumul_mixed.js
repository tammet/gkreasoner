// two independent proofs: an ordinary one (rule + fact 0.6) and an
// arithmetic one (0.6). Expected: cumulated 0.84, arithinst in one proof.
[
{"@name":"r", "@confidence": 0.6, "@logic": ["r"]},
{"@name":"plain", "@logic": [["probe"], ["-r"]]},
{"@name":"arith", "@confidence": 0.6,
 "@logic": [["probe"], ["-=",["$sum","?:Y",5],8]]},
{"@question": ["probe"]}
]
