// the same default, but an exception with a stronger blocker derives the
// blocked side, also through arithmetic (8 > 5).
// Native behaviour is the reference; both proofs contain arithinst steps.
[
{"@name":"default",
 "@logic": [["affordable"], ["-=",["$sum","?:X",2],10], ["-$less","?:X",100],
            ["$block", 2, ["$not", ["affordable"]]]]},
{"@name":"exception",
 "@logic": [["-affordable"], ["-=",["$sum","?:Y",2],10], ["-$less",5,"?:Y"],
            ["$block", 3, ["affordable"]]]},
{"@question": ["affordable"]}
]
