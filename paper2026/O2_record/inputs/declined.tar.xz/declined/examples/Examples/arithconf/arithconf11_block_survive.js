// a default with inline arithmetic and an unrefutable blocker:
// the answer must survive, carrying the blocker.
// Expected: answer found, blocker listed, arithinst step.
[
{"@name":"default",
 "@logic": [["affordable"], ["-=",["$sum","?:X",2],10], ["-$less","?:X",100],
            ["$block", 2, ["$not", ["affordable"]]]]},
{"@question": ["affordable"]}
]
