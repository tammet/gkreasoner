// large numbers near the arithmetic safety limits plus a confidence:
// must not crash and must not produce a confidence outside [0,1].
[
{"@name":"big", "@confidence": 0.9,
 "@logic": [["probe"], ["-=",["$sum","?:X",1000000],1000008]]},
{"@question": ["probe"]}
]
