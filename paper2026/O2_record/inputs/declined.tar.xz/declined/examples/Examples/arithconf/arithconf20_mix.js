// the everything test: a defeasible arithmetic default with confidence,
// an arithmetic exception with a stronger blocker, and an independent
// low-confidence direct hunch.
[
{"@name":"default", "@confidence": 0.9,
 "@logic": [["buy"], ["-=",["$sum","?:X",2],10], ["-$less","?:X",100],
            ["$block", 2, ["$not", ["buy"]]]]},
{"@name":"exception", "@confidence": 0.7,
 "@logic": [["-buy"], ["-=",["$sum","?:Y",2],10], ["-$less",5,"?:Y"],
            ["$block", 3, ["buy"]]]},
{"@name":"hunch", "@confidence": 0.2, "@logic": ["buy"]},
{"@question": ["buy"]}
]
