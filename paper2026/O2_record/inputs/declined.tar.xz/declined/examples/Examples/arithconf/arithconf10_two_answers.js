// two candidate answers, each qualified by its own arithmetic constraint,
// with different confidences. Expected: value(v8) at 0.9 and value(v3)
// at 0.4, arithinst steps in both proofs.
[
{"@name":"a1", "@confidence": 0.9,
 "@logic": [["value","v8"], ["-=",["$sum","?:X",2],10]]},
{"@name":"a2", "@confidence": 0.4,
 "@logic": [["value","v3"], ["-=",["$sum","?:Y",5],8]]},
{"@role":"question", "@logic": ["value","?:X"]}
]
