// constraint pair sum+less like the apples donor, with confidence 0.9.
// Expected: answer found, confidence 0.9, arithinst with V0=8.
[
{"@name":"ax1", "@confidence": 0.9,
 "@logic": [["probe"], ["-=",["$sum","?:X",2],10], ["-$less","?:X",10]]},
{"@question": ["probe"]}
]
