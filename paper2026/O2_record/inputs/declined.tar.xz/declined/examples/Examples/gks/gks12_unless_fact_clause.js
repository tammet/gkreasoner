[
{"@confidence": 0.8, "@logic": ["nice_day",["$block",0,"raining"]]},
{"@question": ["nice_day"]}
]
