[
[["-bird","?:X"],["flies","?:X"],["$block",["$","bird"],["$not",["flies","?:X"]]]],
[["-penguin","?:X"],["-flies","?:X"],["$block",["$","penguin",3],["flies","?:X"]]],
["bird","tweety"],
{"@question": ["flies","?:X"]}
]
