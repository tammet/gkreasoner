[
["apples","john",4],
["apples","mary",7],
[["-apples","?:P","?:N"],["-$less","?:N",5],["few","?:P"]],
[["-apples","?:P","?:N"],["!=","?:N",7],["lucky","?:P"]],
{"@question": ["few","?:P"]}
]
