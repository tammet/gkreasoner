
[

// the task is to classify three objects: h1 (likely human), b1 (likely bird), a1 (likely airplane)
//
// the question at the end asks to find objects which are likely to be organisms, along with the
// confidence that they are organisms

// here we give observations about parts our three objects have

{"@logic": ["has_part","h1","leg"]},

{"@logic": ["has_part","b1","leg"]},
{"@logic": ["has_part","b1","wing"]},
{"@logic": ["has_part","b1","feathers"]},

{"@logic": ["has_part","a1","engine"]},
{"@logic": ["has_part","a1","wing"]},

// here we give default rules with confidences about classifying as humans, birds, airplanes
// the $block literal says that the application of this rule is not allowed, if the second argument of
// the $block predicate can be proved

// as an example, the first rule says that if something has a leg, then with the 30% confidence it is a human, unless we can prove
// that it is not a human

{"@logic": [["has_part","?:X","leg"],"=>",[["isa","?:X","human"],"|",["$block", ["$","human"], ["$not", ["isa","?:X","human"]]]]], "@confidence":30},
{"@logic": [["has_part","?:X","leg"],"=>",[["isa","?:X","bird"],"|",["$block", ["$","bird"], ["$not", ["isa","?:X","bird"]]]]], "@confidence":20},

{"@logic": [["has_part","?:X","wing"],"=>",[["isa","?:X","bird"],"|",["$block", ["$","bird"], ["$not", ["isa","?:X","bird"]]]]], "@confidence":60},
{"@logic": [["has_part","?:X","feathers"],"=>",[["isa","?:X","bird"],"|",["$block", ["$","bird"], ["$not", ["isa","?:X","bird"]]]]], "@confidence":80},

{"@logic": [["has_part","?:X","wing"],"=>",[["isa","?:X","airplane"],"|",["$block", ["$","airplane"], ["$not", ["isa","?:X","airplane"]]]]], "@confidence":40},

// a strict rule saying that if something has an engine as a part, then this thing is not an organism

{"@logic": [["has_part","?:X","engine"],"=>",["-isa","?:X","organism"]]},

// a taxonomy: humans and birds are organisms, airplanes are not organisms

{"@logic": [["isa","?:X","human"],"=>",["isa","?:X","organism"]]},
{"@logic": [["isa","?:X","bird"],"=>",["isa","?:X","organism"]]},
{"@logic": [["isa","?:X","airplane"],"=>",["-isa","?:X","organism"]]},

/*
{"@logic": [["isa","?:X","airplane"],"=>",["has_part","?:X","engine"]]},
{"@logic": [["isa","?:X","airplane"],"=>",["has_part","?:X","wing"]]},
{"@logic": [["isa","?:X","airplane"],"=>",["-has_part","?:X","feathers"]]},
{"@logic": [["isa","?:X","bird"],"=>",["has_part","?:X","wing"]]},
{"@logic": [["isa","?:X","bird"],"=>",["has_part","?:X","leg"]]},
{"@logic": [["isa","?:X","human"],"=>",["has_part","?:X","leg"]]},
*/

// a question to find objects which are organisms, along with the confidence:

{"@question": ["isa","?:X","organism"]}

]

/*

gk output:

{"result": "answer found",

"answers": [
{
"answer": [["$ans","b1"]],
"blockers": [["$block",["$","human"],["$not",["isa","b1","human"]]]],
"confidence": 0.3,
"positive proof":
[
[1, ["in", "frm_7", "axiom", 0.3], [["$block",["$","human"],["$not",["isa","?:X","human"]]], ["-has_part","?:X","leg"], ["isa","?:X","human"]]],
[2, ["in", "frm_2", "axiom", 1], [["has_part","b1","leg"]]],
[3, ["mp", [1,1], 2, "fromaxiom", 0.3], [["$block",["$","human"],["$not",["isa","b1","human"]]], ["isa","b1","human"]]],
[4, ["in", "frm_13", "axiom", 1], [["-isa","?:X","human"], ["isa","?:X","organism"]]],
[5, ["mp", [3,1], 4, "fromaxiom", 0.3], [["$block",["$","human"],["$not",["isa","b1","human"]]], ["isa","b1","organism"]]],
[6, ["in", "frm_16", "goal", 1], [["-isa","?:X","organism"], ["$ans","?:X"]]],
[7, ["mp", [5,1], 6, "fromgoal", 0.3], [["$block",["$","human"],["$not",["isa","b1","human"]]], ["$ans","b1"]]]
]},
{
"answer": [["$ans","h1"]],
"blockers": [["$block",["$","human"],["$not",["isa","h1","human"]]]],
"confidence": 0.3,
"positive proof":
[
[1, ["in", "frm_7", "axiom", 0.3], [["$block",["$","human"],["$not",["isa","?:X","human"]]], ["-has_part","?:X","leg"], ["isa","?:X","human"]]],
[2, ["in", "frm_1", "axiom", 1], [["has_part","h1","leg"]]],
[3, ["mp", [1,1], 2, "fromaxiom", 0.3], [["$block",["$","human"],["$not",["isa","h1","human"]]], ["isa","h1","human"]]],
[4, ["in", "frm_13", "axiom", 1], [["-isa","?:X","human"], ["isa","?:X","organism"]]],
[5, ["mp", [3,1], 4, "fromaxiom", 0.3], [["$block",["$","human"],["$not",["isa","h1","human"]]], ["isa","h1","organism"]]],
[6, ["in", "frm_16", "goal", 1], [["-isa","?:X","organism"], ["$ans","?:X"]]],
[7, ["mp", [5,1], 6, "fromgoal", 0.3], [["$block",["$","human"],["$not",["isa","h1","human"]]], ["$ans","h1"]]]
]},
{
"answer": [["$ans","h1"]],
"blockers": [["$block",["$","bird"],["$not",["isa","h1","bird"]]]],
"confidence": 0.2,
"positive proof":
[
[1, ["in", "frm_8", "axiom", 0.2], [["$block",["$","bird"],["$not",["isa","?:X","bird"]]], ["-has_part","?:X","leg"], ["isa","?:X","bird"]]],
[2, ["in", "frm_1", "axiom", 1], [["has_part","h1","leg"]]],
[3, ["mp", [1,1], 2, "fromaxiom", 0.2], [["$block",["$","bird"],["$not",["isa","h1","bird"]]], ["isa","h1","bird"]]],
[4, ["in", "frm_14", "axiom", 1], [["-isa","?:X","bird"], ["isa","?:X","organism"]]],
[5, ["mp", [3,1], 4, "fromaxiom", 0.2], [["$block",["$","bird"],["$not",["isa","h1","bird"]]], ["isa","h1","organism"]]],
[6, ["in", "frm_16", "goal", 1], [["-isa","?:X","organism"], ["$ans","?:X"]]],
[7, ["mp", [5,1], 6, "fromgoal", 0.2], [["$block",["$","bird"],["$not",["isa","h1","bird"]]], ["$ans","h1"]]]
]},
{
"answer": [["$ans","b1"]],
"blockers": [["$block",["$","bird"],["$not",["isa","b1","bird"]]]],
"confidence": 0.936,
"positive proof":
[
[1, ["in", "frm_8", "axiom", 0.2], [["$block",["$","bird"],["$not",["isa","?:X","bird"]]], ["-has_part","?:X","leg"], ["isa","?:X","bird"]]],
[2, ["in", "frm_2", "axiom", 1], [["has_part","b1","leg"]]],
[3, ["mp", [1,1], 2, "fromaxiom", 0.2], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["isa","b1","bird"]]],
[4, ["in", "frm_14", "axiom", 1], [["-isa","?:X","bird"], ["isa","?:X","organism"]]],
[5, ["mp", [3,1], 4, "fromaxiom", 0.2], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["isa","b1","organism"]]],
[6, ["in", "frm_16", "goal", 1], [["-isa","?:X","organism"], ["$ans","?:X"]]],
[7, ["mp", [5,1], 6, "fromgoal", 0.2], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["$ans","b1"]]],
[8, ["in", "frm_10", "axiom", 0.8], [["$block",["$","bird"],["$not",["isa","?:X","bird"]]], ["-has_part","?:X","feathers"], ["isa","?:X","bird"]]],
[9, ["in", "frm_4", "axiom", 1], [["has_part","b1","feathers"]]],
[10, ["mp", [8,1], 9, "fromaxiom", 0.8], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["isa","b1","bird"]]],
[11, ["mp", [10,1], 4, "fromaxiom", 0.8], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["isa","b1","organism"]]],
[12, ["mp", [11,1], 6, "fromgoal", 0.8], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["$ans","b1"]]],
[13, ["cumul", 7, 12, "fromgoal", 0.84], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["$ans","b1"]]],
[14, ["in", "frm_9", "axiom", 0.6], [["$block",["$","bird"],["$not",["isa","?:X","bird"]]], ["-has_part","?:X","wing"], ["isa","?:X","bird"]]],
[15, ["in", "frm_3", "axiom", 1], [["has_part","b1","wing"]]],
[16, ["mp", [14,1], 15, "fromaxiom", 0.6], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["isa","b1","bird"]]],
[17, ["mp", [16,1], 4, "fromaxiom", 0.6], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["isa","b1","organism"]]],
[18, ["mp", [17,1], 6, "fromgoal", 0.6], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["$ans","b1"]]],
[19, ["cumul", 13, 18, "fromgoal", 0.936], [["$block",["$","bird"],["$not",["isa","b1","bird"]]], ["$ans","b1"]]]
]}
]}

*/
