[{"@name":"phone","@confidence":0.9,"@logic":["same_phone","fred","frederick"]},
{"@name":"id","@confidence":0.7,"@logic":[["same_phone","fred","frederick"],"=>",["=","fred","frederick"]]},
{"@name":"distinct","@confidence":0.8,"@logic":[["-=","fred","frederick"],["$block",1,["=","fred","frederick"]]]},
{"@name":"rich","@confidence":0.9,"@logic":["rich","fred"]},
{"@question":["rich","frederick"]}]
